# Player Debug V1 / V2 integration fix

## Player Debug V1
- Removed the hard-coded section-index floor of 6; snapshots now include all chunk sections, including sections below Y=32.
- Reworked snapshot storage/comparison to use the actual section-array length and treat absent sections as air.
- Kept the existing resend settle-time and cooldown logic.

## Player Debug V2
- Connected chunk-data packets to `BlockIntake` in the active Kren network-handler mixin.
- Registered `BlockCache` with Meteor's event bus.
- Connected block classification results to the Player Debug V2 alert/toast callback; removed reliance on the omitted empty `BlockAnomalyDebug` stub.
- Removed the player-Y < 0 queue-clearing condition from both light caches, which discarded underground packet data.
- Added a one-time scan seed for already-loaded chunks when V2 activates, plus ongoing intake for newly received chunk packets.
- Capped light/block queue draining per tick and deduplicated same-chunk V2 alerts from block and light classifiers.
- Reset block alerts/queue on activation and world changes.

## Validation
- ZIP contents and modified source structure checked.
- Gradle build was attempted but could not start because the environment could not resolve `services.gradle.org` to download Gradle 9.5.1. No successful compile or in-game test is claimed.
- Block detection still uses a heuristic (a fully homogeneous solid section); it can miss bases and may flag unusual natural terrain.
