package kren.debug.bridge;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/** Feeds light packets to the imported CoinDebug PacketIntake queues; the reflective lookup is done once per class. */
public final class CoinLightBridge {
   private static final Map<String, Method> OFFER = new ConcurrentHashMap<>();
   private static final Set<String> MISSING = ConcurrentHashMap.newKeySet();

   private CoinLightBridge() {
   }

   public static void offer(String intakeClassName, int chunkX, int chunkZ, Object lightData) {
      if (lightData == null || MISSING.contains(intakeClassName)) {
         return;
      }
      try {
         Method method = OFFER.get(intakeClassName);
         if (method == null) {
            Class<?> intake = Class.forName(intakeClassName);
            for (Method candidate : intake.getDeclaredMethods()) {
               Class<?>[] p = candidate.getParameterTypes();
               if (candidate.getName().equals("offer") && p.length == 3 && p[0] == int.class
                  && p[1] == int.class && p[2].isInstance(lightData)) {
                  method = candidate;
                  break;
               }
            }
            if (method == null) {
               MISSING.add(intakeClassName);
               System.err.println("[Kren Debug] No offer(int,int,LightData) in " + intakeClassName);
               return;
            }
            OFFER.put(intakeClassName, method);
         }
         method.invoke(null, chunkX, chunkZ, lightData);
      } catch (ReflectiveOperationException | LinkageError e) {
         MISSING.add(intakeClassName);
         System.err.println("[Kren Debug] Could not feed light data to " + intakeClassName + ": " + e);
      }
   }
}
