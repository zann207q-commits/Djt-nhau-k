package kren.debug.bridge;

import kren.debug.core.utils.RenderUtils;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.MinecraftClient;

/** Keeps Meteor's on/off state and the embedded module state in sync. */
public class KrenSync {
   private static final long NO_FRAME_WARN_NANOS = 3_000_000_000L;

   private long expectedSince;
   private boolean warned;

   @EventHandler
   private void onTick(TickEvent.Post event) {
      boolean renderExpected = false;
      for (Module m : Modules.get().getAll()) {
         if (m instanceof KrispyBridgeModule bridge) {
            bridge.sync();
            if (bridge.renderExpected()) {
               renderExpected = true;
            }
         }
      }
      this.watchRender(renderExpected);
   }

   /**
    * The world-render mixin uses require = 0, so if its target/locals do not match this Minecraft
    * build it is skipped silently and nothing is ever drawn. Warn once so that is not a mystery.
    */
   private void watchRender(boolean renderExpected) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (!renderExpected || this.warned || mc.world == null || mc.player == null) {
         this.expectedSince = 0L;
         return;
      }
      long now = System.nanoTime();
      if (this.expectedSince == 0L) {
         this.expectedSince = now;
         return;
      }
      long last = RenderUtils.lastWorldFrameNanos;
      if (last >= this.expectedSince) {
         // At least one frame arrived since the modules were enabled: the mixin works.
         this.warned = true;
         return;
      }
      if (now - this.expectedSince >= NO_FRAME_WARN_NANOS) {
         this.warned = true;
         System.err.println("[Kren Debug] No world render frames received: KrenGameRendererMixin did not apply on this build. ESP/plane rendering will not work.");
         mc.execute(() -> ChatUtils.warning("Kren Debug: render hook did not apply, nothing will be drawn (see latest.log).", new Object[0]));
      }
   }
}
