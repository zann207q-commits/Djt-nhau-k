package kren.debug.bridge;

import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Module;
import net.minecraft.client.MinecraftClient;

/** Meteor module that wraps one embedded Krispy module. */
public class KrispyBridgeModule extends Module {
   private final kren.debug.core.module.Module core;
   private boolean pending;

   public KrispyBridgeModule(Category category, kren.debug.core.module.Module core) {
      super(category, SettingMapper.kebab(core.getName().toString()), core.getDescription() == null ? "" : core.getDescription().toString());
      this.core = core;
      SettingGroup group = this.settings.getDefaultGroup();
      SettingMapper mapper = new SettingMapper(group);
      for (kren.debug.core.module.setting.Setting s : core.getSettings()) {
         try {
            mapper.map(s);
         } catch (Throwable t) {
            System.err.println("[Kren Debug] setting '" + s.getName() + "' of " + core.getName() + " not mapped: " + t);
         }
      }
   }

   private static boolean ready() {
      MinecraftClient mc = MinecraftClient.getInstance();
      return mc.player != null && mc.world != null;
   }

   private void enableCore() {
      try {
         this.core.toggle(true);
      } catch (Throwable t) {
         System.err.println("[Kren Debug] " + this.name + " failed to enable: " + t);
         t.printStackTrace(System.err);
         if (this.isActive()) {
            this.toggle();
         }
      }
   }

   @Override
   public void onActivate() {
      if (ready()) {
         this.pending = false;
         this.enableCore();
      } else {
         this.pending = true;
      }
   }

   @Override
   public void onDeactivate() {
      this.pending = false;
      try {
         this.core.toggle(false);
      } catch (Throwable t) {
         System.err.println("[Kren Debug] " + this.name + " failed to disable: " + t);
      }
   }

   /** True when this module is fully enabled and therefore should be receiving world render frames. */
   boolean renderExpected() {
      return this.isActive() && !this.pending && this.core.isEnabled();
   }

   void sync() {
      if (this.isActive()) {
         if (this.pending) {
            if (ready()) {
               this.pending = false;
               this.enableCore();
            }
         } else if (!this.core.isEnabled()) {
            this.toggle();
         }
      } else if (this.core.isEnabled()) {
         this.toggle();
      }
   }
}
