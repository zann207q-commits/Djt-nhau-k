package kren.debug.bridge;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Locale;
import java.util.Queue;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.orbit.EventHandler;

/**
 * Z Debug V4 ships a native library that exists only for Windows x64. On any other platform the
 * module is not registered, and this guard empties the light-packet queue that the (always
 * installed) Z4 mixin keeps filling, so it cannot grow without bound.
 */
public final class Z4Guard {
   private Queue<?> queue;
   private boolean resolved;

   public static boolean supported() {
      String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
      String arch = System.getProperty("os.arch", "").toLowerCase(Locale.ROOT);
      return os.contains("win") && (arch.equals("amd64") || arch.equals("x86_64"));
   }

   @EventHandler
   private void onTick(TickEvent.Post event) {
      if (!this.resolved) {
         this.resolved = true;
         try {
            Class<?> c = Class.forName("dev.zv3.light.PacketIntake");
            for (Field f : c.getDeclaredFields()) {
               if (Modifier.isStatic(f.getModifiers()) && Queue.class.isAssignableFrom(f.getType())) {
                  f.setAccessible(true);
                  this.queue = (Queue<?>) f.get(null);
                  break;
               }
            }
         } catch (Throwable ignored) {
         }
      }
      if (this.queue != null) {
         this.queue.clear();
      }
   }
}
