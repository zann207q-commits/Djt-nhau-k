package kren.debug.core.mixin;

import kren.debug.core.event.events.ChunkDataEvent;
import kren.debug.core.event.events.EntitySpawnEvent;
import kren.debug.core.event.events.LightUpdateEvent;
import kren.debug.core.event.events.TotemPopEvent;
import kren.debug.core.manager.EventManager;
import kren.debug.core.utils.ChunkLightTracker;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.network.packet.s2c.play.UnloadChunkS2CPacket;
import net.minecraft.network.packet.s2c.play.ChunkDataS2CPacket;
import net.minecraft.network.packet.s2c.play.LightUpdateS2CPacket;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ClientPlayNetworkHandler.class})
public abstract class ClientPlayNetworkHandlerMixin {
   @Inject(
      method = {"onEntityStatus"},
      at = {@At("TAIL")}
   )
   private void onEntityStatus(EntityStatusS2CPacket var1, CallbackInfo var2) {
      MinecraftClient var3 = MinecraftClient.getInstance();
      if (var3.world != null && var1.getStatus() == 35 && var1.getEntity(var3.world) == var3.player) {
         EventManager.b(new TotemPopEvent());
      }
   }

   @Inject(
      method = {"onChunkData"},
      at = {@At("TAIL")}
   )
   private void onChunkData(ChunkDataS2CPacket var1, CallbackInfo var2) {
      // Feed block-snapshot analysis after vanilla has applied the chunk packet.
      dev.bypass.block.BlockIntake.offer(var1.getChunkX(), var1.getChunkZ());
      ChunkLightTracker.ingest(var1.getChunkX(), var1.getChunkZ(), var1.getLightData());
      kren.debug.bridge.CoinLightBridge.offer("dev.bypass.light.PacketIntake", var1.getChunkX(), var1.getChunkZ(), var1.getLightData());
      kren.debug.bridge.CoinLightBridge.offer("x10n.flatslice.light.PacketIntake", var1.getChunkX(), var1.getChunkZ(), var1.getLightData());
      EventManager.b(new ChunkDataEvent(var1));
   }

   @Inject(
      method = {"onLightUpdate"},
      at = {@At("TAIL")}
   )
   private void onLightUpdate(LightUpdateS2CPacket var1, CallbackInfo var2) {
      ChunkLightTracker.ingest(var1.getChunkX(), var1.getChunkZ(), var1.getData());
      kren.debug.bridge.CoinLightBridge.offer("dev.bypass.light.PacketIntake", var1.getChunkX(), var1.getChunkZ(), var1.getData());
      kren.debug.bridge.CoinLightBridge.offer("x10n.flatslice.light.PacketIntake", var1.getChunkX(), var1.getChunkZ(), var1.getData());
      EventManager.b(new LightUpdateEvent(var1));
   }

   @Inject(
      method = {"onUnloadChunk"},
      at = {@At("TAIL")}
   )
   private void onUnloadChunk(UnloadChunkS2CPacket var1, CallbackInfo var2) {
      ChunkLightTracker.unload(var1.pos().x, var1.pos().z);
   }

   @Inject(
      method = {"onEntitySpawn"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onEntitySpawn(EntitySpawnS2CPacket var1, CallbackInfo var2) {
      EntitySpawnEvent var3 = new EntitySpawnEvent(var1);
      EventManager.b(var3);
      if (var3.isCancelled()) {
         var2.cancel();
      }
   }
}
