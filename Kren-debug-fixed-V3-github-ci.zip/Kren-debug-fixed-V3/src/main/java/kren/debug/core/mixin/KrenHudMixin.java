package kren.debug.core.mixin;

import kren.debug.core.event.events.Render2DEvent;
import kren.debug.core.manager.EventManager;
import kren.debug.core.utils.RenderUtils;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public abstract class KrenHudMixin {
   @Inject(method = "render", at = @At("TAIL"))
   private void kren$renderTail(DrawContext ctx, RenderTickCounter counter, CallbackInfo ci) {
      RenderUtils.setContext(ctx);
      EventManager.b(new Render2DEvent(ctx, counter.getTickProgress(true)));
   }

}
