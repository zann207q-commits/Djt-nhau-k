package kren.debug.core.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import kren.debug.core.event.events.Render3DEvent;
import kren.debug.core.manager.EventManager;
import kren.debug.core.utils.RenderUtils;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public abstract class KrenGameRendererMixin {
   @Inject(
      method = {"renderWorld"},
      at = {@At(
         value = "INVOKE_STRING",
         target = "Lnet/minecraft/util/profiler/Profiler;swap(Ljava/lang/String;)V",
         args = {"ldc=hand"}
      )},
      require = 0
   )
   private void kren$onWorldRender(RenderTickCounter counter, CallbackInfo ci, @Local(ordinal = 0) Matrix4f projection, @Local(ordinal = 1) Matrix4f modelView) {
      RenderUtils.updateScreenCenter(projection, modelView);
      EventManager.b(new Render3DEvent(new MatrixStack(), new Matrix4f(projection), counter.getTickProgress(true)));
   }
}
