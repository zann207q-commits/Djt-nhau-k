package kren.debug;

import java.lang.invoke.MethodHandles;
import java.util.List;
import java.util.function.Supplier;
import kren.debug.bridge.KrenSync;
import kren.debug.bridge.KrispyBridgeModule;
import kren.debug.bridge.Z4Guard;
import kren.debug.core.Krispy;
import kren.debug.core.feature.*;
import kren.debug.modules.OGChunkFinder;
import kren.debug.modules.SignalDebug;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;

public class KrenDebug extends MeteorAddon {
   public static final Category CATEGORY = new Category("Kren Debug");

   private static final List<Class<? extends kren.debug.core.module.Module>> EXPOSED = List.of(
      ChunkFinderModule.class,
      ChunkFinderBetterModule.class,
      KazeChunkFinderModule.class,
      SusChunkV2Module.class
   );

   @Override
   public void onInitialize() {
      MeteorClient.EVENT_BUS.registerLambdaFactory("kren.debug", (lookupInMethod, klass) -> (MethodHandles.Lookup) lookupInMethod.invoke(null, klass, MethodHandles.lookup()));
      // Merged Zinc modules live under com.vrzt.zinc and also use @EventHandler.
      MeteorClient.EVENT_BUS.registerLambdaFactory("com.vrzt.zinc", (lookupInMethod, klass) -> (MethodHandles.Lookup) lookupInMethod.invoke(null, klass, MethodHandles.lookup()));
      // Z Debug V4 is bundled as bytecode under dev.zv3. Orbit requires a
      // lambda factory for each package containing event-listener classes.
      // Register it before loading Bypass or LightCache, otherwise their
      // @EventHandler subscriptions throw NoLambdaFactoryException.
      MeteorClient.EVENT_BUS.registerLambdaFactory("dev.zv3", (lookupInMethod, klass) -> (MethodHandles.Lookup) lookupInMethod.invoke(null, klass, MethodHandles.lookup()));
      MeteorClient.EVENT_BUS.registerLambdaFactory("dev.bypass", (lookupInMethod, klass) -> (MethodHandles.Lookup) lookupInMethod.invoke(null, klass, MethodHandles.lookup()));
      MeteorClient.EVENT_BUS.registerLambdaFactory("x10n.flatslice", (lookupInMethod, klass) -> (MethodHandles.Lookup) lookupInMethod.invoke(null, klass, MethodHandles.lookup()));

      Krispy core = Krispy.boot();
      for (Class<? extends kren.debug.core.module.Module> type : EXPOSED) {
         kren.debug.core.module.Module m = core.getModuleManager().getModuleByClass(type);
         if (m == null) {
            System.err.println("[Kren Debug] module missing: " + type.getSimpleName());
            continue;
         }
         try {
            Modules.get().add(new KrispyBridgeModule(CATEGORY, m));
         } catch (Throwable t) {
            System.err.println("[Kren Debug] failed to register " + type.getSimpleName() + ": " + t);
         }
      }
      // Native Meteor modules merged from the fixed addon source.
      List<Supplier<Module>> nativeModules = List.of(
         OGChunkFinder::new,
         SignalDebug::new,
         com.vrzt.zinc.modules.esp.ChunkFinderV2::new
      );
      for (Supplier<Module> factory : nativeModules) {
         try {
            Modules.get().add(factory.get());
         } catch (Throwable t) {
            System.err.println("[Kren Debug] failed to register native module: " + t);
         }
      }
      // Imported CoinDebug modules. Block analysis is integrated into Player Debug V2
      // and uses the same alert pipeline rather than registering the old empty stub.
      try {
         x10n.flatslice.light.LightCache.register();
      } catch (Throwable t) {
         System.err.println("[Kren Debug] failed to register FlatSlice light cache: " + t);
      }
      try {
         dev.bypass.light.LightCache.register();
      } catch (Throwable t) {
         System.err.println("[Kren Debug] failed to register Bypass light cache: " + t);
      }
      try {
         dev.bypass.block.BlockCache.register();
      } catch (Throwable t) {
         System.err.println("[Kren Debug] failed to register Bypass block cache: " + t);
         t.printStackTrace();
      }
      for (Supplier<Module> factory : List.<Supplier<Module>>of(
            x10n.flatslice.modules.FlatSlice::new,
            x10n.flatslice.modules.SpawnerBypass::new,
            dev.bypass.modules.Bypass::new
      )) {
         try {
            Modules.get().add(factory.get());
         } catch (Throwable t) {
            System.err.println("[Kren Debug] failed to register imported CoinDebug module: " + t);
            t.printStackTrace();
         }
      }
      // Imported Z v4 module: register its original bytecode and its light-packet intake.
      // Its native library is Windows x64 only, so skip it elsewhere instead of crashing later.
      if (Z4Guard.supported()) {
         try {
            Class<?> z4Class = Class.forName("dev.zv3.modules.Bypass");
            Module z4Module = (Module) z4Class.getDeclaredConstructor().newInstance();
            Class<?> lightCache = Class.forName("dev.zv3.light.LightCache");
            lightCache.getMethod("register").invoke(null);
            // Add the module last so a failure above never leaves a half-working module in the list.
            Modules.get().add(z4Module);
            System.out.println("[Kren Debug] Registered Z Debug V4 module.");
         } catch (Throwable t) {
            System.err.println("[Kren Debug] failed to register Z Debug V4: " + t);
            t.printStackTrace();
            MeteorClient.EVENT_BUS.subscribe(new Z4Guard());
         }
      } else {
         System.err.println("[Kren Debug] Z Debug V4 needs Windows x64 (native library); module skipped on this platform.");
         MeteorClient.EVENT_BUS.subscribe(new Z4Guard());
      }
      MeteorClient.EVENT_BUS.subscribe(new KrenSync());
   }

   @Override
   public void onRegisterCategories() {
      Modules.registerCategory(CATEGORY);
   }

   @Override
   public String getPackage() {
      return "kren.debug";
   }
}
