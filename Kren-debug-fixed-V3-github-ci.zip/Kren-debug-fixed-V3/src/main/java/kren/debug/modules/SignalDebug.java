package kren.debug.modules;

import kren.debug.KrenDebug;
import java.awt.Color;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RepeaterBlock;
import net.minecraft.block.entity.BeehiveBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

/**
 * Client-thread-only signal/signature scanner. Results are accumulated per chunk rather than
 * replacing the previous result on every pass, which prevents markers from jumping randomly.
 */
public class SignalDebug extends Module {
    private final SettingGroup sgScan = settings.createGroup("Scan");
    private final SettingGroup sgDetect = settings.createGroup("Detection");

    private final Setting<Integer> scanRadius = sgScan.add(new IntSetting.Builder()
        .name("scan-radius").description("Chunk radius around you to scan (capped by your render distance).")
        .defaultValue(8).min(2).sliderMax(16).build());
    private final Setting<Integer> scanInterval = sgScan.add(new IntSetting.Builder()
        .name("scan-interval").description("Milliseconds between full scan passes.")
        .defaultValue(2500).min(250).sliderMax(10000).build());
    private final Setting<Integer> scanBudget = sgScan.add(new IntSetting.Builder()
        .name("scan-budget-ms").description("Max milliseconds of scanning per tick. Higher finishes passes faster but can cost FPS.")
        .defaultValue(2).min(1).sliderMax(10).build());
    private final Setting<Integer> maxMarkers = sgScan.add(new IntSetting.Builder()
        .name("max-markers").description("Max chunks highlighted at once (closest are kept).")
        .defaultValue(64).min(1).sliderMax(256).build());

    private final Setting<Boolean> requireArtificial = sgDetect.add(new BoolSetting.Builder()
        .name("require-player-made").description("Require at least one player-made signal (powered repeaters or cobbled deepslate). Turn off to also flag chunks from natural-looking signals alone (more hits, more false positives).")
        .defaultValue(true).build());
    private final Setting<Integer> minScore = sgDetect.add(new IntSetting.Builder()
        .name("min-score").description("Minimum total score to flag a chunk. Lower = more hits.")
        .defaultValue(3).min(1).sliderMax(15).build());
    private final Setting<Integer> minSignatures = sgDetect.add(new IntSetting.Builder()
        .name("min-signatures").description("Minimum number of different signatures in the same chunk.")
        .defaultValue(2).min(1).sliderMax(5).build());
    private final Setting<Integer> poweredRepeaters = sgDetect.add(new IntSetting.Builder()
        .name("powered-repeaters").description("Powered repeaters needed for that signature.")
        .defaultValue(3).min(1).sliderMax(20).build());
    private final Setting<Integer> anyRepeaters = sgDetect.add(new IntSetting.Builder()
        .name("repeaters").description("Repeaters (powered or not) needed for the weak repeater signature.")
        .defaultValue(3).min(1).sliderMax(20).build());
    private final Setting<Integer> cobbledMin = sgDetect.add(new IntSetting.Builder()
        .name("cobbled-deepslate").description("Cobbled deepslate blocks (Y -16..20) needed for that signature.")
        .defaultValue(50).min(1).sliderMax(300).build());
    private final Setting<Integer> vineMin = sgDetect.add(new IntSetting.Builder()
        .name("vines").description("Vine blocks needed for that signature.")
        .defaultValue(150).min(1).sliderMax(500).build());
    private final Setting<Integer> seagrassMin = sgDetect.add(new IntSetting.Builder()
        .name("seagrass").description("Seagrass blocks (Y<=70) needed for that signature.")
        .defaultValue(30).min(1).sliderMax(200).build());
    private final Setting<Boolean> countHives = sgDetect.add(new BoolSetting.Builder()
        .name("occupied-beehives").description("Count a beehive containing bees as a signature (natural bee nests also have bees).")
        .defaultValue(true).build());

    private final Map<Long, Detection> detections = new HashMap<>();
    private long lastScanTime;
    private long lastNotifyTime;
    private final ArrayDeque<Long> pending = new ArrayDeque<>();

    public SignalDebug() {
        super(KrenDebug.CATEGORY, "signal-debug", "Finds chunks with multiple unusual redstone/build signatures.");
    }

    @Override
    public void onActivate() {
        detections.clear();
        pending.clear();
        lastScanTime = 0L;
        lastNotifyTime = 0L;
    }

    @Override
    public void onDeactivate() {
        detections.clear();
        pending.clear();
        lastScanTime = 0L;
        lastNotifyTime = 0L;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.world == null || mc.player == null) {
            detections.clear();
            pending.clear();
            return;
        }

        long now = System.currentTimeMillis();
        int centerX = mc.player.getChunkPos().x;
        int centerZ = mc.player.getChunkPos().z;
        int viewDistance = mc.options.getViewDistance().getValue();
        int radius = Math.min(scanRadius.get(), Math.max(2, viewDistance));

        // Queue a new pass only when the previous one is finished, then work through it
        // with a small per-tick time budget so the client thread never stalls.
        if (pending.isEmpty()) {
            if (now - lastScanTime < scanInterval.get()) return;
            lastScanTime = now;
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    pending.add(ChunkPos.toLong(centerX + dx, centerZ + dz));
                }
            }
        }

        long deadline = System.nanoTime() + scanBudget.get() * 1_000_000L;
        while (!pending.isEmpty() && System.nanoTime() < deadline) {
            long key = pending.poll();
            WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(ChunkPos.getPackedX(key), ChunkPos.getPackedZ(key));
            if (chunk == null || chunk.isEmpty()) {
                detections.remove(key);
                continue;
            }
            Detection detection = inspectChunk(chunk);
            if (detection.score >= minScore.get() && detection.signatures >= minSignatures.get() && (!requireArtificial.get() || detection.artificial)) {
                Detection old = detections.put(key, detection);
                if (old == null && now - lastNotifyTime >= 3000L) {
                    lastNotifyTime = now;
                    mc.execute(() -> ChatUtils.info("Signal Debug: unusual chunk detected", new Object[0]));
                }
            } else {
                detections.remove(key);
            }
        }

        // Drop unloaded/out-of-range markers, but never clear every marker just because scan order changed.
        Iterator<Map.Entry<Long, Detection>> iterator = detections.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<Long, Detection> entry = iterator.next();
            int x = ChunkPos.getPackedX(entry.getKey());
            int z = ChunkPos.getPackedZ(entry.getKey());
            if (Math.max(Math.abs(x - centerX), Math.abs(z - centerZ)) > radius
                || mc.world.getChunkManager().getWorldChunk(x, z) == null) {
                iterator.remove();
            }
        }

        int markerCap = maxMarkers.get();
        if (detections.size() > markerCap) {
            // Keep the closest detections so the HUD/render work stays bounded.
            List<Map.Entry<Long, Detection>> entries = new ArrayList<>(detections.entrySet());
            entries.sort((a, b) -> Double.compare(distanceSquared(a.getKey(), centerX, centerZ), distanceSquared(b.getKey(), centerX, centerZ)));
            detections.clear();
            for (int i = 0; i < Math.min(markerCap, entries.size()); i++) {
                detections.put(entries.get(i).getKey(), entries.get(i).getValue());
            }
        }
    }

    private static double distanceSquared(long key, int centerX, int centerZ) {
        double dx = ChunkPos.getPackedX(key) - centerX;
        double dz = ChunkPos.getPackedZ(key) - centerZ;
        return dx * dx + dz * dz;
    }

    private Detection inspectChunk(WorldChunk chunk) {
        int activeRepeaters = 0;
        int repeaters = 0;
        int cobbled = 0;
        int vines = 0;
        int seagrass = 0;
        boolean occupiedHive = false;

        try {
            for (BlockEntity blockEntity : chunk.getBlockEntities().values()) {
                if (blockEntity instanceof BeehiveBlockEntity hive && hive.getBeeCount() > 0) {
                    occupiedHive = true;
                    break;
                }
            }
        } catch (Throwable ignored) {
            // Incomplete block-entity data is not sufficient evidence by itself.
        }

        int bottomY = chunk.getBottomY();
        ChunkSection[] sections = chunk.getSectionArray();
        for (int sectionIndex = 0; sectionIndex < sections.length; sectionIndex++) {
            ChunkSection section = sections[sectionIndex];
            if (section == null || section.isEmpty()) continue;
            int sectionY = bottomY + (sectionIndex << 4);
            boolean needsScan = section.hasAny(state -> state.isOf(Blocks.REPEATER)
                || state.isOf(Blocks.COBBLED_DEEPSLATE)
                || state.isOf(Blocks.VINE)
                || state.isOf(Blocks.SEAGRASS)
                || state.isOf(Blocks.TALL_SEAGRASS));
            if (!needsScan) continue;

            for (int y = 0; y < 16; y++) {
                int worldY = sectionY + y;
                for (int x = 0; x < 16; x++) {
                    for (int z = 0; z < 16; z++) {
                        BlockState state = section.getBlockState(x, y, z);
                        if (state.isOf(Blocks.REPEATER)) {
                            repeaters++;
                            if (Boolean.TRUE.equals(state.get(RepeaterBlock.POWERED))) activeRepeaters++;
                        } else if (state.isOf(Blocks.COBBLED_DEEPSLATE) && worldY >= -16 && worldY <= 20) {
                            cobbled++;
                        } else if (state.isOf(Blocks.VINE)) {
                            vines++;
                        } else if ((state.isOf(Blocks.SEAGRASS) || state.isOf(Blocks.TALL_SEAGRASS)) && worldY <= 70) {
                            seagrass++;
                        }
                    }
                }
            }
        }
        return buildDetection(activeRepeaters, repeaters, cobbled, vines, seagrass, occupiedHive);
    }

    private Detection buildDetection(int activeRepeaters, int repeaters, int cobbled, int vines, int seagrass, boolean hive) {
        int score = 0;
        int signatures = 0;
        List<String> reasons = new ArrayList<>();
        if (activeRepeaters >= poweredRepeaters.get()) { score += 5; signatures++; reasons.add("powered repeaters"); }
        else if (repeaters >= anyRepeaters.get()) { score += 1; signatures++; reasons.add("repeaters"); }
        if (cobbled >= cobbledMin.get()) { score += 3; signatures++; reasons.add("cobbled-deepslate cluster"); }
        if (vines >= vineMin.get()) { score += 2; signatures++; reasons.add("vine cluster"); }
        if (seagrass >= seagrassMin.get()) { score += 2; signatures++; reasons.add("seagrass cluster"); }
        if (hive && countHives.get()) { score += 2; signatures++; reasons.add("occupied beehive"); }
        // Vines, seagrass and bee nests all occur naturally; at least one player-made signal is required.
        boolean artificial = activeRepeaters >= poweredRepeaters.get() || cobbled >= cobbledMin.get();
        return new Detection(score, signatures, artificial, reasons.isEmpty() ? "multiple signatures" : String.join(", ", reasons));
    }

    @EventHandler
    private void onRender3D(Render3DEvent event) {
        if (mc.world == null || detections.isEmpty()) return;
        for (Map.Entry<Long, Detection> entry : detections.entrySet()) {
            int chunkX = ChunkPos.getPackedX(entry.getKey());
            int chunkZ = ChunkPos.getPackedZ(entry.getKey());
            if (mc.world.getChunkManager().getWorldChunk(chunkX, chunkZ) == null) continue;
            double x1 = (double) chunkX * 16.0;
            double z1 = (double) chunkZ * 16.0;
            double x2 = x1 + 16.0;
            double z2 = z1 + 16.0;
            double y1 = mc.world.getBottomY();
            double y2 = y1 + mc.world.getHeight();
            int alpha = Math.min(220, 80 + entry.getValue().score * 20);
            meteordevelopment.meteorclient.utils.render.color.Color side = color(alpha / 2);
            meteordevelopment.meteorclient.utils.render.color.Color line = color(alpha);
            event.renderer.box(x1, y1, z1, x2, y2, z2, side, line, ShapeMode.Both, 0);
        }
    }

    private meteordevelopment.meteorclient.utils.render.color.Color color(int alpha) {
        float hue = (float) (System.currentTimeMillis() % 3600L) / 3600.0f;
        int rgb = Color.HSBtoRGB(hue, 1.0f, 1.0f);
        return new meteordevelopment.meteorclient.utils.render.color.Color((rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF, alpha);
    }

    private static final class Detection {
        final int score;
        final int signatures;
        final boolean artificial;
        final String reason;
        Detection(int score, int signatures, boolean artificial, String reason) { this.score = score; this.signatures = signatures; this.artificial = artificial; this.reason = reason; }
    }
}
