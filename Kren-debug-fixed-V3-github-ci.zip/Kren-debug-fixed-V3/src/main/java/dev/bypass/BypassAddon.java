package dev.bypass;

import kren.debug.KrenDebug;
import meteordevelopment.meteorclient.systems.modules.Category;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Compatibility bridge for the imported Bypass module. */
public final class BypassAddon {
    public static final Category CATEGORY = KrenDebug.CATEGORY;
    public static final Logger LOG = LoggerFactory.getLogger("Player Debug V2");
    private BypassAddon() {}
}
