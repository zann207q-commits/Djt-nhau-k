package dev.bypass.block;

import dev.bypass.BypassAddon;
import dev.bypass.modules.Bypass;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1923;
import net.minecraft.class_310;
import net.minecraft.class_638;

public final class BlockCache {
   public static final BlockCache INSTANCE = new BlockCache();
   public static final Long2ObjectOpenHashMap<BlockChunkSnapshot> SNAPSHOTS = new Long2ObjectOpenHashMap();
   private static final LongOpenHashSet ALERTED = new LongOpenHashSet();
   private static final int MAX_DRAIN_PER_TICK = 64;
   private class_638 lastWorld = null;
   private static boolean registered;
   private boolean needsInitialScan = true;

   private BlockCache() {
   }

   public static synchronized void register() {
      if (registered) return;
      MeteorClient.EVENT_BUS.subscribe(INSTANCE);
      registered = true;
   }

   public static void resetAlerts() {
      ALERTED.clear();
      BlockIntake.QUEUE.clear();
      INSTANCE.needsInitialScan = true;
   }

   public static boolean isChunkAlerted(long chunkKey) {
      return ALERTED.contains(chunkKey);
   }

   @EventHandler
   private void onTickPre(Pre event) {
      class_310 mc = class_310.method_1551();
      class_638 world = mc.field_1687;
      if (world != this.lastWorld) {
         if (!SNAPSHOTS.isEmpty()) {
            SNAPSHOTS.clear();
         }

         if (!ALERTED.isEmpty()) {
            ALERTED.clear();
         }

         BlockIntake.QUEUE.clear();
         this.lastWorld = world;
         this.needsInitialScan = true;
      }

      if (world != null) {
         Bypass module = getBypass();
         if (module == null || !module.isActive() || mc.field_1724 == null) {
            BlockIntake.QUEUE.clear();
            return;
         }

         if (this.needsInitialScan) {
            int centerX = mc.field_1724.method_24515().method_10263() >> 4;
            int centerZ = mc.field_1724.method_24515().method_10260() >> 4;
            // Seed already-loaded chunks so enabling V2 does not require walking down or waiting for a resend.
            for (int dx = -8; dx <= 8; dx++) {
               for (int dz = -8; dz <= 8; dz++) {
                  int cx = centerX + dx;
                  int cz = centerZ + dz;
                  long key = class_1923.method_8331(cx, cz);
                  if (!SNAPSHOTS.containsKey(key) && world.getChunkManager().getWorldChunk(cx, cz) != null) {
                     BlockIntake.offer(cx, cz);
                  }
               }
            }
            this.needsInitialScan = false;
         }

         int sectionCount = world.method_32890();
         int bottomSectionY = world.method_32891();
         int drained = 0;
         BlockIntake.PendingChunk pending;
         while (drained < MAX_DRAIN_PER_TICK && (pending = BlockIntake.QUEUE.poll()) != null) {
            ingest(world, pending, sectionCount, bottomSectionY);
            drained++;
         }
      }
   }

   private static void ingest(class_638 world, BlockIntake.PendingChunk p, int sectionCount, int bottomSectionY) {
      long key = class_1923.method_8331(p.chunkX(), p.chunkZ());
      BlockChunkSnapshot snap = (BlockChunkSnapshot)SNAPSHOTS.get(key);
      if (snap == null || snap.sectionCount != sectionCount || snap.bottomSectionY != bottomSectionY) {
         snap = new BlockChunkSnapshot(p.chunkX(), p.chunkZ(), sectionCount, bottomSectionY);
         SNAPSHOTS.put(key, snap);
      }

      try {
         if (!BlockClassifier.apply(world, p.chunkX(), p.chunkZ(), snap, p.arrivalNanos())) {
            return;
         }
      } catch (Throwable var8) {
         BypassAddon.LOG.error("[Player Debug V2] BlockClassifier crashed on chunk " + p.chunkX() + "," + p.chunkZ(), var8);
         return;
      }

      maybeAlert(p.chunkX(), p.chunkZ(), key, snap);
   }

   private static Bypass getBypass() {
      try {
         return meteordevelopment.meteorclient.systems.modules.Modules.get().get(Bypass.class);
      } catch (Throwable ignored) {
         return null;
      }
   }

   private static void maybeAlert(int cx, int cz, long key, BlockChunkSnapshot snap) {
      if (ALERTED.contains(key)) return;
      Bypass module = getBypass();
      if (module == null || !module.isActive()) return;

      int minY = module.getBlockScanMinY();
      int maxY = module.getBlockScanMaxY();
      int needed = module.getBlockMinSections();
      int found = 0;
      for (int i = 0; i < snap.sectionCount; i++) {
         int sectionY = snap.bottomSectionY + i;
         int sectionBottomY = sectionY * 16;
         int sectionTopY = sectionBottomY + 15;
         if (sectionTopY < minY || sectionBottomY > maxY) continue;
         if (snap.status[i] == BlockSectionStatus.HOMOGENEOUS_SOLID) found++;
      }

      if (found >= needed) {
         ALERTED.add(key);
         module.onBlockChunkSpotted(cx, cz);
      }
   }
}
