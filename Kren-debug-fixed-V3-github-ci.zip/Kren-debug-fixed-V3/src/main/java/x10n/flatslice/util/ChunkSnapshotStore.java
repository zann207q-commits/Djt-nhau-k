package x10n.flatslice.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_2246;
import net.minecraft.class_2248;

/** Stores block-state snapshots for chunk resend comparison. */
public final class ChunkSnapshotStore {
   public static final ChunkSnapshotStore INSTANCE = new ChunkSnapshotStore();
   /** Retained for source compatibility; scanning now includes every section. */
   public static final int MIN_SECTION_INDEX = 0;
   public static final int MAX_SECTION_INDEX = 23;
   private final Map<Long, Map<Integer, int[]>> snapshots = new HashMap<>();
   private static final int AIR_STATE_ID = class_2248.method_9507(class_2246.field_10124.method_9564());

   public static long chunkKey(int x, int z) {
      return (long) x << 32 | (z & 0xffffffffL);
   }

   public void storeSnapshot(int x, int z, int[][] sections) {
      Map<Integer, int[]> copy = new HashMap<>();
      if (sections != null) {
         for (int i = 0; i < sections.length; i++) {
            int[] states = sections[i];
            if (states != null) copy.put(i, states.clone());
         }
      }
      snapshots.put(chunkKey(x, z), copy);
   }

   public Map<Integer, int[]> getSnapshot(int x, int z) {
      return snapshots.get(chunkKey(x, z));
   }

   public void removeSnapshot(int x, int z) { snapshots.remove(chunkKey(x, z)); }
   public void clearAllSnapshots() { snapshots.clear(); }
   public void pruneRetainKeys(Set<Long> keys) { snapshots.keySet().retainAll(keys); }
   public void replaceSnapshot(int x, int z, int[][] sections) { storeSnapshot(x, z, sections); }

   public List<BlockChange> compareSections(int x, int z, int[][] current) {
      List<BlockChange> changes = new ArrayList<>();
      Map<Integer, int[]> previous = getSnapshot(x, z);
      if (previous == null || current == null) return changes;

      int maxSections = current.length;
      for (Integer index : previous.keySet()) maxSections = Math.max(maxSections, index + 1);
      for (int sectionIndex = 0; sectionIndex < maxSections; sectionIndex++) {
         int[] before = previous.get(sectionIndex);
         int[] after = sectionIndex < current.length ? current[sectionIndex] : null;
         if (before == null && after == null) continue;

         for (int i = 0; i < 4096; i++) {
            int oldState = before == null ? AIR_STATE_ID : before[i];
            int newState = after == null ? AIR_STATE_ID : after[i];
            if (oldState != newState) changes.add(toBlockChange(x, z, sectionIndex, i, newState, oldState));
         }
      }
      return changes;
   }

   private static BlockChange toBlockChange(int chunkX, int chunkZ, int sectionIndex, int index, int newState, int oldState) {
      // extractSections iterates x, then y, then z, so z is the least-significant coordinate.
      int z = index & 15;
      int y = (index >> 4) & 15;
      int x = (index >> 8) & 15;
      int worldX = chunkX * 16 + x;
      int worldY = (sectionIndex - 4) * 16 + y; // section index 0 is Y=-64
      int worldZ = chunkZ * 16 + z;
      return new BlockChange(worldX, worldY, worldZ, newState, oldState);
   }

}
