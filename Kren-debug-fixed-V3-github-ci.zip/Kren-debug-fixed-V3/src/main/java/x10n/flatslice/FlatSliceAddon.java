package x10n.flatslice;

import kren.debug.KrenDebug;
import meteordevelopment.meteorclient.systems.modules.Category;

/** Compatibility category bridge for imported FlatSlice modules. */
public final class FlatSliceAddon {
    public static final Category CATEGORY = KrenDebug.CATEGORY;
    private FlatSliceAddon() {}
}
