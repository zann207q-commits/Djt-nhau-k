# Kren Debug by Saki

Meteor Client addon for Minecraft 1.21.11.

Modules (category "Kren Debug"):
Chunk Finder, Chunk Finder Better, Kaze Chunk Finder, Sus Chunk V2, OG Chunk Finder, Signal Debug,
Chunk Finder V2, Z Debug V4.

The module logic under `kren.debug.core` is derived from the Krispy client sources
(Krispy b1.3). Original authorship and any original license terms of that code remain
with its author(s); make sure you have the right to use and redistribute it.
