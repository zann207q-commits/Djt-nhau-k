#!/usr/bin/env python3
"""
Rewrite intermediary names (class_123 / method_123 / field_123) in .java sources to Yarn names.

The imported dev/bypass and x10n/flatslice sources were decompiled from an intermediary-named jar, but this
project compiles against Yarn (build.gradle), so they cannot compile as they are.

Usage:
  python tools/remap_intermediary.py <yarn-jar-or-tiny> <dir-or-file> [<dir-or-file> ...]

<yarn-jar-or-tiny> is either mappings.tiny or the yarn jar Gradle already downloaded, e.g.
  ~/.gradle/caches/modules-2/files-2.1/net.fabricmc/yarn/1.21.11+build.6/<hash>/yarn-1.21.11+build.6-v2.jar
Originals are kept next to each file as <name>.java.orig. Re-running on remapped files is harmless.
"""
import re
import shutil
import sys
import zipfile
from pathlib import Path


def read_tiny(path):
    if path.lower().endswith((".jar", ".zip")):
        with zipfile.ZipFile(path) as z:
            name = next(n for n in z.namelist() if n.endswith("mappings.tiny"))
            text = z.read(name).decode("utf-8")
    else:
        text = Path(path).read_text(encoding="utf-8")
    lines = text.split("\n")
    head = lines[0].split("\t")
    if head[0] != "tiny" or head[1] != "2":
        raise SystemExit("Expected a tiny v2 mappings file")
    ns = head[3:]
    src, dst = ns.index("intermediary"), ns.index("named")
    classes, methods, fields = {}, {}, {}
    conflicts = set()

    def put(table, key, val):
        if not val or val == key:
            return
        if key in table and table[key] != val:
            conflicts.add(key)
            return
        table[key] = val

    for ln in lines[1:]:
        if ln.startswith("c\t"):
            p = ln.split("\t")
            put(classes, p[1 + src], p[1 + dst])
        elif ln.startswith("\tm\t"):
            p = ln.strip("\t").split("\t")
            put(methods, p[2 + src], p[2 + dst])
        elif ln.startswith("\tf\t"):
            p = ln.strip("\t").split("\t")
            put(fields, p[2 + src], p[2 + dst])
    return classes, methods, fields, conflicts


QUAL = re.compile(r"\bnet\.minecraft\.(class_\d+(?:\.class_\d+)*)")
CLS = re.compile(r"\bclass_\d+\b")
MTH = re.compile(r"\bmethod_\d+\b")
FLD = re.compile(r"\bfield_\d+\b")


def remap_text(text, classes, methods, fields, missing):
    def qual(m):
        inter = "net/minecraft/" + m.group(1).replace(".", "$")
        named = classes.get(inter)
        if named is None:
            missing.add(inter)
            return m.group(0)
        return named.replace("/", ".").replace("$", ".")

    text = QUAL.sub(qual, text)

    # simple names: index by last intermediary segment
    simple_map = {}
    for inter, named in classes.items():
        key = inter.rsplit("$", 1)[-1].rsplit("/", 1)[-1]
        simple_map.setdefault(key, named.rsplit("$", 1)[-1].rsplit("/", 1)[-1])

    def bare_class(m):
        name = simple_map.get(m.group(0))
        if name is None:
            missing.add(m.group(0))
            return m.group(0)
        return name

    text = CLS.sub(bare_class, text)
    text = MTH.sub(lambda m: methods.get(m.group(0), m.group(0)), text)
    text = FLD.sub(lambda m: fields.get(m.group(0), m.group(0)), text)
    for tok in set(MTH.findall(text)) | set(FLD.findall(text)):
        missing.add(tok)
    return text


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        raise SystemExit(1)
    classes, methods, fields, conflicts = read_tiny(sys.argv[1])
    files = []
    for arg in sys.argv[2:]:
        p = Path(arg)
        files += [p] if p.is_file() else sorted(p.rglob("*.java"))
    total_missing = set()
    for f in files:
        src = f.read_text(encoding="utf-8")
        if not re.search(r"\b(class|method|field)_\d+\b", src):
            continue
        missing = set()
        out = remap_text(src, classes, methods, fields, missing)
        shutil.copyfile(f, f.with_suffix(".java.orig"))
        f.write_text(out, encoding="utf-8")
        total_missing |= missing
        print(f"remapped {f}" + (f"  (unresolved: {len(missing)})" if missing else ""))
    if conflicts:
        print(f"note: {len(conflicts)} ambiguous names were left as they were")
    if total_missing:
        print("UNRESOLVED:", " ".join(sorted(total_missing)))
        raise SystemExit(2)
    print("done - now run ./gradlew build")


if __name__ == "__main__":
    main()
