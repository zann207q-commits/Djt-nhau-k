# Fix pass

- Removed duplicate TickEvent (KrenPlayerTickMixin deleted) - finders no longer tick twice per game tick.
- Removed hidden modules and their now-unused helpers (Prime, Rtp, Tunnel, Sus Chunk, Player Bypass, Anti Vanish, Region Map, Auto Eat/Totem, Discord webhook code, orphan utils).
- ChunkFinderV2: scans full 16x16 (inclusive chunk bounds), world-height aware, overworld only, resets on world change, prunes unloaded chunks, logs worker exceptions, throttled entity check, thread-safe detection, trader/villager/illager toggles (traders off by default).
- SignalDebug: time-budgeted incremental scan (2 ms/tick), requires 2+ distinct signatures, accurate reason text.
- Z Debug V4: name restored to "z debug v4"; skipped on non Windows-x64 (native DLL) with queue guard.
- Risky mixins (GameRenderer/WorldRenderer/send) use require = 0 so a descriptor mismatch no longer aborts game launch.
- Removed orphan kren-misc.mixins.json and outdated Zinc doc.

# Fix pass 2

- ChunkFinderV2: chat message now posted on the client thread (was from worker threads); per-chunk 2 s cooldown + skip-if-already-detected for the rotated-deepslate rescan; new `min-kelp-length` setting (default 24, natural kelp maxes at 26).
- SignalDebug: a detection now needs at least one player-made signal (3+ powered repeaters or 50+ cobbled deepslate); vines/seagrass/bee nests alone no longer flag a chunk.
- Render watchdog: KrenSync warns once (chat + log) if modules are on but KrenGameRendererMixin never delivered a world frame.
- KrenHudMixin: Render2DEvent now fires at TAIL so overlays are not covered by the vanilla HUD.
- Z Debug V4: module is registered only after its light intake registered successfully; z-v3.mixins.json defaultRequire 0 so a target mismatch can't abort launch.
- fabric.mod.json description updated.

# Fix pass 3

- SignalDebug: all thresholds are now settings (groups "Scan" and "Detection"): scan-radius, scan-interval, scan-budget-ms, max-markers, require-player-made, min-score, min-signatures, powered-repeaters, repeaters, cobbled-deepslate, vines, seagrass, occupied-beehives. Defaults equal the previous behaviour.

# Fix pass 4

- Restored the 19 obfuscated class files in src/main/resources/o/ to their real names (they had become mojibake such as "µ£¿.class" after zip extraction on Windows, which makes Z Debug V4 fail with NoClassDefFoundError). Byte-identical to the earlier classes.
- New kren.debug.bridge.CoinLightBridge: the reflective lookup for dev.bypass / x10n.flatslice PacketIntake is done once and cached (it was re-scanning getDeclaredMethods on every chunk and light packet). ClientPlayNetworkHandlerMixin now calls it.
- tools/remap_intermediary.py: dev/bypass and x10n/flatslice are written with intermediary names (class_310, method_1551, ...) but the project builds against Yarn, so they do not compile until remapped. Run once:
    python tools/remap_intermediary.py <yarn-1.21.11+build.6-v2.jar> src/main/java/dev/bypass src/main/java/x10n
- bypass.mixins.json and flatslice.mixins.json are not listed in fabric.mod.json and the classes they name do not exist; they are unused.
