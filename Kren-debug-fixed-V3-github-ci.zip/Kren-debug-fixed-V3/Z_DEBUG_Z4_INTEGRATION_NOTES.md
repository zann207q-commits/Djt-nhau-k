# Kren Debug + Z Debug Z4 integration

## What changed
- Added the original Z v4 module bytecode and its support classes under `src/main/resources/`.
- Module visible name is `z debug v4`.
- Added a small `dev.zv3.BypassAddon` compatibility bridge so the imported bytecode uses Kren's existing `Kren Debug` category.
- Registered the Orbit lambda factory for `dev.zv3` before loading the module, then registered the module and its `LightCache` packet intake from `KrenDebug.onInitialize()`.
- Added the original `z-v3.mixins.json` configuration to the Kren addon metadata.
- Preserved the original x64 Windows native library because the original classifier/animation classes call JNI methods.

## Important limitations
- The build was **not verified** in this environment: Gradle could not download Gradle 9.5.1 because network access to `services.gradle.org` was unavailable.
- The imported module is kept as `.class` bytecode in resources rather than reconstructed Java source. The project relies on the Loom remap task handling those class entries correctly.
- The supplied `native0/x64-windows.dll` is third-party native code and has not been audited. The original module depends on it; do not run this build if you do not trust that DLL.
- This bundle includes the Windows x64 native library only. Other operating systems/architectures are not covered.
- Runtime compatibility still needs testing on the exact Minecraft 1.21.11 + Meteor version. Check `latest.log` if the module fails to register or a mixin fails to apply. The lambda-factory registration addresses the `NoLambdaFactoryException` shown in the supplied log, but cannot be described as runtime-verified unless the game is launched and tested.
