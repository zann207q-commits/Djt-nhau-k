package kren.debug;

import java.lang.invoke.MethodHandles;
import java.util.List;
import kren.debug.bridge.KrenSync;
import kren.debug.bridge.KrispyBridgeModule;
import kren.debug.core.Krispy;
import kren.debug.core.feature.*;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;

public class KrenDebug extends MeteorAddon {
   public static final Category CATEGORY = new Category("Kren Debug");

   private static final List<Class<? extends kren.debug.core.module.Module>> EXPOSED = List.of(
      ChunkFinderModule.class,
      ChunkFinderBetterModule.class,
      PrimeChunkFinderModule.class,
      RtpBaseFinderModule.class,
      TunnelBaseFinderModule.class,
      KazeChunkFinderModule.class,
      SusChunkFinderModule.class,
      SusChunkV2Module.class,
      PlayerBypassModule.class,
      AntiVanishModule.class,
      RegionMapModule.class
   );

   @Override
   public void onInitialize() {
      MeteorClient.EVENT_BUS.registerLambdaFactory("kren.debug", (lookupInMethod, klass) -> (MethodHandles.Lookup) lookupInMethod.invoke(null, klass, MethodHandles.lookup()));

      Krispy core = Krispy.boot();
      for (Class<? extends kren.debug.core.module.Module> type : EXPOSED) {
         kren.debug.core.module.Module m = core.getModuleManager().getModuleByClass(type);
         if (m == null) {
            System.err.println("[Kren Debug] module missing: " + type.getSimpleName());
            continue;
         }
         try {
            Modules.get().add(new KrispyBridgeModule(CATEGORY, m));
         } catch (Throwable t) {
            System.err.println("[Kren Debug] failed to register " + type.getSimpleName() + ": " + t);
         }
      }
      MeteorClient.EVENT_BUS.subscribe(new KrenSync());
   }

   @Override
   public void onRegisterCategories() {
      Modules.registerCategory(CATEGORY);
   }

   @Override
   public String getPackage() {
      return "kren.debug";
   }
}
