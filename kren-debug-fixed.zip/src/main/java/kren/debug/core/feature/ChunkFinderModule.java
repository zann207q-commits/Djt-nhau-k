package kren.debug.core.feature;

import java.awt.Color;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;
import kren.debug.core.Krispy;
import kren.debug.core.event.EventListener;
import kren.debug.core.event.events.ChunkDataEvent;
import kren.debug.core.event.events.LightUpdateEvent;
import kren.debug.core.event.events.Render3DEvent;
import kren.debug.core.event.events.SetBlockStateEvent;
import kren.debug.core.event.events.TickEvent;
import kren.debug.core.module.Category;
import kren.debug.core.module.Module;
import kren.debug.core.module.setting.BooleanSetting;
import kren.debug.core.module.setting.NumberSetting;
import kren.debug.core.utils.EncryptedString;
import kren.debug.core.utils.RenderUtils;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.network.packet.s2c.play.LightData;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap.Type;
import net.minecraft.world.chunk.WorldChunk;

/**
 * Chunk Finder (rewrite).
 *
 * Signal: a section whose SKY light array is explicitly sent as all-zero ("ZEROED_PRESENT")
 * below the configured Y. Only the sky track is used (block light and "uniform max" were the
 * main source of false hits in the old version).
 *
 * What changed compared to the old module:
 *  - sky + ZEROED_PRESENT only
 *  - a chunk is only flagged when its 3x3 neighbourhood holds enough hit sections (cluster),
 *    so a lone random section no longer creates a flag
 *  - optional storage confirmation: chests / barrels / shulkers below a Y limit add weight and
 *    turn the plate orange
 *  - plates are drawn at the depth of the detected sections (not on the surface) and a thin
 *    beam goes up to the surface so you can see where to dig down
 *  - hits are cleared again when a later packet says the section is no longer zeroed
 *  - light-update packets near your own digging are ignored
 *  - state is dropped for unloaded chunks
 */
public final class ChunkFinderModule extends Module {
   private static final int MAX_FLAGS = 512;
   private static final long DIG_IGNORE_MS = 6000L;
   private static final double DIG_RANGE_SQ = 64.0;
   private static final int STORAGE_BONUS = 2;
   private static final int RENDER_CHUNKS = 32;
   private static final int PRUNE_INTERVAL_TICKS = 100;
   private static final long DRAIN_BUDGET_NS = 3_000_000L;
   private static final int MAX_DRAIN_PER_TICK = 4096;
   private static final SoundEvent FLAG_SOUND = SoundEvent.of(Identifier.of("krispy", "chunk_flag"));

   private final NumberSetting plateSize;
   private final BooleanSetting outline;
   private final NumberSetting plateThickness;
   private final BooleanSetting advancementNotifications;
   private final BooleanSetting soundPing;
   private final NumberSetting soundVolume;
   private final BooleanSetting kickOnFlag;
   private final NumberSetting maxY;
   private final NumberSetting minHits;
   private final NumberSetting minCluster;
   private final NumberSetting storageMin;
   private final NumberSetting storageMaxY;
   private final BooleanSetting lightUpdates;
   private final BooleanSetting ignoreOwnDig;
   private final BooleanSetting beam;

   private final ConcurrentLinkedQueue<PendingLight> queue = new ConcurrentLinkedQueue<>();
   private final Map<Long, ChunkState> states = new HashMap<>();
   private final Map<Long, FlaggedChunk> flags = new LinkedHashMap<>();
   private final Set<Long> notified = new HashSet<>();
   private final Map<Long, Long> recentDigs = new HashMap<>();
   private final List<RenderUtils.ColoredBox> renderBoxes = new ArrayList<>();
   private final List<RenderUtils.ColoredLine> renderLines = new ArrayList<>();
   private ClientWorld trackedWorld;
   private int tickCounter;

   public ChunkFinderModule() {
      super(
         EncryptedString.of("Chunk Finder"),
         EncryptedString.of("detects bases underground [ Only works on DonutSMP]"),
         -1,
         Category.DONUT
      );
      plateSize = new NumberSetting(EncryptedString.of("Plate Size"), 1.0, 64.0, 16.0, 0.5);
      outline = new BooleanSetting(EncryptedString.of("Outline"), true);
      plateThickness = new NumberSetting(EncryptedString.of("Plate Thickness"), 0.01, 4.0, 0.15, 0.01);
      advancementNotifications = new BooleanSetting(EncryptedString.of("Advancement Notifications"), true)
         .setDescription(EncryptedString.of("Shows a Chunk Finder advancement popup for every new flagged chunk"));
      soundPing = new BooleanSetting(EncryptedString.of("Sound Ping"), true)
         .setDescription(EncryptedString.of("Plays the original Nexus chunk flag sound"));
      soundVolume = new NumberSetting(EncryptedString.of("Sound Volume"), 0.0, 100.0, 100.0, 1.0);
      kickOnFlag = new BooleanSetting(EncryptedString.of("Kick On Flag"), false)
         .setDescription(EncryptedString.of("Disconnects on the next flag, then turns this setting and Auto RTP off"));
      maxY = new NumberSetting(EncryptedString.of("Max Section Y"), -64.0, 320.0, 1.0, 1.0)
         .getValue(EncryptedString.of("Only sections whose bottom Y is below this count as a signal"));
      minHits = new NumberSetting(EncryptedString.of("Min Hit Sections"), 1.0, 24.0, 1.0, 1.0)
         .getValue(EncryptedString.of("Hit sections the chunk itself must have"));
      minCluster = new NumberSetting(EncryptedString.of("Min Cluster"), 1.0, 60.0, 3.0, 1.0)
         .getValue(EncryptedString.of("Hit sections needed in the 3x3 chunk area. 1 = loose, 3 = default, 5+ = strict"));
      storageMin = new NumberSetting(EncryptedString.of("Storage Confirm"), 0.0, 50.0, 3.0, 1.0)
         .getValue(EncryptedString.of("Chests/barrels/shulkers needed to mark a chunk as confirmed (0 = off)"));
      storageMaxY = new NumberSetting(EncryptedString.of("Storage Max Y"), -64.0, 320.0, 32.0, 1.0)
         .getValue(EncryptedString.of("Only storage at or below this Y counts for confirmation"));
      lightUpdates = new BooleanSetting(EncryptedString.of("Light Updates"), true)
         .setDescription(EncryptedString.of("Also use live light updates, not only the initial chunk packet"));
      ignoreOwnDig = new BooleanSetting(EncryptedString.of("Ignore Own Digging"), true)
         .setDescription(EncryptedString.of("Ignores light updates in chunks you are digging next to"));
      beam = new BooleanSetting(EncryptedString.of("Surface Beam"), true)
         .setDescription(EncryptedString.of("Draws a line from the plate up to the surface"));
      addSettings(
         plateSize, plateThickness, outline, advancementNotifications, soundPing, soundVolume, kickOnFlag,
         maxY, minHits, minCluster, storageMin, storageMaxY, lightUpdates, ignoreOwnDig, beam
      );
   }

   @Override
   public void onEnable() {
      reset();
      trackedWorld = mc.world;
      super.onEnable();
   }

   @Override
   public void onDisable() {
      reset();
      super.onDisable();
   }

   private void reset() {
      queue.clear();
      states.clear();
      flags.clear();
      notified.clear();
      recentDigs.clear();
      renderBoxes.clear();
      renderLines.clear();
      trackedWorld = null;
      tickCounter = 0;
   }

   private void ensureWorld() {
      if (trackedWorld != mc.world) {
         reset();
         trackedWorld = mc.world;
      }
   }

   // ------------------------------------------------------------------ packets

   @EventListener
   public void onChunkData(ChunkDataEvent event) {
      ensureWorld();
      if (mc.world != null && event.packet.getLightData() != null) {
         queue.offer(new PendingLight(event.packet.getChunkX(), event.packet.getChunkZ(), event.packet.getLightData(), false));
      }
   }

   @EventListener
   public void onLightUpdate(LightUpdateEvent event) {
      ensureWorld();
      if (mc.world != null && lightUpdates.getValue() && event.packet.getData() != null) {
         queue.offer(new PendingLight(event.packet.getChunkX(), event.packet.getChunkZ(), event.packet.getData(), true));
      }
   }

   @EventListener
   public void onTick(TickEvent event) {
      ensureWorld();
      if (mc.world == null || mc.player == null) {
         return;
      }
      tickCounter++;
      drain(mc.world.countVerticalSections(), mc.world.getBottomSectionCoord());
      if (tickCounter % PRUNE_INTERVAL_TICKS == 0) {
         prune();
      }
   }

   @EventListener
   public void onBlockChanged(SetBlockStateEvent event) {
      if (mc.player != null && event.pos != null
         && mc.player.squaredDistanceTo(Vec3d.ofCenter(event.pos)) <= DIG_RANGE_SQ) {
         recentDigs.put(ChunkPos.toLong(event.pos.getX() >> 4, event.pos.getZ() >> 4), System.currentTimeMillis());
      }
   }

   private boolean nearRecentDig(int chunkX, int chunkZ) {
      if (recentDigs.isEmpty()) {
         return false;
      }
      long now = System.currentTimeMillis();
      recentDigs.values().removeIf(timestamp -> now - timestamp > DIG_IGNORE_MS);
      for (long packedPos : recentDigs.keySet()) {
         if (Math.abs(ChunkPos.getPackedX(packedPos) - chunkX) <= 1
            && Math.abs(ChunkPos.getPackedZ(packedPos) - chunkZ) <= 1) {
            return true;
         }
      }
      return false;
   }

   // ------------------------------------------------------------------ ingest

   private void drain(int sectionCount, int bottomSection) {
      long deadline = System.nanoTime() + DRAIN_BUDGET_NS;
      for (int i = 0; i < MAX_DRAIN_PER_TICK; i++) {
         if (i > 0 && (i & 7) == 0 && System.nanoTime() >= deadline) {
            return;
         }
         PendingLight pending = queue.poll();
         if (pending == null) {
            return;
         }
         ingest(pending, sectionCount, bottomSection);
      }
   }

   private void ingest(PendingLight pending, int sectionCount, int bottomSection) {
      if (pending.fromUpdate() && ignoreOwnDig.getValue() && nearRecentDig(pending.chunkX(), pending.chunkZ())) {
         return;
      }
      long key = ChunkPos.toLong(pending.chunkX(), pending.chunkZ());
      ChunkState state = states.get(key);
      if (state == null || state.sectionCount != sectionCount || state.bottomSection != bottomSection) {
         state = new ChunkState(sectionCount, bottomSection);
         states.put(key, state);
      }
      state.lastTick = tickCounter;
      boolean changed;
      try {
         changed = applySky(pending.data(), state);
      } catch (Throwable ignored) {
         return;
      }
      if (!changed) {
         return;
      }
      for (int dx = -1; dx <= 1; dx++) {
         for (int dz = -1; dz <= 1; dz++) {
            evaluate(pending.chunkX() + dx, pending.chunkZ() + dz);
         }
      }
   }

   /** Updates the zeroed-section mask of the chunk from the sky light payload. Returns true if the mask changed. */
   private boolean applySky(LightData data, ChunkState state) {
      long before = state.zeroMask;
      BitSet inited = data.getInitedSky();
      BitSet uninited = data.getUninitedSky();
      List<byte[]> payloads = data.getSkyNibbles();
      int payloadIndex = 0;
      int length = state.sectionCount + 2;
      for (int i = 0; i < length; i++) {
         if (inited.get(i)) {
            byte[] payload = payloadIndex < payloads.size() ? payloads.get(payloadIndex) : null;
            payloadIndex++;
            boolean zeroed = LightPayloadClassifier.classifyPayload(payload) == SkyLightPattern.ZEROED_PRESENT;
            setSection(state, i, zeroed);
         } else if (uninited.get(i)) {
            setSection(state, i, false);
         }
      }
      return state.zeroMask != before;
   }

   private static void setSection(ChunkState state, int arrayIndex, boolean zeroed) {
      // index 0 and sectionCount + 1 are the padding sections below / above the world
      if (arrayIndex < 1 || arrayIndex > state.sectionCount) {
         return;
      }
      long bit = 1L << (arrayIndex - 1);
      if (zeroed) {
         state.zeroMask |= bit;
      } else {
         state.zeroMask &= ~bit;
      }
   }

   // ------------------------------------------------------------------ scoring

   private int hitsOf(ChunkState state, int maxYValue) {
      int hits = 0;
      long mask = state.zeroMask;
      while (mask != 0L) {
         int bit = Long.numberOfTrailingZeros(mask);
         mask &= mask - 1L;
         if ((state.bottomSection + bit) * 16 < maxYValue) {
            hits++;
         }
      }
      return hits;
   }

   private int averageDepth(ChunkState state, int maxYValue) {
      int hits = 0;
      long sum = 0L;
      long mask = state.zeroMask;
      while (mask != 0L) {
         int bit = Long.numberOfTrailingZeros(mask);
         mask &= mask - 1L;
         int sectionBottom = (state.bottomSection + bit) * 16;
         if (sectionBottom < maxYValue) {
            hits++;
            sum += sectionBottom + 8;
         }
      }
      return hits == 0 ? 0 : (int)(sum / hits);
   }

   private int countStorage(int chunkX, int chunkZ) {
      if (mc.world == null || !mc.world.isChunkLoaded(chunkX, chunkZ)) {
         return 0;
      }
      WorldChunk chunk = mc.world.getChunk(chunkX, chunkZ);
      if (chunk == null) {
         return 0;
      }
      int limit = storageMaxY.getIntValue();
      int count = 0;
      for (BlockPos pos : chunk.getBlockEntityPositions()) {
         if (pos.getY() > limit) {
            continue;
         }
         BlockEntity entity = mc.world.getBlockEntity(pos);
         if (entity instanceof ChestBlockEntity || entity instanceof BarrelBlockEntity
            || entity instanceof ShulkerBoxBlockEntity) {
            count++;
         }
      }
      return count;
   }

   private void evaluate(int chunkX, int chunkZ) {
      long key = ChunkPos.toLong(chunkX, chunkZ);
      ChunkState state = states.get(key);
      int maxYValue = maxY.getIntValue();
      int ownHits = state == null ? 0 : hitsOf(state, maxYValue);
      if (state == null || ownHits < Math.max(1, minHits.getIntValue())) {
         flags.remove(key);
         return;
      }
      int cluster = 0;
      for (int dx = -1; dx <= 1; dx++) {
         for (int dz = -1; dz <= 1; dz++) {
            ChunkState neighbour = states.get(ChunkPos.toLong(chunkX + dx, chunkZ + dz));
            if (neighbour != null) {
               cluster += hitsOf(neighbour, maxYValue);
            }
         }
      }
      int storageNeeded = storageMin.getIntValue();
      int storage = storageNeeded > 0 ? countStorage(chunkX, chunkZ) : 0;
      boolean confirmed = storageNeeded > 0 && storage >= storageNeeded;
      int score = cluster + (confirmed ? STORAGE_BONUS : 0);
      int required = minCluster.getIntValue();
      if (score < required) {
         flags.remove(key);
         return;
      }
      int level = confirmed ? 2 : (score >= required * 2 ? 1 : 0);
      int depthY = averageDepth(state, maxYValue);
      int blockX = (chunkX << 4) + 8;
      int blockZ = (chunkZ << 4) + 8;
      int surfaceY = mc.world != null && mc.world.isChunkLoaded(chunkX, chunkZ)
         ? mc.world.getTopY(Type.WORLD_SURFACE, blockX, blockZ)
         : depthY + 1;
      FlaggedChunk flag = new FlaggedChunk(new ChunkPos(chunkX, chunkZ), depthY, surfaceY, level, score, storage);
      boolean existed = flags.containsKey(key);
      flags.put(key, flag);
      if (existed) {
         return;
      }
      if (flags.size() > MAX_FLAGS) {
         flags.remove(flags.keySet().iterator().next());
      }
      if (notified.add(key)) {
         announce(flag);
      }
   }

   private void prune() {
      if (mc.world == null) {
         return;
      }
      Iterator<Map.Entry<Long, ChunkState>> iterator = states.entrySet().iterator();
      while (iterator.hasNext()) {
         Map.Entry<Long, ChunkState> entry = iterator.next();
         if (tickCounter - entry.getValue().lastTick < PRUNE_INTERVAL_TICKS) {
            continue;
         }
         long key = entry.getKey();
         if (!mc.world.isChunkLoaded(ChunkPos.getPackedX(key), ChunkPos.getPackedZ(key))) {
            iterator.remove();
            flags.remove(key);
         }
      }
      // re-check every flag so setting changes and unloaded neighbours are reflected
      for (long key : new ArrayList<>(flags.keySet())) {
         evaluate(ChunkPos.getPackedX(key), ChunkPos.getPackedZ(key));
      }
   }

   // ------------------------------------------------------------------ alerts

   private void announce(FlaggedChunk flag) {
      if (advancementNotifications.getValue()) {
         mc.getToastManager().add(new ChunkFinderToast(flag.x(), flag.z()));
      }
      if (soundPing.getValue()) {
         float volume = soundVolume.getIntValue() / 100.0F;
         mc.getSoundManager().play(PositionedSoundInstance.ui(FLAG_SOUND, 1.0F, volume));
      }
      if (kickOnFlag.getValue() && mc.getNetworkHandler() != null) {
         kickOnFlag.setValue(false);
         AutoRtpModule autoRtp = (AutoRtpModule)Krispy.INSTANCE.getModuleManager().getModuleByClass(AutoRtpModule.class);
         if (autoRtp != null) {
            autoRtp.toggle(false);
         }
         Krispy.INSTANCE.getSettingsManager().saveNow();
         mc.getNetworkHandler().getConnection().disconnect(Text.literal(
            "Kicked - Chunk Finder flagged X: " + flag.x() + " Z: " + flag.z() + " Y: ~" + flag.depthY()
               + "\nKick On Flag was automatically turned OFF."
         ));
      }
   }

   // ------------------------------------------------------------------ render

   private static Color colorFor(int level, int alpha) {
      switch (level) {
         case 2:
            return new Color(255, 90, 0, alpha);
         case 1:
            return new Color(255, 220, 0, alpha);
         default:
            return new Color(0, 255, 70, alpha);
      }
   }

   @EventListener
   public void onRender3D(Render3DEvent event) {
      if (flags.isEmpty() || mc.player == null) {
         return;
      }
      Camera camera = RenderUtils.getCamera();
      if (camera == null || !camera.isReady()) {
         return;
      }
      renderBoxes.clear();
      renderLines.clear();
      double halfSize = plateSize.getValue() / 2.0;
      double thickness = plateThickness.getValue();
      boolean drawBeam = beam.getValue();
      ChunkPos playerChunk = mc.player.getChunkPos();
      for (FlaggedChunk flag : flags.values()) {
         if (Math.abs(flag.chunk().x - playerChunk.x) > RENDER_CHUNKS
            || Math.abs(flag.chunk().z - playerChunk.z) > RENDER_CHUNKS) {
            continue;
         }
         Color fillColor = colorFor(flag.level(), 75);
         Color outlineColor = colorFor(flag.level(), 220);
         double centerX = flag.chunk().getCenterX();
         double centerZ = flag.chunk().getCenterZ();
         double plateY = flag.depthY();
         renderBoxes.add(new RenderUtils.ColoredBox(
            centerX - halfSize, plateY, centerZ - halfSize,
            centerX + halfSize, plateY + thickness, centerZ + halfSize, fillColor
         ));
         if (outline.getValue()) {
            RenderUtils.addBoxOutline(
               renderLines,
               centerX - halfSize, plateY, centerZ - halfSize,
               centerX + halfSize, plateY + thickness, centerZ + halfSize, outlineColor, 1.5F
            );
         }
         if (drawBeam && flag.surfaceY() > flag.depthY() + 1) {
            renderLines.add(new RenderUtils.ColoredLine(
               new Vec3d(centerX, plateY + thickness, centerZ),
               new Vec3d(centerX, flag.surfaceY() + 2.0, centerZ),
               outlineColor, 1.5F
            ));
         }
      }
      if (!renderBoxes.isEmpty()) {
         MatrixStack matrices = event.matrixStack;
         matrices.push();
         RenderUtils.applyCameraTransform(matrices, camera);
         RenderUtils.renderFilledBoxes(matrices, renderBoxes);
         if (!renderLines.isEmpty()) {
            RenderUtils.renderLines(matrices, renderLines);
         }
         matrices.pop();
      }
   }

   // ------------------------------------------------------------------ data

   private static final class ChunkState {
      final int sectionCount;
      final int bottomSection;
      long zeroMask;
      int lastTick;

      ChunkState(int sectionCount, int bottomSection) {
         this.sectionCount = sectionCount;
         this.bottomSection = bottomSection;
      }
   }

   private record PendingLight(int chunkX, int chunkZ, LightData data, boolean fromUpdate) {
   }

   /** level: 0 = cluster hit, 1 = strong cluster, 2 = storage confirmed. */
   private record FlaggedChunk(ChunkPos chunk, int depthY, int surfaceY, int level, int score, int storage) {
      int x() {
         return (chunk.x << 4) + 8;
      }

      int z() {
         return (chunk.z << 4) + 8;
      }
   }
}
