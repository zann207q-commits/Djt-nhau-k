package kren.debug.bridge;

import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.orbit.EventHandler;

/** Keeps Meteor's on/off state and the embedded module state in sync. */
public class KrenSync {
   @EventHandler
   private void onTick(TickEvent.Post event) {
      for (Module m : Modules.get().getAll()) {
         if (m instanceof KrispyBridgeModule bridge) {
            bridge.sync();
         }
      }
   }
}
