package kren.debug.bridge;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.function.Consumer;
import kren.debug.core.module.setting.BooleanSetting;
import kren.debug.core.module.setting.ButtonSetting;
import kren.debug.core.module.setting.ChoiceSetting;
import kren.debug.core.module.setting.ModeSetting;
import kren.debug.core.module.setting.NumberSetting;
import kren.debug.core.module.setting.RgbSetting;
import kren.debug.core.module.setting.SettingVisibility;
import kren.debug.core.module.setting.StringSetting;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;

/** Turns embedded Krispy settings into Meteor settings and pushes changes back. */
final class SettingMapper {
   private final SettingGroup group;
   private final Set<String> used = new HashSet<>();

   SettingMapper(SettingGroup group) {
      this.group = group;
   }

   static String kebab(String s) {
      String k = s.trim().toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "-").replaceAll("^-+|-+$", "");
      return k.isEmpty() ? "setting" : k;
   }

   private String unique(String base) {
      String n = base;
      int i = 2;
      while (!this.used.add(n)) {
         n = base + "-" + i++;
      }
      return n;
   }

   @SuppressWarnings({"unchecked", "rawtypes"})
   void map(kren.debug.core.module.setting.Setting s) {
      String name = this.unique(kebab(s.getName().toString()));
      String desc = s.getDescription() == null ? "" : s.getDescription().toString();

      if (s instanceof BooleanSetting b) {
         this.group.add(new BoolSetting.Builder()
            .name(name).description(desc)
            .defaultValue(b.getValue())
            .onChanged(b::setValue)
            .visible(() -> SettingVisibility.visible(s))
            .build());
      } else if (s instanceof NumberSetting n) {
         if (n.getFormat() >= 1.0) {
            int min = (int) Math.round(n.getMin());
            int max = (int) Math.round(n.getMax());
            this.group.add(new IntSetting.Builder()
               .name(name).description(desc)
               .defaultValue((int) Math.round(n.getValue()))
               .min(min).max(max).sliderMin(min).sliderMax(max)
               .onChanged(v -> n.getValue(v.doubleValue()))
               .visible(() -> SettingVisibility.visible(s))
               .build());
         } else {
            int places = (int) Math.max(0, Math.min(6, Math.ceil(-Math.log10(Math.max(n.getFormat(), 1.0E-6)))));
            this.group.add(new DoubleSetting.Builder()
               .name(name).description(desc)
               .defaultValue(n.getValue())
               .min(n.getMin()).max(n.getMax()).sliderMin(n.getMin()).sliderMax(n.getMax())
               .decimalPlaces(places)
               .onChanged(v -> n.getValue(v.doubleValue()))
               .visible(() -> SettingVisibility.visible(s))
               .build());
         }
      } else if (s instanceof ModeSetting ms) {
         EnumSetting.Builder eb = new EnumSetting.Builder();
         eb.name(name);
         eb.description(desc);
         eb.defaultValue((Enum) ms.getValue());
         eb.onChanged((Consumer<Object>) v -> ms.setMode((Enum) v));
         eb.visible(() -> SettingVisibility.visible(s));
         this.group.add(eb.build());
      } else if (s instanceof ChoiceSetting c) {
         this.group.add(new meteordevelopment.meteorclient.settings.StringSetting.Builder()
            .name(name)
            .description(desc + " Options: " + String.join(", ", c.getModes()))
            .defaultValue(c.getMode())
            .onChanged(v -> c.setMode(v))
            .visible(() -> SettingVisibility.visible(s))
            .build());
      } else if (s instanceof StringSetting str) {
         this.group.add(new meteordevelopment.meteorclient.settings.StringSetting.Builder()
            .name(name).description(desc)
            .defaultValue(str.getValue() == null ? "" : str.getValue())
            .onChanged(str::setValue)
            .visible(() -> SettingVisibility.visible(s))
            .build());
      } else if (s instanceof RgbSetting r) {
         int argb = r.getArgb();
         this.group.add(new ColorSetting.Builder()
            .name(name).description(desc)
            .defaultValue(new SettingColor((argb >> 16) & 255, (argb >> 8) & 255, argb & 255, (argb >>> 24) & 255))
            .onChanged(c -> r.setArgb((c.a & 255) << 24 | (c.r & 255) << 16 | (c.g & 255) << 8 | (c.b & 255)))
            .visible(() -> SettingVisibility.visible(s))
            .build());
      } else if (s instanceof ButtonSetting btn) {
         BoolSetting[] holder = new BoolSetting[1];
         holder[0] = this.group.add(new BoolSetting.Builder()
            .name(name).description(desc + " (toggle on to run)")
            .defaultValue(false)
            .onChanged(v -> {
               if (v) {
                  btn.run();
                  if (holder[0] != null) {
                     holder[0].set(false);
                  }
               }
            })
            .build());
      } else {
         System.err.println("[Kren Debug] unsupported setting type: " + s.getClass().getSimpleName());
      }
   }
}
