package kren.debug.core.event;

import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Method;
import kren.debug.core.module.Module;

public class Listener {
   private static final MethodType INVOKER_TYPE = MethodType.methodType(void.class, Object.class, Event.class);
   private final Object instance;
   private final Module module;
   private final Priority priority;
   private final Listener.Invoker invoker;

   public Listener(Object var1, Method var2, Priority var3) {
      this.instance = var1;
      this.module = var1 instanceof Module var4 ? var4 : null;
      this.priority = var3;
      this.invoker = createInvoker(var2);
   }

   public void invoke(Event var1) throws Throwable {
      this.invoker.invoke(this.instance, var1);
   }

   public boolean isActive() {
      return this.module == null || this.module.isEnabled();
   }

   public Object getInstance() {
      return this.instance;
   }

   public Priority getPriority() {
      return this.priority;
   }

   private static Listener.Invoker createInvoker(Method var0) {
      try {
         Class var7 = var0.getDeclaringClass();
         Lookup var2 = MethodHandles.privateLookupIn(var7, MethodHandles.lookup());
         MethodHandle var3 = var2.unreflect(var0);
         CallSite var4 = LambdaMetafactory.metafactory(
            var2,
            "invoke",
            MethodType.methodType(Listener.Invoker.class),
            INVOKER_TYPE,
            var3,
            MethodType.methodType(void.class, var7, var0.getParameterTypes()[0])
         );
         return (Listener.Invoker)var4.getTarget().invoke();
      } catch (Throwable var6) {
         try {
            MethodHandle var1 = MethodHandles.privateLookupIn(var0.getDeclaringClass(), MethodHandles.lookup()).unreflect(var0).asType(INVOKER_TYPE);
            return (var1x, var2x) -> var1.invokeExact((Object)var1x, (Event)var2x);
         } catch (Throwable var5) {
            var0.setAccessible(true);
            return (var1x, var2x) -> var0.invoke(var1x, var2x);
         }
      }
   }

   @FunctionalInterface
   public interface Invoker {
      void invoke(Object var1, Event var2) throws Throwable;
   }
}
