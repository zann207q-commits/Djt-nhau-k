package kren.debug.core.event.events;

import kren.debug.core.event.CancellableEvent;

public class TickEvent extends CancellableEvent {
}
