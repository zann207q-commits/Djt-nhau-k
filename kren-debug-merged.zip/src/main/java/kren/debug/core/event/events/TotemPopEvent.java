package kren.debug.core.event.events;

import kren.debug.core.event.Event;

public final class TotemPopEvent implements Event {
}
