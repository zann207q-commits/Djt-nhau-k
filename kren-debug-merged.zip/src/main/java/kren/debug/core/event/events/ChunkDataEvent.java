package kren.debug.core.event.events;

import kren.debug.core.event.CancellableEvent;
import net.minecraft.network.packet.s2c.play.ChunkDataS2CPacket;

public class ChunkDataEvent extends CancellableEvent {
   public ChunkDataS2CPacket packet;

   public ChunkDataEvent(ChunkDataS2CPacket packet) {
      this.packet = packet;
   }
}
