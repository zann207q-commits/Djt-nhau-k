package kren.debug.core.event;

public interface Event {
   default boolean isCancelled() {
      return false;
   }
}
