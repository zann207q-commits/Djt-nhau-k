package kren.debug.core.feature;

import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public final class AntiVanishHudOverlay {
   private AntiVanishHudOverlay() {
   }

   public static void render(DrawContext ctx) {
      try {
         PlayerWatchHud.render(ctx);
         drawVanish(ctx);
      } catch (Throwable t) {
         System.err.println("[Kren Debug] HUD element failed: " + t);
      }
   }

   private static void drawVanish(DrawContext ctx) {
      List<AntiVanishModule.VanishHudEntry> entries = AntiVanishModule.hudEntries();
      if (entries.isEmpty()) {
         return;
      }
      MinecraftClient mc = MinecraftClient.getInstance();
      TextRenderer tr = mc.textRenderer;
      int rowH = 12;
      int gap = 8;
      int tagW = 0;
      int valW = 0;
      for (AntiVanishModule.VanishHudEntry e : entries) {
         tagW = Math.max(tagW, tr.getWidth(AntiVanishModule.hudTag(e)));
         valW = Math.max(valW, tr.getWidth(AntiVanishModule.hudValue(e)));
      }
      int x = 6;
      int y = mc.getWindow().getScaledHeight() / 3;
      int w = tagW + gap + valW + 10;
      ctx.fill(x - 3, y - 3, x + w, y + entries.size() * rowH + 1, 0x90000000);
      ctx.fill(x - 3, y - 3, x - 1, y + entries.size() * rowH + 1, 0xFF55FFFF);
      for (int i = 0; i < entries.size(); i++) {
         AntiVanishModule.VanishHudEntry e = entries.get(i);
         String tag = AntiVanishModule.hudTag(e);
         boolean warn = "ALERT".equals(tag) || "VANISH".equals(tag);
         int yy = y + i * rowH;
         ctx.drawText(tr, tag, x + 2, yy, warn ? 0xFFFFAA00 : 0x99FFFFFF, true);
         ctx.drawText(tr, AntiVanishModule.hudValue(e), x + 2 + tagW + gap, yy, 0xFFFFFFFF, true);
      }
   }
}
