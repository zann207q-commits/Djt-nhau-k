package kren.debug.core.feature;

import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.sound.SoundEvent;
import net.minecraft.client.toast.Toast;
import net.minecraft.client.toast.ToastManager;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.client.toast.Toast.Visibility;

public final class ChunkFlagToast implements Toast {
   private static final Identifier TEXTURE = Identifier.ofVanilla("toast/advancement");
   private static final Identifier GLOW = Identifier.of("krispy", "textures/gui/chest-glow.png");
   private static final Object TYPE_KEY = new Object();
   private static final SoundEvent SOUND = SoundEvent.of(Identifier.of("krispy", "chunk_flag"));
   private static final ItemStack ICON = createIcon();
   private Text coordinates;
   private Visibility visibility = Visibility.SHOW;
   private boolean playSound;
   private boolean resetPending = true;
   private long resetAt;

   public ChunkFlagToast(int var1, int var2, boolean var3) {
      this.refresh(var1, var2, var3);
   }

   private static ItemStack createIcon() {
      ItemStack var0 = new ItemStack(Items.CHEST);
      var0.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
      return var0;
   }

   public static void show(int var0, int var1, boolean var2) {
      ToastManager var3 = MinecraftClient.getInstance().getToastManager();
      ChunkFlagToast var4 = (ChunkFlagToast)var3.getToast(ChunkFlagToast.class, TYPE_KEY);
      if (var4 == null) {
         var3.add(new ChunkFlagToast(var0, var1, var2));
      } else {
         var4.refresh(var0, var1, var2);
      }
   }

   private void refresh(int var1, int var2, boolean var3) {
      this.coordinates = Text.literal("X: " + var1 + " Z: " + var2);
      this.playSound = var3;
      this.resetPending = true;
      this.visibility = Visibility.SHOW;
   }

   public Object getType() {
      return TYPE_KEY;
   }

   public Visibility getVisibility() {
      return this.visibility;
   }

   public SoundEvent getSoundEvent() {
      return this.playSound ? SOUND : null;
   }

   public void update(ToastManager var1, long var2) {
      if (this.resetPending) {
         this.resetAt = var2;
         this.resetPending = false;
      }

      this.visibility = (double)(var2 - this.resetAt) >= 5000.0 * var1.getNotificationDisplayTimeMultiplier() ? Visibility.HIDE : Visibility.SHOW;
   }

   public void draw(DrawContext var1, TextRenderer var2, long var3) {
      var1.drawGuiTexture(RenderPipelines.GUI_TEXTURED, TEXTURE, 0, 0, this.getWidth(), this.getHeight());
      float var5 = 0.76F + 0.08F * (float)Math.sin((double)var3 / 850.0);
      int var6 = Math.round(var5 * 255.0F) << 24 | 16777215;
      var1.drawTexture(RenderPipelines.GUI_TEXTURED, GLOW, 0, 0, 0.0F, 0.0F, 32, 32, 64, 64, 64, 64, var6);
      var1.drawText(var2, Text.literal("Chunk Finder Better"), 30, 7, -43521, false);
      var1.drawText(var2, this.coordinates, 30, 18, -1, false);
      var1.drawItemWithoutEntity(ICON, 8, 8);
   }
}
