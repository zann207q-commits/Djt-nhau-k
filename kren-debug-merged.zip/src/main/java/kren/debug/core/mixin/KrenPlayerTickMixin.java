package kren.debug.core.mixin;

import kren.debug.core.event.events.TickEvent;
import kren.debug.core.manager.EventManager;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public abstract class KrenPlayerTickMixin {
   @Inject(method = "tick", at = @At("HEAD"))
   private void kren$playerTick(CallbackInfo ci) {
      EventManager.b(new TickEvent());
   }
}
