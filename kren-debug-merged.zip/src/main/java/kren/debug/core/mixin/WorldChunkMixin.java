package kren.debug.core.mixin;

import kren.debug.core.event.events.SetBlockStateEvent;
import kren.debug.core.manager.EventManager;
import net.minecraft.world.World;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.BlockState;
import net.minecraft.world.chunk.WorldChunk;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({WorldChunk.class})
public class WorldChunkMixin {
   @Shadow
   @Final
   World world;

   @Inject(
      method = {"setBlockState"},
      at = {@At("TAIL")}
   )
   private void onSetBlockState(BlockPos var1, BlockState var2, int var3, CallbackInfoReturnable<BlockState> var4) {
      if (this.world.isClient() && EventManager.hasActiveListener(SetBlockStateEvent.class)) {
         EventManager.b(new SetBlockStateEvent(var1, (BlockState)var4.getReturnValue(), var2));
      }
   }
}
