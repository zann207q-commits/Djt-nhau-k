package kren.debug.core.mixin;

import kren.debug.core.event.events.SetScreenEvent;
import kren.debug.core.event.events.TickEvent;
import kren.debug.core.manager.EventManager;
import kren.debug.core.module.ext.ExtBridge;
import kren.debug.core.module.ext.Stage;
import kren.debug.core.utils.FlagAlarm;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.world.ClientWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftClient.class)
public abstract class KrenClientMixin {
   @Shadow
   public ClientWorld world;

   @Inject(method = "tick", at = @At("HEAD"))
   private void kren$tickHead(CallbackInfo ci) {
      FlagAlarm.tick((MinecraftClient) (Object) this);
      ExtBridge.tick(Stage.PRE);
      if (this.world != null) {
         EventManager.b(new TickEvent());
      }
   }

   @Inject(method = "tick", at = @At("RETURN"))
   private void kren$tickReturn(CallbackInfo ci) {
      ExtBridge.tick(Stage.POST);
   }

   @Inject(method = "setScreen", at = @At("HEAD"), cancellable = true)
   private void kren$setScreen(Screen screen, CallbackInfo ci) {
      SetScreenEvent event = new SetScreenEvent(screen);
      EventManager.b(event);
      if (event.isCancelled()) {
         ci.cancel();
      }
   }
}
