package kren.debug.core.mixin;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Draws "Kren Debug by Saki" at the top of the Minecraft main menu. */
@Mixin(TitleScreen.class)
public abstract class KrenTitleScreenMixin extends Screen {
   protected KrenTitleScreenMixin(Text title) {
      super(title);
   }

   @Inject(method = "render", at = @At("TAIL"))
   private void kren$banner(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
      Text banner = Text.empty()
         .append(Text.literal("Kren Debug").formatted(Formatting.AQUA, Formatting.BOLD))
         .append(Text.literal(" by Saki").formatted(Formatting.GRAY));
      float scale = 2.0F;
      int textW = this.textRenderer.getWidth(banner);
      var matrices = context.getMatrices();
      matrices.pushMatrix();
      matrices.scale(scale, scale);
      context.drawText(this.textRenderer, banner, (int) ((this.width / scale - textW) / 2.0F), 4, 0xFFFFFFFF, true);
      matrices.popMatrix();
   }
}
