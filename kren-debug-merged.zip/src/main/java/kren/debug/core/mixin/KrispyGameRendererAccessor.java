package kren.debug.core.mixin;

import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.fog.FogRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({GameRenderer.class})
public interface KrispyGameRendererAccessor {
   @Invoker("getFov")
   float krispy$getFov(Camera var1, float var2, boolean var3);

   @Accessor("fogRenderer")
   FogRenderer krispy$getFogRenderer();

   @Invoker("shouldRenderBlockOutline")
   boolean krispy$shouldRenderBlockOutline();
}
