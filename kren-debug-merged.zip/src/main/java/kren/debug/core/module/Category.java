package kren.debug.core.module;

import kren.debug.core.utils.EncryptedString;

public enum Category {
   COMBAT(EncryptedString.of("Combat")),
   MISC(EncryptedString.of("Misc")),
   MACROS(EncryptedString.of("Macros")),
   DONUT(EncryptedString.of("Donut")),
   RENDER(EncryptedString.of("Render")),
   CLIENT(EncryptedString.of("Client"));

   public final CharSequence name;

   private Category(final CharSequence nullxx) {
      this.name = nullxx;
   }
}
