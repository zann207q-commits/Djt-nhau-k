package kren.debug.core.module.ext;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;
import kren.debug.core.module.ext.event.BlockUpdateEvent;
import kren.debug.core.module.ext.event.PacketReceiveNettyEvent;
import kren.debug.core.module.ext.event.PacketSendEvent;
import kren.debug.core.module.ext.event.Render3DEvent;
import kren.debug.core.module.ext.event.TickEvent;
import kren.debug.core.module.ext.setting.Setting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.network.packet.Packet;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.Frustum;

public final class ExtBridge {
   private static final List<ClientModule> MODULES = new CopyOnWriteArrayList<>();
   private static final Map<Class<?>, List<ExtBridge.Handler>> HANDLERS = new ConcurrentHashMap<>();
   private static final ConcurrentLinkedQueue<Runnable> LATER = new ConcurrentLinkedQueue<>();
   private static final TickEvent TICK = new TickEvent();

   private ExtBridge() {
   }

   static void track(ClientModule var0) {
      MODULES.add(var0);

      for (Class var1 = var0.getClass(); var1 != null && var1 != ClientModule.class; var1 = var1.getSuperclass()) {
         for (Method var5 : var1.getDeclaredMethods()) {
            EventHandler var6 = var5.getAnnotation(EventHandler.class);
            if (var6 != null && var5.getParameterCount() == 1) {
               var5.setAccessible(true);
               Class var7 = var5.getParameterTypes()[0];
               add(var7, new ExtBridge.Handler(var0, var6.stage(), var2 -> {
                  try {
                     var5.invoke(var0, var2);
                  } catch (ReflectiveOperationException var4) {
                     throw new RuntimeException((Throwable)(var4.getCause() != null ? var4.getCause() : var4));
                  }
               }, false));
            }
         }
      }
   }

   static <E> void subscribe(ClientModule var0, Class<E> var1, Stage var2, Consumer<E> var3, boolean var4) {
      add(var1, new ExtBridge.Handler(var0, var2, var1x -> var3.accept((E)var1x), var4));
   }

   static void dropOwned(ClientModule var0) {
      for (List var2 : HANDLERS.values()) {
         var2.removeIf(var1 -> ((ExtBridge.Handler)var1).owned && ((ExtBridge.Handler)var1).owner == var0);
      }
   }

   private static void add(Class<?> var0, ExtBridge.Handler var1) {
      HANDLERS.computeIfAbsent(var0, var0x -> new CopyOnWriteArrayList<>()).add(var1);
   }

   static void later(Runnable var0) {
      LATER.add(var0);
   }

   public static boolean wants(Class<?> var0) {
      List var1 = HANDLERS.get(var0);
      if (var1 != null) {
         for (Object var3Raw : var1) {ExtBridge.Handler var3 = (ExtBridge.Handler)var3Raw;
            if (var3.owner.isEnabled()) {
               return true;
            }
         }
      }

      return false;
   }

   private static void post(Object var0, Stage var1) {
      List var2 = HANDLERS.get(var0.getClass());
      if (var2 != null) {
         for (Object var4Raw : var2) {ExtBridge.Handler var4 = (ExtBridge.Handler)var4Raw;
            if (var4.stage == var1 && var4.owner.isEnabled()) {
               try {
                  var4.fn.accept(var0);
               } catch (Throwable var6) {
                  System.err.println("Krispy: " + var4.owner.name() + " failed handling " + var0.getClass().getSimpleName() + ": " + var6);
               }
            }
         }
      }
   }

   public static void tick(Stage var0) {
      if (var0 == Stage.PRE) {
         Runnable var1;
         while ((var1 = LATER.poll()) != null) {
            try {
               var1.run();
            } catch (Throwable var6) {
               System.err.println("Krispy: deferred task failed: " + var6);
            }
         }

         for (ClientModule var3 : MODULES) {
            for (Setting var5 : var3.extSettings()) {
               var5.poll();
            }
         }
      }

      post(TICK, var0);
   }

   public static void render3D(float var0, Frustum var1) {
      if (wants(Render3DEvent.class)) {
         post(new Render3DEvent(var0, var1), Stage.PRE);
      }
   }

   public static boolean packetReceive(Packet<?> var0) {
      if (!wants(PacketReceiveNettyEvent.class)) {
         return false;
      } else {
         PacketReceiveNettyEvent var1 = new PacketReceiveNettyEvent(var0);
         post(var1, Stage.PRE);
         return var1.isCancelled();
      }
   }

   public static boolean packetSend(Packet<?> var0) {
      if (!wants(PacketSendEvent.class)) {
         return false;
      } else {
         PacketSendEvent var1 = new PacketSendEvent(var0);
         post(var1, Stage.PRE);
         return var1.isCancelled();
      }
   }

   public static void blockUpdate(BlockPos var0, BlockState var1, BlockState var2) {
      if (wants(BlockUpdateEvent.class)) {
         post(new BlockUpdateEvent(var0, var1, var2), Stage.PRE);
      }
   }

   private static record Handler(ClientModule owner, Stage stage, Consumer<Object> fn, boolean owned) {
   }
}
