package kren.debug.core.module.ext;

public enum Stage {
   PRE,
   POST;
}
