package kren.debug.core.module.ext.event;

import net.minecraft.network.packet.Packet;

public final class PacketSendEvent extends CancellableEvent {
   public static final EventType<PacketSendEvent> TYPE = new EventType<>(PacketSendEvent.class);
   public Packet<?> packet;

   public PacketSendEvent(Packet<?> var1) {
      this.packet = var1;
   }
}
