package kren.debug.core.module;

public interface NewFeature {
}
