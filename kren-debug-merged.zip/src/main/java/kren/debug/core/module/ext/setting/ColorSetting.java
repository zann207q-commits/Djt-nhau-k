package kren.debug.core.module.ext.setting;

import kren.debug.core.module.setting.RgbSetting;
import kren.debug.core.utils.EncryptedString;

public final class ColorSetting extends Setting {
   private final RgbSetting backing;

   public ColorSetting(String var1, int var2) {
      super(var1);
      this.backing = new RgbSetting(EncryptedString.of(var1), var2);
   }

   public int argb() {
      return this.backing.getArgb();
   }

   public int rgb() {
      return this.argb() & 16777215;
   }

   public int argbWithAlpha(int var1) {
      return Math.max(0, Math.min(255, var1)) << 24 | this.rgb();
   }

   public void setArgb(int var1) {
      if (this.argb() != var1) {
         this.backing.setArgb(var1);
         this.notifyChanged();
      }
   }

   public float[] value() {
      int var1 = this.argb();
      return new float[]{(float)(var1 >> 16 & 0xFF) / 255.0F, (float)(var1 >> 8 & 0xFF) / 255.0F, (float)(var1 & 0xFF) / 255.0F, (float)(var1 >>> 24) / 255.0F};
   }

   @Override
   public kren.debug.core.module.setting.Setting krispy() {
      return this.backing;
   }

   @Override
   protected Object snapshot() {
      return this.argb();
   }
}
