package kren.debug.core.module;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import kren.debug.core.Krispy;
import kren.debug.core.feature.*;

public final class ModuleManager {
   private final List<Module> modules = new ArrayList<>();
   private final Map<Class<?>, Module> modulesByClass = new HashMap<>();

   public ModuleManager() {
      // helpers used internally by the finders
      this.safe("Auto Rtp", AutoRtpModule::new);
      this.safe("Auto Eat", AutoEatModule::new);
      this.safe("Auto Totem", AutoTotemModule::new);
      // modules exposed in Meteor
      this.safe("Chunk Finder", ChunkFinderModule::new);
      this.safe("Chunk Finder Better", ChunkFinderBetterModule::new);
      this.safe("Prime Chunk Finder", PrimeChunkFinderModule::new);
      this.safe("Rtp Base Finder", RtpBaseFinderModule::new);
      this.safe("Tunnel Base Finder", TunnelBaseFinderModule::new);
      this.safe("Kaze Chunk Finder", KazeChunkFinderModule::new);
      this.safe("Sus Chunk Finder", SusChunkFinderModule::new);
      this.safe("Sus Chunk V2", SusChunkV2Module::new);
      this.safe("Player Bypass", PlayerBypassModule::new);
      this.safe("Anti Vanish", AntiVanishModule::new);
      this.safe("Region Map", RegionMapModule::new);
   }

   private void safe(String label, Supplier<? extends Module> factory) {
      try {
         this.a(factory.get());
      } catch (Throwable t) {
         System.err.println("[Kren Debug] " + label + " unavailable: " + t);
         t.printStackTrace(System.err);
      }
   }

   public void a(Module m) {
      Krispy.INSTANCE.getEventBus().register(m);
      this.modules.add(m);
      this.modulesByClass.put(m.getClass(), m);
   }

   public List<Module> c() {
      return this.modules;
   }

   public Module getModuleByClass(Class<? extends Module> type) {
      Module m = this.modulesByClass.get(type);
      if (m != null) {
         return m;
      }
      for (Module other : this.modules) {
         if (type.isInstance(other)) {
            return other;
         }
      }
      return null;
   }
}
