package kren.debug.core.module.ext.event;

import net.minecraft.client.render.Frustum;

public final class Render3DEvent {
   public static final EventType<Render3DEvent> TYPE = new EventType<>(Render3DEvent.class);
   public float partialTick;
   public Frustum frustum;

   public Render3DEvent(float var1, Frustum var2) {
      this.partialTick = var1;
      this.frustum = var2;
   }
}
