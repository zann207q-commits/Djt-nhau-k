package kren.debug.core;

import kren.debug.core.manager.EventManager;
import kren.debug.core.manager.SettingsManager;
import kren.debug.core.module.ModuleManager;
import net.minecraft.client.MinecraftClient;

/** Headless runtime for the embedded Krispy modules (no GUI, no profile files). */
public final class Krispy {
   public static Krispy INSTANCE;
   public static MinecraftClient mc;
   public EventManager EVENT_BUS;
   public ModuleManager MODULE_MANAGER;
   public SettingsManager settingsManager;
   public String version = " b1.3";

   private Krispy() {
   }

   public static synchronized Krispy boot() {
      if (INSTANCE == null) {
         Krispy k = new Krispy();
         INSTANCE = k;
         mc = MinecraftClient.getInstance();
         k.EVENT_BUS = new EventManager();
         k.settingsManager = new SettingsManager();
         k.MODULE_MANAGER = new ModuleManager();
      }
      return INSTANCE;
   }

   public SettingsManager getSettingsManager() {
      return this.settingsManager;
   }

   public ModuleManager getModuleManager() {
      return this.MODULE_MANAGER;
   }

   public EventManager getEventBus() {
      return this.EVENT_BUS;
   }
}
