package kren.debug.core.manager;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import kren.debug.core.Krispy;
import kren.debug.core.event.CancellableEvent;
import kren.debug.core.event.Event;
import kren.debug.core.event.EventListener;
import kren.debug.core.event.Listener;

public final class EventManager {
   private static final Listener[] NONE = new Listener[0];
   private final Map<Class<?>, Listener[]> EVENTS = new ConcurrentHashMap<>();

   public void register(Object var1) {
      Method[] var2 = var1.getClass().getDeclaredMethods();

      for (Method var6 : var2) {
         if (var6.isAnnotationPresent(EventListener.class) && var6.getParameterCount() == 1 && Event.class.isAssignableFrom(var6.getParameterTypes()[0])) {
            this.addListener(var1, var6, var6.getAnnotation(EventListener.class));
         }
      }
   }

   private synchronized void addListener(Object var1, Method var2, EventListener var3) {
      Class var4 = var2.getParameterTypes()[0];
      ArrayList<Listener> var5 = new ArrayList<>(Arrays.asList(this.EVENTS.getOrDefault(var4, NONE)));
      var5.add(new Listener(var1, var2, var3.priority()));
      var5.sort(Comparator.comparingInt(var0 -> var0.getPriority().getValue()));
      this.EVENTS.put(var4, var5.toArray(NONE));
   }

   public synchronized void unregister(Object var1) {
      for (Entry var3 : this.EVENTS.entrySet()) {
         Listener[] var4 = Arrays.<Listener>stream((Listener[])var3.getValue()).filter(var1x -> var1x.getInstance() != var1).toArray(Listener[]::new);
         if (var4.length != ((Listener[])var3.getValue()).length) {
            var3.setValue(var4);
         }
      }
   }

   public synchronized void clear() {
      this.EVENTS.clear();
   }

   public void a(Event var1) {
      if (true) {
         Listener[] var2 = this.EVENTS.get(var1.getClass());
         if (var2 != null) {
            for (Listener var6 : var2) {
               try {
                  if (var6.isActive() && (!var1.isCancelled() || var1 instanceof CancellableEvent)) {
                     var6.invoke(var1);
                  }
               } catch (Throwable var8) {
                  System.err
                     .println(
                        "Error dispatching event "
                           + var1.getClass().getSimpleName()
                           + " to "
                           + (var6.getInstance() != null ? var6.getInstance().getClass().getSimpleName() : "unknown")
                     );
                  var8.printStackTrace(System.err);
               }
            }
         }
      }
   }

   private boolean hasActive(Class<? extends Event> var1) {
      Listener[] var2 = this.EVENTS.get(var1);
      if (var2 != null) {
         for (Listener var6 : var2) {
            if (var6.isActive()) {
               return true;
            }
         }
      }

      return false;
   }

   public static void b(Event var0) {
      if (Krispy.INSTANCE != null && Krispy.INSTANCE.getEventBus() != null) {
         Krispy.INSTANCE.getEventBus().a(var0);
      }
   }

   public static boolean hasActiveListener(Class<? extends Event> var0) {
      return Krispy.INSTANCE != null && Krispy.INSTANCE.getEventBus() != null && Krispy.INSTANCE.getEventBus().hasActive(var0);
   }
}
