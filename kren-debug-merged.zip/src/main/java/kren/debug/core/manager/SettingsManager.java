package kren.debug.core.manager;

/** Meteor persists settings itself; the embedded runtime does not save anything. */
public final class SettingsManager {
   public void saveNow() {
   }

   public void loadProfile() {
   }
}
