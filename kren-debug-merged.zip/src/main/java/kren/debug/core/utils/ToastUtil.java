package kren.debug.core.utils;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.toast.SystemToast;
import net.minecraft.text.Text;

/** Small toast helper used by the Kaze Chunk Finder port. */
public final class ToastUtil {
   private ToastUtil() {
   }

   public static boolean show(String title, String body) {
      try {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc.getToastManager() == null) {
            return false;
         }
         SystemToast.add(mc.getToastManager(), SystemToast.Type.PERIODIC_NOTIFICATION, Text.literal(title), Text.literal(body));
         return true;
      } catch (Throwable t) {
         return false;
      }
   }
}
