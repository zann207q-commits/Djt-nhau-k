package kren.debug.core.utils;

public final class BytecodeException {
   private BytecodeException() {
   }

   @SuppressWarnings("unchecked")
   public static <E extends Throwable> RuntimeException unchecked(Throwable cause) throws E {
      throw (E)cause;
   }
}
