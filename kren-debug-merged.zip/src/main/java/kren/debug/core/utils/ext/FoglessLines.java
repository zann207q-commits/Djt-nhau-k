package kren.debug.core.utils.ext;

import kren.debug.core.mixin.KrispyGameRendererAccessor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.DrawStyle;
import net.minecraft.world.debug.gizmo.GizmoDrawing;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import org.joml.Vector3fc;

@Environment(EnvType.CLIENT)
public final class FoglessLines {
   private static final double NEAR = 0.05;
   private final Vec3d eye;
   private final Vector3fc forward;
   private final double pixelPerDepth;

   private FoglessLines(Vec3d var1, Vector3fc var2, double var3) {
      this.eye = var1;
      this.forward = var2;
      this.pixelPerDepth = var3;
   }

   public static FoglessLines forFrame(float var0) {
      Camera var1 = MinecraftClient.getInstance().gameRenderer.getCamera();
      return new FoglessLines(var1.getCameraPos(), var1.getHorizontalPlane(), pixelScale(var0));
   }

   public static double pixelScale(float var0) {
      MinecraftClient var1 = MinecraftClient.getInstance();
      Camera var2 = var1.gameRenderer.getCamera();
      float var3 = ((KrispyGameRendererAccessor)var1.gameRenderer).krispy$getFov(var2, var0, true);
      return 2.0 * Math.tan(Math.toRadians((double)var3) * 0.5) / (double)Math.max(1, var1.getWindow().getFramebufferHeight());
   }

   public static FoglessLines forView(Vec3d var0, Vector3fc var1, double var2) {
      return new FoglessLines(var0, var1, var2);
   }

   public void line(Vec3d var1, Vec3d var2, int var3, float var4) {
      double var5 = this.depth(var1);
      double var7 = this.depth(var2);
      if (!(var5 < 0.05) || !(var7 < 0.05)) {
         if (var5 < 0.05) {
            var1 = var1.lerp(var2, (0.05 - var5) / (var7 - var5));
            var5 = 0.05;
         } else if (var7 < 0.05) {
            var2 = var2.lerp(var1, (0.05 - var7) / (var5 - var7));
            var7 = 0.05;
         }

         Vec3d var9 = var1.subtract(this.eye).crossProduct(var2.subtract(var1));
         double var10 = var9.length();
         if (!(var10 < 1.0E-9)) {
            double var12 = (double)var4 * 0.5 * this.pixelPerDepth / var10;
            Vec3d var14 = var9.multiply(var12 * var5);
            Vec3d var15 = var9.multiply(var12 * var7);
            GizmoDrawing.quad(
                  var1.add(var14), var2.add(var15), var2.subtract(var15), var1.subtract(var14), DrawStyle.filled(var3)
               )
               .ignoreOcclusion();
         }
      }
   }

   public void box(Box var1, int var2, float var3) {
      double var4 = var1.minX;
      double var6 = var1.minY;
      double var8 = var1.minZ;
      double var10 = var1.maxX;
      double var12 = var1.maxY;
      double var14 = var1.maxZ;

      for (double var19 : new double[]{var6, var12}) {
         this.line(new Vec3d(var4, var19, var8), new Vec3d(var10, var19, var8), var2, var3);
         this.line(new Vec3d(var10, var19, var8), new Vec3d(var10, var19, var14), var2, var3);
         this.line(new Vec3d(var10, var19, var14), new Vec3d(var4, var19, var14), var2, var3);
         this.line(new Vec3d(var4, var19, var14), new Vec3d(var4, var19, var8), var2, var3);
      }

      this.line(new Vec3d(var4, var6, var8), new Vec3d(var4, var12, var8), var2, var3);
      this.line(new Vec3d(var10, var6, var8), new Vec3d(var10, var12, var8), var2, var3);
      this.line(new Vec3d(var10, var6, var14), new Vec3d(var10, var12, var14), var2, var3);
      this.line(new Vec3d(var4, var6, var14), new Vec3d(var4, var12, var14), var2, var3);
   }

   private double depth(Vec3d var1) {
      return (var1.x - this.eye.x) * (double)this.forward.x()
         + (var1.y - this.eye.y) * (double)this.forward.y()
         + (var1.z - this.eye.z) * (double)this.forward.z();
   }
}
