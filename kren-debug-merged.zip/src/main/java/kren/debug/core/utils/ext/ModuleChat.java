package kren.debug.core.utils.ext;

import kren.debug.core.module.ext.ClientModule;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.text.Text;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.MutableText;

@Environment(EnvType.CLIENT)
public final class ModuleChat {
   private static final String HEADER = "Kren Debug";
   private static final int DARK_GREY = 5592405;
   private static final int GREY = 11184810;
   private static final int WHITE = 16777215;
   private static final int DANGER = 16733525;
   private static final int GOOD = 5635925;
   private static final int WARN = 16755200;
   private static final int VALUE = 5636095;

   private ModuleChat() {
   }

   public static ModuleChat.Body body() {
      return new ModuleChat.Body();
   }

   public static void send(ClientModule var0, Text var1) {
      onClientThread(() -> {
         if (var0.notificationsOn()) {
            addLine(var0, var1);
         }
      });
   }

   public static void send(ClientModule var0, ModuleChat.Body var1) {
      send(var0, var1.build());
   }

   public static void send(ClientModule var0, String var1) {
      send(var0, Text.literal(var1));
   }

   public static void actionBar(ClientModule var0, ModuleChat.Body var1) {
      Text var2 = var1.build();
      onClientThread(() -> {
         MinecraftClient var2x = MinecraftClient.getInstance();
         if (var0.notificationsOn() && var2x.inGameHud != null) {
            var2x.inGameHud.setOverlayMessage(line(var0, var2), false);
         }
      });
   }

   private static void addLine(ClientModule var0, Text var1) {
      MinecraftClient var2 = MinecraftClient.getInstance();
      if (var2.inGameHud != null) {
         var2.inGameHud.getChatHud().addMessage(line(var0, var1));
      }
   }

   private static MutableText line(ClientModule var0, Text var1) {
      return Text.empty()
         .append(Text.literal("[").withColor(5592405))
         .append(Text.literal("Kren Debug").withColor(5636095))
         .append(Text.literal("] ").withColor(5592405))
         .append(Text.literal(var0.name()).withColor(16777215))
         .append(Text.literal(" : ").withColor(5592405))
         .append(Text.empty().withColor(11184810).append(var1));
   }

   private static void onClientThread(Runnable var0) {
      MinecraftClient var1 = MinecraftClient.getInstance();
      if (var1.isOnThread()) {
         var0.run();
      } else {
         var1.execute(var0);
      }
   }

   @Environment(EnvType.CLIENT)
   public static final class Body {
      private final MutableText root = Text.empty().withColor(11184810);

      private Body() {
      }

      public ModuleChat.Body text(String var1) {
         this.root.append(Text.literal(var1));
         return this;
      }

      public ModuleChat.Body name(String var1) {
         return this.part(var1, 16777215);
      }

      public ModuleChat.Body danger(String var1) {
         return this.part(var1, 16733525);
      }

      public ModuleChat.Body good(String var1) {
         return this.part(var1, 5635925);
      }

      public ModuleChat.Body warn(String var1) {
         return this.part(var1, 16755200);
      }

      public ModuleChat.Body value(Object var1) {
         return this.part(String.valueOf(var1), 5636095);
      }

      public ModuleChat.Body coords(int var1, int var2, int var3) {
         return this.part(var1 + ", " + var2 + ", " + var3, 5636095);
      }

      public ModuleChat.Body append(Text var1) {
         this.root.append(var1);
         return this;
      }

      public Text build() {
         return this.root.copy();
      }

      private ModuleChat.Body part(String var1, int var2) {
         this.root.append(Text.literal(var1).withColor(var2));
         return this;
      }
   }
}
