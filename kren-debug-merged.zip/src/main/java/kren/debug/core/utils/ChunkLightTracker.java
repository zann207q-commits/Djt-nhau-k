package kren.debug.core.utils;

import java.util.Arrays;
import java.util.BitSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.network.packet.s2c.play.LightData;

public final class ChunkLightTracker {
   private static final Map<Long, Snapshot> SNAPSHOTS = new HashMap<>();
   private static final Set<Long> FLAGGED = new HashSet<>();
   private static volatile Set<Long> flaggedSnapshot = Set.of();
   private static ClientWorld world;

   private ChunkLightTracker() {}

   public static synchronized void ingest(int chunkX, int chunkZ, LightData data) {
      MinecraftClient mc = MinecraftClient.getInstance();
      ClientWorld currentWorld = mc.world;
      if (currentWorld != null && data != null) {
         if (world != currentWorld) {
            SNAPSHOTS.clear();
            FLAGGED.clear();
            flaggedSnapshot = Set.of();
            world = currentWorld;
         }

         int sectionCount = currentWorld.countVerticalSections();
         int bottomSectionY = currentWorld.getBottomSectionCoord();
         long key = ChunkPos.toLong(chunkX, chunkZ);
         Snapshot snapshot = SNAPSHOTS.get(key);
         if (snapshot == null || snapshot.sky.length != sectionCount + 2 || snapshot.bottomSectionY != bottomSectionY) {
            snapshot = new Snapshot(sectionCount, bottomSectionY);
            SNAPSHOTS.put(key, snapshot);
         }

         applyTrack(data.getInitedSky(), data.getUninitedSky(), data.getSkyNibbles(), snapshot.sky);

         for (int i = 1; i < snapshot.sky.length - 1; i++) {
            int sectionBottom = (bottomSectionY + i - 1) * 16;
            int sectionTop = sectionBottom + 15;
            if (sectionTop >= -64 && sectionBottom <= 184 && sectionTop < 62 && snapshot.sky[i] == LightState.ZEROED_PRESENT) {
               if (FLAGGED.add(key)) {
                  flaggedSnapshot = Set.copyOf(FLAGGED);
               }
               break;
            }
         }
      }
   }

   public static synchronized void unload(int chunkX, int chunkZ) {
      long key = ChunkPos.toLong(chunkX, chunkZ);
      SNAPSHOTS.remove(key);
      if (FLAGGED.remove(key)) {
         flaggedSnapshot = Set.copyOf(FLAGGED);
      }
   }

   public static Set<Long> getFlaggedChunks() {
      return flaggedSnapshot;
   }

   private static void applyTrack(BitSet initialized, BitSet uninitialized, List<byte[]> payloads, LightState[] output) {
      int payloadIndex = 0;

      for (int i = 0; i < output.length; i++) {
         if (initialized.get(i)) {
            byte[] payload = payloadIndex < payloads.size() ? payloads.get(payloadIndex) : null;
            payloadIndex++;
            output[i] = classify(payload);
         } else if (uninitialized.get(i)) {
            output[i] = LightState.EMPTY_MASK;
         }
      }
   }

   private static LightState classify(byte[] data) {
      if (data != null && data.length == 2048) {
         boolean allZero = true;
         boolean allFull = true;

         for (byte value : data) {
            if (value != 0) {
               allZero = false;
            }

            if (value != -1) {
               allFull = false;
            }

            if (!allZero && !allFull) {
               return LightState.NORMAL;
            }
         }

         if (allZero) {
            return LightState.ZEROED_PRESENT;
         } else {
            return allFull ? LightState.UNIFORM_MAX : LightState.NORMAL;
         }
      } else {
         return LightState.UNKNOWN;
      }
   }

   private static final class Snapshot {
      final int bottomSectionY;
      final LightState[] sky;

      Snapshot(int sectionCount, int bottomSectionY) {
         this.bottomSectionY = bottomSectionY;
         this.sky = new LightState[sectionCount + 2];
         Arrays.fill(this.sky, LightState.UNKNOWN);
      }
   }

   private enum LightState {
      NORMAL, EMPTY_MASK, ZEROED_PRESENT, UNIFORM_MAX, UNKNOWN
   }
}
