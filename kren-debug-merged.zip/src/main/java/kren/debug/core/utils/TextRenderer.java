package kren.debug.core.utils;

import kren.debug.core.Krispy;
import net.minecraft.client.gui.DrawContext;
import org.joml.Matrix3x2fStack;

public final class TextRenderer {
   private TextRenderer() {
   }

   public static void drawString(CharSequence text, DrawContext ctx, int x, int y, int color) {
      RenderUtils.setContext(ctx);
      drawLargeString(text, ctx, x, y, color);
   }

   public static int getWidth(CharSequence text) {
      return Krispy.mc.textRenderer.getWidth(text.toString()) * 2;
   }

   public static void drawCenteredString(CharSequence text, DrawContext ctx, int x, int y, int color) {
      drawCenteredMinecraftText(text, ctx, x, y, color);
   }

   public static void drawLargeString(CharSequence text, DrawContext ctx, int x, int y, int color) {
      Matrix3x2fStack m = ctx.getMatrices();
      m.pushMatrix();
      m.scale(2.0F, 2.0F);
      ctx.drawText(Krispy.mc.textRenderer, text.toString(), x / 2, y / 2, color, false);
      m.popMatrix();
   }

   public static void drawCenteredMinecraftText(CharSequence text, DrawContext ctx, int x, int y, int color) {
      Matrix3x2fStack m = ctx.getMatrices();
      m.pushMatrix();
      m.scale(2.0F, 2.0F);
      ctx.drawText(Krispy.mc.textRenderer, text.toString(), x / 2 - Krispy.mc.textRenderer.getWidth(text.toString()) / 2, y / 2, color, false);
      m.popMatrix();
   }
}
