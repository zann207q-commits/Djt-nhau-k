/* Renamed for source analysis. Original archive path: com/example/addon/modules/bb.java
 * Display name: OG Chunk Finder
 * Confidence: High confidence: OG chunk scan and chunk marking.
 * This extracted module may require original addon dependencies to compile.
 */
/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  meteordevelopment.meteorclient.events.render.Render2DEvent
 *  meteordevelopment.meteorclient.events.render.Render3DEvent
 *  meteordevelopment.meteorclient.events.world.ChunkDataEvent
 *  meteordevelopment.meteorclient.events.world.TickEvent$Pre
 *  meteordevelopment.meteorclient.renderer.Renderer2D
 *  meteordevelopment.meteorclient.renderer.text.TextRenderer
 *  meteordevelopment.meteorclient.settings.BoolSetting$Builder
 *  meteordevelopment.meteorclient.settings.ColorSetting$Builder
 *  meteordevelopment.meteorclient.settings.DoubleSetting$Builder
 *  meteordevelopment.meteorclient.settings.EnumSetting$Builder
 *  meteordevelopment.meteorclient.settings.IntSetting$Builder
 *  meteordevelopment.meteorclient.settings.Setting
 *  meteordevelopment.meteorclient.settings.SettingGroup
 *  meteordevelopment.meteorclient.systems.modules.Module
 *  meteordevelopment.meteorclient.utils.render.color.Color
 *  meteordevelopment.meteorclient.utils.render.color.SettingColor
 *  meteordevelopment.orbit.EventHandler
 *  net.minecraft.util.math.Direction.Axis
 */
package kren.debug.modules;

import kren.debug.KrenDebug;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import meteordevelopment.meteorclient.events.render.Render2DEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.Renderer2D;
import meteordevelopment.meteorclient.renderer.text.TextRenderer;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.PolarBearEntity;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.World;
import net.minecraft.block.Blocks;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Box;
import net.minecraft.block.RepeaterBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.block.BlockState;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.Properties;
import net.minecraft.state.property.Property;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.util.Identifier;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.block.entity.BeehiveBlockEntity;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.client.network.AbstractClientPlayerEntity;

public class OGChunkFinder
extends Module {
    private static final int WORLD_MIN_Y = -64;
    private static final int SCAN_MIN_Y = -32;
    private static final int DOMINANT_MIN_Y = -16;
    private final SettingGroup sgGeneral;
    private final SettingGroup sgNotify;
    private final Setting<b> mode;
    private final Setting<Integer> ageScanRadius;
    private final Setting<Integer> ageScanInterval;
    private final Setting<SettingColor> ogColor;
    private final Setting<Boolean> sheen;
    private final Setting<Double> sheenSpeed;
    private final Setting<Boolean> sparkles;
    private final Setting<SettingColor> sparkleColor;
    private final Setting<Integer> sparkleCount;
    private final Setting<Integer> floorMaxY;
    private final Setting<Integer> coverageMin;
    private final Setting<Integer> stackMin;
    private final Setting<Integer> usageMin;
    private final Setting<Integer> growthMin;
    private final Setting<Integer> growthMinY;
    private final Setting<Integer> growthMaxY;
    private final Setting<Integer> scanRadius;
    private final Setting<Integer> renderRadius;
    private final Setting<Integer> rescanInterval;
    private final Setting<Integer> rescanRadius;
    private final Setting<Double> yMin;
    private final Setting<Double> boxHeight;
    private final Setting<Boolean> notifyShow;
    private final Setting<Double> notifyY;
    private final Setting<Double> notifyMs;
    private final Setting<SettingColor> notifyAccent;
    private final Map<Long, Integer> growthCache = new HashMap<Long, Integer>();
    private final Map<Block, Boolean> ageCache = new IdentityHashMap<Block, Boolean>();
    private final Map<Long, String> ageMarkers = new HashMap<Long, String>();
    private long currentKey = -1L;
    private int currentScore;
    private long foundNanos;
    private long lastNotifyNanos;
    private long lastAgeScanNanos;
    private long lastAgeMarkTime;
    private String ageNotifyReason;
    private int tickCounter;

    public OGChunkFinder() {
        super(KrenDebug.CATEGORY, "og-chunk-finder", "");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgNotify = this.settings.createGroup("Notify");
        this.mode = this.sgGeneral.add((Setting)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)new EnumSetting.Builder().name("detection-mode")).description("Which chunk detection system to use. Legacy is your original gold old-floor finder. Age Exploiter runs the ported WaterClient OG Chunk Finder signature engine (active repeaters, light sources, glow lichen near other players, polar bear biomes or ice beds, beehives, deepslate, vines and spawn growth).")).defaultValue((Object)b.Legacy)).build());
        this.ageScanRadius = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("age-scan-radius")).description("How many chunks around you the Age Exploiter signature scan checks.")).defaultValue((Object)3)).min(1).max(8).build());
        this.ageScanInterval = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("age-scan-interval")).description("Milliseconds between Age Exploiter signature scans. Higher = less lag.")).defaultValue((Object)3000)).min(1000).max(10000).sliderRange(1500, 5000).build());
        this.ogColor = this.sgGeneral.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)new ColorSetting.Builder().name("og-color")).description("Gold color of the detected OG chunk.")).defaultValue(new SettingColor(255, 205, 40, 230)).build());
        this.sheen = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("sheen")).description("Animated golden shine that ripples across the chunk so it looks shiny.")).defaultValue((Object)true)).build());
        this.sheenSpeed = this.sgGeneral.add((Setting)((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("sheen-speed")).description("How fast the shine ripples across the chunk.")).defaultValue(1.2).min(0.2).max(4.0).sliderRange(0.2, 3.0).build());
        this.sparkles = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("sparkles")).description("Twinkling sparkle glints scattered through the chunk volume.")).defaultValue((Object)true)).build());
        this.sparkleColor = this.sgGeneral.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)new ColorSetting.Builder().name("sparkle-color")).description("Color of the twinkling sparkles inside the chunk.")).defaultValue(new SettingColor(255, 245, 170, 255)).build());
        this.sparkleCount = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("sparkle-count")).description("How many sparkles shimmer inside the chunk.")).defaultValue((Object)36)).min(5).max(120).sliderRange(10, 80).build());
        this.floorMaxY = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("floor-max-y")).description("Highest Y the old uniform floor is allowed to sit at. Old floors are around Y 0-4; raise it only if your server's old generation sits higher.")).defaultValue((Object)20)).min(-16).max(64).build());
        this.coverageMin = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("coverage-min")).description("How full a single 16x16 layer must be with the same block to count as an old floor (out of 256 blocks). Lower = more sensitive and finds more chunks but adds more false positives.")).defaultValue((Object)180)).min(100).max(256).build());
        this.stackMin = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("stack-min")).description("How full the layer directly above or below the floor must be with one block (out of 256) to confirm it isn't a one-off flat surface. Lower = more sensitive.")).defaultValue((Object)160)).min(80).max(256).build());
        this.usageMin = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("usage-min")).description("Chunks with at least this many block entities (chests, furnaces, beds, crafting tables...) are treated as lived-in/used. Used chunks rank above plain old chunks, and heavily used chunks qualify even without the old floor signature. Lower = flags more chunks.")).defaultValue((Object)12)).min(1).max(100).build());
        this.growthMin = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("growth-min")).description("Chunks containing at least this many grown crop blocks (wheat, carrots, potatoes, beetroot, nether wart, sweet berries, bamboo, cocoa - anything with an age stage) count as heavy growth like a farm. Lower = flags more chunks.")).defaultValue((Object)80)).min(10).max(500).build());
        this.growthMinY = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("growth-y-min")).description("Lowest Y scanned for grown crops.")).defaultValue((Object)40)).min(-64).max(320).build());
        this.growthMaxY = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("growth-y-max")).description("Highest Y scanned for grown crops.")).defaultValue((Object)200)).min(-64).max(320).build());
        this.scanRadius = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("scan-radius")).description("How many chunks around you to scan for the old floor signature.")).defaultValue((Object)10)).min(2).max(20).build());
        this.renderRadius = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("render-radius")).description("How many chunks away the gold highlight is still drawn.")).defaultValue((Object)24)).min(4).max(48).build());
        this.rescanInterval = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("rescan-interval")).description("Ticks between re-scanning the already-loaded chunks around you. 0 disables re-scanning. Lower = more sensitive (finds chunks whose floor was missed on load).")).defaultValue((Object)120)).min(0).max(1200).build());
        this.rescanRadius = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("rescan-radius")).description("How many chunks around you to re-scan every interval. Keep it low; it is real block work.")).defaultValue((Object)3)).min(1).max(10).build());
        this.yMin = this.sgGeneral.add((Setting)((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("chunk-y-min")).description("Bottom Y of the gold chunk highlight. The box is drawn from here upward.")).defaultValue(0.0).min(-64.0).max(320.0).build());
        this.boxHeight = this.sgGeneral.add((Setting)((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("box-height")).description("Vertical height of the gold chunk highlight, measured up from chunk-y-min. Drag this to adjust how tall the rendered chunk box is.")).defaultValue(96.0).min(1.0).max(384.0).sliderRange(16.0, 256.0).build());
        this.notifyShow = this.sgNotify.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("notify")).description("Pop an 'OG Chunk Spotted' alert on screen, gold to match og-color with the same gradient, sheen and sparkles, whenever a new strongest chunk is found.")).defaultValue((Object)true)).build());
        this.notifyY = this.sgNotify.add((Setting)((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("notify-y")).description("Y (vertical) position of the OG Chunk Spotted popup on screen.")).defaultValue(12.0).min(0.0).max(500.0).sliderRange(0.0, 300.0).build());
        this.notifyMs = this.sgNotify.add((Setting)((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("notify-ms")).description("How long the OG Chunk Spotted popup stays on screen, in milliseconds.")).defaultValue(3000.0).min(1000.0).max(10000.0).sliderRange(1000.0, 6000.0).build());
        this.notifyAccent = this.sgNotify.add((Setting)((ColorSetting.Builder)((ColorSetting.Builder)new ColorSetting.Builder().name("notify-accent")).description("Color of the spinning star and 'OG Chunk Spotted' text.")).defaultValue(new SettingColor(255, 235, 150, 255)).build());
    }

    public void onActivate() {
        this.currentKey = -1L;
        this.currentScore = 0;
        this.lastNotifyNanos = 0L;
        this.growthCache.clear();
        this.ageMarkers.clear();
        this.lastAgeScanNanos = 0L;
        this.lastAgeMarkTime = 0L;
        this.ageNotifyReason = null;
    }

    public void onDeactivate() {
        this.currentKey = -1L;
        this.currentScore = 0;
        this.lastNotifyNanos = 0L;
        this.growthCache.clear();
        this.ageMarkers.clear();
        this.lastAgeScanNanos = 0L;
        this.lastAgeMarkTime = 0L;
        this.ageNotifyReason = null;
    }

    @EventHandler
    private void onChunkData(ChunkDataEvent chunkDataEvent) {
        try {
            if (this.mc.world == null || this.mc.player == null) {
                return;
            }
            if (this.mc.world.getRegistryKey() != World.OVERWORLD) {
                return;
            }
            if (this.mode.get() == b.AgeExploiter) {
                return;
            }
            WorldChunk worldChunk2 = chunkDataEvent.chunk();
            if (worldChunk2 == null) {
                return;
            }
            ChunkPos chunkPos2 = worldChunk2.getPos();
            int n2 = this.mc.player.getBlockPos().getX() >> 4;
            int n3 = this.mc.player.getBlockPos().getZ() >> 4;
            if (Math.max(Math.abs(chunkPos2.x - n2), Math.abs(chunkPos2.z - n3)) > (Integer)this.scanRadius.get()) {
                return;
            }
            this.considerChunk(worldChunk2);
        } catch (Throwable throwable) {
            // empty catch block
        }
    }

    @EventHandler
    private void onTick(TickEvent.Pre pre) {
        int n2;
        int n3;
        if (this.mc.world == null) {
            if (this.currentKey != -1L) {
                this.currentKey = -1L;
                this.currentScore = 0;
            }
            return;
        }
        if (this.currentKey != -1L && this.mc.world.getChunkManager().getWorldChunk(n3 = (int)this.currentKey, n2 = (int)(this.currentKey >> 32)) == null) {
            this.currentKey = -1L;
            this.currentScore = 0;
            this.growthCache.remove((long)(n3 << 32) | (long)n2 & 0xFFFFFFFFL);
        }
        if (this.mc.player == null || this.mc.world.getRegistryKey() != World.OVERWORLD) {
            return;
        }
        if (this.mode.get() == b.AgeExploiter) {
            this.ageTick();
            return;
        }
        n3 = (Integer)this.rescanInterval.get();
        if (n3 <= 0) {
            return;
        }
        ++this.tickCounter;
        if (this.tickCounter < n3) {
            return;
        }
        this.tickCounter = 0;
        if (!this.growthCache.isEmpty()) {
            Iterator<Map.Entry<Long, Integer>> iterator = this.growthCache.entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<Long, Integer> entry = iterator.next();
                long l2 = entry.getKey();
                if (this.mc.world.getChunkManager().getWorldChunk((int)l2, (int)(l2 >> 32)) != null) continue;
                iterator.remove();
            }
        }
        n2 = this.mc.player.getBlockPos().getX() >> 4;
        int n4 = this.mc.player.getBlockPos().getZ() >> 4;
        int n5 = (Integer)this.rescanRadius.get();
        for (int i2 = -n5; i2 <= n5; ++i2) {
            for (int i3 = -n5; i3 <= n5; ++i3) {
                try {
                    WorldChunk worldChunk2 = this.mc.world.getChunkManager().getWorldChunk(n2 + i3, n4 + i2);
                    if (worldChunk2 == null) continue;
                    this.considerChunk(worldChunk2);
                    continue;
                } catch (Throwable throwable) {
                    // empty catch block
                }
            }
        }
    }

    private void considerChunk(WorldChunk worldChunk2) {
        boolean bl2;
        int n2;
        Object object;
        int n3;
        int n4;
        long l2;
        block12: {
            ChunkPos chunkPos2 = worldChunk2.getPos();
            l2 = ChunkPos.toLong((int)chunkPos2.x, (int)chunkPos2.z);
            n4 = 0;
            int[] nArray = this.scanSignature(worldChunk2);
            if (nArray != null) {
                n3 = nArray[1];
                int n5 = nArray[2];
                if (n3 >= (Integer)this.coverageMin.get() && n5 >= (Integer)this.stackMin.get()) {
                    n4 = n3 * 64 + n5;
                }
            }
            n3 = 0;
            try {
                java.util.Map<?, ?> blockEntities = worldChunk2.getBlockEntities();
                if (blockEntities == null) break block12;
                n2 = 0;
                for (Object v2 : blockEntities.values()) {
                    if (v2 instanceof BlockEntity) {
                        ++n2;
                    }
                }
                if (n2 >= (Integer)this.usageMin.get()) {
                    n3 = n2;
                }
            } catch (Throwable throwable) {
                // empty catch block
            }
        }
        object = this.growthCache.get(l2);
        if (object == null) {
            object = this.countGrowth(worldChunk2);
            this.growthCache.put(l2, (Integer)object);
        }
        boolean bl3 = bl2 = (n2 = ((Integer)object).intValue()) >= (Integer)this.growthMin.get();
        if (n4 == 0 && n3 == 0 && !bl2) {
            return;
        }
        int n6 = n3 * 4096 + n4 + (bl2 ? n2 * 64 : 0);
        if (this.currentKey == -1L || n6 > this.currentScore) {
            this.currentKey = l2;
            this.currentScore = n6;
            this.lastNotifyNanos = this.foundNanos = System.nanoTime();
        }
    }

    private boolean isCrop(Block block2) {
        Boolean bl2 = this.ageCache.get(block2);
        if (bl2 != null) {
            return bl2;
        }
        boolean bl3 = false;
        try {
            StateManager stateManager2 = block2.getStateManager();
            bl3 = stateManager2 != null && stateManager2.getProperty("age") != null;
        } catch (Throwable throwable) {
            // empty catch block
        }
        this.ageCache.put(block2, bl3);
        return bl3;
    }

    private int countGrowth(WorldChunk worldChunk2) {
        int n2;
        int n3;
        ChunkSection[] class_2826Array = worldChunk2.getSectionArray();
        if (class_2826Array == null) {
            return 0;
        }
        int n4 = worldChunk2.getBottomY();
        int n5 = (Integer)this.growthMinY.get();
        int n6 = (Integer)this.growthMaxY.get();
        if (n6 < n5) {
            n3 = n6;
            n6 = n5;
            n5 = n3;
        }
        if ((n3 = n5 - n4 >> 4) < 0) {
            n3 = 0;
        }
        if ((n2 = n6 - n4 >> 4) >= class_2826Array.length) {
            n2 = class_2826Array.length - 1;
        }
        if (n2 < n3) {
            return 0;
        }
        int n7 = 0;
        for (int i2 = n3; i2 <= n2; ++i2) {
            ChunkSection chunkSection2 = class_2826Array[i2];
            if (chunkSection2 == null || chunkSection2.isEmpty()) continue;
            int n8 = n4 + (i2 << 4);
            for (int i3 = 0; i3 < 16; ++i3) {
                int n9 = n8 + i3;
                if (n9 < n5 || n9 > n6) continue;
                for (int i4 = 0; i4 < 16; ++i4) {
                    for (int i5 = 0; i5 < 16; ++i5) {
                        if (!this.isCrop(chunkSection2.getBlockState(i4, i3, i5).getBlock())) continue;
                        ++n7;
                    }
                }
            }
        }
        return n7;
    }

    private int[] scanSignature(WorldChunk worldChunk2) {
        int n2;
        int n3;
        int n4;
        int n5;
        int n6;
        int n7;
        int n8;
        ChunkSection[] class_2826Array = worldChunk2.getSectionArray();
        if (class_2826Array == null) {
            return null;
        }
        int n9 = worldChunk2.getBottomY();
        int n10 = -32 - n9 >> 4;
        if (n10 < 0) {
            n10 = 0;
        }
        if ((n8 = ((Integer)this.floorMaxY.get()).intValue()) < -16) {
            n8 = -16;
        }
        if ((n7 = n8 - n9 >> 4) < n10) {
            n7 = n10;
        }
        if (n7 >= class_2826Array.length) {
            n7 = class_2826Array.length - 1;
        }
        int n11 = 64;
        HashMap[] hashMapArray = new HashMap[n11];
        for (n6 = n10; n6 <= n7; ++n6) {
            ChunkSection chunkSection2 = class_2826Array[n6];
            if (chunkSection2 == null || chunkSection2.isEmpty()) continue;
            n5 = n9 + (n6 << 4);
            for (n4 = 0; n4 < 16; ++n4) {
                n3 = n5 + n4;
                if (n3 < -32 || n3 > n8) continue;
                HashMap<Block, Integer> hashMap = hashMapArray[n3 - -32];
                if (hashMap == null) {
                    hashMapArray[n3 - -32] = hashMap = new HashMap<Block, Integer>();
                }
                for (int i2 = 0; i2 < 16; ++i2) {
                    for (int i3 = 0; i3 < 16; ++i3) {
                        Block block2;
                        Integer n12 = (Integer)hashMap.get(block2 = chunkSection2.getBlockState(i2, n4, i3).getBlock());
                        hashMap.put(block2, n12 == null ? 1 : n12 + 1);
                    }
                }
            }
        }
        n6 = -1;
        int n13 = 0;
        for (n5 = -16; n5 <= n8; ++n5) {
            n4 = n5 - -32;
            if (n4 < 0 || n4 >= hashMapArray.length || hashMapArray[n4] == null || (n3 = this.maxCount(hashMapArray[n4])) <= n13) continue;
            n13 = n3;
            n6 = n5;
        }
        if (n6 < 0) {
            return null;
        }
        n5 = 0;
        n4 = n6 + 1 - -32;
        n3 = n6 - 1 - -32;
        if (n4 >= 0 && n4 < hashMapArray.length && hashMapArray[n4] != null) {
            n5 = this.maxCount(hashMapArray[n4]);
        }
        if (n3 >= 0 && n3 < hashMapArray.length && hashMapArray[n3] != null && (n2 = this.maxCount(hashMapArray[n3])) > n5) {
            n5 = n2;
        }
        return new int[]{n6, n13, n5};
    }

    private int maxCount(Map<Block, Integer> map) {
        int n2 = 0;
        for (Integer n3 : map.values()) {
            if (n3 == null || n3 <= n2) continue;
            n2 = n3;
        }
        return n2;
    }

    private void ageTick() {
        try {
            int n2;
            int n3;
            Map.Entry<Long, String> entry;
            long l2 = System.currentTimeMillis();
            int n4 = this.mc.player.getBlockPos().getX() >> 4;
            int n5 = this.mc.player.getBlockPos().getZ() >> 4;
            if (!this.ageMarkers.isEmpty()) {
                Iterator<Map.Entry<Long, String>> iterator = this.ageMarkers.entrySet().iterator();
                while (iterator.hasNext()) {
                    int n6;
                    entry = iterator.next();
                    long l3 = entry.getKey();
                    n3 = (int)l3;
                    if (this.mc.world.getChunkManager().getWorldChunk(n3, n6 = (int)(l3 >> 32)) != null && Math.max(Math.abs(n3 - n4), Math.abs(n6 - n5)) <= (Integer)this.renderRadius.get()) continue;
                    iterator.remove();
                }
            }
            if (l2 - this.lastAgeScanNanos < (long)((Integer)this.ageScanInterval.get()).intValue()) {
                return;
            }
            this.lastAgeScanNanos = l2;
            int n7 = (Integer)this.ageScanRadius.get();
            entry = new ArrayList();
            ArrayList<a> arrayList = new ArrayList<a>();
            for (n2 = -n7; n2 <= n7; ++n2) {
                for (n3 = -n7; n3 <= n7; ++n3) {
                    long l4;
                    WorldChunk worldChunk2 = this.mc.world.getChunkManager().getWorldChunk(n4 + n3, n5 + n2);
                    if (worldChunk2 == null || worldChunk2.isEmpty() || this.ageMarkers.containsKey(l4 = ChunkPos.toLong((int)(n4 + n3), (int)(n5 + n2)))) continue;
                    entry.add(l4);
                    arrayList.add(this.scanAgeChunk(worldChunk2, n4 + n3, n5 + n2, n4, n5));
                }
            }
            if (arrayList.isEmpty()) {
                return;
            }
            n2 = entry.size();
            for (n3 = 0; n3 < n2; ++n3) {
                if (((a)arrayList.get((int)n3)).tallSeagrass < 75) continue;
                this.markAge((Long)entry.get(n3), "tall_seagrass");
                return;
            }
            for (n3 = 0; n3 < n2; ++n3) {
                if (((a)arrayList.get((int)n3)).activeRepeaters < 3) continue;
                this.markAge((Long)entry.get(n3), "repeater");
                return;
            }
            for (n3 = 0; n3 < n2; ++n3) {
                if (!((a)arrayList.get((int)n3)).light) continue;
                this.markAge((Long)entry.get(n3), "light");
                return;
            }
            for (n3 = 0; n3 < n2; ++n3) {
                if (((a)arrayList.get((int)n3)).lichenKey < 0L) continue;
                this.markAge((Long)entry.get(n3), "glow_lichen");
                return;
            }
            Long l5 = this.findPolarBear();
            if (l5 != null) {
                this.markAge(l5, "polar_bear");
                return;
            }
            for (int i2 = 0; i2 < n2; ++i2) {
                boolean bl2;
                boolean bl3;
                a a2 = (a)arrayList.get(i2);
                boolean bl4 = bl3 = a2.beehive || a2.vine >= 150 || a2.seagrass >= 70 || a2.flowers >= 6 || a2.cobbled >= 3 || a2.rotated >= 3;
                if (!bl3) continue;
                String string = a2.repeaterBlocks >= 3 ? "repeater" : "normal";
                boolean bl5 = bl2 = "repeater".equals(string) || System.currentTimeMillis() - this.lastAgeMarkTime >= 50000L;
                if (bl2) {
                    this.markAge((Long)entry.get(i2), string);
                }
                return;
            }
        } catch (Throwable throwable) {
            // empty catch block
        }
    }

    private void markAge(Long l2, String string) {
        if (this.ageMarkers.containsKey(l2)) {
            return;
        }
        long l3 = ChunkPos.getPackedX((long)l2);
        long l4 = ChunkPos.getPackedZ((long)l2);
        for (Long l5 : this.ageMarkers.keySet()) {
            long l6;
            long l7 = (long)ChunkPos.getPackedX((long)l5) - l3;
            if (l7 * l7 + (l6 = (long)ChunkPos.getPackedZ((long)l5) - l4) * l6 >= 576L) continue;
            return;
        }
        this.ageMarkers.put(l2, string);
        this.lastAgeMarkTime = System.currentTimeMillis();
        this.ageNotifyReason = string;
        this.lastNotifyNanos = System.nanoTime();
    }

    private a scanAgeChunk(WorldChunk worldChunk2, int n2, int n3, int n4, int n5) {
        BlockState blockState2;
        a a2 = new a();
        try {
            java.util.Map<BlockPos, BlockEntity> blockEntities = worldChunk2.getBlockEntities();
            if (blockEntities != null) {
                for (BlockEntity blockEntity2 : blockEntities.values()) {
                    if (!(blockEntity2 instanceof BeehiveBlockEntity) || ((BeehiveBlockEntity)blockEntity2).getBeeCount() <= 0) continue;
                    blockState2 = this.mc.world.getBlockState(blockEntity2.getPos());
                    if (blockState2 == null || !blockState2.isOf(Blocks.BEE_NEST) && !blockState2.isOf(Blocks.BEEHIVE)) continue;
                    a2.beehive = true;
                    break;
                }
            }
        } catch (Throwable throwable) {
            // chunk changed while scanning, ignore
        }
        ChunkSection[] class_2826Array = worldChunk2.getSectionArray();
        if (class_2826Array == null) {
            return a2;
        }
        int n6 = worldChunk2.getBottomY();
        boolean bl2 = Math.max(Math.abs(n2 - n4), Math.abs(n3 - n5)) <= 7;
        for (int i2 = 0; i2 < class_2826Array.length; ++i2) {
            ChunkSection chunkSection2 = class_2826Array[i2];
            if (chunkSection2 == null || chunkSection2.isEmpty()) continue;
            int n7 = n6 + (i2 << 4);
            boolean bl3 = n7 + 16 <= 16;
            boolean bl4 = n7 + 16 > -1 && n7 <= 1;
            boolean bl5 = n7 + 16 > 0 && n7 <= 50;
            boolean bl6 = n7 + 16 > 0 && n7 <= 63;
            for (int i3 = 0; i3 < 16; ++i3) {
                for (int i4 = 0; i4 < 16; ++i4) {
                    int n8 = n7 + i4;
                    for (int i5 = 0; i5 < 16; ++i5) {
                        BlockState blockState3 = chunkSection2.getBlockState(i3, i4, i5);
                        Block block2 = blockState3.getBlock();
                        if (block2 == Blocks.TALL_SEAGRASS) {
                            if (a2.tallSeagrass < 75) {
                                ++a2.tallSeagrass;
                            }
                            if (bl3 && a2.seagrass < 70) {
                                ++a2.seagrass;
                            }
                        } else if (block2 == Blocks.SEAGRASS && bl3 && a2.seagrass < 70) {
                            ++a2.seagrass;
                        }
                        if (block2 == Blocks.REPEATER) {
                            if (a2.repeaterBlocks < 3) {
                                ++a2.repeaterBlocks;
                            }
                            if (a2.activeRepeaters < 3 && Boolean.TRUE.equals(blockState3.get((Property)RepeaterBlock.POWERED))) {
                                ++a2.activeRepeaters;
                            }
                        }
                        if (!a2.light && bl4 && n8 >= -1 && n8 <= 1 && this.isAgeLight(block2)) {
                            a2.light = true;
                        }
                        if (bl2 && a2.lichenKey < 0L && block2 == Blocks.GLOW_LICHEN) {
                            double d2 = (double)((n2 << 4) + i3) + 0.5;
                            double d3 = (double)((n3 << 4) + i5) + 0.5;
                            List<AbstractClientPlayerEntity> list = this.mc.world.getPlayers();
                            if (list != null) {
                                for (AbstractClientPlayerEntity otherPlayer : list) {
                                    double d4;
                                    double d5;
                                    if (otherPlayer == this.mc.player || a2.lichenKey >= 0L || !((d5 = otherPlayer.getX() - d2) * d5 + (d4 = otherPlayer.getZ() - d3) * d4 <= 12544.0)) continue;
                                    a2.lichenKey = ChunkPos.toLong((int)n2, (int)n3);
                                }
                            }
                        }
                        if (a2.cobbled < 3 && bl5 && n8 >= 0 && n8 <= 50 && block2 == Blocks.COBBLED_DEEPSLATE) {
                            ++a2.cobbled;
                        }
                        if (a2.rotated < 3 && bl6 && n8 >= 0 && n8 <= 63 && block2 == Blocks.DEEPSLATE && this.isRotatedDeepslate(blockState3)) {
                            ++a2.rotated;
                        }
                        if (a2.vine < 150 && block2 == Blocks.VINE) {
                            ++a2.vine;
                        }
                        if (!bl3 || a2.flowers >= 6 || !blockState3.isIn(BlockTags.FLOWERS)) continue;
                        ++a2.flowers;
                    }
                }
            }
            if (a2.tallSeagrass >= 75) break;
        }
        return a2;
    }

    private boolean isAgeLight(Block block2) {
        return block2 == Blocks.JACK_O_LANTERN || block2 == Blocks.GLOWSTONE || block2 == Blocks.SEA_LANTERN || block2 == Blocks.TORCH || block2 == Blocks.END_ROD || block2 == Blocks.REDSTONE_LAMP || block2 == Blocks.LANTERN || block2 == Blocks.CAMPFIRE || block2 == Blocks.SOUL_TORCH || block2 == Blocks.SOUL_WALL_TORCH || block2 == Blocks.SOUL_LANTERN || block2 == Blocks.SHROOMLIGHT || block2 == Blocks.CRYING_OBSIDIAN || block2 == Blocks.SOUL_CAMPFIRE || block2 == Blocks.OCHRE_FROGLIGHT || block2 == Blocks.VERDANT_FROGLIGHT || block2 == Blocks.PEARLESCENT_FROGLIGHT || block2 == Blocks.WALL_TORCH;
    }

    private static boolean isSnowyBiome(RegistryEntry<?> entry) {
        String path = entry.getKey().map(key -> key.getValue().getPath()).orElse("");
        return path.contains("frozen") || path.contains("snowy") || path.contains("ice") || path.contains("grove")
            || path.contains("slopes") || path.contains("peaks") || path.contains("cold");
    }

    private Long findPolarBear() {
        try {
            Box searchBox = this.mc.player.getBoundingBox().expand(48.0, 128.0, 48.0);
            List<Entity> list = this.mc.world.getOtherEntities((Entity)this.mc.player, searchBox, entity2 -> entity2 instanceof PolarBearEntity);
            if (list == null || list.size() < 2) {
                return null;
            }
            for (Entity entity3 : list) {
                BlockPos blockPos2 = entity3.getBlockPos();
                boolean bl2 = false;
                try {
                    RegistryEntry<?> registryEntry2 = this.mc.world.getBiome(blockPos2);
                    if (registryEntry2 != null && (isSnowyBiome(registryEntry2))) {
                        bl2 = true;
                    }
                } catch (Throwable throwable) {
                    // empty catch block
                }
                if (bl2) {
                    return ChunkPos.toLong((int)(blockPos2.getX() >> 4), (int)(blockPos2.getZ() >> 4));
                }
                int n2 = 0;
                for (int i2 = -3; i2 <= 3; ++i2) {
                    for (int i3 = -3; i3 <= 3; ++i3) {
                        Block block2 = this.mc.world.getBlockState(blockPos2.add(i2, 0, i3)).getBlock();
                        if (block2 != Blocks.ICE && block2 != Blocks.PACKED_ICE && block2 != Blocks.BLUE_ICE && block2 != Blocks.SNOW_BLOCK && block2 != Blocks.POWDER_SNOW) continue;
                        ++n2;
                    }
                }
                if (n2 < 5) continue;
                return ChunkPos.toLong((int)(blockPos2.getX() >> 4), (int)(blockPos2.getZ() >> 4));
            }
        } catch (Throwable throwable) {
            // empty catch block
        }
        return null;
    }

    private boolean isRotatedDeepslate(BlockState blockState2) {
        try {
            if (!blockState2.contains(Properties.AXIS)) {
                return false;
            }
            return blockState2.get(Properties.AXIS) != Direction.Axis.Y;
        } catch (Throwable throwable) {
            return false;
        }
    }

    private void renderAgeMarkers(Render3DEvent render3DEvent) {
        if (this.mc.world == null || this.mc.player == null) {
            return;
        }
        int n2 = this.mc.player.getBlockPos().getX() >> 4;
        int n3 = this.mc.player.getBlockPos().getZ() >> 4;
        for (Map.Entry<Long, String> entry : this.ageMarkers.entrySet()) {
            long l2 = entry.getKey();
            int n4 = (int)l2;
            int n5 = (int)(l2 >> 32);
            if (Math.max(Math.abs(n4 - n2), Math.abs(n5 - n3)) > (Integer)this.renderRadius.get() || this.mc.world.getChunkManager().getWorldChunk(n4, n5) == null) continue;
            this.renderGoldBox(render3DEvent, n4, n5);
        }
    }

    private void renderGoldBox(Render3DEvent render3DEvent, int n2, int n3) {
        SettingColor settingColor = (SettingColor)this.ogColor.get();
        double d2 = (Double)this.yMin.get();
        double d3 = Math.min(320.0, d2 + (Double)this.boxHeight.get());
        if (d3 <= d2) {
            return;
        }
        double d4 = n2 << 4;
        double d5 = d4 + 16.0;
        double d6 = n3 << 4;
        double d7 = d6 + 16.0;
        double d8 = System.currentTimeMillis();
        double d9 = 0.5 + 0.5 * Math.sin(d8 * 0.0015);
        int n4 = Math.max(15, Math.min(255, (int)((double)settingColor.a * 0.9 * (0.7 + 0.3 * d9))));
        int n5 = Math.max(6, (int)((double)settingColor.a * 0.16));
        int n6 = Math.max(6, (int)((double)settingColor.a * 0.32));
        Color color = new Color(settingColor.r, settingColor.g, settingColor.b, n4);
        Color color2 = new Color(settingColor.r, settingColor.g, settingColor.b, n5);
        Color color3 = new Color(settingColor.r, settingColor.g, settingColor.b, n6);
        render3DEvent.renderer.quad(d4, d2, d6, d5, d2, d6, d5, d2, d7, d4, d2, d7, color3, color3, color3, color3);
        render3DEvent.renderer.quad(d4, d3, d6, d4, d3, d7, d5, d3, d7, d5, d3, d6, color3, color3, color3, color3);
        render3DEvent.renderer.quad(d4, d2, d6, d5, d2, d6, d5, d3, d6, d4, d3, d6, color2, color2, color2, color2);
        render3DEvent.renderer.quad(d5, d2, d6, d5, d2, d7, d5, d3, d7, d5, d3, d6, color2, color2, color2, color2);
        render3DEvent.renderer.quad(d5, d2, d7, d4, d2, d7, d4, d3, d7, d5, d3, d7, color2, color2, color2, color2);
        render3DEvent.renderer.quad(d4, d2, d7, d4, d2, d6, d4, d3, d6, d4, d3, d7, color2, color2, color2, color2);
        this.boxEdges(render3DEvent, d4, d5, d2, d3, d6, d7, color);
        if (((Boolean)this.sheen.get()).booleanValue()) {
            double d10 = d8 * 0.001 * (Double)this.sheenSpeed.get();
            for (int i2 = 0; i2 < 16; ++i2) {
                double d11 = d4 + (double)i2;
                double d12 = d11 + 1.0;
                double d13 = ((double)i2 + 0.5) / 16.0;
                double d14 = (Math.sin(Math.PI * 2 * d13 - d10 * 2.0) + 1.0) * 0.5;
                int n7 = (int)((double)n6 * 0.5 + d14 * 150.0);
                if (n7 <= 0) continue;
                Color color4 = new Color(255, Math.min(255, settingColor.g + 50), Math.min(255, settingColor.b + 20), Math.min(255, n7));
                render3DEvent.renderer.quad(d11, d3, d6, d12, d3, d6, d12, d3, d7, d11, d3, d7, color4, color4, color4, color4);
            }
        }
        if (((Boolean)this.sparkles.get()).booleanValue()) {
            this.renderSparkles(render3DEvent, n2, n3, d4, d6, d2, d3, d8);
        }
    }

    @EventHandler
    private void onRender(Render3DEvent render3DEvent) {
        if (this.mode.get() == b.AgeExploiter) {
            this.renderAgeMarkers(render3DEvent);
            return;
        }
        if (this.currentKey == -1L) {
            return;
        }
        if (this.mc.world == null || this.mc.player == null) {
            return;
        }
        int n2 = (int)this.currentKey;
        int n3 = (int)(this.currentKey >> 32);
        int n4 = this.mc.player.getBlockPos().getX() >> 4;
        int n5 = this.mc.player.getBlockPos().getZ() >> 4;
        if (Math.max(Math.abs(n2 - n4), Math.abs(n3 - n5)) > (Integer)this.renderRadius.get()) {
            return;
        }
        if (this.mc.world.getChunkManager().getWorldChunk(n2, n3) == null) {
            return;
        }
        this.renderGoldBox(render3DEvent, n2, n3);
    }

    private void renderSparkles(Render3DEvent render3DEvent, int n2, int n3, double d2, double d3, double d4, double d5, double d6) {
        int n4 = (Integer)this.sparkleCount.get();
        SettingColor settingColor = (SettingColor)this.sparkleColor.get();
        Random random = new Random((long)n2 * -7046029254386353131L ^ (long)n3 * -8796714882961330635L);
        for (int i2 = 0; i2 < n4; ++i2) {
            double d7 = d2 + random.nextDouble() * 16.0;
            double d8 = d3 + random.nextDouble() * 16.0;
            double d9 = d4 + random.nextDouble() * (d5 - d4);
            double d10 = random.nextDouble() * Math.PI * 2.0;
            double d11 = 0.5 + 0.5 * Math.sin(d6 * 0.0025 + d10);
            int n5 = (int)((double)settingColor.a * d11 * d11);
            if (n5 <= 12) continue;
            Color color = new Color(settingColor.r, settingColor.g, settingColor.b, n5);
            double d12 = 0.45;
            render3DEvent.renderer.line(d7 - d12, d9, d8, d7 + d12, d9, d8, color);
            render3DEvent.renderer.line(d7, d9 - d12, d8, d7, d9 + d12, d8, color);
            render3DEvent.renderer.line(d7, d9, d8 - d12, d7, d9, d8 + d12, color);
        }
    }

    @EventHandler
    private void onNotifyHud(Render2DEvent render2DEvent) {
        if (!((Boolean)this.notifyShow.get()).booleanValue() || this.lastNotifyNanos == 0L) {
            return;
        }
        if (this.mc == null || this.mc.player == null || this.mc.world == null) {
            return;
        }
        long l2 = System.nanoTime();
        long l3 = (l2 - this.lastNotifyNanos) / 1000000L;
        double d2 = (Double)this.notifyMs.get();
        if (l3 < 0L || l3 >= (long)d2) {
            return;
        }
        try {
            int n2;
            int n3;
            double d3;
            double d4;
            double d5;
            int n4;
            int n5;
            double d6;
            double d7;
            double d8;
            double d9;
            double d10 = (double)l3 / d2;
            double d11 = d9 = d10 > 0.8 ? 255.0 * (1.0 - (d10 - 0.8) / 0.2) : 255.0;
            if (d9 <= 0.0) {
                return;
            }
            double d12 = (double)this.mc.getWindow().getFramebufferWidth() / 2.0;
            String string = this.mode.get() == b.AgeExploiter && this.ageNotifyReason != null ? "Age Exploiter: " + this.ageNotifyReason : "OG Chunk Spotted";
            double d13 = 48.0;
            double d14 = 24.0;
            double d15 = 2.0;
            double d16 = 14.0;
            double d17 = 0.0;
            TextRenderer textRenderer = TextRenderer.get();
            if (textRenderer != null) {
                textRenderer.begin(d15);
                d17 = textRenderer.getWidth(string, string.length(), false);
                d16 = textRenderer.getHeight(false);
                textRenderer.end();
                d8 = 448.0;
                if (d17 > d8 && d17 > 0.0) {
                    d15 = Math.max(1.0, d15 * d8 / d17);
                    textRenderer.begin(d15);
                    d17 = textRenderer.getWidth(string, string.length(), false);
                    d16 = textRenderer.getHeight(false);
                    textRenderer.end();
                }
            }
            d8 = d13 + d17 + d14;
            double d18 = Math.max(44.0, d16 + 18.0);
            double d19 = d12 - d8 / 2.0;
            double d20 = (Double)this.notifyY.get();
            SettingColor settingColor = (SettingColor)this.ogColor.get();
            double d21 = System.currentTimeMillis();
            Renderer2D.COLOR.begin();
            int n6 = 22;
            for (int i2 = 0; i2 < n6; ++i2) {
                double d22 = d20 + d18 * (double)i2 / (double)n6;
                double d23 = d20 + d18 * (double)(i2 + 1) / (double)n6;
                d7 = (double)i2 / (double)(n6 - 1);
                d6 = (1.0 - d7) * 0.22;
                int n7 = Math.min(255, (int)((double)settingColor.r + (double)(255 - settingColor.r) * d6));
                int n8 = Math.min(255, (int)((double)settingColor.g + (double)(255 - settingColor.g) * d6));
                int n9 = Math.min(255, (int)((double)settingColor.b + (double)(255 - settingColor.b) * d6));
                n5 = (int)((double)settingColor.a * (1.0 - d7 * 0.55) * d9 / 255.0);
                Renderer2D.COLOR.quad(d19, d22, d8, d23 - d22, new Color(n7, n8, n9, n5));
            }
            if (((Boolean)this.sheen.get()).booleanValue()) {
                double d24 = d21 * 0.001 * (Double)this.sheenSpeed.get();
                n4 = 30;
                for (int i3 = 0; i3 < n4; ++i3) {
                    d5 = d19 + d8 * (double)i3 / (double)n4;
                    d4 = d19 + d8 * (double)(i3 + 1) / (double)n4;
                    d3 = ((double)i3 + 0.5) / (double)n4;
                    double d25 = (Math.sin(Math.PI * 2 * d3 - d24 * 2.0) + 1.0) * 0.5;
                    n5 = (int)(d9 * 0.5 + d25 * 130.0);
                    if (n5 <= 0) continue;
                    int n10 = Math.min(255, settingColor.r + 40);
                    n3 = Math.min(255, settingColor.g + 45);
                    n2 = Math.min(255, settingColor.b + 20);
                    Renderer2D.COLOR.quad(d5, d20 + 1.0, Math.max(1.0, d4 - d5), 3.0, new Color(n10, n3, n2, Math.min(255, n5)));
                }
            }
            if (((Boolean)this.sparkles.get()).booleanValue()) {
                SettingColor settingColor2 = (SettingColor)this.sparkleColor.get();
                int n11 = Math.min((Integer)this.sparkleCount.get(), 20);
                for (n4 = 0; n4 < n11; ++n4) {
                    double d26 = OGChunkFinder.hrand(n4 * 3 + 1);
                    d7 = OGChunkFinder.hrand(n4 * 3 + 2);
                    d6 = d19 + 8.0 + d26 * (d8 - 16.0);
                    double d27 = d20 + 8.0 + d7 * (d18 - 16.0);
                    double d28 = OGChunkFinder.hrand(n4 * 5 + 3) * Math.PI * 2.0;
                    double d29 = 0.5 + 0.5 * Math.sin(d21 * 0.0025 + d28);
                    n2 = (int)((double)settingColor2.a * d29 * d29);
                    if (n2 <= 14) continue;
                    Color color = new Color(settingColor2.r, settingColor2.g, settingColor2.b, n2);
                    double d30 = 2.4;
                    Renderer2D.COLOR.line(d6 - d30, d27, d6 + d30, d27, color);
                    Renderer2D.COLOR.line(d6, d27 - d30, d6, d27 + d30, color);
                }
            }
            double d31 = d19 + 27.0;
            double d32 = d20 + d18 / 2.0;
            d5 = Math.toRadians(18.0 * (d21 / 1000.0));
            d4 = 11.0;
            d3 = 5.2;
            double[] dArray = new double[10];
            double[] dArray2 = new double[10];
            for (n5 = 0; n5 < 5; ++n5) {
                double d33 = d5 + Math.toRadians((double)n5 * 72.0);
                dArray[n5 * 2] = d31 + Math.cos(d33) * d4;
                dArray2[n5 * 2] = d32 + Math.sin(d33) * d4;
                double d34 = d33 + Math.toRadians(36.0);
                dArray[n5 * 2 + 1] = d31 + Math.cos(d34) * d3;
                dArray2[n5 * 2 + 1] = d32 + Math.sin(d34) * d3;
            }
            SettingColor settingColor3 = (SettingColor)this.notifyAccent.get();
            Color color = new Color(settingColor3.r, settingColor3.g, settingColor3.b, Math.max(20, Math.min(255, (int)d9)));
            this.fillPolygon2D(dArray, dArray2, 10, color);
            for (n3 = 0; n3 < 10; ++n3) {
                int n12 = (n3 + 1) % 10;
                Renderer2D.COLOR.line(dArray[n3], dArray2[n3], dArray[n12], dArray2[n12], color);
            }
            Renderer2D.COLOR.render();
            TextRenderer textRenderer2 = TextRenderer.get();
            if (textRenderer2 == null) {
                return;
            }
            int n13 = Math.max(20, Math.min(255, (int)d9));
            textRenderer2.begin(d15);
            textRenderer2.render(string, d19 + d13, d20 + d18 / 2.0 - d16 / 2.0, new Color(settingColor3.r, settingColor3.g, settingColor3.b, n13), true);
            textRenderer2.end();
        } catch (Throwable throwable) {
            // empty catch block
        }
    }

    private static double hrand(long l2) {
        double d2 = Math.sin((double)l2 * 12.9898) * 43758.5453;
        return d2 - Math.floor(d2);
    }

    private void fillPolygon2D(double[] dArray, double[] dArray2, int n2, Color color) {
        double d2 = Double.MAX_VALUE;
        double d3 = -1.7976931348623157E308;
        for (int i2 = 0; i2 < n2; ++i2) {
            if (dArray2[i2] < d2) {
                d2 = dArray2[i2];
            }
            if (!(dArray2[i2] > d3)) continue;
            d3 = dArray2[i2];
        }
        double[] dArray3 = new double[n2];
        for (int i3 = (int)Math.floor(d2); i3 <= (int)Math.ceil(d3); ++i3) {
            int n3;
            double d4 = (double)i3 + 0.5;
            int n4 = 0;
            for (n3 = 0; n3 < n2; ++n3) {
                boolean bl2;
                int n5 = n3;
                int n6 = (n3 + 1) % n2;
                boolean bl3 = dArray2[n5] <= d4;
                boolean bl4 = bl2 = dArray2[n6] <= d4;
                if (bl3 == bl2) continue;
                double d5 = (d4 - dArray2[n5]) / (dArray2[n6] - dArray2[n5]);
                dArray3[n4++] = dArray[n5] + d5 * (dArray[n6] - dArray[n5]);
            }
            this.sort2D(dArray3, n4);
            n3 = 0;
            while (n3 + 1 < n4) {
                Renderer2D.COLOR.line(dArray3[n3], d4, dArray3[n3 + 1], d4, color);
                n3 += 2;
            }
        }
    }

    private void sort2D(double[] dArray, int n2) {
        for (int i2 = 1; i2 < n2; ++i2) {
            double d2 = dArray[i2];
            for (int i3 = i2 - 1; i3 >= 0 && dArray[i3] > d2; --i3) {
                dArray[i3 + 1] = dArray[i3];
            }
            dArray[i3 + 1] = d2;
        }
    }

    private void boxEdges(Render3DEvent render3DEvent, double d2, double d3, double d4, double d5, double d6, double d7, Color color) {
        render3DEvent.renderer.line(d2, d4, d6, d3, d4, d6, color);
        render3DEvent.renderer.line(d3, d4, d6, d3, d4, d7, color);
        render3DEvent.renderer.line(d3, d4, d7, d2, d4, d7, color);
        render3DEvent.renderer.line(d2, d4, d7, d2, d4, d6, color);
        render3DEvent.renderer.line(d2, d5, d6, d3, d5, d6, color);
        render3DEvent.renderer.line(d3, d5, d6, d3, d5, d7, color);
        render3DEvent.renderer.line(d3, d5, d7, d2, d5, d7, color);
        render3DEvent.renderer.line(d2, d5, d7, d2, d5, d6, color);
        render3DEvent.renderer.line(d2, d4, d6, d2, d5, d6, color);
        render3DEvent.renderer.line(d3, d4, d6, d3, d5, d6, color);
        render3DEvent.renderer.line(d3, d4, d7, d3, d5, d7, color);
        render3DEvent.renderer.line(d2, d4, d7, d2, d5, d7, color);
    }

    public static enum b {
        Legacy,
        AgeExploiter;

    }

    private static final class a {
        int tallSeagrass;
        int activeRepeaters;
        int repeaterBlocks;
        int cobbled;
        int rotated;
        int vine;
        int seagrass;
        int flowers;
        boolean light;
        boolean beehive;
        long lichenKey = -1L;

        private a() {
        }
    }
}

