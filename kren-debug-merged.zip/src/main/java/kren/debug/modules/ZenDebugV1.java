/* Renamed for source analysis. Original archive path: com/example/addon/modules/bc.java
 * Display name: Zen Debug V1
 * Confidence: High confidence: flagged chunk markers and RTP/kick options.
 * This extracted module may require original addon dependencies to compile.
 */
/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  meteordevelopment.meteorclient.events.packets.PacketEvent$Receive
 *  meteordevelopment.meteorclient.events.render.Render3DEvent
 *  meteordevelopment.meteorclient.events.world.TickEvent$Pre
 *  meteordevelopment.meteorclient.gui.GuiTheme
 *  meteordevelopment.meteorclient.gui.widgets.WWidget
 *  meteordevelopment.meteorclient.gui.widgets.containers.WVerticalList
 *  meteordevelopment.meteorclient.gui.widgets.pressable.WButton
 *  meteordevelopment.meteorclient.settings.BoolSetting$Builder
 *  meteordevelopment.meteorclient.settings.ColorSetting$Builder
 *  meteordevelopment.meteorclient.settings.DoubleSetting$Builder
 *  meteordevelopment.meteorclient.settings.IntSetting$Builder
 *  meteordevelopment.meteorclient.settings.Setting
 *  meteordevelopment.meteorclient.settings.SettingGroup
 *  meteordevelopment.meteorclient.settings.StringSetting$Builder
 *  meteordevelopment.meteorclient.systems.modules.Module
 *  meteordevelopment.meteorclient.utils.player.ChatUtils
 *  meteordevelopment.meteorclient.utils.render.color.Color
 *  meteordevelopment.meteorclient.utils.render.color.SettingColor
 *  meteordevelopment.orbit.EventHandler
 */
package kren.debug.modules;

import kren.debug.KrenDebug;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.widgets.WWidget;
import meteordevelopment.meteorclient.gui.widgets.containers.WVerticalList;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.text.Text;
import net.minecraft.network.packet.s2c.play.ChunkDataS2CPacket;
import net.minecraft.network.packet.s2c.play.LightUpdateS2CPacket;
import net.minecraft.client.toast.SystemToast;
import net.minecraft.client.toast.ToastManager;
import net.minecraft.text.MutableText;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.network.packet.s2c.play.LightData;

public class ZenDebugV1
extends Module {
    private static final int INTAKE_MAX_PER_TICK = 4096;
    private static final int WORLD_MIN_Y = -64;
    private static final int ALERT_MAX_Y = 184;
    private static final int BASE_DETECT_CEILING_Y = 62;
    private static final long NOTIFY_MS = 3000L;
    private static final Path DISCONNECTED_CHUNKS_PATH = Path.of("peace_debug_disconnected_chunks.txt", new String[0]);
    private static final Map<Long, Long> DISCONNECTED_CHUNKS = new ConcurrentHashMap<Long, Long>();
    private static final String[] REGIONS = new String[]{"/rtp asia", "/rtp eu central", "/rtp eu west", "/rtp eu oceania", "/rtp east", "/rtp west"};
    private final SettingGroup sgGeneral;
    private final SettingGroup sgRender;
    private final SettingGroup sgAlerts;
    private final SettingGroup sgRtp;
    private final Setting<SettingColor> flagColor;
    private final Setting<Double> fadeDuration;
    private final Setting<Integer> renderRadius;
    private final Setting<Double> markerY;
    private final Setting<Double> plateHeight;
    private final Setting<Boolean> kickOnFlag;
    private final Setting<Boolean> rtpEnabled;
    private final Setting<String> rtpCommand;
    private final Setting<Double> rtpDelay;
    private final Setting<Boolean> rtpRegion;
    private final List<String> queue = new ArrayList<String>();
    private long lastSent;
    private final ConcurrentLinkedQueue<c> intakeQueue = new ConcurrentLinkedQueue();
    private final Map<Long, b> snapshots = new ConcurrentHashMap<Long, b>();
    private final Map<Long, Long> detected = new ConcurrentHashMap<Long, Long>();
    private final Map<Long, Long> testUntil = new ConcurrentHashMap<Long, Long>();
    private ClientWorld lastWorld;

    public ZenDebugV1() {
        super(KrenDebug.CATEGORY, "zen-debug-v1", "");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgRender = this.settings.createGroup("Render");
        this.sgAlerts = this.settings.createGroup("Alerts");
        this.sgRtp = this.settings.createGroup("RTP");
        this.flagColor = this.sgGeneral.add(((new ColorSetting.Builder().name("flag-color")).description("Color of the plate and its effects.")).defaultValue(new SettingColor(230, 40, 40, 210)).build());
        this.fadeDuration = this.sgRender.add(((new DoubleSetting.Builder().name("fade-duration")).description("How long flagged chunks take to fade in and back out, in seconds.")).defaultValue(3.0).min(0.1).max(10.0).sliderRange(0.1, 10.0).build());
        this.renderRadius = this.sgRender.add((((new IntSetting.Builder().name("render-radius")).description("How many chunks around you to draw flagged plates for.")).defaultValue(16)).min(4).max(48).build());
        this.markerY = this.sgRender.add(((new DoubleSetting.Builder().name("marker-y")).description("Y level of the bottom of the highlight boxes.")).defaultValue(64.0).min(-64.0).max(320.0).build());
        this.plateHeight = this.sgRender.add(((new DoubleSetting.Builder().name("plate-height")).description("Vertical height of the highlight boxes.")).defaultValue(1.0).min(0.05).max(4.0).build());
        this.kickOnFlag = this.sgAlerts.add((((new BoolSetting.Builder().name("kick-on-flag")).description("Disconnect immediately when a new flag is spotted.")).defaultValue(false)).build());
        this.rtpEnabled = this.sgRtp.add((((new BoolSetting.Builder().name("auto-rtp")).description("Automatically runs the RTP command every so often so you keep wandering.")).defaultValue(false)).build());
        this.rtpCommand = this.sgRtp.add((((new StringSetting.Builder().name("command")).description("The command run on each interval when rtp-to-random-region is off.")).defaultValue("/rtp")).build());
        this.rtpDelay = this.sgRtp.add(((new DoubleSetting.Builder().name("delay")).description("Delay between /rtp commands in seconds.")).defaultValue(1.0).min(0.05).max(10.0).sliderRange(0.05, 10.0).decimalPlaces(2).build());
        this.rtpRegion = this.sgRtp.add((((new BoolSetting.Builder().name("rtp-to-random-region")).description("Cycle through every region in a random order instead of a plain /rtp.")).defaultValue(false)).build());
    }

    public void onActivate() {
        this.intakeQueue.clear();
        this.snapshots.clear();
        this.detected.clear();
        this.testUntil.clear();
        this.lastSent = 0L;
        this.queue.clear();
        this.lastWorld = null;
    }

    public void onDeactivate() {
        this.intakeQueue.clear();
        this.snapshots.clear();
        this.detected.clear();
        this.testUntil.clear();
        this.lastSent = 0L;
        this.queue.clear();
        this.lastWorld = null;
    }

    public WWidget getWidget(GuiTheme guiTheme) {
        WVerticalList wVerticalList = guiTheme.verticalList();
        WButton wButton = (WButton)wVerticalList.add((WWidget)guiTheme.button("Test Flag (15s)")).expandX().widget();
        wButton.tooltip = "Places a preview flag plate on your current chunk for 15 seconds.";
        wButton.action = this::runTestFlag;
        return wVerticalList;
    }

    private void runTestFlag() {
        if (this.mc.player == null || this.mc.world == null) {
            ChatUtils.warning((String)"Join a world before testing the flag.", (Object[])new Object[0]);
            return;
        }
        if (!this.isActive()) {
            this.toggle();
        }
        int n2 = this.mc.player.getBlockPos().getX() >> 4;
        int n3 = this.mc.player.getBlockPos().getZ() >> 4;
        long l2 = ChunkPos.toLong((int)n2, (int)n3);
        this.detected.put(l2, System.nanoTime());
        this.testUntil.put(l2, System.nanoTime() + 15000000000L);
        int n4 = (n2 << 4) + 8;
        int n5 = (n3 << 4) + 8;
        this.sendFlagChat(n4, n5, true);
        this.showToast(n4, n5);
    }

    @EventHandler
    private void onPacketReceive(PacketEvent.Receive receive) {
        if (this.mc.world == null || this.mc.player == null) {
            return;
        }
        if (receive.packet instanceof ChunkDataS2CPacket) {
            ChunkDataS2CPacket chunkDataS2CPacket2 = (ChunkDataS2CPacket)receive.packet;
            this.intakeQueue.offer(new c(chunkDataS2CPacket2.getChunkX(), chunkDataS2CPacket2.getChunkZ(), chunkDataS2CPacket2.getLightData()));
        } else if (receive.packet instanceof LightUpdateS2CPacket) {
            LightUpdateS2CPacket lightUpdateS2CPacket2 = (LightUpdateS2CPacket)receive.packet;
            this.intakeQueue.offer(new c(lightUpdateS2CPacket2.getChunkX(), lightUpdateS2CPacket2.getChunkZ(), lightUpdateS2CPacket2.getData()));
        }
    }

    @EventHandler
    private void onTick(TickEvent.Pre pre) {
        c c2;
        ClientWorld NarrationMessageBuilder = this.mc.world;
        if (NarrationMessageBuilder == null || this.mc.player == null) {
            this.intakeQueue.clear();
            return;
        }
        if (NarrationMessageBuilder != this.lastWorld) {
            this.snapshots.clear();
            this.detected.clear();
            this.testUntil.clear();
            this.intakeQueue.clear();
            this.lastWorld = NarrationMessageBuilder;
        }
        if (this.mc.player.getY() < 0.0) {
            this.intakeQueue.clear();
            this.tickRtp();
            return;
        }
        for (int i2 = 0; i2 < 4096 && (c2 = this.intakeQueue.poll()) != null; ++i2) {
            try {
                this.ingest(c2);
                continue;
            } catch (Throwable throwable) {
                // skip malformed light packet
            }
        }
        this.pruneSnapshots();
        this.tickRtp();
    }

    private void pruneSnapshots() {
        if (this.snapshots.size() <= 2048) {
            return;
        }
        int px = this.mc.player.getBlockPos().getX() >> 4;
        int pz = this.mc.player.getBlockPos().getZ() >> 4;
        for (Long key : this.snapshots.keySet()) {
            if (this.detected.containsKey(key)) continue;
            int cx = (int)key.longValue();
            int cz = (int)(key.longValue() >> 32);
            if (Math.abs(cx - px) > 32 || Math.abs(cz - pz) > 32) {
                this.snapshots.remove(key);
            }
        }
    }

    private void ingest(c c2) {
        if (c2.data == null) {
            return;
        }
        long l2 = ChunkPos.toLong((int)c2.chunkX, (int)c2.chunkZ);
        b b2 = this.snapshots.get(l2);
        if (b2 == null) {
            b2 = new b(c2.chunkX, c2.chunkZ, 0, -4);
            this.snapshots.put(l2, b2);
        }
        a.apply(c2.data, b2, c2.arrivalNanos);
        this.maybeAlert(c2.chunkX, c2.chunkZ, l2, b2);
    }

    private void maybeAlert(int n2, int n3, long l2, b b2) {
        if (!this.isActive()) {
            return;
        }
        if (this.detected.containsKey(l2)) {
            return;
        }
        for (int i2 = 1; i2 <= b2.sectionCount; ++i2) {
            if (i2 >= b2.sky.length) continue;
            int n4 = b2.bottomSectionY + i2 - 1;
            int n5 = n4 * 16 + 15;
            int n6 = n4 * 16;
            if (n5 < -64 || n6 > 184 || n5 >= 62 || b2.sky[i2] != d.ZEROED_PRESENT) continue;
            this.detected.put(l2, System.nanoTime());
            this.onChunkSpotted(n2, n3);
            return;
        }
    }

    private void onChunkSpotted(int n2, int n3) {
        long l2;
        int n4 = (n2 << 4) + 8;
        int n5 = (n3 << 4) + 8;
        this.sendFlagChat(n4, n5, false);
        this.showToast(n4, n5);
        if (((Boolean)this.kickOnFlag.get()).booleanValue() && !DISCONNECTED_CHUNKS.containsKey(l2 = ChunkPos.toLong((int)n2, (int)n3))) {
            DISCONNECTED_CHUNKS.put(l2, 0L);
            try {
                Files.writeString(DISCONNECTED_CHUNKS_PATH, (CharSequence)(l2 + System.lineSeparator()), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            } catch (Throwable throwable) {
                // empty catch block
            }
            ChatUtils.warning((String)"(Zen Debug V1) Kick-on-flag triggered. Saved coordinates and disconnecting.", (Object[])new Object[0]);
            String string = "(Zen Debug V1) Flag at " + n4 + ", " + n5;
            this.mc.execute(() -> this.mc.disconnect((Text)Text.literal((String)string)));
        }
    }

    private void sendFlagChat(int n2, int n3, boolean bl2) {
        MutableText mutableText2 = Text.literal((String)"\u00bb ZEN DEBUG ON FUCKIN TOP \u00ab").formatted(new Formatting[]{Formatting.RED, Formatting.BOLD});
        mutableText2 = mutableText2.append((Text)Text.literal((String)(bl2 ? "TEST FLAG" : "FLAG SPOTTED")).formatted(new Formatting[]{Formatting.WHITE, Formatting.BOLD}));
        mutableText2 = mutableText2.append((Text)Text.literal((String)(n2 + ", " + n3)).formatted(Formatting.WHITE));
        ChatUtils.sendMsg((Text)mutableText2);
    }

    private void showToast(int n2, int n3) {
        MutableText mutableText2 = Text.literal((String)"ZEN DEBUG ON FUCKIN TOP").formatted(Formatting.WHITE);
        MutableText mutableText3 = Text.literal((String)(n2 + ", " + n3)).formatted(Formatting.WHITE);
        SystemToast.add((ToastManager)this.mc.getToastManager(), new SystemToast.Type(5000L), (Text)mutableText2, (Text)mutableText3);
    }

    private void tickRtp() {
        double d2;
        if (!((Boolean)this.rtpEnabled.get()).booleanValue()) {
            return;
        }
        long l2 = System.currentTimeMillis();
        if ((double)(l2 - this.lastSent) < (d2 = ((Double)this.rtpDelay.get()).doubleValue()) * 1000.0) {
            return;
        }
        this.lastSent = l2;
        if (((Boolean)this.rtpRegion.get()).booleanValue()) {
            if (this.queue.isEmpty()) {
                Collections.addAll(this.queue, REGIONS);
                Collections.shuffle(this.queue);
            }
            try {
                ChatUtils.sendPlayerMsg((String)this.queue.remove(0));
            } catch (Throwable throwable) {
                // empty catch block
            }
            return;
        }
        String string = (String)this.rtpCommand.get();
        if (string != null && !string.trim().isEmpty()) {
            try {
                ChatUtils.sendPlayerMsg((String)string.trim());
            } catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    @EventHandler
    private void onRender(Render3DEvent render3DEvent) {
        if (this.mc.world == null || this.mc.player == null) {
            return;
        }
        int n2 = this.mc.player.getBlockPos().getX() >> 4;
        int n3 = this.mc.player.getBlockPos().getZ() >> 4;
        int n4 = (Integer)this.renderRadius.get();
        SettingColor settingColor = (SettingColor)this.flagColor.get();
        double d2 = (Double)this.fadeDuration.get() * 1000.0;
        long l2 = System.nanoTime();
        Iterator<Map.Entry<Long, Long>> iterator = this.testUntil.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<Long, Long> entry = iterator.next();
            if (l2 < entry.getValue()) continue;
            iterator.remove();
            this.detected.remove(entry.getKey());
            this.snapshots.remove(entry.getKey());
        }
        double d3 = (Double)this.markerY.get();
        double d4 = d3 + (Double)this.plateHeight.get();
        Iterator<Map.Entry<Long, Long>> iterator2 = this.detected.entrySet().iterator();
        while (iterator2.hasNext()) {
            double d5;
            double d6;
            double d7;
            double d8;
            double d9;
            double d10;
            double d11;
            double d12;
            double d13;
            double d14;
            double d15;
            double d16;
            double d17;
            double d18;
            double d19;
            Color color;
            double d20;
            double d21;
            double d22;
            double d23;
            int n5;
            double d24;
            double d25;
            double d26;
            double d27;
            double d28;
            double d29;
            int n6;
            double d30;
            Map.Entry<Long, Long> entry = iterator2.next();
            long l3 = entry.getKey();
            int n7 = (int)l3;
            int n8 = (int)(l3 >> 32);
            if (n7 == n2 && n8 == n3 && this.mc.player.getBlockPos().getY() <= -1) {
                if (this.testUntil.containsKey(l3)) continue;
                iterator2.remove();
                this.snapshots.remove(l3);
                continue;
            }
            if (Math.abs(n7 - n2) > n4 || Math.abs(n8 - n3) > n4) continue;
            double d31 = (double)(l2 - entry.getValue()) / d2;
            double d32 = d31 <= 0.0 ? 0.0 : (d30 = d31 >= 1.0 ? 1.0 : d31);
            if (d30 <= 0.0) continue;
            double d33 = d30 * d30 * (3.0 - 2.0 * d30);
            int n9 = Math.max(15, Math.min(255, (int)((double)settingColor.a * 0.85)));
            int n10 = Math.max(6, Math.min(255, (int)((double)settingColor.a * 0.55)));
            Color color2 = new Color(settingColor.r, settingColor.g, settingColor.b, (int)((double)n9 * d33));
            double d34 = n7 << 4;
            double d35 = n8 << 4;
            double d36 = d34 + 8.0;
            double d37 = d35 + 8.0;
            int n11 = 48;
            int n12 = 5;
            double d38 = 8.0;
            Color color3 = new Color(settingColor.r, settingColor.g, settingColor.b, Math.max(6, Math.min(255, (int)((double)n10 * d33))));
            for (n6 = 0; n6 < n11; ++n6) {
                d29 = Math.PI * 2 * (double)n6 / (double)n11;
                d28 = Math.PI * 2 * (double)(n6 + 1) / (double)n11;
                d27 = d36 + Math.cos(d29) * d38;
                d26 = d37 + Math.sin(d29) * d38;
                d25 = d36 + Math.cos(d28) * d38;
                d24 = d37 + Math.sin(d28) * d38;
                render3DEvent.renderer.quad(d36, d4, d37, d27, d4, d26, d25, d4, d24, d36, d4, d37, color3, color3, color3, color3);
                render3DEvent.renderer.quad(d27, d4, d26, d25, d4, d24, d25, d3, d24, d27, d3, d26, color3, color3, color3, color3);
            }
            for (n6 = 0; n6 < n11 - 1; ++n6) {
                d29 = Math.PI * 2 * (double)n6 / (double)n11;
                d28 = Math.PI * 2 * (double)(n6 + 1) / (double)n11;
                d27 = d36 + Math.cos(d29) * d38;
                d26 = d37 + Math.sin(d29) * d38;
                d25 = d36 + Math.cos(d28) * d38;
                d24 = d37 + Math.sin(d28) * d38;
                render3DEvent.renderer.line(d27, d4, d26, d25, d4, d24, new Color(color2.r, color2.g, color2.b, (int)((double)n9 * d33 * 0.8)));
            }
            double d39 = (double)System.currentTimeMillis() * 0.0015;
            int n13 = 24;
            d28 = 0.3;
            for (n5 = 0; n5 < n13; ++n5) {
                d23 = Math.PI * 2 * (double)n5 / (double)n13 + d39 * 0.4;
                d22 = Math.cos(d23);
                d21 = Math.sin(d23);
                double d40 = d38 - 0.15;
                double d41 = d38 - 1.2;
                double d42 = -d21 * d28 * 0.5;
                d20 = d22 * d28 * 0.5;
                color = new Color(color2.r, color2.g, color2.b, (int)((double)n9 * d33));
                render3DEvent.renderer.quad(d36 + d22 * d40 + d42, d4, d37 + d21 * d40 + d20, d36 + d22 * d40 - d42, d4, d37 + d21 * d40 - d20, d36 + d22 * d41 - d42, d4, d37 + d21 * d41 - d20, d36 + d22 * d41 + d42, d4, d37 + d21 * d41 + d20, color, color, color, color);
            }
            n5 = 100;
            for (int i2 = 0; i2 < n5 - 1; ++i2) {
                d26 = (double)i2 / (double)n5;
                d25 = (double)(i2 + 1) / (double)n5;
                d24 = d39 + d26 * Math.PI * 6.0;
                d19 = d39 + d25 * Math.PI * 6.0;
                d18 = 1.5 + 5.0 * d26;
                d17 = 1.5 + 5.0 * d25;
                d16 = d36 + Math.cos(d24) * d18;
                d15 = d37 + Math.sin(d24) * d18;
                d14 = d36 + Math.cos(d19) * d17;
                d13 = d37 + Math.sin(d19) * d17;
                int n14 = (int)(d33 * 220.0 * (0.5 + 0.5 * (1.0 - d26)));
                render3DEvent.renderer.line(d16, d4, d15, d14, d4, d13, new Color(settingColor.r, settingColor.g, settingColor.b, n14));
            }
            d23 = 1.0;
            d22 = 0.45;
            d21 = d4;
            Color color4 = new Color(settingColor.r, settingColor.g, settingColor.b, Math.max(8, Math.min(255, (int)(d33 * 220.0))));
            for (int i3 = 0; i3 < n12 * 2; ++i3) {
                int n15 = (i3 + 1) % (n12 * 2);
                d18 = -1.5707963267948966 + (double)i3 * Math.PI / (double)n12 + d39 * 0.6;
                d17 = -1.5707963267948966 + (double)n15 * Math.PI / (double)n12 + d39 * 0.6;
                d16 = i3 % 2 == 0 ? d23 : d22;
                d15 = n15 % 2 == 0 ? d23 : d22;
                d14 = d36 + Math.cos(d18) * d16;
                d13 = d37 + Math.sin(d18) * d16;
                double d43 = d36 + Math.cos(d17) * d15;
                double d44 = d37 + Math.sin(d17) * d15;
                render3DEvent.renderer.line(d14, d21, d13, d43, d21, d44, color4);
            }
            d19 = (double)System.currentTimeMillis() * 0.001;
            int n16 = 8;
            long l4 = l3 * 2654435761L + 1013904223L;
            d20 = d33 * 200.0;
            color = new Color(settingColor.r, settingColor.g, settingColor.b, Math.max(10, Math.min(255, (int)d20)));
            for (int i4 = 0; i4 < n16; ++i4) {
                double d45;
                double d46;
                long l5 = l4 + (long)i4 * 7919L;
                double d47 = ZenDebugV1.hrand(l5 + 3L);
                double d48 = ZenDebugV1.hrand(l5 + 70001L);
                double d49 = ZenDebugV1.hrand(l5 + 13L) * Math.PI * 2.0;
                double d50 = ZenDebugV1.hrand(l5 + 101L) * Math.PI * 2.0;
                d12 = 0.15 + ZenDebugV1.hrand(l5 + 151L) * 0.15;
                d11 = 0.5 + d47 * 7.5;
                d10 = d48 * Math.PI * 2.0;
                d9 = d36 + Math.cos(d10) * d11;
                double d51 = d37 + Math.sin(d10) * d11;
                double d52 = d3 + 2.0 + d50 / (Math.PI * 2) * 4.0;
                d8 = d9 + Math.sin(d19 * d12 + d49) * 2.4;
                d7 = d51 + Math.sin(d19 * d12 * 0.8 + d49 * 1.7) * 1.8;
                d6 = d52 + Math.sin(d19 * d12 * 1.3 + d49 * 2.3) * 0.8;
                d5 = 0.38;
                double d53 = 0.16;
                double d54 = this.mc.player.getX();
                double d55 = d8 - d54;
                double d56 = Math.sqrt(d55 * d55 + (d46 = d7 - (d45 = this.mc.player.getZ())) * d46);
                if (d56 < 0.001) {
                    d56 = 0.001;
                }
                double d57 = d55 / d56;
                double d58 = d46 / d56;
                double d59 = -d58;
                double d60 = d57;
                for (int i5 = 0; i5 < n12 * 2; ++i5) {
                    double d61 = (double)i5 * Math.PI / (double)n12;
                    double d62 = i5 % 2 == 0 ? d5 : d53;
                    double d63 = i5 % 2 == 0 ? d53 : d5;
                    double d64 = d8 + d59 * Math.sin(d61) * d62;
                    double d65 = d7 + d60 * Math.sin(d61) * d62;
                    double d66 = d6 + Math.cos(d61) * d62;
                    double d67 = d8 + d59 * Math.sin(d61 + Math.PI / (double)n12) * d63;
                    double d68 = d7 + d60 * Math.sin(d61 + Math.PI / (double)n12) * d63;
                    double d69 = d6 + Math.cos(d61 + Math.PI / (double)n12) * d63;
                    render3DEvent.renderer.quad(d64, d66, d65, d8, d6, d7, d8, d6, d7, d67, d69, d68, color);
                }
            }
            d15 = (double)System.currentTimeMillis() * 8.0E-4 + (double)(l3 & 0x1FL);
            d14 = d3 + 1.5;
            d13 = 8.0;
            double d70 = 1.1;
            int n17 = 28;
            int n18 = Math.max(8, Math.min(255, (int)(d33 * 210.0)));
            Color color5 = new Color(settingColor.r, settingColor.g, settingColor.b, n18);
            for (int i6 = 0; i6 < n17; ++i6) {
                double d71 = Math.PI * 2 * (double)i6 / (double)n17;
                double d72 = Math.PI * 2 * (double)(i6 + 1) / (double)n17;
                double d73 = d14 + d70 * Math.cos(d71 - d15);
                double d74 = d14 + d70 * Math.cos(d72 - d15);
                render3DEvent.renderer.line(d36 + Math.cos(d71) * d13, d73, d37 + Math.sin(d71) * d13, d36 + Math.cos(d72) * d13, d74, d37 + Math.sin(d72) * d13, color5);
            }
            d12 = -((double)System.currentTimeMillis() * 8.0E-4) + (double)(l3 >>> 8 & 0x1FL);
            d11 = d3 + 1.5;
            d10 = 8.0;
            d9 = 1.1;
            int n19 = 28;
            int n20 = Math.max(8, Math.min(255, (int)(d33 * 210.0)));
            Color color6 = new Color(settingColor.r, settingColor.g, settingColor.b, n20);
            for (int i7 = 0; i7 < n19; ++i7) {
                d8 = Math.PI * 2 * (double)i7 / (double)n19;
                d7 = Math.PI * 2 * (double)(i7 + 1) / (double)n19;
                d6 = d11 + d9 * Math.cos(d8 - d12);
                d5 = d11 + d9 * Math.cos(d7 - d12);
                render3DEvent.renderer.line(d36 + Math.cos(d8) * d10, d6, d37 + Math.sin(d8) * d10, d36 + Math.cos(d7) * d10, d5, d37 + Math.sin(d7) * d10, color6);
            }
        }
    }

    private static double hrand(long l2) {
        double d2 = Math.sin((double)l2 * 12.9898) * 43758.5453;
        return d2 - Math.floor(d2);
    }

    private static final class c {
        final int chunkX;
        final int chunkZ;
        final LightData data;
        final long arrivalNanos = System.nanoTime();

        c(int n2, int n3, LightData lightData2) {
            this.chunkX = n2;
            this.chunkZ = n3;
            this.data = lightData2;
        }
    }

    private static final class b {
        static final int MAX_SECTIONS = 24;
        final int chunkX;
        final int chunkZ;
        final int bottomSectionY;
        d[] sky;
        d[] block;
        long[] skyUpdatedNanos;
        long[] blockUpdatedNanos;
        int sectionCount;

        b(int n2, int n3, int n4, int n5) {
            this.chunkX = n2;
            this.chunkZ = n3;
            this.bottomSectionY = n5;
            this.grow(n4);
        }

        void grow(int n2) {
            int n3 = Math.max(n2, 1);
            d[] dArray = new d[n3];
            d[] dArray2 = new d[n3];
            long[] lArray = new long[n3];
            long[] lArray2 = new long[n3];
            for (int i2 = 0; i2 < n3; ++i2) {
                dArray[i2] = d.UNKNOWN;
                dArray2[i2] = d.UNKNOWN;
            }
            if (this.sky != null) {
                System.arraycopy(this.sky, 0, dArray, 0, Math.min(this.sectionCount, n3));
                System.arraycopy(this.block, 0, dArray2, 0, Math.min(this.sectionCount, n3));
                System.arraycopy(this.skyUpdatedNanos, 0, lArray, 0, Math.min(this.sectionCount, n3));
                System.arraycopy(this.blockUpdatedNanos, 0, lArray2, 0, Math.min(this.sectionCount, n3));
            }
            this.sky = dArray;
            this.block = dArray2;
            this.skyUpdatedNanos = lArray;
            this.blockUpdatedNanos = lArray2;
            this.sectionCount = n3;
        }
    }

    private static final class a {
        private a() {
        }

        static d classifyPayload(byte[] byArray) {
            if (byArray == null || byArray.length != 2048) {
                return d.UNKNOWN;
            }
            boolean bl2 = false;
            boolean bl3 = false;
            for (byte by : byArray) {
                if (by != 0) {
                    bl2 = true;
                }
                if (by == -1) continue;
                bl3 = true;
            }
            if (!bl2) {
                return d.ZEROED_PRESENT;
            }
            if (!bl3) {
                return d.UNIFORM_MAX;
            }
            return d.NORMAL;
        }

        static void apply(LightData lightData2, b b2, long l2) {
            int n2 = Math.max(Math.max(lightData2.getInitedSky().length(), lightData2.getUninitedSky().length()), Math.max(lightData2.getInitedBlock().length(), lightData2.getUninitedBlock().length()));
            if (n2 > b2.sectionCount) {
                b2.grow(Math.min(n2, 24));
            }
            a.applyTrack(lightData2.getInitedSky(), lightData2.getUninitedSky(), lightData2.getSkyNibbles(), b2.sky, b2.skyUpdatedNanos, l2);
            a.applyTrack(lightData2.getInitedBlock(), lightData2.getUninitedBlock(), lightData2.getBlockNibbles(), b2.block, b2.blockUpdatedNanos, l2);
        }

        private static void applyTrack(BitSet bitSet, BitSet bitSet2, List<byte[]> list, d[] dArray, long[] lArray, long l2) {
            int n2 = 0;
            for (int i2 = 0; i2 < dArray.length; ++i2) {
                if (bitSet.get(i2)) {
                    byte[] byArray = n2 < list.size() ? list.get(n2) : null;
                    ++n2;
                    dArray[i2] = a.classifyPayload(byArray);
                    lArray[i2] = l2;
                    continue;
                }
                if (!bitSet2.get(i2)) continue;
                dArray[i2] = d.EMPTY_MASK;
                lArray[i2] = l2;
            }
        }
    }

    private static enum d {
        NORMAL(0, 220, 0),
        EMPTY_MASK(255, 220, 0),
        ZEROED_PRESENT(255, 40, 40),
        UNIFORM_MAX(0, 220, 255),
        MISSING(140, 140, 140),
        UNKNOWN(80, 80, 80);

        private final int r;
        private final int g;
        private final int b;

        private d(int n3, int n4, int n5) {
            this.r = n3;
            this.g = n4;
            this.b = n5;
        }
    }
}

