/*
 * Sus Bypass V2 - source cleanup/fixes
 * NOTE: This is source-level only; compile and test against the exact Meteor
 * Client + Minecraft mappings used by the original addon.
 */
package kren.debug.modules;

import kren.debug.KrenDebug;
import meteordevelopment.meteorclient.events.game.SendMessageEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.network.ClientPlayerEntity;

public class SusBypassV2
extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Boolean> autoToggle;
    private final Setting<Boolean> rotationFix;
    private final Setting<Integer> maxTurn;
    private final Setting<Boolean> aimFix;
    private final Setting<Double> jitter;
    private final Setting<Integer> jitterTicks;
    private final Setting<Boolean> loopMode;
    private final Setting<Integer> loopInterval;
    private final Setting<Integer> activeSeconds;
    private int rotationFixed;
    private int aimJittered;
    private int tickCounter;
    private float lastYaw;
    private float lastPitch;
    private boolean firstTick;
    private boolean autoOff;

    public SusBypassV2() {
        super(KrenDebug.CATEGORY, "sus-bypass-v2", "");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.autoToggle = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("auto-toggle")).description("When enabled, attempts activation when the player is below Y=0. Note: inactive modules do not receive tick events in standard Meteor, so this option requires an always-subscribed listener in the host addon to work while disabled.")).defaultValue((Object)false)).build());
        this.rotationFix = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("rotation-fix")).description("Limit large yaw/pitch changes per tick locally. This does not guarantee anti-cheat bypass.")).defaultValue((Object)true)).build());
        this.maxTurn = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("max-turn")).description("Maximum degrees your head may turn in one tick while rotation-fix is on. Lower = less suspicious, higher = snappier aim.")).defaultValue((Object)90)).min(20).max(180).sliderRange(30, 180).visible(() -> (Boolean)this.rotationFix.get())).build());
        this.aimFix = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("aim-fix")).description("Add a tiny random look adjustment while nearly stationary. This does not guarantee anti-cheat bypass.")).defaultValue((Object)true)).build());
        this.jitter = this.sgGeneral.add((Setting)((DoubleSetting.Builder)((DoubleSetting.Builder)((DoubleSetting.Builder)new DoubleSetting.Builder().name("jitter")).description("Micro-shake strength in degrees added every few ticks while aim-fix is on.")).defaultValue(0.05).min(0.01).max(1.0).sliderRange(0.01, 0.5).visible(() -> (Boolean)this.aimFix.get())).build());
        this.jitterTicks = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("jitter-ticks")).description("How many ticks between each micro-shake.")).defaultValue((Object)4)).min(2).max(20).sliderRange(2, 10).visible(() -> (Boolean)this.aimFix.get())).build());
        this.loopMode = this.sgGeneral.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("loop-mode")).description("Keep the module running and report local adjustments periodically. Off = run briefly, report local adjustments, then turn itself off.")).defaultValue((Object)false)).build());
        this.loopInterval = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("loop-interval")).description("Seconds between each local adjustment report while loop-mode is on.")).defaultValue((Object)60)).min(10).max(600).sliderRange(30, 300).visible(() -> (Boolean)this.loopMode.get())).build());
        this.activeSeconds = this.sgGeneral.add((Setting)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)new IntSetting.Builder().name("active-seconds")).description("How long the module runs before reporting local adjustments and turning itself off when loop-mode is off.")).defaultValue((Object)5)).min(1).max(60).sliderRange(2, 30).visible(() -> (Boolean)this.loopMode.get() == false)).build());
        this.lastYaw = 0.0f;
        this.lastPitch = 0.0f;
        this.firstTick = true;
    }

    public void onActivate() {
        this.resetStats();
        this.firstTick = true;
        this.autoOff = false;
        if (((Boolean)this.loopMode.get()).booleanValue()) {
            ChatUtils.infoPrefix((String)"SusBypass", (String)("Active (loop) - local adjustments will be reported every (highlight)" + this.loopInterval.get() + "(default) seconds."), (Object[])new Object[0]);
        } else {
            ChatUtils.infoPrefix((String)"SusBypass", (String)("Active - local adjustments will be reported in (highlight)" + this.activeSeconds.get() + "(default) seconds."), (Object[])new Object[0]);
        }
    }

    public void onDeactivate() {
        if (this.autoOff) {
            this.autoOff = false;
            return;
        }
        if (this.rotationFixed + this.aimJittered > 0) {
            ChatUtils.infoPrefix((String)"SusBypass", (String)("Off - made (highlight)" + (this.rotationFixed + this.aimJittered) + "(default) local adjustments this session."), (Object[])new Object[0]);
        }
    }

    private void resetStats() {
        this.rotationFixed = 0;
        this.aimJittered = 0;
        this.tickCounter = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Pre pre) {
        float f2;
        if (this.mc.player == null) {
            return;
        }
        if (((Boolean)this.autoToggle.get()).booleanValue() && !this.isActive() && this.mc.player.getY() < 0.0) {
            this.toggle();
            return;
        }
        if (!this.isActive()) {
            return;
        }
        ++this.tickCounter;
        ClientPlayerEntity clientPlayerEntity2 = this.mc.player;
        float f3 = clientPlayerEntity2.headYaw;
        float f4 = clientPlayerEntity2.bodyYaw;
        if (this.firstTick) {
            this.lastYaw = f3;
            this.lastPitch = f4;
            this.firstTick = false;
            return;
        }
        float f5 = wrapDegrees(f3 - this.lastYaw);
        float f6 = wrapDegrees(f4 - this.lastPitch);
        if (((Boolean)this.rotationFix.get()).booleanValue()) {
            f2 = ((Integer)this.maxTurn.get()).intValue();
            boolean bl2 = false;
            if (Math.abs(f5) > f2) {
                clientPlayerEntity2.headYaw = this.lastYaw + Math.copySign(f2, f5);
                f5 = wrapDegrees(clientPlayerEntity2.headYaw - this.lastYaw);
                bl2 = true;
            }
            if (Math.abs(f6) > f2) {
                clientPlayerEntity2.bodyYaw = Math.max(-90.0f, Math.min(90.0f, this.lastPitch + Math.copySign(f2, f6)));
                f6 = wrapDegrees(clientPlayerEntity2.bodyYaw - this.lastPitch);
                bl2 = true;
            }
            if (bl2) {
                ++this.rotationFixed;
            }
        }
        if (((Boolean)this.aimFix.get()).booleanValue() && Math.abs(f5) < 0.5f && Math.abs(f6) < 0.5f && this.tickCounter % (Integer)this.jitterTicks.get() == 0) {
            f2 = (float)((Double)this.jitter.get()).doubleValue();
            clientPlayerEntity2.headYaw += (float)((Math.random() - 0.5) * 2.0 * (double)f2);
            clientPlayerEntity2.bodyYaw = Math.max(-90.0f, Math.min(90.0f, clientPlayerEntity2.bodyYaw + (float)((Math.random() - 0.5) * 2.0 * (double)f2)));
            ++this.aimJittered;
        }
        this.lastYaw = clientPlayerEntity2.headYaw;
        this.lastPitch = clientPlayerEntity2.bodyYaw;
        if (((Boolean)this.loopMode.get()).booleanValue()) {
            if (this.tickCounter % ((Integer)this.loopInterval.get() * 20) == 0) {
                this.reportFlags();
                this.resetStats();
            }
        } else if (this.tickCounter >= (Integer)this.activeSeconds.get() * 20) {
            this.reportFlags();
            this.autoOff = true;
            this.toggle();
        }
    }

    @EventHandler
    private void onSendMessage(SendMessageEvent sendMessageEvent) {
        if (sendMessageEvent.message == null || !sendMessageEvent.message.equals("#")) {
            return;
        }
        sendMessageEvent.cancel();
        this.reportFlags();
    }

    private void reportFlags() {
        ChatUtils.infoPrefix((String)"SusBypass", (String)("Local adjustments: (highlight)" + (this.rotationFixed + this.aimJittered) + "(default) total - ROTATION limited x" + this.rotationFixed + ", AIM x" + this.aimJittered), (Object[])new Object[0]);
    }

    private static float wrapDegrees(float f2) {
        return (f2 % 360.0f + 540.0f) % 360.0f - 180.0f;
    }
}

