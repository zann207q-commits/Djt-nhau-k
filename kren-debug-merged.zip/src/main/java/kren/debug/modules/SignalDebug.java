/* Renamed for source analysis. Original archive path: com/example/addon/modules/bg.java
 * Display name: Signal Debug
 * Confidence: High confidence: repeater/signal scan and notifications.
 * This extracted module may require original addon dependencies to compile.
 */
/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  meteordevelopment.meteorclient.events.render.Render3DEvent
 *  meteordevelopment.meteorclient.events.world.TickEvent$Post
 *  meteordevelopment.meteorclient.renderer.ShapeMode
 *  meteordevelopment.meteorclient.systems.modules.Module
 *  meteordevelopment.meteorclient.utils.player.ChatUtils
 *  meteordevelopment.meteorclient.utils.render.color.Color
 *  meteordevelopment.orbit.EventHandler
 */
package kren.debug.modules;

import kren.debug.KrenDebug;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.block.Blocks;
import net.minecraft.block.RepeaterBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.BlockState;
import net.minecraft.state.property.Property;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.block.entity.BeehiveBlockEntity;

public class SignalDebug
extends Module {
    private static final long FULL_SCAN_INTERVAL = 20000L;
    private static final long QUICK_SCAN_INTERVAL = 200L;
    private static final long COOLDOWN_MS = 50000L;
    private final ConcurrentHashMap<ChunkPos, String> foundChunks = new ConcurrentHashMap();
    private final AtomicBoolean scanning = new AtomicBoolean(false);
    private volatile ExecutorService executor;
    private long lastFullScanTime;
    private long lastQuickScanTime;
    private volatile long lastMarkTime;
    private volatile long lastNotifyTime;
    private volatile ChunkPos lastNotifyPos;
    private final AtomicBoolean quickScanning = new AtomicBoolean(false);

    public SignalDebug() {
        super(KrenDebug.CATEGORY, "signal-debug", "");
    }

    public void onActivate() {
        this.foundChunks.clear();
        this.lastFullScanTime = 0L;
        this.lastQuickScanTime = 0L;
        this.lastMarkTime = 0L;
        this.lastNotifyTime = 0L;
        this.lastNotifyPos = null;
        this.scanning.set(false);
        this.quickScanning.set(false);
    }

    public void onDeactivate() {
        this.foundChunks.clear();
        if (this.executor != null) {
            this.executor.shutdownNow();
            this.executor = null;
        }
        this.scanning.set(false);
        this.quickScanning.set(false);
    }

    @EventHandler
    private void onTick(TickEvent.Post post) {
        if (this.mc.world == null || this.mc.player == null) {
            return;
        }
        long l2 = System.currentTimeMillis();
        if (l2 - this.lastQuickScanTime >= 200L && !this.scanning.get() && this.quickScanning.compareAndSet(false, true)) {
            this.lastQuickScanTime = l2;
            this.quickRepeaterScan();
        }
        if (l2 - this.lastFullScanTime >= 20000L && this.scanning.compareAndSet(false, true)) {
            this.lastFullScanTime = l2;
            this.fullScan();
        }
    }

    private void quickRepeaterScan() {
        if (this.mc.world == null || this.mc.player == null) {
            this.quickScanning.set(false);
            return;
        }
        ArrayList<ChunkPos> arrayList = new ArrayList<ChunkPos>();
        ArrayList<WorldChunk> arrayList2 = new ArrayList<WorldChunk>();
        this.collectChunks(arrayList, arrayList2);
        this.getOrCreateExecutor("signal-debug-scan").submit(() -> {
            try {
                for (int i2 = 0; i2 < arrayList.size(); ++i2) {
                    if (this.countPoweredRepeaters((WorldChunk)arrayList2.get(i2)) < 3) continue;
                    this.foundChunks.clear();
                    this.foundChunks.put((ChunkPos)arrayList.get(i2), "repeater");
                    this.notifyDetected((ChunkPos)arrayList.get(i2));
                    return;
                }
            } catch (Throwable throwable) {
                // chunk changed under us, try again next scan
            } finally {
                this.quickScanning.set(false);
            }
        });
    }

    private void fullScan() {
        if (this.mc.world == null || this.mc.player == null) {
            this.scanning.set(false);
            return;
        }
        ArrayList<ChunkPos> arrayList = new ArrayList<ChunkPos>();
        ArrayList<WorldChunk> arrayList2 = new ArrayList<WorldChunk>();
        this.collectChunks(arrayList, arrayList2);
        this.getOrCreateExecutor("signal-debug-scan").submit(() -> {
            long l2 = System.currentTimeMillis();
            try {
                int n2;
                for (n2 = 0; n2 < arrayList.size(); ++n2) {
                    if (this.countPoweredRepeaters((WorldChunk)arrayList2.get(n2)) < 3) continue;
                    this.lastMarkTime = l2;
                    this.foundChunks.clear();
                    this.foundChunks.put((ChunkPos)arrayList.get(n2), "repeater");
                    this.notifyDetected((ChunkPos)arrayList.get(n2));
                    return;
                }
                for (n2 = 0; n2 < arrayList.size(); ++n2) {
                    String string;
                    boolean bl2;
                    WorldChunk worldChunk2 = (WorldChunk)arrayList2.get(n2);
                    boolean bl3 = this.checkHive(worldChunk2);
                    boolean bl4 = !bl3 && this.checkCobbledDeepslate(worldChunk2);
                    boolean bl5 = !bl3 && this.checkVines(worldChunk2);
                    boolean bl6 = !bl3 && !bl5 && this.checkSeagrass(worldChunk2);
                    boolean bl7 = bl2 = !bl3 && !bl5 && !bl6 && !bl4 && this.checkAnyRepeaters(worldChunk2);
                    if (!bl3 && !bl4 && !bl5 && !bl6 && !bl2) continue;
                    String string2 = string = bl2 ? "repeater" : "normal";
                    if ("repeater".equals(string)) {
                        this.lastMarkTime = l2;
                        this.foundChunks.clear();
                        this.foundChunks.put((ChunkPos)arrayList.get(n2), string);
                    } else if (l2 - this.lastMarkTime >= 50000L) {
                        this.lastMarkTime = l2;
                        this.foundChunks.clear();
                        this.foundChunks.put((ChunkPos)arrayList.get(n2), string);
                        this.notifyDetected((ChunkPos)arrayList.get(n2));
                    }
                    return;
                }
            } catch (Throwable throwable) {
                // chunk changed under us, next full scan will retry
            } finally {
                this.scanning.set(false);
            }
        });
    }

    private void collectChunks(List<ChunkPos> list, List<WorldChunk> list2) {
        ChunkPos chunkPos2 = this.mc.player.getChunkPos();
        int n2 = Math.min((Integer)this.mc.options.getViewDistance().getValue(), 8);
        for (int i2 = -n2; i2 <= n2; ++i2) {
            for (int i3 = -n2; i3 <= n2; ++i3) {
                ChunkPos chunkPos3 = new ChunkPos(chunkPos2.x + i2, chunkPos2.z + i3);
                WorldChunk worldChunk2 = this.mc.world.getChunkManager().getWorldChunk(chunkPos3.x, chunkPos3.z);
                if (worldChunk2 == null || worldChunk2.isEmpty()) continue;
                list.add(chunkPos3);
                list2.add(worldChunk2);
            }
        }
    }

    private int countPoweredRepeaters(WorldChunk worldChunk2) {
        int n2 = 0;
        for (ChunkSection chunkSection2 : worldChunk2.getSectionArray()) {
            if (chunkSection2 == null || chunkSection2.isEmpty() || !chunkSection2.hasAny(blockState2 -> blockState2.isOf(Blocks.REPEATER))) continue;
            for (int i2 = 0; i2 < 16; ++i2) {
                for (int i3 = 0; i3 < 16; ++i3) {
                    for (int i4 = 0; i4 < 16; ++i4) {
                        BlockState blockState3 = chunkSection2.getBlockState(i2, i3, i4);
                        if (!blockState3.isOf(Blocks.REPEATER) || !Boolean.TRUE.equals(blockState3.get((Property)RepeaterBlock.LOCKED)) || ++n2 < 3) continue;
                        return n2;
                    }
                }
            }
        }
        return n2;
    }

    private boolean checkHive(WorldChunk worldChunk2) {
        for (BlockEntity blockEntity2 : worldChunk2.getBlockEntities().values()) {
            if (!(blockEntity2 instanceof BeehiveBlockEntity) || ((BeehiveBlockEntity)blockEntity2).getBeeCount() <= 0) continue;
            return true;
        }
        return false;
    }

    private boolean checkCobbledDeepslate(WorldChunk worldChunk2) {
        int n2;
        int n3 = 0;
        int n4 = worldChunk2.getBottomY();
        ChunkSection[] class_2826Array = worldChunk2.getSectionArray();
        for (int i2 = 0; i2 < class_2826Array.length && (n2 = n4 + i2 * 16) <= 20; ++i2) {
            ChunkSection chunkSection2;
            if (n2 + 16 < 0 || (chunkSection2 = class_2826Array[i2]) == null || chunkSection2.isEmpty() || !chunkSection2.hasAny(blockState2 -> blockState2.isOf(Blocks.COBBLED_DEEPSLATE))) continue;
            for (int i3 = 0; i3 < 16; ++i3) {
                for (int i4 = 0; i4 < 16; ++i4) {
                    for (int i5 = 0; i5 < 16; ++i5) {
                        int n5 = n2 + i4;
                        if (n5 < 0 || n5 > 20 || !chunkSection2.getBlockState(i3, i4, i5).isOf(Blocks.COBBLED_DEEPSLATE) || ++n3 < 50) continue;
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private boolean checkVines(WorldChunk worldChunk2) {
        int n2 = 0;
        for (ChunkSection chunkSection2 : worldChunk2.getSectionArray()) {
            if (chunkSection2 == null || chunkSection2.isEmpty() || !chunkSection2.hasAny(blockState2 -> blockState2.isOf(Blocks.VINE))) continue;
            for (int i2 = 0; i2 < 16; ++i2) {
                for (int i3 = 0; i3 < 16; ++i3) {
                    for (int i4 = 0; i4 < 16; ++i4) {
                        if (!chunkSection2.getBlockState(i2, i3, i4).isOf(Blocks.VINE) || ++n2 < 150) continue;
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private boolean checkSeagrass(WorldChunk worldChunk2) {
        int n2;
        int n3 = 0;
        int n4 = worldChunk2.getBottomY();
        ChunkSection[] class_2826Array = worldChunk2.getSectionArray();
        for (int i2 = 0; i2 < class_2826Array.length && (n2 = n4 + i2 * 16) <= 70; ++i2) {
            ChunkSection chunkSection2 = class_2826Array[i2];
            if (chunkSection2 == null || chunkSection2.isEmpty() || !chunkSection2.hasAny(blockState2 -> blockState2.isOf(Blocks.SEAGRASS) || blockState2.isOf(Blocks.TALL_SEAGRASS))) continue;
            for (int i3 = 0; i3 < 16; ++i3) {
                for (int i4 = 0; i4 < 16; ++i4) {
                    for (int i5 = 0; i5 < 16; ++i5) {
                        BlockState blockState3 = chunkSection2.getBlockState(i3, i4, i5);
                        if (!blockState3.isOf(Blocks.SEAGRASS) && !blockState3.isOf(Blocks.TALL_SEAGRASS) || ++n3 < 30) continue;
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private boolean checkAnyRepeaters(WorldChunk worldChunk2) {
        int n2 = 0;
        for (ChunkSection chunkSection2 : worldChunk2.getSectionArray()) {
            if (chunkSection2 == null || chunkSection2.isEmpty() || !chunkSection2.hasAny(blockState2 -> blockState2.isOf(Blocks.REPEATER))) continue;
            for (int i2 = 0; i2 < 16; ++i2) {
                for (int i3 = 0; i3 < 16; ++i3) {
                    for (int i4 = 0; i4 < 16; ++i4) {
                        if (!chunkSection2.getBlockState(i2, i3, i4).isOf(Blocks.REPEATER) || ++n2 < 3) continue;
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private void notifyDetected(ChunkPos chunkPos2) {
        long l2 = System.currentTimeMillis();
        if (chunkPos2.equals((Object)this.lastNotifyPos) && l2 - this.lastNotifyTime < 5000L) {
            return;
        }
        this.lastNotifyPos = chunkPos2;
        this.lastNotifyTime = l2;
        this.mc.execute(() -> ChatUtils.info((String)"Signal Debug Detected", (Object[])new Object[0]));
    }

    private ExecutorService getOrCreateExecutor(String string) {
        if (this.executor == null || this.executor.isShutdown()) {
            this.executor = Executors.newSingleThreadExecutor(runnable -> {
                Thread thread = new Thread(runnable, string);
                thread.setDaemon(true);
                return thread;
            });
        }
        return this.executor;
    }

    @EventHandler
    private void onRender3D(Render3DEvent render3DEvent) {
        if (this.mc.world == null || this.foundChunks.isEmpty()) {
            return;
        }
        for (Map.Entry<ChunkPos, String> entry : this.foundChunks.entrySet()) {
            ChunkPos chunkPos2 = entry.getKey();
            double d2 = (double)chunkPos2.x * 16.0;
            double d3 = (double)chunkPos2.z * 16.0;
            double d4 = d2 + 16.0;
            double d5 = d3 + 16.0;
            // Pillar: spans the whole world height instead of a flat plate at Y=63.
            double d6 = this.mc.world.getBottomY();
            double d7 = d6 + this.mc.world.getHeight();
            if ("repeater".equals(entry.getValue())) {
                render3DEvent.renderer.box(d2, d6, d3, d4, d7, d5, this.rainbowColor(30), this.rainbowColor(180), ShapeMode.Both, 0);
                double d8 = 8.0;
                render3DEvent.renderer.box(d2 + d8, d6, d3 + d8, d4 - d8, d7, d5 - d8, this.rainbowColor(60), this.rainbowColor(255), ShapeMode.Both, 0);
                continue;
            }
            render3DEvent.renderer.box(d2, d6, d3, d4, d7, d5, this.rainbowColor(50), this.rainbowColor(255), ShapeMode.Both, 0);
        }
    }

    private meteordevelopment.meteorclient.utils.render.color.Color rainbowColor(int n2) {
        float f2 = (float)(System.currentTimeMillis() % 3600L) / 3600.0f;
        int n3 = Color.HSBtoRGB(f2, 1.0f, 1.0f);
        return new meteordevelopment.meteorclient.utils.render.color.Color(n3 >> 16 & 0xFF, n3 >> 8 & 0xFF, n3 & 0xFF, n2);
    }
}

