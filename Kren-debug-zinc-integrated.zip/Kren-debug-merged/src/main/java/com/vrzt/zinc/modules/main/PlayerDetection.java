package com.vrzt.zinc.modules.main;

import com.vrzt.zinc.ZincToast;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;

import com.vrzt.zinc.ZincAddon;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.ModuleListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringListSetting;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;

public class PlayerDetection extends Module {
   private final SettingGroup sgGeneral;
   private final SettingGroup sgwhitelist;
   private final SettingGroup sgwebhook;
   private final SettingGroup sgPanicPay;
   private static final Set<String> PERMANENT_WHITELIST = new HashSet(Arrays.asList("FreeCamera"));
   private final Setting<List<String>> userWhitelist;
   private final Setting<List<Module>> modulesToToggle;
   private final Setting<Boolean> enableWebhook;
   private final Setting<String> webhookUrl;
   private final Setting<Boolean> selfPing;
   private final Setting<String> discordId;
   private final Setting<Boolean> enableDisconnect;
   private final Setting<Mode> notificationMode;
   private final Setting<Boolean> toggleonplayer;
   private final Setting<Boolean> enablePanicPay;
   private final Setting<String> panicPayTarget;
   private final Setting<String> panicPayAmount;
   private final Set<String> detectedPlayers;
   private final HttpClient httpClient;

   public PlayerDetection() {
      super(ZincAddon.Zinc, "PlayerDetection", "Detects when players are in the world");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgwhitelist = this.settings.createGroup("Whitelist");
      this.sgwebhook = this.settings.createGroup("Webhook");
      this.sgPanicPay = this.settings.createGroup("Panic Pay");
      this.userWhitelist = this.sgwhitelist.add(((StringListSetting.Builder)((StringListSetting.Builder)((StringListSetting.Builder)(new StringListSetting.Builder()).name("User Whitelist")).description("List of player names to ignore")).defaultValue(new ArrayList())).build());
      this.modulesToToggle = this.sgGeneral.add(((ModuleListSetting.Builder)((ModuleListSetting.Builder)((ModuleListSetting.Builder)(new ModuleListSetting.Builder()).name("Modules To Toggle")).description("Select modules to toggle when a non-whitelisted player is detected")).defaultValue(new ArrayList())).build());
      this.enableWebhook = this.sgwebhook.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("Webhook")).description("Send webhook notifications when players are detected")).defaultValue(false)).build());
      SettingGroup var10001 = this.sgwebhook;
      StringSetting.Builder var10002 = (StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)(new StringSetting.Builder()).name("Webhook URL")).description("Discord webhook URL")).defaultValue("");
      Setting var10003 = this.enableWebhook;
      Objects.requireNonNull(var10003);
      this.webhookUrl = var10001.add(((StringSetting.Builder)var10002.visible(var10003::get)).build());
      var10001 = this.sgwebhook;
      BoolSetting.Builder var4 = (BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("Self Ping")).description("Ping yourself in the webhook message")).defaultValue(false);
      var10003 = this.enableWebhook;
      Objects.requireNonNull(var10003);
      this.selfPing = var10001.add(((BoolSetting.Builder)var4.visible(var10003::get)).build());
      this.discordId = this.sgwebhook.add(((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)(new StringSetting.Builder()).name("Discord ID")).description("Your Discord user ID for pinging")).defaultValue("")).visible(() -> (Boolean)this.enableWebhook.get() && (Boolean)this.selfPing.get())).build());
      this.enableDisconnect = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("Disconnect")).description("Automatically disconnect when players are detected")).defaultValue(true)).build());
      this.notificationMode = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("notification-mode")).description("How to notify when players are detected")).defaultValue(PlayerDetection.Mode.Both)).build());
      this.toggleonplayer = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("Toggle when a player is detected")).description("Automatically toggles THIS module when a player is detected")).defaultValue(true)).build());
      this.enablePanicPay = this.sgPanicPay.add(((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("Enable Panic Pay")).defaultValue(false)).build());
      var10001 = this.sgPanicPay;
      StringSetting.Builder var5 = (StringSetting.Builder)((StringSetting.Builder)(new StringSetting.Builder()).name("Target Player")).defaultValue("");
      var10003 = this.enablePanicPay;
      Objects.requireNonNull(var10003);
      this.panicPayTarget = var10001.add(((StringSetting.Builder)var5.visible(var10003::get)).build());
      var10001 = this.sgPanicPay;
      var5 = (StringSetting.Builder)((StringSetting.Builder)(new StringSetting.Builder()).name("Amount")).defaultValue("");
      var10003 = this.enablePanicPay;
      Objects.requireNonNull(var10003);
      this.panicPayAmount = var10001.add(((StringSetting.Builder)var5.visible(var10003::get)).build());
      this.detectedPlayers = new HashSet();
      this.httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10L)).build();
   }

   @EventHandler
   private void onRender3D(Render3DEvent event) {
      if (this.mc.player != null && this.mc.world != null) {
         Set<String> currentPlayers = new HashSet();
         String currentPlayerName = this.mc.player.getName().getString();
         Set<String> fullWhitelist = new HashSet(PERMANENT_WHITELIST);
         fullWhitelist.addAll((Collection)this.userWhitelist.get());

         for(PlayerEntity player : this.mc.world.getPlayers()) {
            if (player != this.mc.player) {
               String playerName = player.getName().getString();
               if (!playerName.equals(currentPlayerName) && !fullWhitelist.contains(playerName)) {
                  currentPlayers.add(playerName);
               }
            }
         }

         if (!currentPlayers.isEmpty() && !currentPlayers.equals(this.detectedPlayers)) {
            this.detectedPlayers.clear();
            this.detectedPlayers.addAll(currentPlayers);
            this.handlePlayerDetection(currentPlayers);
         } else if (currentPlayers.isEmpty()) {
            this.detectedPlayers.clear();
         }

      }
   }

   private void handlePlayerDetection(Set<String> players) {
      String playerList = String.join(", ", players);
      if (this.notificationMode.get() == PlayerDetection.Mode.Toast || this.notificationMode.get() == PlayerDetection.Mode.Both) {
         ZincToast.show(Text.literal("Player Detection"), Text.literal(playerList));
      }

      if (this.notificationMode.get() == PlayerDetection.Mode.Chat || this.notificationMode.get() == PlayerDetection.Mode.Both) {
         this.info("Player(s) detected: (highlight)%s", new Object[]{playerList});
      }

      ChatUtils.sendPlayerMsg("#stop");

      for(Module m : (List)this.modulesToToggle.get()) {
         m.toggle();
      }

      if ((Boolean)this.enablePanicPay.get()) {
         String target = ((String)this.panicPayTarget.get()).trim();
         String amount = ((String)this.panicPayAmount.get()).trim();
         if (!target.isEmpty() && !amount.isEmpty()) {
            ChatUtils.sendPlayerMsg(String.format("/pay %s %s", target, amount));
         }
      }

      if ((Boolean)this.enableWebhook.get()) {
         this.sendWebhookNotification(players);
      }

      if ((Boolean)this.toggleonplayer.get()) {
         this.toggle();
      }

      if ((Boolean)this.enableDisconnect.get()) {
         CompletableFuture.runAsync(() -> {
            try {
               Thread.sleep(500L);
               this.disconnectFromServer(playerList);
            } catch (InterruptedException var3) {
               Thread.currentThread().interrupt();
            }

         });
      }

   }

   private void sendWebhookNotification(Set<String> players) {
      String url = ((String)this.webhookUrl.get()).trim();
      if (!url.isEmpty()) {
         CompletableFuture.runAsync(() -> {
            try {
               String playerList = String.join(", ", players);
               String serverInfo = this.mc.getCurrentServerEntry() != null ? this.mc.getCurrentServerEntry().address : "Unknown Server";
               String messageContent = (Boolean)this.selfPing.get() && !((String)this.discordId.get()).isEmpty() ? String.format("<@%s>", ((String)this.discordId.get()).trim()) : "";
               String jsonPayload = String.format("{\"content\":\"%s\",\"embeds\":[{\"title\":\"\ud83d\udea8 Player Detection Alert\",\"color\":15158332,\"fields\":[{\"name\":\"Players\",\"value\":\"%s\",\"inline\":false},{\"name\":\"Server\",\"value\":\"%s\",\"inline\":true},{\"name\":\"Time\",\"value\":\"<t:%d:R>\",\"inline\":true}]}]}", messageContent, playerList, serverInfo, System.currentTimeMillis() / 1000L);
               HttpRequest request = HttpRequest.newBuilder().uri(URI.create(url)).header("Content-Type", "application/json").POST(BodyPublishers.ofString(jsonPayload)).build();
               this.httpClient.send(request, BodyHandlers.ofString());
            } catch (Exception var8) {
            }

         });
      }
   }

   private void disconnectFromServer(String playerList) {
      if (this.mc.getNetworkHandler() != null) {
         this.mc.getNetworkHandler().getConnection().disconnect(Text.literal("Player(s) detected: " + playerList));
      }

   }

   public void onActivate() {
      this.detectedPlayers.clear();
   }

   public void onDeactivate() {
      this.detectedPlayers.clear();
   }

   public String getInfoString() {
      return this.detectedPlayers.isEmpty() ? null : String.valueOf(this.detectedPlayers.size());
   }



   public static enum Mode {
      Chat,
      Toast,
      Both;

      // $FF: synthetic method
      private static Mode[] $values() {
         return new Mode[]{Chat, Toast, Both};
      }
   }
}
