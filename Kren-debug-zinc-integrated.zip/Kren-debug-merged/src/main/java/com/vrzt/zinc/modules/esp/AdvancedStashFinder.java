package com.vrzt.zinc.modules.esp;

import com.vrzt.zinc.ZincToast;
import com.vrzt.zinc.ZincUtil;
import net.minecraft.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.block.entity.DispenserBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.HopperBlockEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.text.Text;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.vrzt.zinc.ZincAddon;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.WindowScreen;
import meteordevelopment.meteorclient.gui.widgets.WWidget;
import meteordevelopment.meteorclient.gui.widgets.containers.WTable;
import meteordevelopment.meteorclient.gui.widgets.containers.WVerticalList;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import meteordevelopment.meteorclient.gui.widgets.pressable.WMinus;
import meteordevelopment.meteorclient.pathing.PathManagers;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StorageBlockListSetting;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.orbit.EventHandler;

public class AdvancedStashFinder extends Module {
   private static final Gson GSON = (new GsonBuilder()).setPrettyPrinting().create();
   private final SettingGroup sgGeneral;
   private final SettingGroup sgWebhook;
   private final Setting<List<BlockEntityType<?>>> storageBlocks;
   private final Setting<Integer> minimumStorageCount;
   private final Setting<Integer> minimumDistance;
   private final Setting<Boolean> criticalSpawner;
   private final Setting<Boolean> disconnectOnFind;
   private final Setting<Boolean> sendNotifications;
   private final Setting<Mode> notificationMode;
   private final Setting<Boolean> enableWebhook;
   private final Setting<String> webhookUrl;
   private final Setting<Boolean> selfPing;
   private final Setting<String> discordId;
   public List<Chunk> chunks;
   private final HttpClient httpClient;

   public AdvancedStashFinder() {
      super(ZincAddon.esp, "AdvancedStashFinder", "Advanced stash finder with webhook support and auto-disconnect.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgWebhook = this.settings.createGroup("Webhook");
      this.storageBlocks = this.sgGeneral.add(((StorageBlockListSetting.Builder)((StorageBlockListSetting.Builder)(new StorageBlockListSetting.Builder()).name("storage-blocks")).description("Select the storage blocks to search for.")).defaultValue(StorageBlockListSetting.STORAGE_BLOCKS).build());
      this.minimumStorageCount = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("minimum-storage-count")).description("The minimum amount of storage blocks in a chunk to record the chunk.")).defaultValue(4)).min(1).sliderMin(1).sliderMax(1000).build());
      this.minimumDistance = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("minimum-distance")).description("The minimum distance you must be from spawn to record a certain chunk.")).defaultValue(0)).min(0).sliderMax(10000).build());
      this.criticalSpawner = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("critical-spawner")).description("Mark chunk as stash even if only a single spawner is found.")).defaultValue(true)).build());
      this.disconnectOnFind = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("disconnect-on-base-find")).description("Automatically disconnect from the server when a base is found.")).defaultValue(false)).build());
      this.sendNotifications = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("notifications")).description("Sends Minecraft notifications when new stashes are found.")).defaultValue(true)).build());
      SettingGroup var10001 = this.sgGeneral;
      EnumSetting.Builder var10002 = (EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("notification-mode")).description("The mode to use for notifications.")).defaultValue(AdvancedStashFinder.Mode.Both);
      Setting var10003 = this.sendNotifications;
      Objects.requireNonNull(var10003);
      this.notificationMode = var10001.add(((EnumSetting.Builder)var10002.visible(var10003::get)).build());
      this.enableWebhook = this.sgWebhook.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("webhook")).description("Send webhook notifications when stashes are found")).defaultValue(false)).build());
      var10001 = this.sgWebhook;
      StringSetting.Builder var3 = (StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)(new StringSetting.Builder()).name("webhook-url")).description("Discord webhook URL")).defaultValue("");
      var10003 = this.enableWebhook;
      Objects.requireNonNull(var10003);
      this.webhookUrl = var10001.add(((StringSetting.Builder)var3.visible(var10003::get)).build());
      var10001 = this.sgWebhook;
      BoolSetting.Builder var4 = (BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("self-ping")).description("Ping yourself in the webhook message")).defaultValue(false);
      var10003 = this.enableWebhook;
      Objects.requireNonNull(var10003);
      this.selfPing = var10001.add(((BoolSetting.Builder)var4.visible(var10003::get)).build());
      this.discordId = this.sgWebhook.add(((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)(new StringSetting.Builder()).name("discord-id")).description("Your Discord user ID for pinging")).defaultValue("")).visible(() -> (Boolean)this.enableWebhook.get() && (Boolean)this.selfPing.get())).build());
      this.chunks = new ArrayList();
      this.httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10L)).build();
   }

   public void onActivate() {
      this.load();
   }

   @EventHandler
   private void onChunkData(ChunkDataEvent event) {
      double chunkXAbs = (double)Math.abs(ZincUtil.chunkX(event.chunk().getPos()) * 16);
      double chunkZAbs = (double)Math.abs(ZincUtil.chunkZ(event.chunk().getPos()) * 16);
      if (!(Math.sqrt(chunkXAbs * chunkXAbs + chunkZAbs * chunkZAbs) < (double)(Integer)this.minimumDistance.get())) {
         Chunk chunk = new Chunk(event.chunk().getPos());

         for(BlockEntity blockEntity : event.chunk().getBlockEntities().values()) {
            BlockEntityType<?> type = blockEntity.getType();
            if (blockEntity instanceof MobSpawnerBlockEntity) {
               ++chunk.spawners;
            } else if (((List)this.storageBlocks.get()).contains(type)) {
               if (blockEntity instanceof ChestBlockEntity) {
                  ++chunk.chests;
               } else if (blockEntity instanceof BarrelBlockEntity) {
                  ++chunk.barrels;
               } else if (blockEntity instanceof ShulkerBoxBlockEntity) {
                  ++chunk.shulkers;
               } else if (blockEntity instanceof EnderChestBlockEntity) {
                  ++chunk.enderChests;
               } else if (blockEntity instanceof AbstractFurnaceBlockEntity) {
                  ++chunk.furnaces;
               } else if (blockEntity instanceof DispenserBlockEntity) {
                  ++chunk.dispensersDroppers;
               } else if (blockEntity instanceof HopperBlockEntity) {
                  ++chunk.hoppers;
               }
            }
         }

         boolean isStash = false;
         boolean isCriticalSpawner = false;
         String detectionReason = "";
         if ((Boolean)this.criticalSpawner.get() && chunk.spawners > 0) {
            isStash = true;
            isCriticalSpawner = true;
            detectionReason = "Spawner(s) detected (Critical mode)";
         } else if (chunk.getTotal() >= (Integer)this.minimumStorageCount.get()) {
            isStash = true;
            detectionReason = "Storage threshold reached (" + chunk.getTotal() + " blocks)";
         }

         if (isStash) {
            Chunk prevChunk = null;
            int i = this.chunks.indexOf(chunk);
            if (i < 0) {
               this.chunks.add(chunk);
            } else {
               prevChunk = (Chunk)this.chunks.set(i, chunk);
            }

            this.saveJson();
            this.saveCsv();
            boolean isNewOrUpdated = !chunk.equals(prevChunk) || !chunk.countsEqual(prevChunk);
            if ((Boolean)this.sendNotifications.get() && isNewOrUpdated) {
               String stashType = isCriticalSpawner ? "spawner base" : "stash";
               int totalStorage = chunk.getTotal();
               switch (((Mode)this.notificationMode.get()).ordinal()) {
                  case 0:
                     this.info("Found %s at (highlight)%s(default), (highlight)%s(default). %s", new Object[]{stashType, chunk.x, chunk.z, detectionReason});
                     break;
                  case 1:
                     ZincToast.show(Text.literal("StashFinder"), Text.literal(totalStorage + " storage"));
                     break;
                  case 2:
                     this.info("Found %s at (highlight)%s(default), (highlight)%s(default). %s", new Object[]{stashType, chunk.x, chunk.z, detectionReason});
                     ZincToast.show(Text.literal("StashFinder"), Text.literal(totalStorage + " storage"));
               }
            }

            if ((Boolean)this.enableWebhook.get() && isNewOrUpdated) {
               this.sendWebhookNotification(chunk, isCriticalSpawner, detectionReason);
            }

            if ((Boolean)this.disconnectOnFind.get() && isNewOrUpdated) {
               this.toggle();
               if (this.mc.getNetworkHandler() != null) {
                  this.mc.getNetworkHandler().getConnection().disconnect(Text.literal("StashFinder: stash found"));
               }
            }
         }

      }
   }

   private void sendWebhookNotification(Chunk chunk, boolean isCriticalSpawner, String detectionReason) {
      String url = ((String)this.webhookUrl.get()).trim();
      if (url.isEmpty()) {
         this.warning("Webhook URL not configured!", new Object[0]);
      } else {
         CompletableFuture.runAsync(() -> {
            try {
               String serverInfo = this.mc.getCurrentServerEntry() != null ? this.mc.getCurrentServerEntry().address : "Unknown Server";
               String messageContent = "";
               if ((Boolean)this.selfPing.get() && !((String)this.discordId.get()).trim().isEmpty()) {
                  messageContent = String.format("<@%s>", ((String)this.discordId.get()).trim());
               }

               String stashType = isCriticalSpawner ? "Spawner Base" : "Stash";
               String description = String.format("%s found at coordinates %d, %d", stashType, chunk.x, chunk.z);
               StringBuilder itemsFound = new StringBuilder();
               int totalItems = 0;
               if (chunk.spawners > 0) {
                  itemsFound.append("Spawners: ").append(chunk.spawners).append("\\n");
                  totalItems += chunk.spawners;
               }

               if (chunk.chests > 0) {
                  itemsFound.append("Chests: ").append(chunk.chests).append("\\n");
                  totalItems += chunk.chests;
               }

               if (chunk.barrels > 0) {
                  itemsFound.append("Barrels: ").append(chunk.barrels).append("\\n");
                  totalItems += chunk.barrels;
               }

               if (chunk.shulkers > 0) {
                  itemsFound.append("Shulker Boxes: ").append(chunk.shulkers).append("\\n");
                  totalItems += chunk.shulkers;
               }

               if (chunk.enderChests > 0) {
                  itemsFound.append("Ender Chests: ").append(chunk.enderChests).append("\\n");
                  totalItems += chunk.enderChests;
               }

               if (chunk.furnaces > 0) {
                  itemsFound.append("Furnaces: ").append(chunk.furnaces).append("\\n");
                  totalItems += chunk.furnaces;
               }

               if (chunk.dispensersDroppers > 0) {
                  itemsFound.append("Dispensers/Droppers: ").append(chunk.dispensersDroppers).append("\\n");
                  totalItems += chunk.dispensersDroppers;
               }

               if (chunk.hoppers > 0) {
                  itemsFound.append("Hoppers: ").append(chunk.hoppers).append("\\n");
                  totalItems += chunk.hoppers;
               }

               String jsonPayload = String.format("{\"content\":\"%s\",\"username\":\"Advanced Stashfinder\",\"embeds\":[{\"title\":\"\ud83d\udce6 Advanced Stashfinder Alert\",\"description\":\"%s\",\"color\":%d,\"fields\":[{\"name\":\"Detection Reason\",\"value\":\"%s\",\"inline\":false},{\"name\":\"Total Items Found\",\"value\":\"%d\",\"inline\":false},{\"name\":\"Items Breakdown\",\"value\":\"%s\",\"inline\":false},{\"name\":\"Coordinates\",\"value\":\"%d, %d\",\"inline\":true},{\"name\":\"Server\",\"value\":\"%s\",\"inline\":true},{\"name\":\"Time\",\"value\":\"<t:%d:R>\",\"inline\":true}],\"footer\":{\"text\":\"Advanced Stashfinder\"}}]}", messageContent.replace("\"", "\\\""), description.replace("\"", "\\\""), isCriticalSpawner ? 16711680 : 3066993, detectionReason.replace("\"", "\\\""), totalItems, itemsFound.toString().replace("\"", "\\\""), chunk.x, chunk.z, serverInfo.replace("\"", "\\\""), System.currentTimeMillis() / 1000L);
               HttpRequest request = HttpRequest.newBuilder().uri(URI.create(url)).header("Content-Type", "application/json").POST(BodyPublishers.ofString(jsonPayload)).timeout(Duration.ofSeconds(30L)).build();
               HttpResponse<String> response = this.httpClient.send(request, BodyHandlers.ofString());
               if (response.statusCode() == 204) {
                  this.info("Webhook notification sent successfully", new Object[0]);
               } else {
                  this.error("Webhook failed with status: " + response.statusCode(), new Object[0]);
               }
            } catch (InterruptedException | IOException e) {
               this.error("Failed to send webhook: " + ((Exception)e).getMessage(), new Object[0]);
            }

         });
      }
   }

   public WWidget getWidget(GuiTheme theme) {
      this.chunks.sort(Comparator.comparingInt((value) -> -value.getTotal()));
      WVerticalList list = theme.verticalList();
      WButton clear = (WButton)list.add(theme.button("Clear")).widget();
      WTable table = new WTable();
      if (!this.chunks.isEmpty()) {
         list.add(table);
      }

      clear.action = () -> {
         this.chunks.clear();
         table.clear();
      };
      this.fillTable(theme, table);
      return list;
   }

   private void fillTable(GuiTheme theme, WTable table) {
      for(Chunk chunk : this.chunks) {
         table.add(theme.label("Pos: " + chunk.x + ", " + chunk.z));
         table.add(theme.label("Total: " + chunk.getTotal()));
         WButton open = (WButton)table.add(theme.button("Open")).widget();
         open.action = () -> this.mc.setScreen(new ChunkScreen(theme, chunk));
         WButton gotoBtn = (WButton)table.add(theme.button("Goto")).widget();
         gotoBtn.action = () -> PathManagers.get().moveTo(new BlockPos(chunk.x, 0, chunk.z), true);
         WMinus delete = (WMinus)table.add(theme.minus()).widget();
         delete.action = () -> {
            if (this.chunks.remove(chunk)) {
               table.clear();
               this.fillTable(theme, table);
               this.saveJson();
               this.saveCsv();
            }

         };
         table.row();
      }

   }

   private void load() {
      boolean loaded = false;
      File file = this.getJsonFile();
      if (file.exists()) {
         try {
            FileReader reader = new FileReader(file);
            this.chunks = (List)GSON.fromJson(reader, (new TypeToken<List<Chunk>>() {
            }).getType());
            reader.close();

            for(Chunk chunk : this.chunks) {
               chunk.calculatePos();
            }

            loaded = true;
         } catch (Exception var8) {
            if (this.chunks == null) {
               this.chunks = new ArrayList();
            }
         }
      }

      file = this.getCsvFile();
      if (!loaded && file.exists()) {
         try {
            BufferedReader reader = new BufferedReader(new FileReader(file));
            reader.readLine();

            Chunk chunk;
            String line;
            for(; (line = reader.readLine()) != null; this.chunks.add(chunk)) {
               String[] values = line.split(",");
               chunk = new Chunk(new ChunkPos(Integer.parseInt(values[0]), Integer.parseInt(values[1])));
               chunk.chests = Integer.parseInt(values[2]);
               chunk.barrels = Integer.parseInt(values[3]);
               chunk.shulkers = Integer.parseInt(values[4]);
               chunk.enderChests = Integer.parseInt(values[5]);
               chunk.furnaces = Integer.parseInt(values[6]);
               chunk.dispensersDroppers = Integer.parseInt(values[7]);
               chunk.hoppers = Integer.parseInt(values[8]);
               if (values.length > 9) {
                  chunk.spawners = Integer.parseInt(values[9]);
               }
            }

            reader.close();
         } catch (Exception var7) {
            if (this.chunks == null) {
               this.chunks = new ArrayList();
            }
         }
      }

   }

   private void saveCsv() {
      try {
         File file = this.getCsvFile();
         file.getParentFile().mkdirs();
         Writer writer = new FileWriter(file);
         writer.write("X,Z,Chests,Barrels,Shulkers,EnderChests,Furnaces,DispensersDroppers,Hoppers,Spawners\n");

         for(Chunk chunk : this.chunks) {
            chunk.write(writer);
         }

         writer.close();
      } catch (IOException e) {
         e.printStackTrace();
      }

   }

   private void saveJson() {
      try {
         File file = this.getJsonFile();
         file.getParentFile().mkdirs();
         Writer writer = new FileWriter(file);
         GSON.toJson(this.chunks, writer);
         writer.close();
      } catch (IOException e) {
         e.printStackTrace();
      }

   }

   private File getJsonFile() {
      return new File(new File(new File(MeteorClient.FOLDER, "stashes"), Utils.getFileWorldName()), "advanced-stashes.json");
   }

   private File getCsvFile() {
      return new File(new File(new File(MeteorClient.FOLDER, "stashes"), Utils.getFileWorldName()), "advanced-stashes.csv");
   }

   public String getInfoString() {
      return String.valueOf(this.chunks.size());
   }

   public static enum Mode {
      Chat,
      Toast,
      Both;

      // $FF: synthetic method
      private static Mode[] $values() {
         return new Mode[]{Chat, Toast, Both};
      }
   }

   public static class Chunk {
      private static final StringBuilder sb = new StringBuilder();
      public ChunkPos chunkPos;
      public transient int x;
      public transient int z;
      public int chests;
      public int barrels;
      public int shulkers;
      public int enderChests;
      public int furnaces;
      public int dispensersDroppers;
      public int hoppers;
      public int spawners;

      public Chunk(ChunkPos chunkPos) {
         this.chunkPos = chunkPos;
         this.calculatePos();
      }

      public void calculatePos() {
         this.x = ZincUtil.chunkX(this.chunkPos) * 16 + 8;
         this.z = ZincUtil.chunkZ(this.chunkPos) * 16 + 8;
      }

      public int getTotal() {
         return this.chests + this.barrels + this.shulkers + this.enderChests + this.furnaces + this.dispensersDroppers + this.hoppers + this.spawners;
      }

      public void write(Writer writer) throws IOException {
         sb.setLength(0);
         sb.append(this.x).append(',').append(this.z).append(',');
         sb.append(this.chests).append(',').append(this.barrels).append(',').append(this.shulkers).append(',').append(this.enderChests).append(',').append(this.furnaces).append(',').append(this.dispensersDroppers).append(',').append(this.hoppers).append(',').append(this.spawners).append('\n');
         writer.write(sb.toString());
      }

      public boolean countsEqual(Chunk c) {
         if (c == null) {
            return false;
         } else {
            return this.chests != c.chests || this.barrels != c.barrels || this.shulkers != c.shulkers || this.enderChests != c.enderChests || this.furnaces != c.furnaces || this.dispensersDroppers != c.dispensersDroppers || this.hoppers != c.hoppers || this.spawners != c.spawners;
         }
      }

      public boolean equals(Object o) {
         if (this == o) {
            return true;
         } else if (o != null && this.getClass() == o.getClass()) {
            Chunk chunk = (Chunk)o;
            return Objects.equals(this.chunkPos, chunk.chunkPos);
         } else {
            return false;
         }
      }

      public int hashCode() {
         return Objects.hash(new Object[]{this.chunkPos});
      }
   }

   private static class ChunkScreen extends WindowScreen {
      private final Chunk chunk;

      public ChunkScreen(GuiTheme theme, Chunk chunk) {
         super(theme, "Chunk at " + chunk.x + ", " + chunk.z);
         this.chunk = chunk;
      }

      public void initWidgets() {
         WTable t = (WTable)this.add(this.theme.table()).expandX().widget();
         t.add(this.theme.label("Total:"));
         t.add(this.theme.label("" + this.chunk.getTotal()));
         t.row();
         t.add(this.theme.horizontalSeparator()).expandX();
         t.row();
         t.add(this.theme.label("Chests:"));
         t.add(this.theme.label("" + this.chunk.chests));
         t.row();
         t.add(this.theme.label("Barrels:"));
         t.add(this.theme.label("" + this.chunk.barrels));
         t.row();
         t.add(this.theme.label("Shulkers:"));
         t.add(this.theme.label("" + this.chunk.shulkers));
         t.row();
         t.add(this.theme.label("Ender Chests:"));
         t.add(this.theme.label("" + this.chunk.enderChests));
         t.row();
         t.add(this.theme.label("Spawners:"));
         t.add(this.theme.label("" + this.chunk.spawners));
         t.row();
         t.add(this.theme.label("Furnaces:"));
         t.add(this.theme.label("" + this.chunk.furnaces));
         t.row();
         t.add(this.theme.label("Dispensers and droppers:"));
         t.add(this.theme.label("" + this.chunk.dispensersDroppers));
         t.row();
         t.add(this.theme.label("Hoppers:"));
         t.add(this.theme.label("" + this.chunk.hoppers));
      }
   }


}
