package com.vrzt.zinc;

import com.vrzt.zinc.modules.Zinc.BaseDigger;
import com.vrzt.zinc.modules.esp.AdvancedStashFinder;
import com.vrzt.zinc.modules.esp.BlockNotifier;
import com.vrzt.zinc.modules.esp.ChunkFinder;
import com.vrzt.zinc.modules.esp.ChunkFinderV2;
import com.vrzt.zinc.modules.esp.KelpESP;
import com.vrzt.zinc.modules.esp.LightESP;
import com.vrzt.zinc.modules.main.PlayerDetection;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;

public class ZincAddon extends MeteorAddon {
    public static final Category esp = new Category("Zinc ESP");
    public static final Category Zinc = new Category("Zinc");

    @Override
    public void onInitialize() {
        Modules modules = Modules.get();
        modules.add(new AdvancedStashFinder());
        modules.add(new BlockNotifier());
        modules.add(new ChunkFinder());
        modules.add(new ChunkFinderV2());
        modules.add(new KelpESP());
        modules.add(new LightESP());
        modules.add(new PlayerDetection());
        modules.add(new BaseDigger());
    }

    @Override
    public void onRegisterCategories() {
        Modules.registerCategory(esp);
        Modules.registerCategory(Zinc);
    }

    @Override
    public String getPackage() {
        return "com.vrzt.zinc";
    }
}
