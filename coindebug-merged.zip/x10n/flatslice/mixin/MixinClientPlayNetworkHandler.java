package x10n.flatslice.mixin;

import net.minecraft.class_2672;
import net.minecraft.class_2676;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import x10n.flatslice.light.PacketIntake;

@Mixin({class_634.class})
public abstract class MixinClientPlayNetworkHandler {
   @Inject(
      method = {"method_11128"},
      at = {@At("HEAD")}
   )
   private void flatslice$onChunkData(class_2672 packet, CallbackInfo ci) {
      PacketIntake.offer(packet.method_11523(), packet.method_11524(), packet.method_38599());
   }

   @Inject(
      method = {"method_11143"},
      at = {@At("HEAD")}
   )
   private void flatslice$onLightUpdate(class_2676 packet, CallbackInfo ci) {
      PacketIntake.offer(packet.method_11558(), packet.method_11554(), packet.method_38600());
   }
}
