package x10n.flatslice.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_2246;
import net.minecraft.class_2248;

public class ChunkSnapshotStore {
   public static final ChunkSnapshotStore INSTANCE = new ChunkSnapshotStore();
   public static final int MIN_SECTION_INDEX = 6;
   public static final int MAX_SECTION_INDEX = 23;
   private final Map<Long, Map<Integer, int[]>> snapshots = new HashMap<>();
   private static final int AIR_STATE_ID = class_2248.method_9507(class_2246.field_10124.method_9564());

   public static long chunkKey(int var0, int var1) {
      return (long)var0 << 32 | var1 & 4294967295L;
   }

   public void storeSnapshot(int var1, int var2, int[][] var3) {
      HashMap var4 = new HashMap();

      for (int var5 = 6; var5 <= 23; var5++) {
         if (var3[var5] != null) {
            var4.put(var5, (int[])var3[var5].clone());
         }
      }

      this.snapshots.put(chunkKey(var1, var2), var4);
   }

   public Map<Integer, int[]> getSnapshot(int var1, int var2) {
      return this.snapshots.get(chunkKey(var1, var2));
   }

   public void removeSnapshot(int var1, int var2) {
      this.snapshots.remove(chunkKey(var1, var2));
   }

   public void clearAllSnapshots() {
      this.snapshots.clear();
   }

   public void pruneRetainKeys(Set<Long> var1) {
      this.snapshots.keySet().retainAll(var1);
   }

   public void replaceSnapshot(int var1, int var2, int[][] var3) {
      this.storeSnapshot(var1, var2, var3);
   }

   public List<BlockChange> compareSections(int var1, int var2, int[][] var3) {
      ArrayList var4 = new ArrayList();
      Map var5 = this.getSnapshot(var1, var2);
      if (isAllEmpty(var5)) {
         return var4;
      } else {
         for (int var6 = 6; var6 <= 23; var6++) {
            int[] var7 = (int[])var5.get(var6);
            int[] var8 = var3[var6];
            if (var7 != null || var8 != null) {
               if (var7 != null && var8 != null) {
                  if (!Arrays.equals(var7, var8)) {
                     for (int var13 = 0; var13 < var7.length; var13++) {
                        if (var7[var13] != var8[var13]) {
                           var4.add(this.toBlockChange(var1, var2, var6, var13, var8[var13], var7[var13]));
                        }
                     }
                  }
               } else {
                  int[] var9 = var7 != null ? var7 : var8;

                  for (int var10 = 0; var10 < var9.length; var10++) {
                     int var11 = var7 != null ? var7[var10] : 0;
                     int var12 = var8 != null ? var8[var10] : 0;
                     if (var11 != var12) {
                        var4.add(this.toBlockChange(var1, var2, var6, var10, var12, var11));
                     }
                  }
               }
            }
         }

         return var4;
      }
   }

   private BlockChange toBlockChange(int var1, int var2, int var3, int var4, int var5, int var6) {
      int var7 = var4 & 15;
      int var8 = var4 >> 4 & 15;
      int var9 = var4 >> 8 & 15;
      int var10 = var3 - 4;
      int var11 = var1 * 16 + var7;
      int var12 = var10 * 16 + var9;
      int var13 = var2 * 16 + var8;
      return new BlockChange(var11, var12, var13, var5, var6);
   }

   private static boolean isAllEmpty(Map<Integer, int[]> var0) {
      if (var0 == null) {
         return true;
      } else {
         for (int var1 = 6; var1 <= 23; var1++) {
            int[] var2 = (int[])var0.get(var1);
            if (var2 != null) {
               for (int var6 : var2) {
                  if (var6 != AIR_STATE_ID) {
                     return false;
                  }
               }
            }
         }

         return true;
      }
   }
}
