package x10n.flatslice.util;

public class BlockChange {
   public final int worldX;
   public final int worldY;
   public final int worldZ;
   public final int newState;
   public final int oldState;

   public BlockChange(int worldX, int worldY, int worldZ, int newState, int oldState) {
      this.worldX = worldX;
      this.worldY = worldY;
      this.worldZ = worldZ;
      this.newState = newState;
      this.oldState = oldState;
   }
}
