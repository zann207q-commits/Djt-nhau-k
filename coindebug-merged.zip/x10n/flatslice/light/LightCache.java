package x10n.flatslice.light;

import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongIterator;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import java.util.function.LongConsumer;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1923;
import net.minecraft.class_310;
import net.minecraft.class_638;
import x10n.flatslice.FlatSliceAddon;
import x10n.flatslice.modules.FlatSlice;

public final class LightCache {
   public static final LightCache INSTANCE = new LightCache();
   public static final Long2ObjectOpenHashMap<ChunkLightSnapshot> SNAPSHOTS = new Long2ObjectOpenHashMap();
   private static final LongOpenHashSet ALERTED = new LongOpenHashSet();
   public static final int ALERT_MIN_Y = -64;
   public static final int ALERT_MAX_Y = 184;
   public static final int BASE_DETECT_CEILING_Y = 62;
   private static final int MAX_DRAIN_PER_TICK = 4096;
   private static final int LIGHT_CACHE_RADIUS = 24;
   private class_638 lastWorld;

   private LightCache() {
   }

   public static void register() {
      MeteorClient.EVENT_BUS.subscribe(INSTANCE);
   }

   public static boolean isChunkAlerted(long var0) {
      return ALERTED.contains(var0);
   }

   public static void clearAll() {
      SNAPSHOTS.clear();
      ALERTED.clear();
      PacketIntake.QUEUE.clear();
   }

   public static void forEachAlerted(LongConsumer var0) {
      for (long var4 : ALERTED.toLongArray()) {
         var0.accept(var4);
      }
   }

   @EventHandler
   private void onTickPre(Pre var1) {
      class_310 var2 = class_310.method_1551();
      class_638 var3 = var2.field_1687;
      if (var3 != this.lastWorld) {
         SNAPSHOTS.clear();
         ALERTED.clear();
         PacketIntake.QUEUE.clear();
         this.lastWorld = var3;
      }

      if (var3 != null) {
         if (var2.field_1724 != null) {
            int var4 = var2.field_1724.method_24515().method_10263() >> 4;
            int var5 = var2.field_1724.method_24515().method_10260() >> 4;
            LongIterator var6 = SNAPSHOTS.keySet().iterator();

            while (var6.hasNext()) {
               long var7 = var6.nextLong();
               int var9 = (int)(var7 >> 32);
               int var10 = (int)(var7 & 4294967295L);
               if (Math.abs(var9 - var4) > 24 || Math.abs(var10 - var5) > 24) {
                  var6.remove();
               }
            }
         }

         if (var2.field_1724 != null && var2.field_1724.method_23318() < 0.0) {
            PacketIntake.QUEUE.clear();
         } else {
            int var11 = var3.method_32890();
            int var12 = var3.method_32891();
            int var13 = 0;

            PacketIntake.PendingLight var14;
            while ((var14 = PacketIntake.QUEUE.poll()) != null) {
               ingest(var14, var11, var12);
               if (++var13 >= 4096) {
                  break;
               }
            }
         }
      }
   }

   private static void ingest(PacketIntake.PendingLight var0, int var1, int var2) {
      long var3 = class_1923.method_8331(var0.chunkX(), var0.chunkZ());
      ChunkLightSnapshot var5 = (ChunkLightSnapshot)SNAPSHOTS.get(var3);
      if (var5 == null || var5.sectionCount != var1 || var5.bottomSectionY != var2) {
         var5 = new ChunkLightSnapshot(var0.chunkX(), var0.chunkZ(), var1, var2);
         SNAPSHOTS.put(var3, var5);
      }

      try {
         LightDataClassifier.apply(var0.data(), var5, var0.arrivalNanos());
      } catch (Throwable var7) {
         FlatSliceAddon.LOG.error("[FlatSlice] LightDataClassifier crashed on chunk " + var0.chunkX() + "," + var0.chunkZ(), var7);
         return;
      }

      maybeAlert(var0.chunkX(), var0.chunkZ(), var3, var5);
   }

   private static void maybeAlert(int var0, int var1, long var2, ChunkLightSnapshot var4) {
      if (!ALERTED.contains(var2)) {
         FlatSlice var5 = (FlatSlice)Modules.get().get(FlatSlice.class);
         if (var5 != null && var5.isActive()) {
            int var6 = var4.sectionCount + 1;

            for (int var7 = 1; var7 < var6; var7++) {
               int var8 = (var4.bottomSectionY + (var7 - 1)) * 16 + 15;
               int var9 = (var4.bottomSectionY + (var7 - 1)) * 16;
               if (var8 >= -64 && var9 <= 184 && var8 < 62 && var4.sky[var7] == SectionStatus.ZEROED_PRESENT) {
                  ALERTED.add(var2);
                  var5.onChunkSpotted(var0, var1);
                  return;
               }
            }
         }
      }
   }
}
