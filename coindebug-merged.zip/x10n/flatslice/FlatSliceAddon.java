package x10n.flatslice;

import com.mojang.logging.LogUtils;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;
import org.slf4j.Logger;
import x10n.flatslice.light.LightCache;
import x10n.flatslice.modules.FlatSlice;
import x10n.flatslice.modules.SmartRtp;
import x10n.flatslice.modules.SpawnerBypass;

public class FlatSliceAddon extends MeteorAddon {
   public static final Logger LOG = LogUtils.getLogger();
   public static final Category CATEGORY = new Category("Player Debug");

   public void onInitialize() {
      LOG.info("[Player Debug] Initializing");
      Modules.get().add(new FlatSlice());
      Modules.get().add(new SpawnerBypass());
      Modules.get().add(new SmartRtp());
      LightCache.register();
   }

   public void onRegisterCategories() {
      Modules.registerCategory(CATEGORY);
   }

   public String getPackage() {
      return "x10n.flatslice";
   }
}
