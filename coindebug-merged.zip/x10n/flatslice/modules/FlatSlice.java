package x10n.flatslice.modules;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.ColorSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2791;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_370;
import net.minecraft.class_5250;
import net.minecraft.class_634;
import net.minecraft.class_370.class_9037;
import x10n.flatslice.FlatSliceAddon;
import x10n.flatslice.light.ChunkLightSnapshot;
import x10n.flatslice.light.LightCache;
import x10n.flatslice.light.SectionStatus;
import x10n.flatslice.util.BlockChange;
import x10n.flatslice.util.ChunkSnapshotStore;

public class FlatSlice extends Module {
   private static final double SLAB_Y = 63.0;
   private static final int RENDER_DISTANCE_CHUNKS = 16;
   private static final int GRAD_STEPS = 12;
   private static final long SPOT_HOLD_MS = 120000L;
   public static volatile boolean chunkSpotted = false;
   private final Map<Long, Long> spottedHold = new ConcurrentHashMap<>();
   private final SettingGroup sgGeneral;
   private final SettingGroup sgAnimation;
   private final SettingGroup sgAlerts;
   private final SettingGroup sgResend;
   private final Setting<SettingColor> chunkColor;
   private final Setting<SettingColor> outlineColor;
   private final Setting<Double> opacity;
   private final Setting<Double> outlineAlpha;
   private final Setting<Double> chunkScale;
   private final Setting<Boolean> smoothEdges;
   private final Setting<FlatSlice.Animation> animation;
   private final Setting<Double> animationSpeed;
   private final Setting<SettingColor> animationColor;
   private final Setting<Boolean> tracers;
   private final Setting<SettingColor> tracerColor;
   private final Setting<Boolean> clearChunksOnToggle;
   private final Setting<Boolean> alertToast;
   private final Setting<Boolean> chatOnSpotted;
   private final Setting<Boolean> showCoordinates;
   private final Setting<Boolean> disconnectOnChunk;
   private final Setting<Integer> maxNotifications;
   private final Setting<Boolean> resendDiff;
   private final Setting<Integer> resendWarnY;
   private final Setting<Integer> resendCooldownMs;
   private final Setting<Integer> resendSettleMs;
   private int alertsFired = 0;
   private long lastResetMs = 0L;
   private final Set<Long> snapshottedKeys = new HashSet<>();
   private final Map<Long, Long> snapTime = new ConcurrentHashMap<>();
   private final Map<Long, Long> resendLastMs = new ConcurrentHashMap<>();
   private final Map<Long, Long> resendFlash = new ConcurrentHashMap<>();
   private static final long RESEND_FLASH_TTL_MS = 15000L;

   public FlatSlice() {
      super(FlatSliceAddon.CATEGORY, "player-debug-v1", "Player Debug V1 - animated, smooth base chunk locator.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgAnimation = this.settings.createGroup("Animation");
      this.sgAlerts = this.settings.createGroup("Alerts");
      this.sgResend = this.settings.createGroup("Resend");
      this.chunkColor = this.sgGeneral
         .add(
            ((Builder)((Builder)new Builder().name("chunk-color")).description("Fill color of the chunk render at Y 63."))
               .defaultValue(new SettingColor(255, 255, 255, 200))
               .build()
         );
      this.outlineColor = this.sgGeneral
         .add(
            ((Builder)((Builder)new Builder().name("outline-color")).description("Color of the chunk outline."))
               .defaultValue(new SettingColor(255, 255, 255, 255))
               .build()
         );
      this.opacity = this.sgGeneral
         .add(
            ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                     .name("opacity"))
                  .description("Global opacity of the whole chunk render (fill + outline)."))
               .defaultValue(1.0)
               .range(0.0, 1.0)
               .sliderRange(0.0, 1.0)
               .decimalPlaces(2)
               .build()
         );
      this.outlineAlpha = this.sgGeneral
         .add(
            ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                     .name("outline-alpha"))
                  .description("Opacity of the chunk outline lines on top of the global opacity."))
               .defaultValue(1.0)
               .range(0.0, 1.0)
               .sliderRange(0.0, 1.0)
               .decimalPlaces(2)
               .build()
         );
      this.chunkScale = this.sgGeneral
         .add(
            ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                     .name("chunk-scale"))
                  .description("Scale of the chunk render, centered on the chunk."))
               .defaultValue(1.0)
               .range(0.25, 4.0)
               .sliderRange(0.25, 4.0)
               .decimalPlaces(2)
               .build()
         );
      this.smoothEdges = this.sgGeneral
         .add(
            ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("smooth-edges"))
                     .description("Render the chunk with a soft gradient edge instead of a hard slab."))
                  .defaultValue(true))
               .build()
         );
      this.tracers = this.sgGeneral
         .add(
            ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("tracers"))
                     .description("Draw a smooth stable tracer to each located chunk."))
                  .defaultValue(false))
               .build()
         );
      this.tracerColor = this.sgGeneral
         .add(
            ((Builder)((Builder)new Builder().name("tracer-color")).description("Color of the tracers."))
               .defaultValue(new SettingColor(125, 210, 255, 220))
               .build()
         );
      this.clearChunksOnToggle = this.sgGeneral
         .add(
            ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("clear-chunks-on-toggle"))
                     .description("Remove the located chunks when the module is turned off or on."))
                  .defaultValue(true))
               .build()
         );
      this.animation = this.sgAnimation
         .add(
            ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                        .name("animation"))
                     .description("Animation rendered inside the chunk marker."))
                  .defaultValue(FlatSlice.Animation.PULSE))
               .build()
         );
      this.animationSpeed = this.sgAnimation
         .add(
            ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                     .name("animation-speed"))
                  .description("Speed of the animation."))
               .defaultValue(1.0)
               .min(0.1)
               .max(10.0)
               .sliderRange(0.1, 5.0)
               .decimalPlaces(2)
               .build()
         );
      this.animationColor = this.sgAnimation
         .add(
            ((Builder)((Builder)new Builder().name("animation-color")).description("Color of the animation effect inside the chunk."))
               .defaultValue(new SettingColor(255, 45, 45, 255))
               .build()
         );
      this.alertToast = this.sgAlerts
         .add(
            ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("toast-on-spotted"))
                     .description("Show a toast notification when a chunk is located."))
                  .defaultValue(true))
               .build()
         );
      this.chatOnSpotted = this.sgAlerts
         .add(
            ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("chat-on-spotted"))
                     .description("Print a chat line when a chunk is located."))
                  .defaultValue(true))
               .build()
         );
      this.showCoordinates = this.sgAlerts
         .add(
            ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("show-coordinates"))
                     .description("Include the chunk-center coordinates in the chat line. Only applies when chat-on-spotted is on."))
                  .defaultValue(true))
               .build()
         );
      this.disconnectOnChunk = this.sgAlerts
         .add(
            ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("disconnect-on-chunk"))
                     .description("Instantly disconnect from the server when a chunk is located."))
                  .defaultValue(false))
               .build()
         );
      this.maxNotifications = this.sgAlerts
         .add(
            ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("max-notifications"))
                     .description("Maximum number of chat/toast notifications per 60 seconds."))
                  .defaultValue(100))
               .min(1)
               .max(1000)
               .sliderRange(1, 500)
               .build()
         );
      this.resendDiff = this.sgResend
         .add(
            ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("resend-diff"))
                     .description("Detect chunks that are silently re-sent by the server with different content (mask flips) as an extra player signal."))
                  .defaultValue(true))
               .build()
         );
      this.resendWarnY = this.sgResend
         .add(
            ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("resend-warn-y"))
                     .description("Only alert when at least one changed block is below this Y level."))
                  .defaultValue(16))
               .min(-64)
               .max(320)
               .sliderRange(-64, 128)
               .build()
         );
      this.resendCooldownMs = this.sgResend
         .add(
            ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("resend-cooldown"))
                     .description("Minimum milliseconds between CHUNK RESEND alerts for the same chunk."))
                  .defaultValue(10000))
               .min(0)
               .max(120000)
               .sliderRange(0, 60000)
               .build()
         );
      this.resendSettleMs = this.sgResend
         .add(
            ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("resend-settle-ms"))
                     .description(
                        "Only alert when the stored snapshot has been stable for at least this long before the diffing re-send. Kills chunk-loading false flags."
                     ))
                  .defaultValue(4000))
               .min(0)
               .max(60000)
               .sliderRange(0, 20000)
               .build()
         );
   }

   public void onActivate() {
      chunkSpotted = false;
      this.alertsFired = 0;
      this.lastResetMs = 0L;
      if ((Boolean)this.clearChunksOnToggle.get()) {
         LightCache.clearAll();
         ChunkSnapshotStore.INSTANCE.clearAllSnapshots();
         this.snapshottedKeys.clear();
         this.snapTime.clear();
         this.resendLastMs.clear();
         this.resendFlash.clear();
         this.spottedHold.clear();
      }
   }

   public void onDeactivate() {
      chunkSpotted = false;
      if ((Boolean)this.clearChunksOnToggle.get()) {
         LightCache.clearAll();
         ChunkSnapshotStore.INSTANCE.clearAllSnapshots();
         this.snapshottedKeys.clear();
         this.snapTime.clear();
         this.resendLastMs.clear();
         this.resendFlash.clear();
         this.spottedHold.clear();
      }
   }

   public void onChunkSpotted(int var1, int var2) {
      chunkSpotted = true;
      this.spottedHold.put(ChunkSnapshotStore.chunkKey(var1, var2), System.currentTimeMillis() + 120000L);
      long var3 = System.currentTimeMillis();
      if (var3 - this.lastResetMs >= 60000L) {
         this.alertsFired = 0;
         this.lastResetMs = var3;
      }

      if ((Boolean)this.disconnectOnChunk.get()) {
         class_634 var5 = this.mc.method_1562();
         if (var5 != null) {
            var5.method_48296().method_10747(class_2561.method_43470(String.format("Player Debug: chunk at %d, %d", (var1 << 4) + 8, (var2 << 4) + 8)));
         }
      }

      if (this.alertsFired < (Integer)this.maxNotifications.get()) {
         this.alertsFired++;
         int var9 = (var1 << 4) + 8;
         int var6 = (var2 << 4) + 8;
         if ((Boolean)this.chatOnSpotted.get()) {
            if ((Boolean)this.showCoordinates.get()) {
               ChatUtils.warning(String.format("(Player Debug) Chunk found: %d, %d", var9, var6), new Object[0]);
            } else {
               ChatUtils.warning("(Player Debug) Chunk found", new Object[0]);
            }
         }

         if ((Boolean)this.alertToast.get()) {
            class_5250 var7 = class_2561.method_43470("Player Debug: chunk found").method_27692(class_124.field_1075);
            class_5250 var8 = class_2561.method_43470(String.format("%d, %d", var9, var6));
            class_370.method_27024(this.mc.method_1566(), class_9037.field_47588, var7, var8);
         }
      }
   }

   private void onChunkResend(int var1, int var2) {
      long var3 = System.currentTimeMillis();
      if (var3 - this.lastResetMs >= 60000L) {
         this.alertsFired = 0;
         this.lastResetMs = var3;
      }

      if ((Boolean)this.disconnectOnChunk.get()) {
         class_634 var5 = this.mc.method_1562();
         if (var5 != null) {
            var5.method_48296().method_10747(class_2561.method_43470(String.format("Player Debug: chunk resend at %d, %d", (var1 << 4) + 8, (var2 << 4) + 8)));
         }
      }

      if (this.alertsFired < (Integer)this.maxNotifications.get()) {
         this.alertsFired++;
         int var9 = (var1 << 4) + 8;
         int var6 = (var2 << 4) + 8;
         if ((Boolean)this.chatOnSpotted.get()) {
            if ((Boolean)this.showCoordinates.get()) {
               ChatUtils.warning(String.format("(Player Debug) CHUNK RESEND. at %d, %d", var9, var6), new Object[0]);
            } else {
               ChatUtils.warning("(Player Debug) CHUNK RESEND.", new Object[0]);
            }
         }

         if ((Boolean)this.alertToast.get()) {
            class_5250 var7 = class_2561.method_43470("Player Debug: chunk resent").method_27692(class_124.field_1075);
            class_5250 var8 = class_2561.method_43470(String.format("%d, %d", var9, var6));
            class_370.method_27024(this.mc.method_1566(), class_9037.field_47588, var7, var8);
         }
      }
   }

   @EventHandler
   private void onTick(Post var1) {
      if (this.mc.field_1687 != null && this.mc.field_1724 != null && (Boolean)this.resendDiff.get()) {
         if (this.mc.field_1687.method_27983() == class_1937.field_25179) {
            int var2 = this.mc.field_1724.method_24515().method_10263() >> 4;
            int var3 = this.mc.field_1724.method_24515().method_10260() >> 4;
            long var4 = System.currentTimeMillis();
            HashSet var6 = new HashSet();

            for (int var7 = -8; var7 <= 8; var7++) {
               for (int var8 = -8; var8 <= 8; var8++) {
                  int var9 = var2 + var7;
                  int var10 = var3 + var8;
                  long var11 = ChunkSnapshotStore.chunkKey(var9, var10);
                  var6.add(var11);
                  if (!this.snapshottedKeys.contains(var11)) {
                     class_2818 var13 = this.mc.field_1687.method_8497(var9, var10);
                     if (var13 != null) {
                        ChunkSnapshotStore.INSTANCE.storeSnapshot(var9, var10, extractSections(var13));
                        this.snapshottedKeys.add(var11);
                        this.snapTime.put(var11, var4);
                     }
                  }
               }
            }

            this.snapshottedKeys.retainAll(var6);
            this.snapTime.keySet().retainAll(var6);
            ChunkSnapshotStore.INSTANCE.pruneRetainKeys(this.snapshottedKeys);
            this.resendLastMs.keySet().retainAll(var6);
         }
      }
   }

   @EventHandler
   private void onChunkData(ChunkDataEvent var1) {
      if (this.mc.field_1687 != null && this.mc.field_1724 != null && (Boolean)this.resendDiff.get()) {
         if (this.mc.field_1687.method_27983() == class_1937.field_25179) {
            class_2818 var2 = var1.chunk();
            class_1923 var3 = var2.method_12004();
            int var4 = var3.field_9181;
            int var5 = var3.field_9180;
            long var6 = ChunkSnapshotStore.chunkKey(var4, var5);
            int[][] var8 = extractSections(var2);
            long var9 = System.currentTimeMillis();
            if (!this.snapshottedKeys.contains(var6)) {
               ChunkSnapshotStore.INSTANCE.storeSnapshot(var4, var5, var8);
               this.snapshottedKeys.add(var6);
               this.snapTime.put(var6, var9);
            } else {
               long var11 = this.snapTime.getOrDefault(var6, var9);
               if (var9 - var11 < ((Integer)this.resendSettleMs.get()).intValue()) {
                  ChunkSnapshotStore.INSTANCE.storeSnapshot(var4, var5, var8);
                  this.snapTime.put(var6, var9);
               } else {
                  List var13 = ChunkSnapshotStore.INSTANCE.compareSections(var4, var5, var8);
                  if (!var13.isEmpty()) {
                     for (BlockChange var15 : var13) {
                        if (var15.worldY < (Integer)this.resendWarnY.get()) {
                           Long var16 = this.resendLastMs.get(var6);
                           if (var16 == null || var9 - var16 >= ((Integer)this.resendCooldownMs.get()).intValue()) {
                              this.resendLastMs.put(var6, var9);
                              this.resendFlash.put(var6, var9 + 15000L);
                              this.onChunkResend(var4, var5);
                           }
                           break;
                        }
                     }
                  }

                  ChunkSnapshotStore.INSTANCE.storeSnapshot(var4, var5, var8);
                  this.snapTime.put(var6, var9);
               }
            }
         }
      }
   }

   private static int[][] extractSections(class_2791 var0) {
      class_2826[] var1 = var0.method_12006();
      int[][] var2 = new int[var1.length][];
      int var3 = Math.min(23, var1.length - 1);

      for (int var4 = 6; var4 <= var3; var4++) {
         class_2826 var5 = var1[var4];
         if (var5 != null && !var5.method_38292()) {
            int[] var6 = new int[4096];
            int var7 = 0;

            for (int var8 = 0; var8 < 16; var8++) {
               for (int var9 = 0; var9 < 16; var9++) {
                  for (int var10 = 0; var10 < 16; var10++) {
                     class_2680 var11 = var5.method_12254(var10, var8, var9);
                     var6[var7++] = class_2248.method_9507(var11);
                  }
               }
            }

            var2[var4] = var6;
         }
      }

      return var2;
   }

   private static int alphaByte(double var0) {
      if (Double.isNaN(var0)) {
         return 0;
      } else {
         int var2 = (int)Math.round(var0);
         if (var2 < 0) {
            var2 = 0;
         } else if (var2 > 255) {
            var2 = 255;
         }

         return var2;
      }
   }

   @EventHandler
   private void onRender3d(Render3DEvent var1) {
      if (this.mc.field_1687 != null
         && this.mc.field_1724 != null
         && (!LightCache.SNAPSHOTS.isEmpty() || !this.resendFlash.isEmpty() || !this.spottedHold.isEmpty())) {
         double var2 = (Double)this.chunkScale.get();
         double var4 = (Double)this.opacity.get();
         double var6 = (Double)this.outlineAlpha.get();
         double var8 = (Double)this.animationSpeed.get();
         FlatSlice.Animation var10 = (FlatSlice.Animation)this.animation.get();
         int var11 = this.mc.field_1724.method_24515().method_10263() >> 4;
         int var12 = this.mc.field_1724.method_24515().method_10260() >> 4;
         Color var13 = new Color((Color)this.chunkColor.get());
         Color var14 = new Color((Color)this.outlineColor.get());
         Color var15 = new Color((Color)this.animationColor.get());
         class_243 var16 = this.tracers.get() ? RenderUtils.center : null;
         Color var17 = new Color((Color)this.tracerColor.get());
         long var18 = System.currentTimeMillis();

         for (int var20 = var11 - 16; var20 <= var11 + 16; var20++) {
            for (int var21 = var12 - 16; var21 <= var12 + 16; var21++) {
               long var22 = class_1923.method_8331(var20, var21);
               ChunkLightSnapshot var24 = (ChunkLightSnapshot)LightCache.SNAPSHOTS.get(var22);
               if (this.inSpotHold(var22, var18) || LightCache.isChunkAlerted(var22) || var24 != null && hasBaseSignal(var24)) {
                  this.renderChunk(var1, var20, var21, var2, var4, var6, var8, var10, var13, var14, var15, var16, var17);
               }
            }
         }

         this.renderResendFlashes(var1);
      }
   }

   private boolean inSpotHold(long var1, long var3) {
      Long var5 = this.spottedHold.get(var1);
      if (var5 == null) {
         return false;
      } else if (var3 >= var5) {
         this.spottedHold.remove(var1);
         return false;
      } else {
         return true;
      }
   }

   private void renderResendFlashes(Render3DEvent var1) {
      if (!this.resendFlash.isEmpty()) {
         long var2 = System.currentTimeMillis();
         Iterator var4 = this.resendFlash.entrySet().iterator();

         while (var4.hasNext()) {
            Entry var5 = (Entry)var4.next();
            long var6 = (Long)var5.getValue();
            if (var2 >= var6) {
               var4.remove();
            } else {
               int var8 = (int)((Long)var5.getKey() >> 32);
               int var9 = (int)((Long)var5.getKey() & 4294967295L);
               double var10 = (var6 - var2) / 15000.0;
               double var12 = 0.45 + 0.55 * Math.abs(Math.sin(var2 / 1000.0 * 2.0));
               double var14 = 5.6;
               double var16 = var8 * 16.0 + 8.0;
               double var18 = var9 * 16.0 + 8.0;
               Color var20 = new Color(255, 60, 60, alphaByte(90.0 * var12 * var10));
               Color var21 = new Color(255, 60, 60, alphaByte(255.0 * var10));
               var1.renderer.box(var16 - var14, 63.0, var18 - var14, var16 + var14, 63.13, var18 + var14, var20, var21, ShapeMode.Both, 0);
               double var22 = 4.0 + 3.6 * var12;
               var1.renderer
                  .box(var16 - var22, 63.07, var18 - var22, var16 + var22, 63.07, var18 + var22, new Color(255, 60, 60, 0), var21, ShapeMode.Lines, 0);
            }
         }
      }
   }

   private void renderChunk(
      Render3DEvent var1,
      int var2,
      int var3,
      double var4,
      double var6,
      double var8,
      double var10,
      FlatSlice.Animation var12,
      Color var13,
      Color var14,
      Color var15,
      class_243 var16,
      Color var17
   ) {
      double var18 = var2 * 16.0 + 8.0;
      double var20 = var3 * 16.0 + 8.0;
      double var22 = 8.0 * var4;
      double var24 = System.currentTimeMillis() / 1000.0 * var10;
      double var26 = 1.0;
      if (var12 == FlatSlice.Animation.PULSE) {
         var26 = 0.55 + 0.45 * Math.sin(var24 * 2.0);
      }

      double var28 = var13.a * var6 * var26;
      Color var30 = new Color(var13.r, var13.g, var13.b, alphaByte(var28));
      Color var31 = new Color(var14.r, var14.g, var14.b, alphaByte(var14.a * var6 * var26 * var8));
      if ((Boolean)this.smoothEdges.get()) {
         for (int var32 = 1; var32 <= 12; var32++) {
            double var33 = var32 / 12.0;
            double var35 = var22 * var33;
            double var37 = var28 * (0.15 + 0.85 * var33);
            Color var39 = new Color(var13.r, var13.g, var13.b, alphaByte(var37));
            var1.renderer.box(var18 - var35, 63.0, var20 - var35, var18 + var35, 63.13, var20 + var35, var39, var39, ShapeMode.Sides, 0);
         }

         var1.renderer.box(var18 - var22, 63.0, var20 - var22, var18 + var22, 63.13, var20 + var22, new Color(0, 0, 0, 0), var31, ShapeMode.Lines, 0);
         var1.renderer
            .box(
               var18 - var22 - 0.15,
               62.98,
               var20 - var22 - 0.15,
               var18 + var22 + 0.15,
               63.02,
               var20 + var22 + 0.15,
               new Color(0, 0, 0, 0),
               new Color(var31.r, var31.g, var31.b, alphaByte(var31.a * 0.35)),
               ShapeMode.Lines,
               0
            );
      } else {
         var1.renderer.box(var18 - var22, 63.0, var20 - var22, var18 + var22, 63.13, var20 + var22, var30, var31, ShapeMode.Both, 0);
      }

      if (var12 != FlatSlice.Animation.NONE) {
         this.renderAnimation(var1, var18, var20, var22, var24, var12, var15, var6 * var26);
      }

      if (var16 != null) {
         var1.renderer.line(var16.field_1352, var16.field_1351, var16.field_1350, var18, 63.0, var20, var17);
      }
   }

   private void renderAnimation(Render3DEvent var1, double var2, double var4, double var6, double var8, FlatSlice.Animation var10, Color var11, double var12) {
      double var14 = 63.07;
      Color var16 = new Color(var11.r, var11.g, var11.b, alphaByte(var11.a * var12));
      if (var10 == FlatSlice.Animation.RIPPLE) {
         double var17 = var8 * 0.5 % 1.0;
         double var19 = var6 * var17;
         if (var19 > 0.2) {
            var1.renderer.box(var2 - var19, var14, var4 - var19, var2 + var19, var14, var4 + var19, var16, var16, ShapeMode.Lines, 0);
         }

         double var21 = var6 * ((var8 * 0.5 + 0.35) % 1.0);
         if (var21 > 0.2) {
            var1.renderer
               .box(
                  var2 - var21,
                  var14,
                  var4 - var21,
                  var2 + var21,
                  var14,
                  var4 + var21,
                  new Color(var11.r, var11.g, var11.b, alphaByte(var11.a * var12 * 0.5)),
                  new Color(var11.r, var11.g, var11.b, alphaByte(var11.a * var12 * 0.5)),
                  ShapeMode.Lines,
                  0
               );
         }
      } else if (var10 == FlatSlice.Animation.SCAN) {
         double var23 = var8 * 0.4 % 2.0;
         if (var23 < 1.0) {
            double var25 = var2 - var6 + 2.0 * var6 * var23;
            var1.renderer.line(var25, var14, var4 - var6, var25, var14, var4 + var6, var16);
         } else {
            double var26 = var4 - var6 + 2.0 * var6 * (var23 - 1.0);
            var1.renderer.line(var2 - var6, var14, var26, var2 + var6, var14, var26, var16);
         }
      } else if (var10 == FlatSlice.Animation.CHASE) {
         double var24 = var8 * 0.5 % 4.0;
         if (var24 < 1.0) {
            var1.renderer.line(var2 - var6, var14, var4 - var6, var2 - var6 + 2.0 * var6 * var24, var14, var4 - var6, var16);
         } else if (var24 < 2.0) {
            double var27 = var24 - 1.0;
            var1.renderer.line(var2 + var6, var14, var4 - var6, var2 + var6, var14, var4 - var6 + 2.0 * var6 * var27, var16);
         } else if (var24 < 3.0) {
            double var28 = var24 - 2.0;
            var1.renderer.line(var2 + var6, var14, var4 + var6, var2 + var6 - 2.0 * var6 * var28, var14, var4 + var6, var16);
         } else {
            double var29 = var24 - 3.0;
            var1.renderer.line(var2 - var6, var14, var4 + var6, var2 - var6, var14, var4 + var6 - 2.0 * var6 * var29, var16);
         }
      }
   }

   private static boolean hasBaseSignal(ChunkLightSnapshot var0) {
      for (int var1 = 1; var1 < var0.sectionCount + 1; var1++) {
         int var2 = (var0.bottomSectionY + (var1 - 1)) * 16 + 15;
         if (var2 < 62 && var0.sky[var1] == SectionStatus.ZEROED_PRESENT) {
            return true;
         }
      }

      return false;
   }

   public static enum Animation {
      NONE("None"),
      PULSE("Pulse"),
      RIPPLE("Ripple"),
      SCAN("Scan"),
      CHASE("Chase");

      private final String title;

      @Override
      public String toString() {
         return this.title;
      }

      private Animation(String nullxx) {
         this.title = nullxx;
      }
   }
}
