package x10n.flatslice.modules;

import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import x10n.flatslice.FlatSliceAddon;

public class TpaAccount extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<String> accountName;
   private final Setting<Integer> sendDelay;
   private boolean armed = false;
   private long lastSendMs = 0L;

   public TpaAccount() {
      super(FlatSliceAddon.CATEGORY, "tpa-account", "Sends /tpahere to your alt account every 20 seconds once a chunk is located.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.accountName = this.sgGeneral
         .add(
            ((Builder)((Builder)((Builder)new Builder().name("account-name")).description("The name of your alt account, e.g. myalt123.")).defaultValue(""))
               .build()
         );
      this.sendDelay = this.sgGeneral
         .add(
            ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("send-delay"))
                     .description("Seconds between each /tpahere send."))
                  .defaultValue(20))
               .min(5)
               .max(120)
               .sliderRange(5, 120)
               .build()
         );
   }

   public void onActivate() {
      this.armed = false;
      this.lastSendMs = 0L;
   }

   public void onDeactivate() {
      this.armed = false;
      this.lastSendMs = 0L;
   }

   @EventHandler
   private void onTick(Post var1) {
      if (this.mc.field_1724 != null) {
         if (!this.armed && (FlatSlice.chunkSpotted || SpawnerBypass.chunkSpotted)) {
            this.armed = true;
            this.lastSendMs = 0L;
         }

         if (this.armed) {
            String var2 = (String)this.accountName.get();
            if (!var2.isEmpty()) {
               long var3 = System.currentTimeMillis();
               if (var3 - this.lastSendMs >= ((Integer)this.sendDelay.get()).intValue() * 1000L) {
                  this.lastSendMs = var3;
                  ChatUtils.sendPlayerMsg("/tpahere " + var2.trim());
               }
            }
         }
      }
   }
}
