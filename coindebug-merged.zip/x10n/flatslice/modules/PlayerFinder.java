package x10n.flatslice.modules;

import java.util.ArrayList;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import meteordevelopment.meteorclient.events.packets.PacketEvent.Receive;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2673;
import net.minecraft.class_2680;
import net.minecraft.class_370;
import net.minecraft.class_5250;
import net.minecraft.class_370.class_9037;
import x10n.flatslice.FlatSliceAddon;

public class PlayerFinder extends Module {
   public static volatile long lastPlayerDetectedMs = 0L;
   static final String[] NOISE_TOKENS = new String[]{
      "air",
      "sand",
      "gravel",
      "powder",
      "water",
      "lava",
      "kelp",
      "seagrass",
      "fire",
      "leaves",
      "vine",
      "vines",
      "bamboo",
      "sugar_cane",
      "cactus",
      "mushroom",
      "grass",
      "dripstone",
      "sculk",
      "moss",
      "coral",
      "pointed",
      "snow",
      "ice",
      "mud"
   };
   static final String[] HIGH_VALUE_TOKENS = new String[]{
      "door",
      "trapdoor",
      "gate",
      "lever",
      "button",
      "plate",
      "torch",
      "lantern",
      "candle",
      "redstone",
      "repeater",
      "comparator",
      "piston",
      "observer",
      "dispenser",
      "dropper",
      "hopper",
      "chest",
      "barrel",
      "furnace",
      "spawner",
      "anvil",
      "crafting",
      "enchanting",
      "brewing",
      "beacon",
      "bed",
      "campfire",
      "shulker",
      "jukebox",
      "note",
      "lectern",
      "composter",
      "grindstone",
      "bell",
      "chain",
      "target",
      "lodestone",
      "respawn_anchor",
      "conduit",
      "smithing",
      "stonecutter",
      "cartography",
      "smoker",
      "blast"
   };
   public static final int RING_SEGMENTS = 24;
   private final SettingGroup sgGeneral;
   private final SettingGroup sgMarker;
   private final SettingGroup sgAlerts;
   private final Setting<Integer> thresholdY;
   private final Setting<Boolean> onlyWhenAbove;
   private final Setting<Integer> airStateId;
   private final Setting<PlayerFinder.ConfidenceMode> confidenceMode;
   private final Setting<Double> ringRadius;
   private final Setting<SettingColor> ringColor;
   private final Setting<Double> ringAlpha;
   private final Setting<Boolean> renderBlock;
   private final Setting<Boolean> tracers;
   private final Setting<SettingColor> tracerColor;
   private final Setting<Integer> markerTtlSeconds;
   private final Setting<Integer> chunkCooldownMs;
   private final Setting<Integer> alertCooldownMs;
   private final Setting<Boolean> toastOnDetect;
   private final Setting<Boolean> chatOnDetect;
   private final Setting<Boolean> showCoordinates;
   private final Map<Long, PlayerFinder.Marker> markers = new ConcurrentHashMap<>();
   private final Map<Long, Long> chunkLastAlertMs = new ConcurrentHashMap<>();
   private volatile long lastGlobalAlertMs = 0L;

   public PlayerFinder() {
      super(
         FlatSliceAddon.CATEGORY,
         "player-finder",
         "Detects players underground by catching real block updates leaking through server-side anti-ESP masks. Renders a ring marker at the leaked block."
      );
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgMarker = this.settings.createGroup("Marker");
      this.sgAlerts = this.settings.createGroup("Alerts");
      this.thresholdY = this.sgGeneral
         .add(
            ((Builder)((Builder)((Builder)new Builder().name("threshold-y"))
                     .description("Y level below which the server masks blocks. Any real block update below this line is treated as a player leak."))
                  .defaultValue(16))
               .min(-64)
               .max(320)
               .sliderRange(-64, 100)
               .build()
         );
      this.onlyWhenAbove = this.sgGeneral
         .add(
            ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("only-when-above"))
                     .description("Only listen while your player is at or above the threshold. Prevents your own underground edits from triggering alerts."))
                  .defaultValue(true))
               .build()
         );
      this.airStateId = this.sgGeneral
         .add(
            ((Builder)((Builder)((Builder)new Builder().name("air-state-id"))
                     .description("Raw network state id of air (0 on vanilla servers). Updates equal to this id are breaks, not placements, and are ignored."))
                  .defaultValue(0))
               .min(0)
               .max(100000)
               .sliderRange(0, 100)
               .build()
         );
      this.confidenceMode = this.sgGeneral
         .add(
            ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                        .name("confidence-mode"))
                     .description(
                        "All=every leaked block update (~85%% player), NoiseFree=ignore physics/mob blocks like sand/water/fire (~92%%), HighValue=only redstone doors chests furnaces pistons etc (~97%%)."
                     ))
                  .defaultValue(PlayerFinder.ConfidenceMode.NoiseFree))
               .build()
         );
      this.ringRadius = this.sgMarker
         .add(
            ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                     .name("ring-radius"))
                  .description("Radius of the round marker rendered at the detected block."))
               .defaultValue(2.5)
               .min(0.5)
               .max(16.0)
               .sliderRange(0.5, 8.0)
               .decimalPlaces(1)
               .build()
         );
      this.ringColor = this.sgMarker
         .add(
            ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                     .name("ring-color"))
                  .description("Color of the marker ring."))
               .defaultValue(new SettingColor(255, 45, 45, 255))
               .build()
         );
      this.ringAlpha = this.sgMarker
         .add(
            ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                     .name("ring-alpha"))
                  .description("Opacity of the marker ring."))
               .defaultValue(1.0)
               .range(0.0, 1.0)
               .sliderRange(0.0, 1.0)
               .decimalPlaces(2)
               .build()
         );
      this.renderBlock = this.sgMarker
         .add(
            ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("render-block"))
                     .description("Also render the leaked block itself as a box under the ring."))
                  .defaultValue(true))
               .build()
         );
      this.tracers = this.sgMarker
         .add(
            ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("tracers"))
                     .description("Draw a tracer from your camera to each detected block."))
                  .defaultValue(false))
               .build()
         );
      this.tracerColor = this.sgMarker
         .add(
            ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                     .name("tracer-color"))
                  .description("Color of the tracers."))
               .defaultValue(new SettingColor(255, 45, 45, 220))
               .build()
         );
      this.markerTtlSeconds = this.sgMarker
         .add(
            ((Builder)((Builder)((Builder)new Builder().name("marker-ttl")).description("How many seconds a marker stays rendered.")).defaultValue(8))
               .min(1)
               .max(120)
               .sliderRange(1, 60)
               .build()
         );
      this.chunkCooldownMs = this.sgAlerts
         .add(
            ((Builder)((Builder)((Builder)new Builder().name("chunk-cooldown")).description("Minimum milliseconds between alerts for the same chunk."))
                  .defaultValue(5000))
               .min(0)
               .max(60000)
               .sliderRange(0, 30000)
               .build()
         );
      this.alertCooldownMs = this.sgAlerts
         .add(
            ((Builder)((Builder)((Builder)new Builder().name("alert-cooldown")).description("Global minimum milliseconds between PLAYER DETECTED alerts."))
                  .defaultValue(2000))
               .min(0)
               .max(60000)
               .sliderRange(0, 30000)
               .build()
         );
      this.toastOnDetect = this.sgAlerts
         .add(
            ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("toast-on-detect"))
                     .description("Show a toast when a player is detected."))
                  .defaultValue(true))
               .build()
         );
      this.chatOnDetect = this.sgAlerts
         .add(
            ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("chat-on-detect"))
                     .description("Print a client-side chat line when a player is detected."))
                  .defaultValue(true))
               .build()
         );
      this.showCoordinates = this.sgAlerts
         .add(
            ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("show-coordinates"))
                     .description("Include the detected coordinates in alerts."))
                  .defaultValue(true))
               .build()
         );
   }

   public void onDeactivate() {
      this.markers.clear();
      this.chunkLastAlertMs.clear();
      this.lastGlobalAlertMs = 0L;
   }

   @EventHandler
   private void onPacketReceive(Receive var1) {
      class_2596 var2 = var1.packet;
      if (var2 instanceof class_2673) {
         this.mc.execute(() -> this.handleBlockUpdate((class_2673)var2));
      }
   }

   private void handleBlockUpdate(class_2673 var1) {
      if (this.mc.field_1687 != null && this.mc.field_1724 != null) {
         int var2 = this.mc.field_1724.method_24515().method_10264();
         if (!(Boolean)this.onlyWhenAbove.get() || var2 >= (Integer)this.thresholdY.get()) {
            class_2338 var3 = var1.method_11531();
            if (var3.method_10264() < (Integer)this.thresholdY.get()) {
               int var4 = var1.method_11532();
               if (var4 != (Integer)this.airStateId.get()) {
                  class_2680 var5 = this.mc.field_1687.method_8320(var3);
                  if (class_2248.method_9507(var5) != var4) {
                     PlayerFinder.ConfidenceMode var6 = (PlayerFinder.ConfidenceMode)this.confidenceMode.get();
                     if (var6 == PlayerFinder.ConfidenceMode.NoiseFree || var6 == PlayerFinder.ConfidenceMode.HighValue) {
                        String var7 = blockFamily(var4);
                        if (var6 == PlayerFinder.ConfidenceMode.NoiseFree ? isNoise(var7) : !isHighValue(var7)) {
                           return;
                        }
                     }

                     this.record(var3);
                  }
               }
            }
         }
      }
   }

   private static String blockFamily(int var0) {
      try {
         class_2680 var1 = class_2248.method_9531(var0);
         if (var1 == null) {
            return "";
         } else {
            class_2248 var2 = var1.method_26204();
            if (var2 == null) {
               return "";
            } else {
               String var3 = var2.toString();
               if (var3 == null) {
                  return "";
               } else {
                  int var4 = var3.indexOf(58);
                  return var4 >= 0 ? var3.substring(var4 + 1).toLowerCase() : var3.toLowerCase();
               }
            }
         }
      } catch (Throwable var5) {
         return "";
      }
   }

   private static boolean tokenMatches(String[] var0, String var1) {
      for (String var5 : var0) {
         if (var1.equals(var5) || var1.startsWith(var5 + "_") || var1.endsWith("_" + var5) || var1.indexOf("_" + var5 + "_") >= 0) {
            return true;
         }
      }

      return false;
   }

   private static boolean isNoise(String var0) {
      return tokenMatches(NOISE_TOKENS, var0);
   }

   private static boolean isHighValue(String var0) {
      return tokenMatches(HIGH_VALUE_TOKENS, var0);
   }

   private void record(class_2338 var1) {
      long var2 = System.currentTimeMillis();
      long var4 = (long)(var1.method_10263() >> 4) << 32 | var1.method_10260() >> 4 & 4294967295L;
      Long var6 = this.chunkLastAlertMs.get(var4);
      if (var6 != null && var2 - var6 < ((Integer)this.chunkCooldownMs.get()).intValue()) {
         this.markers
            .put(
               var1.method_10063(),
               new PlayerFinder.Marker(
                  var1.method_10263() + 0.5,
                  var1.method_10264() + 0.5,
                  var1.method_10260() + 0.5,
                  var2 + ((Integer)this.markerTtlSeconds.get()).intValue() * 1000L
               )
            );
      } else {
         this.chunkLastAlertMs.put(var4, var2);
         if (var2 - this.lastGlobalAlertMs < ((Integer)this.alertCooldownMs.get()).intValue()) {
            this.markers
               .put(
                  var1.method_10063(),
                  new PlayerFinder.Marker(
                     var1.method_10263() + 0.5,
                     var1.method_10264() + 0.5,
                     var1.method_10260() + 0.5,
                     var2 + ((Integer)this.markerTtlSeconds.get()).intValue() * 1000L
                  )
               );
         } else {
            this.lastGlobalAlertMs = var2;
            lastPlayerDetectedMs = var2;
            this.markers
               .put(
                  var1.method_10063(),
                  new PlayerFinder.Marker(
                     var1.method_10263() + 0.5,
                     var1.method_10264() + 0.5,
                     var1.method_10260() + 0.5,
                     var2 + ((Integer)this.markerTtlSeconds.get()).intValue() * 1000L
                  )
               );
            int var7 = var1.method_10263();
            int var8 = var1.method_10264();
            int var9 = var1.method_10260();
            if ((Boolean)this.chatOnDetect.get()) {
               if ((Boolean)this.showCoordinates.get()) {
                  ChatUtils.warning(String.format("(Player Finder) PLAYER DETECTED. at %d, %d, %d", var7, var8, var9), new Object[0]);
               } else {
                  ChatUtils.warning("(Player Finder) PLAYER DETECTED.", new Object[0]);
               }
            }

            if ((Boolean)this.toastOnDetect.get()) {
               class_5250 var10 = class_2561.method_43470("PLAYER DETECTED.").method_27692(class_124.field_1075);
               class_5250 var11 = this.showCoordinates.get()
                  ? class_2561.method_43470(String.format("%d, %d, %d", var7, var8, var9))
                  : class_2561.method_43470("Underground block leak");
               class_370.method_27024(this.mc.method_1566(), class_9037.field_47588, var10, var11);
            }
         }
      }
   }

   private static int alphaByte(double var0) {
      int var2 = (int)Math.round(var0);
      if (var2 < 0) {
         var2 = 0;
      } else if (var2 > 255) {
         var2 = 255;
      }

      return var2;
   }

   @EventHandler
   private void onRender3d(Render3DEvent var1) {
      long var2 = System.currentTimeMillis();
      ArrayList var4 = new ArrayList();

      for (Entry var6 : this.markers.entrySet()) {
         PlayerFinder.Marker var7 = (PlayerFinder.Marker)var6.getValue();
         if (var2 > var7.expireMs) {
            var4.add((Long)var6.getKey());
         }
      }

      for (Long var39 : var4) {
         this.markers.remove(var39);
      }

      if (!this.markers.isEmpty()) {
         double var38 = (Double)this.ringRadius.get();
         Color var8 = new Color((Color)this.ringColor.get());
         Color var9 = new Color(var8.r, var8.g, var8.b, alphaByte(var8.a * (Double)this.ringAlpha.get()));
         Color var10 = new Color((Color)this.tracerColor.get());
         class_243 var11 = this.tracers.get() ? RenderUtils.center : null;

         for (PlayerFinder.Marker var13 : this.markers.values()) {
            double var14 = var13.y;
            double var16 = var13.x;
            double var18 = var13.z;
            if ((Boolean)this.renderBlock.get()) {
               var1.renderer.box(var16 - 0.5, var14 - 0.5, var18 - 0.5, var16 + 0.5, var14 + 0.5, var18 + 0.5, var9, var9, ShapeMode.Both, 0);
            }

            double var20 = 0.0;
            double var22 = 0.0;

            for (int var24 = 0; var24 < 24; var24++) {
               double var25 = var24 * (Math.PI * 2) / 24.0;
               double var27 = (var24 + 1) * (Math.PI * 2) / 24.0;
               double var29 = var16 + Math.cos(var25) * var38;
               double var31 = var18 + Math.sin(var25) * var38;
               double var33 = var16 + Math.cos(var27) * var38;
               double var35 = var18 + Math.sin(var27) * var38;
               var1.renderer.line(var29, var14, var31, var33, var14, var35, var9);
               if (var24 == 0) {
                  ;
               }
            }

            var1.renderer.line(var16, var14 - 1.5, var18, var16, var14 + 1.5, var18, var9);
            if (var11 != null) {
               var1.renderer.line(var11.field_1352, var11.field_1351, var11.field_1350, var16, var14, var18, var10);
            }
         }
      }
   }

   public static enum ConfidenceMode {
      All,
      NoiseFree,
      HighValue;
   }

   private static class Marker {
      public final double x;
      public final double y;
      public final double z;
      public final long expireMs;

      public Marker(double var1, double var3, double var5, long var7) {
         this.x = var1;
         this.y = var3;
         this.z = var5;
         this.expireMs = var7;
      }
   }
}
