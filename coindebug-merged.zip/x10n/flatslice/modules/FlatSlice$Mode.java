package x10n.flatslice.modules;

public enum FlatSlice$Mode {
   CHUNK,
   PILLAR;
}
