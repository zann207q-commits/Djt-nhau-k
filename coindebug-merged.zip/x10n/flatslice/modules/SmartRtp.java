package x10n.flatslice.modules;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import meteordevelopment.meteorclient.events.render.Render2DEvent;
import meteordevelopment.meteorclient.gui.WidgetScreen;
import meteordevelopment.meteorclient.renderer.Renderer2D;
import meteordevelopment.meteorclient.renderer.text.TextRenderer;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.IntSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.orbit.EventHandler;
import x10n.flatslice.FlatSliceAddon;

public class SmartRtp extends Module {
   private static final Color HEADER_COLOR = new Color(180, 180, 180, 255);
   private static final Color TEXT_COLOR = new Color(255, 255, 255, 255);
   private static final DateTimeFormatter FMT_24 = DateTimeFormatter.ofPattern("HH:mm:ss");
   private static final DateTimeFormatter FMT_12 = DateTimeFormatter.ofPattern("hh:mm:ss a");
   private static final ZoneId ZONE_NA_WEST = ZoneId.of("America/Los_Angeles");
   private static final ZoneId ZONE_NA_EAST = ZoneId.of("America/New_York");
   private static final ZoneId ZONE_EU = ZoneId.of("Europe/Berlin");
   private static final ZoneId ZONE_OCEANIA = ZoneId.of("Australia/Sydney");
   private static final ZoneId ZONE_ASIA = ZoneId.of("Asia/Shanghai");
   private final SettingGroup sgBox = this.settings.createGroup("Box");
   private final SettingGroup sgRegions = this.settings.createGroup("Regions");
   private final Setting<Integer> boxX = this.sgBox
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("box-x")).description("Horizontal position of the box, in screen coordinates.")).defaultValue(2))
            .min(0)
            .max(1920)
            .sliderRange(0, 1000)
            .build()
      );
   private final Setting<Integer> boxY = this.sgBox
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("box-y")).description("Vertical position of the box, in screen coordinates.")).defaultValue(2))
            .min(0)
            .max(1080)
            .sliderRange(0, 600)
            .build()
      );
   private final Setting<Integer> backgroundAlpha = this.sgBox
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("background-alpha")).description("Opacity of the black box background.")).defaultValue(140))
            .min(0)
            .max(255)
            .sliderRange(0, 255)
            .build()
      );
   private final Setting<Double> textScale = this.sgBox
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                  .name("text-scale"))
               .description("Scale of the text inside the box."))
            .defaultValue(1.0)
            .min(0.5)
            .max(3.0)
            .sliderRange(0.5, 2.5)
            .decimalPlaces(1)
            .build()
      );
   private final Setting<Boolean> showSeconds = this.sgBox
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("show-seconds"))
                  .description("Show seconds in the displayed times."))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> use24h = this.sgBox
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("24-hour"))
                  .description("Use 24 hour format instead of AM/PM."))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> showTitle = this.sgBox
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("show-title"))
                  .description("Render the \"Smart RTP\" header at the top of the box."))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> naWest = this.sgRegions
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("na-west"))
                  .description("Show the NA West clock (America/Los_Angeles)."))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> naEast = this.sgRegions
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("na-east"))
                  .description("Show the NA East clock (America/New_York)."))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> eu = this.sgRegions
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("eu"))
                  .description("Show the EU clock (Europe/Berlin)."))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> oceania = this.sgRegions
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("oceania"))
                  .description("Show the Oceania clock (Australia/Sydney)."))
               .defaultValue(true))
            .build()
      );
   private final Setting<Boolean> asia = this.sgRegions
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("asia"))
                  .description("Show the Asia clock (Asia/Shanghai)."))
               .defaultValue(true))
            .build()
      );

   public SmartRtp() {
      super(
         FlatSliceAddon.CATEGORY,
         "smart-rtp",
         "Renders a little black HUD box with the live local time in NA West, NA East, EU, Oceania and Asia so you can feel out the server region before picking an RTP. (Smart RTP Mode)"
      );
   }

   @EventHandler
   private void onRender2D(Render2DEvent var1) {
      if (this.mc.field_1755 == null || this.mc.field_1755 instanceof WidgetScreen) {
         if (this.mc.field_1687 != null && this.mc.field_1724 != null) {
            double var2 = (Double)this.textScale.get();
            long var4 = System.currentTimeMillis();
            ArrayList var6 = new ArrayList();
            ArrayList var7 = new ArrayList();
            if ((Boolean)this.showTitle.get()) {
               var6.add("Smart RTP");
               var7.add("");
            }

            if ((Boolean)this.naWest.get()) {
               var6.add("NA West");
               var7.add(this.format(ZONE_NA_WEST, var4));
            }

            if ((Boolean)this.naEast.get()) {
               var6.add("NA East");
               var7.add(this.format(ZONE_NA_EAST, var4));
            }

            if ((Boolean)this.eu.get()) {
               var6.add("EU");
               var7.add(this.format(ZONE_EU, var4));
            }

            if ((Boolean)this.oceania.get()) {
               var6.add("Oceania");
               var7.add(this.format(ZONE_OCEANIA, var4));
            }

            if ((Boolean)this.asia.get()) {
               var6.add("Asia");
               var7.add(this.format(ZONE_ASIA, var4));
            }

            if (!var6.isEmpty()) {
               Renderer2D.COLOR.begin();
               TextRenderer var8 = TextRenderer.get();
               var8.begin(var2);
               double var9 = 0.0;

               for (int var11 = 0; var11 < var6.size(); var11++) {
                  double var12 = var8.getWidth((String)var6.get(var11));
                  if (var11 > 0) {
                     var12 += 4.0 + var8.getWidth((String)var7.get(var11));
                  }

                  if (var12 > var9) {
                     var9 = var12;
                  }
               }

               boolean var31 = (Boolean)this.showTitle.get() && !var6.isEmpty() && "Smart RTP".equals(var6.get(0));
               if (var31 && var8.getWidth((String)var6.get(0)) > var9) {
                  var9 = var8.getWidth((String)var6.get(0));
               }

               double var13 = 5.0 * var2;
               double var15 = var8.getHeight() + 1.0 * var2;
               double var17 = var9 + var13 * 2.0;
               double var19 = var15 * var6.size() + var13 * 2.0;
               int var21 = (Integer)this.boxX.get();
               int var22 = (Integer)this.boxY.get();
               Renderer2D.COLOR.quad(var21, var22, var17, var19, new Color(0, 0, 0, (Integer)this.backgroundAlpha.get()));
               double var23 = var22 + var13;

               for (int var30 = 0; var30 < var6.size(); var30++) {
                  String var25 = (String)var6.get(var30);
                  String var26 = (String)var7.get(var30);
                  Color var27 = var31 && var30 == 0 ? HEADER_COLOR : TEXT_COLOR;
                  var8.render(var25, var21 + var13, var23, var27, true);
                  if (var26.length() > 0) {
                     double var28 = var21 + var17 - var13 - var8.getWidth(var26);
                     var8.render(var26, var28, var23, var27, true);
                  }

                  var23 += var15;
               }

               var8.end();
               Renderer2D.COLOR.render();
            }
         }
      }
   }

   private String format(ZoneId var1, long var2) {
      ZonedDateTime var4 = ZonedDateTime.ofInstant(Instant.ofEpochMilli(var2), var1);
      if ((Boolean)this.showSeconds.get()) {
         return (this.use24h.get() ? FMT_24 : FMT_12).format(var4);
      } else {
         DateTimeFormatter var5 = DateTimeFormatter.ofPattern(this.use24h.get() ? "HH:mm" : "hh:mm a");
         return var5.format(var4);
      }
   }
}
