package x10n.flatslice.modules;

import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import x10n.flatslice.FlatSliceAddon;

public class AutoRtp extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<String> command;
   private final Setting<Boolean> fireOnSpot;
   private final Setting<Integer> delay;
   private long lastSendMs = 0L;
   private long lastHandledDetectMs = 0L;
   private boolean lastSpotted = false;

   public AutoRtp() {
      super(FlatSliceAddon.CATEGORY, "auto-rtp-v1", "Sends your rtp command in chat every few seconds, or instantly when a chunk is spotted.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.command = this.sgGeneral
         .add(
            ((Builder)((Builder)((Builder)new Builder().name("command")).description("The chat command to spam. Example: /rtp")).defaultValue("/rtp")).build()
         );
      this.fireOnSpot = this.sgGeneral
         .add(
            ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("fire-on-spot"))
                     .description(
                        "Send the command once immediately when a chunk is spotted OR a player is detected by the finder, instead of on the timer. Repeat sends are spaced by the timer interval."
                     ))
                  .defaultValue(false))
               .build()
         );
      this.delay = this.sgGeneral
         .add(
            ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("delay"))
                     .description("Seconds between each send. 1 = sends every second."))
                  .defaultValue(1))
               .min(1)
               .max(10)
               .sliderRange(1, 10)
               .build()
         );
   }

   public void onActivate() {
      this.lastSendMs = 0L;
      this.lastHandledDetectMs = 0L;
      this.lastSpotted = false;
   }

   @EventHandler
   private void onTick(Post var1) {
      if (this.mc.field_1724 != null) {
         String var2 = (String)this.command.get();
         if (!var2.isEmpty()) {
            long var3 = System.currentTimeMillis();
            int var5 = (Integer)this.delay.get() * 1000;
            if (!(Boolean)this.fireOnSpot.get()) {
               if (var3 - this.lastSendMs >= var5) {
                  this.lastSendMs = var3;
                  ChatUtils.sendPlayerMsg(var2);
               }
            } else {
               boolean var6 = FlatSlice.chunkSpotted;
               boolean var7 = var6 && !this.lastSpotted;
               this.lastSpotted = var6;
               long var8 = PlayerFinder.lastPlayerDetectedMs;
               boolean var10 = var8 != 0L && var8 > this.lastHandledDetectMs;
               if (var10) {
                  this.lastHandledDetectMs = var8;
               }

               if ((var7 || var10) && (this.lastSendMs == 0L || var3 - this.lastSendMs >= var5)) {
                  this.lastSendMs = var3;
                  ChatUtils.sendPlayerMsg(var2);
               }
            }
         }
      }
   }
}
