package x10n.flatslice.modules;

import java.util.HashSet;
import java.util.Set;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.EnumSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_1923;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2818;
import net.minecraft.class_370;
import net.minecraft.class_5250;
import net.minecraft.class_634;
import net.minecraft.class_370.class_9037;
import x10n.flatslice.FlatSliceAddon;

public class SpawnerBypass extends Module {
   public static volatile boolean chunkSpotted = false;
   private final SettingGroup sgGeneral;
   private final SettingGroup sgRender;
   private final SettingGroup sgAlerts;
   private final Setting<SpawnerBypass.Mode> mode;
   private final Setting<SettingColor> chunkColor;
   private final Setting<SettingColor> outlineColor;
   private final Setting<Double> opacity;
   private final Setting<Double> outlineAlpha;
   private final Setting<Double> chunkScale;
   private final Setting<Boolean> tracers;
   private final Setting<SettingColor> tracerColor;
   private final Setting<Boolean> clearChunksOnToggle;
   private final Setting<Boolean> alertToast;
   private final Setting<Boolean> chatOnSpotted;
   private final Setting<Boolean> showCoordinates;
   private final Setting<Boolean> disconnectOnChunk;
   private final Setting<Integer> maxNotifications;
   private final Set<class_1923> centreChunks;
   private long lastScanMs = 0L;
   private int alertsFired = 0;
   private long lastResetMs = 0L;

   public SpawnerBypass() {
      super(FlatSliceAddon.CATEGORY, "spawner-bypass", "Locates chunks that contain mob spawners, like skeleton spawners.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgRender = this.settings.createGroup("Render");
      this.sgAlerts = this.settings.createGroup("Alerts");
      this.mode = this.sgGeneral
         .add(
            ((Builder)((Builder)((Builder)new Builder().name("mode")).description("Render style: whole chunk outline or a pillar at the chunk center."))
                  .defaultValue(SpawnerBypass.Mode.CHUNK))
               .build()
         );
      this.chunkColor = this.sgGeneral
         .add(
            ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                     .name("chunk-color"))
                  .description("Fill color of the spawner chunk render."))
               .defaultValue(new SettingColor(255, 255, 255, 210))
               .build()
         );
      this.outlineColor = this.sgGeneral
         .add(
            ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                     .name("outline-color"))
                  .description("Color of the outline."))
               .defaultValue(new SettingColor(115, 200, 255, 255))
               .build()
         );
      this.opacity = this.sgGeneral
         .add(
            ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                     .name("opacity"))
                  .description("Global opacity of the whole render (fill + outline)."))
               .defaultValue(1.0)
               .range(0.0, 1.0)
               .sliderRange(0.0, 1.0)
               .decimalPlaces(2)
               .build()
         );
      this.outlineAlpha = this.sgGeneral
         .add(
            ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                     .name("outline-alpha"))
                  .description("Opacity of the outline lines on top of the global opacity."))
               .defaultValue(1.0)
               .range(0.0, 1.0)
               .sliderRange(0.0, 1.0)
               .decimalPlaces(2)
               .build()
         );
      this.chunkScale = this.sgGeneral
         .add(
            ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                     .name("chunk-scale"))
                  .description("Scale of the pillar render, centered on the chunk."))
               .defaultValue(1.0)
               .range(0.25, 4.0)
               .sliderRange(0.25, 4.0)
               .decimalPlaces(2)
               .build()
         );
      this.tracers = this.sgRender
         .add(
            ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("tracers"))
                     .description("Draw a tracer line from screen center to each located spawner chunk."))
                  .defaultValue(true))
               .build()
         );
      this.tracerColor = this.sgRender
         .add(
            ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                     .name("tracer-color"))
                  .description("Color of the tracer lines."))
               .defaultValue(new SettingColor(125, 210, 255, 220))
               .build()
         );
      this.clearChunksOnToggle = this.sgRender
         .add(
            ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("clear-chunks-on-toggle"))
                     .description("Remove the located chunks when the module is turned off or on."))
                  .defaultValue(true))
               .build()
         );
      this.alertToast = this.sgAlerts
         .add(
            ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("toast-on-spotted"))
                     .description("Show a toast notification when a spawner chunk is located."))
                  .defaultValue(true))
               .build()
         );
      this.chatOnSpotted = this.sgAlerts
         .add(
            ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("chat-on-spotted"))
                     .description("Print a chat line when a spawner chunk is located."))
                  .defaultValue(true))
               .build()
         );
      this.showCoordinates = this.sgAlerts
         .add(
            ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("show-coordinates"))
                     .description("Include the chunk-center coordinates in the chat line."))
                  .defaultValue(true))
               .build()
         );
      this.disconnectOnChunk = this.sgAlerts
         .add(
            ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                        .name("disconnect-on-chunk"))
                     .description("Instantly disconnect from the server when a spawner chunk is located."))
                  .defaultValue(false))
               .build()
         );
      this.maxNotifications = this.sgAlerts
         .add(
            ((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)((meteordevelopment.meteorclient.settings.IntSetting.Builder)new meteordevelopment.meteorclient.settings.IntSetting.Builder()
                        .name("max-notifications"))
                     .description("Maximum number of chat/toast notifications per 60 seconds."))
                  .defaultValue(100))
               .min(1)
               .max(1000)
               .sliderRange(1, 500)
               .build()
         );
      this.centreChunks = new HashSet<>();
   }

   public void onActivate() {
      chunkSpotted = false;
      this.alertsFired = 0;
      this.lastResetMs = 0L;
      if ((Boolean)this.clearChunksOnToggle.get()) {
         this.centreChunks.clear();
      }
   }

   public void onDeactivate() {
      if ((Boolean)this.clearChunksOnToggle.get()) {
         this.centreChunks.clear();
      }
   }

   @EventHandler
   private void onTick(Post var1) {
      if (this.mc.field_1687 != null && this.mc.field_1724 != null) {
         long var2 = System.currentTimeMillis();
         if (var2 - this.lastScanMs >= 1500L) {
            this.lastScanMs = var2;
            class_1923 var4 = this.mc.field_1724.method_31476();
            int var5 = var4.field_9181;
            int var6 = var4.field_9180;

            for (int var7 = -12; var7 <= 12; var7++) {
               for (int var8 = -12; var8 <= 12; var8++) {
                  class_2818 var9 = this.mc.field_1687.method_8497(var5 + var7, var6 + var8);
                  if (var9 != null && hasSpawner(var9)) {
                     class_1923 var10 = new class_1923(var5 + var7, var6 + var8);
                     if (this.centreChunks.add(var10)) {
                        this.onChunkSpotted(var10);
                     }
                  }
               }
            }
         }
      }
   }

   private static boolean hasSpawner(class_2818 var0) {
      for (class_2586 var2 : var0.method_12214().values()) {
         if (var2 != null && isMobSpawner(var2)) {
            return true;
         }
      }

      return false;
   }

   private static boolean isMobSpawner(class_2586 var0) {
      return "minecraft:mob_spawner".equals(class_2591.method_11033(var0.method_11017()).toString());
   }

   private void onChunkSpotted(class_1923 var1) {
      chunkSpotted = true;
      long var2 = System.currentTimeMillis();
      if (var2 - this.lastResetMs >= 60000L) {
         this.alertsFired = 0;
         this.lastResetMs = var2;
      }

      if ((Boolean)this.disconnectOnChunk.get()) {
         class_634 var4 = this.mc.method_1562();
         if (var4 != null) {
            var4.method_48296()
               .method_10747(
                  class_2561.method_43470(String.format("Spawner Bypass: spawner chunk at %d, %d", var1.field_9181 * 16 + 8, var1.field_9180 * 16 + 8))
               );
         }
      }

      if (this.alertsFired < (Integer)this.maxNotifications.get()) {
         this.alertsFired++;
         int var8 = var1.field_9181 * 16 + 8;
         int var5 = var1.field_9180 * 16 + 8;
         if ((Boolean)this.chatOnSpotted.get()) {
            if ((Boolean)this.showCoordinates.get()) {
               this.info("(Spawner Bypass) Spawner chunk at: " + var8 + " " + var5, new Object[0]);
            } else {
               this.info("(Spawner Bypass) Spawner chunk found", new Object[0]);
            }
         }

         if ((Boolean)this.alertToast.get()) {
            class_5250 var6 = class_2561.method_43470("Spawner Bypass: chunk found").method_27692(class_124.field_1075);
            class_5250 var7 = class_2561.method_43470(String.format("%d, %d", var8, var5));
            class_370.method_27024(this.mc.method_1566(), class_9037.field_47588, var6, var7);
         }
      }
   }

   private static int alphaByte(double var0) {
      if (Double.isNaN(var0)) {
         return 0;
      } else {
         int var2 = (int)Math.round(var0);
         if (var2 < 0) {
            var2 = 0;
         } else if (var2 > 255) {
            var2 = 255;
         }

         return var2;
      }
   }

   @EventHandler
   private void onRender3D(Render3DEvent var1) {
      if (this.mc.field_1687 != null && this.mc.field_1724 != null && !this.centreChunks.isEmpty()) {
         SpawnerBypass.Mode var2 = (SpawnerBypass.Mode)this.mode.get();
         double var3 = (Double)this.chunkScale.get();
         double var5 = (Double)this.opacity.get();
         double var7 = (Double)this.outlineAlpha.get();
         Color var9 = new Color((Color)this.chunkColor.get());
         Color var10 = new Color((Color)this.outlineColor.get());
         class_243 var11 = this.tracers.get() ? RenderUtils.center : null;
         Color var12 = new Color((Color)this.tracerColor.get());

         for (class_1923 var14 : this.centreChunks) {
            double var15 = var14.field_9181 * 16.0 + 8.0;
            double var17 = var14.field_9180 * 16.0 + 8.0;
            Color var19 = new Color(var9.r, var9.g, var9.b, alphaByte(var9.a * var5));
            Color var20 = new Color(var10.r, var10.g, var10.b, alphaByte(var10.a * var5 * var7));
            if (var2 == SpawnerBypass.Mode.CHUNK) {
               double var21 = var14.field_9181 * 16.0;
               double var23 = var14.field_9180 * 16.0;
               var1.renderer.box(var21, 62.0, var23, var21 + 16.0, 62.13, var23 + 16.0, var19, var20, ShapeMode.Both, 0);
            } else {
               double var25 = 1.25 * var3;
               var1.renderer.box(var15 - var25, 61.0, var17 - var25, var15 + var25, 101.0, var17 + var25, var19, var20, ShapeMode.Both, 0);
            }

            if (var11 != null) {
               var1.renderer.line(var11.field_1352, var11.field_1351, var11.field_1350, var15, 62.0, var17, var12);
            }
         }
      }
   }

   public static enum Mode {
      CHUNK,
      PILLAR;
   }
}
