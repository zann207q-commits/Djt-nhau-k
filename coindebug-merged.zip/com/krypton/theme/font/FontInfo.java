package com.krypton.theme.font;

public record FontInfo(String family, FontStyle type) {
   @Override
   public String toString() {
      String family = this.family;
      String type = String.valueOf(this.type);
      return family + " " + type;
   }

   public boolean matches(FontInfo other) {
      if (this == other) {
         return true;
      } else {
         return other != null && this.family != null && this.type != null ? this.family.equals(other.family) && this.type == other.type : false;
      }
   }
}
