package com.krypton.theme.font;

import com.krypton.theme.gui.TextDriver;
import com.krypton.theme.render.Mesh;
import com.krypton.theme.render.MeshRenderer;
import com.krypton.theme.render.Pipelines;
import com.krypton.theme.util.Color;
import java.nio.ByteBuffer;
import net.minecraft.class_310;
import org.lwjgl.BufferUtils;

public class CustomFontDriver implements TextDriver {
   public static Color SHADOW = new Color(60, 60, 60, 180);
   public FontFace face;
   public Mesh mesh = new Mesh(Pipelines.UI_TEXT);
   public GlyphPage[] pages;
   public GlyphPage page;
   public boolean active;
   public boolean nested;
   public double pageScale = 1.0;
   public double scaleRatio = 1.0;

   public CustomFontDriver(FontFace face) {
      this.face = face;
      byte[] bytes = FontDiscovery.readAll(face.open());
      ByteBuffer fontData = BufferUtils.createByteBuffer(bytes.length).put(bytes).flip();
      this.pages = new GlyphPage[5];

      for (int i = 0; i < this.pages.length; i++) {
         this.pages[i] = new GlyphPage(fontData, (int)Math.round(27.0 * (i * 0.5 + 1.0)));
      }
   }

   @Override
   public void setAlpha(double alpha) {
      this.mesh.alphaMultiplier = alpha;
   }

   @Override
   public void begin(double scale, boolean flagA, boolean flagB) {
      if (this.active) {
         throw new RuntimeException("CustomTextRenderer.begin() called twice");
      } else {
         if (!flagA) {
            this.mesh.begin();
         }

         if (flagB) {
            this.page = this.pages[this.pages.length - 1];
         } else {
            double quantised = Math.floor(scale * 10.0) / 10.0;
            byte index;
            if (quantised >= 3.0) {
               index = 5;
            } else if (quantised >= 2.5) {
               index = 4;
            } else if (quantised >= 2.0) {
               index = 3;
            } else if (quantised >= 1.5) {
               index = 2;
            } else {
               index = 1;
            }

            this.page = this.pages[index - 1];
         }

         this.active = true;
         this.nested = flagA;
         this.pageScale = this.page.size() / 27.0;
         this.scaleRatio = 1.0 + (scale - this.pageScale) / this.pageScale;
      }
   }

   @Override
   public double width(String text, int length, boolean flag) {
      if (text.isEmpty()) {
         return 0.0;
      } else {
         GlyphPage page = this.active ? this.page : this.pages[0];
         return (page.measure(text, length) + (flag ? 1 : 0)) * this.scaleRatio / 1.5;
      }
   }

   @Override
   public double height(boolean flag) {
      GlyphPage page = this.active ? this.page : this.pages[0];
      return (page.size() + 1 + (flag ? 1 : 0)) * this.scaleRatio / 1.5;
   }

   @Override
   public double draw(String text, double x, double y, Color color, boolean shadow) {
      boolean wasActive = this.active;
      if (!wasActive) {
         this.begin();
      }

      double penX;
      if (shadow) {
         int shadowAlpha = SHADOW.a;
         SHADOW.a = (int)(color.a / 255.0 * shadowAlpha);
         penX = this.page
            .draw(this.mesh, text, x + this.pageScale * this.scaleRatio / 1.5, y + this.pageScale * this.scaleRatio / 1.5, SHADOW, this.scaleRatio / 1.5);
         this.page.draw(this.mesh, text, x, y, color, this.scaleRatio / 1.5);
         SHADOW.a = shadowAlpha;
      } else {
         penX = this.page.draw(this.mesh, text, x, y, color, this.scaleRatio / 1.5);
      }

      if (!wasActive) {
         this.end();
      }

      return penX;
   }

   @Override
   public boolean isCustom() {
      return this.active;
   }

   @Override
   public void end() {
      if (!this.active) {
         throw new RuntimeException("CustomTextRenderer.end() called without calling begin()");
      } else {
         if (!this.nested) {
            this.mesh.end();
            MeshRenderer.begin()
               .target(class_310.method_1551().method_1522())
               .pipeline(Pipelines.UI_TEXT)
               .mesh(this.mesh)
               .texture("u_Texture", this.page.texture.method_71659(), this.page.texture.method_75484())
               .draw();
         }

         this.active = false;
         this.scaleRatio = 1.0;
      }
   }

   public void dispose() {
      for (GlyphPage page : this.pages) {
         page.texture.close();
      }
   }
}
