package com.krypton.theme.font;

import java.io.InputStream;

public class BuiltinFontFace extends FontFace {
   public String resourceName;

   public BuiltinFontFace(FontInfo info, String resourceName) {
      super(info);
      this.resourceName = resourceName;
   }

   @Override
   public InputStream open() {
      InputStream stream = FontDiscovery.openBuiltin(this.resourceName);
      if (stream == null) {
         String name = this.resourceName;
         throw new RuntimeException("Failed to load builtin font " + name + ".");
      } else {
         return stream;
      }
   }

   @Override
   public String toString() {
      String base = super.toString();
      return base + " (builtin)";
   }
}
