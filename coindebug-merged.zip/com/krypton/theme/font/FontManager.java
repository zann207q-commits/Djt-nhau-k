package com.krypton.theme.font;

import java.io.File;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class FontManager {
   public static String[] BUILTIN_FAMILIES = new String[]{"font"};
   public static List<FontFamily> families = new ArrayList<>();
   public static String defaultFamilyName;
   public static FontFace defaultFace;
   public static CustomFontDriver driver;
   public static boolean loaded = false;

   public static void init() {
      if (!loaded) {
         loaded = true;
         reload();
      }
   }

   public static void reload() {
      families.clear();

      for (String builtin : BUILTIN_FAMILIES) {
         FontDiscovery.discoverBuiltin(families, builtin);
      }

      for (String directory : FontDiscovery.fontDirectories()) {
         FontDiscovery.discoverDirectory(families, new File(directory), BUILTIN_FAMILIES);
      }

      families.sort(Comparator.comparing(FontFamily::name));
      defaultFamilyName = FontDiscovery.probe(BUILTIN_FAMILIES[0]).family();
      defaultFace = family(defaultFamilyName).face(FontStyle.Regular);
      use(defaultFace);
   }

   public static void use(FontFace face) {
      if (driver != null) {
         if (driver.face.equals(face)) {
            return;
         }

         driver.dispose();
      }

      try {
         driver = new CustomFontDriver(face);
      } catch (Exception var4) {
         if (face.equals(defaultFace)) {
            String description = String.valueOf(face);
            throw new RuntimeException("Failed to load default font: " + description, var4);
         }

         PrintStream err = System.err;
         String description = String.valueOf(face);
         err.println("Failed to load font: " + description);
         var4.printStackTrace();
         use(defaultFace);
      }
   }

   public static FontFamily family(String name) {
      for (FontFamily family : families) {
         if (family.name().equalsIgnoreCase(name)) {
            return family;
         }
      }

      return null;
   }
}
