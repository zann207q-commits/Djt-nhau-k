package com.krypton.theme.font;

public enum FontStyle {
   Regular,
   Bold,
   Italic,
   BoldItalic;

   public static FontStyle parse(String subfamily) {
      return switch (subfamily) {
         case "Bold" -> Bold;
         case "Italic" -> Italic;
         case "Bold Italic", "BoldItalic" -> BoldItalic;
         default -> Regular;
      };
   }

   @Override
   public String toString() {
      return switch (this) {
         case Bold -> "Bold";
         case Italic -> "Italic";
         case BoldItalic -> "Bold Italic";
         default -> "Regular";
      };
   }
}
