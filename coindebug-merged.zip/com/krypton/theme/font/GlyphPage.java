package com.krypton.theme.font;

import com.krypton.theme.render.Mesh;
import com.krypton.theme.util.Color;
import com.krypton.theme.util.IconTexture;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.TextureFormat;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import org.lwjgl.BufferUtils;
import org.lwjgl.stb.STBTTFontinfo;
import org.lwjgl.stb.STBTTPackContext;
import org.lwjgl.stb.STBTTPackRange;
import org.lwjgl.stb.STBTTPackedchar;
import org.lwjgl.stb.STBTruetype;
import org.lwjgl.stb.STBTTPackedchar.Buffer;
import org.lwjgl.system.MemoryStack;

public class GlyphPage {
   public static int ATLAS_SIZE = 2048;
   public IconTexture texture;
   public int pixelHeight;
   public float pixelScale;
   public float ascent;
   public Int2ObjectOpenHashMap<Glyph> glyphs = new Int2ObjectOpenHashMap();

   public GlyphPage(ByteBuffer fontData, int pixelHeight) {
      this.pixelHeight = pixelHeight;
      STBTTFontinfo fontInfo = STBTTFontinfo.create();
      STBTruetype.stbtt_InitFont(fontInfo, fontData);
      ByteBuffer pixels = BufferUtils.createByteBuffer(4194304);
      Buffer[] ranges = new Buffer[]{
         STBTTPackedchar.create(95),
         STBTTPackedchar.create(96),
         STBTTPackedchar.create(128),
         STBTTPackedchar.create(144),
         STBTTPackedchar.create(256),
         STBTTPackedchar.create(1)
      };
      STBTTPackContext packContext = STBTTPackContext.create();
      STBTruetype.stbtt_PackBegin(packContext, pixels, 2048, 2048, 0, 1);
      org.lwjgl.stb.STBTTPackRange.Buffer packRanges = STBTTPackRange.create(ranges.length);
      packRanges.put(STBTTPackRange.create().set(pixelHeight, 32, null, 95, ranges[0], (byte)2, (byte)2));
      packRanges.put(STBTTPackRange.create().set(pixelHeight, 160, null, 96, ranges[1], (byte)2, (byte)2));
      packRanges.put(STBTTPackRange.create().set(pixelHeight, 256, null, 128, ranges[2], (byte)2, (byte)2));
      packRanges.put(STBTTPackRange.create().set(pixelHeight, 880, null, 144, ranges[3], (byte)2, (byte)2));
      packRanges.put(STBTTPackRange.create().set(pixelHeight, 1024, null, 256, ranges[4], (byte)2, (byte)2));
      packRanges.put(STBTTPackRange.create().set(pixelHeight, 8734, null, 1, ranges[5], (byte)2, (byte)2));
      packRanges.flip();
      STBTruetype.stbtt_PackFontRanges(packContext, fontData, 0, packRanges);
      STBTruetype.stbtt_PackEnd(packContext);
      this.texture = new IconTexture(2048, 2048, TextureFormat.RED8, FilterMode.LINEAR, FilterMode.LINEAR);
      this.texture.upload(pixels);
      this.pixelScale = STBTruetype.stbtt_ScaleForPixelHeight(fontInfo, pixelHeight);
      MemoryStack stack = MemoryStack.stackPush();

      try {
         IntBuffer ascent = stack.mallocInt(1);
         STBTruetype.stbtt_GetFontVMetrics(fontInfo, ascent, null, null);
         this.ascent = ascent.get(0);
      } catch (Throwable var16) {
         if (stack != null) {
            try {
               stack.close();
            } catch (Throwable var15) {
               var16.addSuppressed(var15);
            }
         }

         throw var16;
      }

      if (stack != null) {
         stack.close();
      }

      for (int rangeIndex = 0; rangeIndex < ranges.length; rangeIndex++) {
         Buffer range = ranges[rangeIndex];
         int firstCodepoint = ((STBTTPackRange)packRanges.get(rangeIndex)).first_unicode_codepoint_in_range();

         for (int i = 0; i < range.capacity(); i++) {
            STBTTPackedchar packed = (STBTTPackedchar)range.get(i);
            float invAtlasWidth = 4.8828125E-4F;
            float invAtlasHeight = 4.8828125E-4F;
            this.glyphs
               .put(
                  i + firstCodepoint,
                  new Glyph(
                     packed.xoff(),
                     packed.yoff(),
                     packed.xoff2(),
                     packed.yoff2(),
                     packed.x0() * invAtlasWidth,
                     packed.y0() * invAtlasHeight,
                     packed.x1() * invAtlasWidth,
                     packed.y1() * invAtlasHeight,
                     packed.xadvance()
                  )
               );
         }
      }
   }

   public double measure(String text, int length) {
      double width = 0.0;

      for (int i = 0; i < length; i++) {
         char c = text.charAt(i);
         Glyph glyph = (Glyph)this.glyphs.get(c);
         if (glyph == null) {
            glyph = (Glyph)this.glyphs.get(32);
         }

         width += glyph.xAdvance();
      }

      return width;
   }

   public int size() {
      return this.pixelHeight;
   }

   public double draw(Mesh mesh, String text, double x, double y, Color color, double scale) {
      y += this.ascent * this.pixelScale * scale;
      int length = text.length();
      mesh.ensureCapacity(length * 4, length * 6);

      for (int i = 0; i < length; i++) {
         char c = text.charAt(i);
         Glyph glyph = (Glyph)this.glyphs.get(c);
         if (glyph == null) {
            glyph = (Glyph)this.glyphs.get(32);
         }

         mesh.quad(
            mesh.vec2(x + glyph.x0() * scale, y + glyph.y0() * scale).vec2((double)glyph.u0(), (double)glyph.v0()).color(color).nextIndex(),
            mesh.vec2(x + glyph.x0() * scale, y + glyph.y1() * scale).vec2((double)glyph.u0(), (double)glyph.v1()).color(color).nextIndex(),
            mesh.vec2(x + glyph.x1() * scale, y + glyph.y1() * scale).vec2((double)glyph.u1(), (double)glyph.v1()).color(color).nextIndex(),
            mesh.vec2(x + glyph.x1() * scale, y + glyph.y0() * scale).vec2((double)glyph.u1(), (double)glyph.v0()).color(color).nextIndex()
         );
         x += glyph.xAdvance() * scale;
      }

      return x;
   }
}
