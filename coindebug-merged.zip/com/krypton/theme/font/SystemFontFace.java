package com.krypton.theme.font;

import java.io.InputStream;
import java.nio.file.Path;

public class SystemFontFace extends FontFace {
   public Path path;

   public SystemFontFace(FontInfo info, Path path) {
      super(info);
      this.path = path;
   }

   @Override
   public InputStream open() {
      if (!this.path.toFile().exists()) {
         throw new RuntimeException("Tried to load font that no longer exists.");
      } else {
         InputStream stream = FontDiscovery.openFile(this.path.toFile());
         if (stream == null) {
            String path = String.valueOf(this.path);
            throw new RuntimeException("Failed to load font from " + path + ".");
         } else {
            return stream;
         }
      }
   }

   @Override
   public String toString() {
      String base = super.toString();
      String path = this.path.toString();
      return base + " (" + path + ")";
   }
}
