package com.krypton.theme.font;

import java.util.ArrayList;
import java.util.List;

public class FontFamily {
   public String name;
   public List<FontFace> faces = new ArrayList<>();

   public FontFamily(String name) {
      this.name = name;
   }

   public boolean add(FontFace face) {
      return this.faces.add(face);
   }

   public boolean has(FontStyle style) {
      return this.face(style) != null;
   }

   public FontFace face(FontStyle style) {
      if (style == null) {
         return null;
      } else {
         for (FontFace face : this.faces) {
            if (face.info.type().equals(style)) {
               return face;
            }
         }

         return null;
      }
   }

   public String name() {
      return this.name;
   }
}
