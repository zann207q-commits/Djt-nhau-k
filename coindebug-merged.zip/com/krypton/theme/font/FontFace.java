package com.krypton.theme.font;

import java.io.InputStream;

public abstract class FontFace {
   public FontInfo info;

   public FontFace(FontInfo info) {
      this.info = info;
   }

   public abstract InputStream open();

   @Override
   public String toString() {
      return this.info.toString();
   }
}
