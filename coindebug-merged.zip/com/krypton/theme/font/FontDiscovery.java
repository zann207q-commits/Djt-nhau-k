package com.krypton.theme.font;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.PrintStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_156;
import org.lwjgl.BufferUtils;
import org.lwjgl.stb.STBTTFontinfo;
import org.lwjgl.stb.STBTruetype;

public class FontDiscovery {
   public static byte[] readAll(InputStream stream) {
      try {
         return stream.readAllBytes();
      } catch (Exception var4) {
         PrintStream err = System.err;
         String message = var4.getMessage();
         err.println("Error reading from stream: " + message);
         return new byte[0];
      }
   }

   public static FontInfo probe(File file) {
      return probe(openFile(file));
   }

   public static FontInfo probe(String resourceName) {
      return probe(openBuiltin(resourceName));
   }

   public static FontInfo probe(InputStream stream) {
      if (stream == null) {
         return null;
      } else {
         byte[] bytes = readAll(stream);
         if (bytes.length < 5) {
            return null;
         } else if (bytes[0] == 0 && bytes[1] == 1 && bytes[2] == 0 && bytes[3] == 0 && bytes[4] == 0) {
            ByteBuffer buffer = BufferUtils.createByteBuffer(bytes.length).put(bytes).flip();
            STBTTFontinfo info = STBTTFontinfo.create();
            if (!STBTruetype.stbtt_InitFont(info, buffer)) {
               return null;
            } else {
               ByteBuffer familyName = STBTruetype.stbtt_GetFontNameString(info, 3, 1, 1033, 1);
               ByteBuffer subfamilyName = STBTruetype.stbtt_GetFontNameString(info, 3, 1, 1033, 2);
               return subfamilyName != null && familyName != null
                  ? new FontInfo(
                     StandardCharsets.UTF_16.decode(familyName).toString(), FontStyle.parse(StandardCharsets.UTF_16.decode(subfamilyName).toString())
                  )
                  : null;
            }
         } else {
            return null;
         }
      }
   }

   public static Set<String> fontDirectories() {
      HashSet<String> directories = new HashSet<>();
      String javaHome = System.getProperty("java.home");
      directories.add(javaHome + "/lib/fonts");

      for (File directory : userFontDirectories()) {
         if (directory.exists()) {
            directories.add(directory.getAbsolutePath());
         }
      }

      for (File directoryx : systemFontDirectories()) {
         if (directoryx.exists()) {
            directories.add(directoryx.getAbsolutePath());
         }
      }

      return directories;
   }

   public static List<File> userFontDirectories() {
      List<File> directories;
      switch (class_156.method_668()) {
         case field_1133: {
            String home = System.getProperty("user.home");
            directories = List.of(new File(home + "\\AppData\\Local\\Microsoft\\Windows\\Fonts"));
            break;
         }
         case field_1137: {
            String home = System.getProperty("user.home");
            directories = List.of(new File(home + "/Library/Fonts/"));
            break;
         }
         default: {
            String home = System.getProperty("user.home");
            File local = new File(home + "/.local/share/fonts");
            String home2 = System.getProperty("user.home");
            directories = List.of(local, new File(home2 + "/.fonts"));
         }
      }

      return directories;
   }

   public static List<File> systemFontDirectories() {
      return switch (class_156.method_668()) {
         case field_1133 -> {
            String systemRoot = System.getenv("SystemRoot");
            yield List.of(new File(systemRoot + "\\Fonts"));
         }
         case field_1137 -> List.of(new File("/System/Library/Fonts/"));
         default -> List.of(new File("/usr/share/fonts/"));
      };
   }

   public static void discoverBuiltin(List<FontFamily> families, String resourceName) {
      FontInfo info = probe(resourceName);
      if (info != null) {
         BuiltinFontFace face = new BuiltinFontFace(info, resourceName);
         if (!register(families, face)) {
            PrintStream err = System.err;
            String description = String.valueOf(face);
            err.println("Failed to load builtin font " + description);
         }
      }
   }

   public static void discoverDirectory(List<FontFamily> families, File directory, String[] builtinNames) {
      if (directory.exists() && directory.isDirectory()) {
         File[] entries = directory.listFiles(entryx -> entryx.isFile() && entryx.getName().endsWith(".ttf") || entryx.isDirectory());
         if (entries != null) {
            for (File entry : entries) {
               if (entry.isDirectory()) {
                  discoverDirectory(families, entry, builtinNames);
               } else {
                  FontInfo info = probe(entry);
                  if (info != null) {
                     boolean builtin = false;

                     for (String builtinName : builtinNames) {
                        if (builtinName.equals(info.family())) {
                           builtin = true;
                           break;
                        }
                     }

                     if (!builtin) {
                        SystemFontFace face = new SystemFontFace(info, entry.toPath());
                        if (!register(families, face)) {
                           PrintStream err = System.err;
                           String description = String.valueOf(face);
                           err.println("Failed to load system font " + description);
                        }
                     }
                  }
               }
            }
         }
      }
   }

   public static boolean register(List<FontFamily> families, FontFace face) {
      if (face == null) {
         return false;
      } else {
         FontInfo info = face.info;
         FontFamily family = findFamily(families, info.family());
         if (family == null) {
            family = new FontFamily(info.family());
            families.add(family);
         }

         return family.has(info.type()) ? false : family.add(face);
      }
   }

   public static FontFamily findFamily(List<FontFamily> families, String name) {
      for (FontFamily family : families) {
         if (family.name().equalsIgnoreCase(name)) {
            return family;
         }
      }

      return null;
   }

   public static InputStream openBuiltin(String resourceName) {
      return FontDiscovery.class.getResourceAsStream("/assets/krypton/fonts/" + resourceName + ".ttf");
   }

   public static InputStream openFile(File file) {
      try {
         return new FileInputStream(file);
      } catch (FileNotFoundException var2) {
         var2.printStackTrace();
         return null;
      }
   }
}
