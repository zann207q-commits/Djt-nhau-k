package com.krypton.theme.event;

import net.minecraft.class_11909;

public class MouseClickEvent extends CancellableEvent {
   public class_11909 click;
   public int action;
   public long windowHandle;

   public MouseClickEvent(class_11909 click, long windowHandle, int action) {
      this.click = click;
      this.windowHandle = windowHandle;
      this.action = action;
   }
}
