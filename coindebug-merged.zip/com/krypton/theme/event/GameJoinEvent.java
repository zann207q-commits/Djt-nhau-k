package com.krypton.theme.event;

public class GameJoinEvent implements Event {
}
