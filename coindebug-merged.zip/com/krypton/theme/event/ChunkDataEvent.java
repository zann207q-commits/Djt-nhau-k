package com.krypton.theme.event;

import net.minecraft.class_2672;

public class ChunkDataEvent implements Event {
   public class_2672 packet;

   public ChunkDataEvent(class_2672 packet) {
      this.packet = packet;
   }
}
