package com.krypton.theme.event;

public enum EventPriority {
   HIGHEST(0),
   HIGH(1),
   NORMAL(2),
   LOW(3),
   LOWEST(4);

   public int value;

   private EventPriority(int value) {
      this.value = value;
   }

   public int getValue() {
      return this.value;
   }
}
