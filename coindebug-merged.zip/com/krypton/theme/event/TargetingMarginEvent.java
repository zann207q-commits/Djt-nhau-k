package com.krypton.theme.event;

import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

public class TargetingMarginEvent implements Event {
   public class_1297 entity;
   public CallbackInfoReturnable<Float> returnable;

   public TargetingMarginEvent(class_1297 entity, CallbackInfoReturnable<Float> returnable) {
      this.entity = entity;
      this.returnable = returnable;
   }
}
