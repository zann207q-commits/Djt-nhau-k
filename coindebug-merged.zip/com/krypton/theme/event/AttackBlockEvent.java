package com.krypton.theme.event;

public class AttackBlockEvent extends CancellableEvent {
}
