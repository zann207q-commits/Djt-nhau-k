package com.krypton.theme.event;

public class XrEvent implements Event {
}
