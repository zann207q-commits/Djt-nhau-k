package com.krypton.theme.event;

import net.minecraft.class_332;

public class Render2DEvent implements Event {
   public class_332 context;
   public float tickDelta;

   public Render2DEvent(class_332 context, float tickDelta) {
      this.context = context;
      this.tickDelta = tickDelta;
   }
}
