package com.krypton.theme.event;

public class ItemUseEvent extends CancellableEvent {
   public int cooldown;

   public ItemUseEvent(int cooldown) {
      this.cooldown = cooldown;
   }
}
