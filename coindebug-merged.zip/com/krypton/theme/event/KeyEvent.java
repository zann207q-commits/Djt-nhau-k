package com.krypton.theme.event;

import net.minecraft.class_11908;

public class KeyEvent extends CancellableEvent {
   public class_11908 input;
   public int action;
   public long windowHandle;

   public KeyEvent(class_11908 input, long windowHandle, int action) {
      this.input = input;
      this.windowHandle = windowHandle;
      this.action = action;
   }
}
