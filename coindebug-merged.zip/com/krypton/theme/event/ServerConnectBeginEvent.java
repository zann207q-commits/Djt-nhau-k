package com.krypton.theme.event;

import net.minecraft.class_639;

public class ServerConnectBeginEvent implements Event {
   public final class_639 address;

   public ServerConnectBeginEvent(class_639 address) {
      this.address = address;
   }

   public class_639 getAddress() {
      return this.address;
   }
}
