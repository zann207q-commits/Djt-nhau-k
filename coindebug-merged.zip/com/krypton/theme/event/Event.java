package com.krypton.theme.event;

public interface Event {
   default boolean isCancelled() {
      return false;
   }
}
