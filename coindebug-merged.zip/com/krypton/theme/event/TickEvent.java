package com.krypton.theme.event;

public class TickEvent implements Event {
}
