package com.krypton.theme.event;

import net.minecraft.class_2604;

public class EntitySpawnEvent extends CancellableEvent {
   public class_2604 packet;

   public EntitySpawnEvent(class_2604 packet) {
      this.packet = packet;
   }
}
