package com.krypton.theme.event;

import net.minecraft.class_2596;

public class PacketSendEvent extends CancellableEvent {
   public class_2596<?> packet;

   public PacketSendEvent(class_2596<?> packet) {
      this.packet = packet;
   }
}
