package com.krypton.theme.event;

import net.minecraft.class_2338;
import net.minecraft.class_2350;

public class BreakBlockEvent extends CancellableEvent {
   public class_2338 pos;
   public class_2350 direction;

   public BreakBlockEvent(class_2338 pos, class_2350 direction) {
      this.pos = pos;
      this.direction = direction;
   }
}
