package com.krypton.theme.event;

import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

public class KxEvent implements Event {
   public class_1297 entity;
   public CallbackInfoReturnable<?> returnable;

   public KxEvent(class_1297 entity, CallbackInfoReturnable<?> returnable) {
      this.entity = entity;
      this.returnable = returnable;
   }
}
