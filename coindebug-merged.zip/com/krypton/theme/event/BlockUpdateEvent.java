package com.krypton.theme.event;

import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class BlockUpdateEvent extends CancellableEvent {
   public class_2338 pos;
   public class_2680 oldState;
   public class_2680 newState;

   public BlockUpdateEvent(class_2338 pos, class_2680 oldState, class_2680 newState) {
      this.pos = pos;
      this.oldState = oldState;
      this.newState = newState;
   }
}
