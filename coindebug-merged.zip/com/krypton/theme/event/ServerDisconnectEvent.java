package com.krypton.theme.event;

import net.minecraft.class_639;
import net.minecraft.class_642;

public record ServerDisconnectEvent(class_639 address, class_642 info) implements Event {
}
