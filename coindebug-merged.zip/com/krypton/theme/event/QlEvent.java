package com.krypton.theme.event;

public class QlEvent implements Event {
}
