package com.krypton.theme.event;

import net.minecraft.class_1041;

public class QbEvent implements Event {
   public class_1041 window;

   public QbEvent(class_1041 window) {
      this.window = window;
   }
}
