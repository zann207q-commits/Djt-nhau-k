package com.krypton.theme.event;

public class CameraClipEvent extends CancellableEvent {
}
