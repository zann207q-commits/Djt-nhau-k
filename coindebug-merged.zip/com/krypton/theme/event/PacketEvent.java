package com.krypton.theme.event;

import net.minecraft.class_2596;

public class PacketEvent extends CancellableEvent {
   public class_2596<?> packet;

   public PacketEvent(class_2596<?> packet) {
      this.packet = packet;
   }
}
