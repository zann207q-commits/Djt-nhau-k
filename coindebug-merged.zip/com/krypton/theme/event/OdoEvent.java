package com.krypton.theme.event;

public class OdoEvent implements Event {
}
