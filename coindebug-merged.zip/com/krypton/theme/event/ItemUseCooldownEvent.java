package com.krypton.theme.event;

public class ItemUseCooldownEvent extends CancellableEvent {
   public int cooldown;

   public ItemUseCooldownEvent(int cooldown) {
      this.cooldown = cooldown;
   }
}
