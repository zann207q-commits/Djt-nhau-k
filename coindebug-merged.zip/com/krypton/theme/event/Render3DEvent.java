package com.krypton.theme.event;

import com.krypton.theme.util.Renderer3D;
import net.minecraft.class_4587;

public class Render3DEvent implements Event {
   public class_4587 matrices;
   public Renderer3D renderer;
   public float tickDelta;
   public double x;
   public double y;
   public double z;

   public Render3DEvent(class_4587 matrices, Renderer3D renderer, float tickDelta, double x, double y, double z) {
      this.matrices = matrices;
      this.renderer = renderer;
      this.tickDelta = tickDelta;
      this.x = x;
      this.y = y;
      this.z = z;
   }
}
