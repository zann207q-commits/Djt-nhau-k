package com.krypton.theme.event;

public class GameLeftEvent implements Event {
}
