package com.krypton.theme.event;

public class AttackEvent extends CancellableEvent {
}
