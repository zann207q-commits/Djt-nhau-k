package com.krypton.theme.event;

import net.minecraft.class_437;

public class ScreenOpenEvent extends CancellableEvent {
   public class_437 screen;

   public ScreenOpenEvent(class_437 screen) {
      this.screen = screen;
   }
}
