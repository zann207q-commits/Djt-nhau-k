package com.krypton.theme.event;

public abstract class CancellableEvent implements Event {
   public boolean cancelled = false;

   @Override
   public boolean isCancelled() {
      return this.cancelled;
   }

   public void cancel() {
      this.cancelled = true;
   }
}
