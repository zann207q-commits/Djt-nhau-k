package com.krypton.theme.event;

public class TotemPopEvent implements Event {
}
