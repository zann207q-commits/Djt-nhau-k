package com.krypton.theme.event;

public class MouseScrollEvent extends CancellableEvent {
   public double delta;

   public MouseScrollEvent(double delta) {
      this.delta = delta;
   }
}
