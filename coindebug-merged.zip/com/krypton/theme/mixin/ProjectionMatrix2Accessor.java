package com.krypton.theme.mixin;

import net.minecraft.class_11278;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({class_11278.class})
public interface ProjectionMatrix2Accessor {
   @Invoker("getMatrix")
   Matrix4f krypton$callGetMatrix(float var1, float var2);
}
