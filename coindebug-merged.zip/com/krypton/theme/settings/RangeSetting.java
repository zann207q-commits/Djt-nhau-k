package com.krypton.theme.settings;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.Random;

public class RangeSetting extends Setting {
   public double min;
   public double max;
   public double step;
   public double defaultMin;
   public double defaultMax;
   public double valueMin;
   public double valueMax;

   public RangeSetting(String name, double min, double max, double step, double valueMin, double valueMax) {
      super(name);
      this.min = min;
      this.max = max;
      this.step = step;
      this.valueMin = valueMin;
      this.valueMax = valueMax;
      this.defaultMin = valueMin;
      this.defaultMax = valueMax;
   }

   public int getMinInt() {
      return (int)this.valueMin;
   }

   public float getMinFloat() {
      return (float)this.valueMin;
   }

   public long getMinLong() {
      return (long)this.valueMin;
   }

   public int getMaxInt() {
      return (int)this.valueMax;
   }

   public float getMaxFloat() {
      return (float)this.valueMax;
   }

   public long getMaxLong() {
      return (long)this.valueMax;
   }

   public double getMin() {
      return this.min;
   }

   public double getMax() {
      return this.max;
   }

   public double getValueMin() {
      return this.valueMin;
   }

   public void setValueMin(double value) {
      double inverse = 1.0 / this.step;
      this.valueMin = Math.round(Math.max(this.min, Math.min(this.max, value)) * inverse) / inverse;
      this.fireChanged();
   }

   public double getValueMax() {
      return this.valueMax;
   }

   public void setValueMax(double value) {
      double inverse = 1.0 / this.step;
      this.valueMax = Math.round(Math.max(this.min, Math.min(this.max, value)) * inverse) / inverse;
      this.fireChanged();
   }

   public double getDefaultMin() {
      return this.defaultMin;
   }

   public double getDefaultMax() {
      return this.defaultMax;
   }

   public double getStep() {
      return this.step;
   }

   @Override
   public boolean isDefault() {
      return this.valueMin == this.defaultMin && this.valueMax == this.defaultMax;
   }

   @Override
   public JsonElement toJson() {
      JsonObject o = new JsonObject();
      o.addProperty("min", this.valueMin);
      o.addProperty("max", this.valueMax);
      return o;
   }

   @Override
   public void fromJson(JsonElement element) {
      if (element.isJsonObject()) {
         JsonObject o = element.getAsJsonObject();
         if (o.has("min") && o.has("max")) {
            this.setValueMin(o.get("min").getAsDouble());
            this.setValueMax(o.get("max").getAsDouble());
         }
      }
   }

   @Override
   public void reset() {
      this.setValueMin(this.defaultMin);
      this.setValueMax(this.defaultMax);
   }

   public double randomDouble() {
      return this.getValueMax() > this.getValueMin() ? new Random().nextDouble(this.getValueMin(), this.getValueMax()) : this.getValueMin();
   }

   public int randomInt() {
      return this.getValueMax() > this.getValueMin() ? new Random().nextInt(this.getMinInt(), this.getMaxInt()) : this.getMinInt();
   }

   public float randomFloat() {
      return this.getValueMax() > this.getValueMin() ? new Random().nextFloat(this.getMinFloat(), this.getMaxFloat()) : this.getMinFloat();
   }

   public long randomLong() {
      return this.getValueMax() > this.getValueMin() ? new Random().nextLong(this.getMinLong(), this.getMaxLong()) : this.getMinLong();
   }
}
