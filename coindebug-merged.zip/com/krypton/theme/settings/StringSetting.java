package com.krypton.theme.settings;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class StringSetting extends Setting {
   public String defaultValue;
   public String value;

   public StringSetting(String name, String value) {
      super(name);
      this.defaultValue = value;
      this.value = value;
   }

   public String getDefault() {
      return this.defaultValue;
   }

   public String get() {
      return this.value;
   }

   public void set(String value) {
      this.value = value;
      this.fireChanged();
   }

   @Override
   public boolean isDefault() {
      return this.value.equals(this.defaultValue);
   }

   @Override
   public JsonElement toJson() {
      return new JsonPrimitive(this.value);
   }

   @Override
   public void fromJson(JsonElement element) {
      if (element.isJsonPrimitive()) {
         this.set(element.getAsString());
      }
   }

   @Override
   public void reset() {
      this.set(this.defaultValue);
   }

   public StringSetting description(String description) {
      super.description(description);
      return this;
   }

   public StringSetting noSerialize() {
      super.noSerialize();
      return this;
   }
}
