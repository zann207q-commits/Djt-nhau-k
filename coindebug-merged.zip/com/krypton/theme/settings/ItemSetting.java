package com.krypton.theme.settings;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ItemSetting extends Setting {
   public class_1792 defaultValue;
   public List<class_1792> candidates;
   public class_1792 value;

   public ItemSetting(String name, class_1792 value) {
      this(name, value, null);
   }

   public ItemSetting(String name, class_1792 value, List<class_1792> candidates) {
      super(name);
      this.value = value;
      this.defaultValue = value;
      this.candidates = candidates;
   }

   public List<class_1792> getCandidates() {
      return this.candidates;
   }

   public class_1792 get() {
      return this.value;
   }

   public void set(class_1792 value) {
      this.value = value;
      this.fireChanged();
   }

   public class_1792 getDefault() {
      return this.defaultValue;
   }

   @Override
   public void reset() {
      this.set(this.defaultValue);
   }

   @Override
   public boolean isDefault() {
      return this.value == this.defaultValue;
   }

   @Override
   public JsonElement toJson() {
      return new JsonPrimitive(class_7923.field_41178.method_10221(this.value).toString());
   }

   @Override
   public void fromJson(JsonElement element) {
      if (element.isJsonPrimitive()) {
         this.set((class_1792)class_7923.field_41178.method_63535(class_2960.method_60654(element.getAsString())));
      }
   }
}
