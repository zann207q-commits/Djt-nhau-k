package com.krypton.theme.settings;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.krypton.theme.util.OrePlacement;
import java.util.HashSet;
import java.util.Set;

public class OreListSetting extends Setting {
   public Set<Object> defaults;
   public Set<Object> value;

   public OreListSetting(String name, Set<Object> value) {
      super(name);
      this.value = new HashSet<>(value);
      this.defaults = new HashSet<>(value);
   }

   public Set<Object> get() {
      return this.value;
   }

   public void set(Set<Object> value) {
      this.value = new HashSet<>(value);
      this.fireChanged();
   }

   public Set<Object> getDefaults() {
      return this.defaults;
   }

   @Override
   public void reset() {
      this.value = new HashSet<>(this.defaults);
      this.fireChanged();
   }

   @Override
   public boolean isDefault() {
      return this.value.equals(this.defaults);
   }

   @Override
   public JsonElement toJson() {
      JsonArray array = new JsonArray();
      this.value.stream().map(OreEntry::name).sorted().forEach(array::add);
      return array;
   }

   @Override
   public void fromJson(JsonElement element) {
      if (element.isJsonArray()) {
         JsonArray array = element.getAsJsonArray();
         this.value.clear();

         for (JsonElement child : array) {
            if (child.isJsonPrimitive()) {
               String name = child.getAsString();

               for (OreEntry ore : OrePlacement.TABLE) {
                  if (ore.name().equals(name)) {
                     this.value.add(ore);
                     break;
                  }
               }
            }
         }

         this.fireChanged();
      }
   }
}
