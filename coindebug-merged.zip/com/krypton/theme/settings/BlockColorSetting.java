package com.krypton.theme.settings;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.krypton.theme.util.Color;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class BlockColorSetting extends Setting {
   public Map<class_2248, Color> defaults;
   public List<class_2248> candidates;
   public Map<class_2248, Color> entries;

   public BlockColorSetting(String name, Map<class_2248, Color> entries, List<class_2248> candidates) {
      super(name);
      this.entries = new HashMap<>(entries);
      this.defaults = new HashMap<>(entries);
      this.candidates = candidates;
   }

   public BlockColorSetting(String name, Map<class_2248, Color> entries) {
      this(name, entries, null);
   }

   public BlockColorSetting(String name) {
      this(name, new HashMap<>(), null);
   }

   public List<class_2248> getCandidates() {
      return this.candidates;
   }

   public Map<class_2248, Color> getEntries() {
      return this.entries;
   }

   public void setEntries(Map<class_2248, Color> entries) {
      this.entries = new HashMap<>(entries);
      this.fireChanged();
   }

   public Set<class_2248> keys() {
      return this.entries.keySet();
   }

   public Color getColor(class_2248 block) {
      return this.entries.get(block);
   }

   public void put(class_2248 block, Color color) {
      this.entries.put(block, color.copy());
      this.fireChanged();
   }

   public void putAlias(class_2248 block, Color color) {
      this.entries.put(block, color.copy());
      this.fireChanged();
   }

   public void remove(class_2248 block) {
      this.entries.remove(block);
      this.fireChanged();
   }

   public boolean contains(class_2248 block) {
      return this.entries.containsKey(block);
   }

   public Map<class_2248, Color> getDefaults() {
      return this.defaults;
   }

   @Override
   public void reset() {
      this.entries = new HashMap<>(this.defaults);
      this.fireChanged();
   }

   @Override
   public boolean isDefault() {
      return this.entries.isEmpty() && this.defaults.isEmpty();
   }

   @Override
   public JsonElement toJson() {
      JsonObject root = new JsonObject();
      this.entries
         .entrySet()
         .stream()
         .sorted(Entry.comparingByKey(Comparator.comparing(b -> class_7923.field_41175.method_10221(b).toString())))
         .forEach(entry -> {
            JsonObject o = new JsonObject();
            Color c = entry.getValue();
            o.addProperty("r", c.r);
            o.addProperty("g", c.g);
            o.addProperty("b", c.b);
            o.addProperty("a", c.a);
            root.add(class_7923.field_41175.method_10221(entry.getKey()).toString(), o);
         });
      return root;
   }

   @Override
   public void fromJson(JsonElement element) {
      if (element.isJsonObject()) {
         JsonObject root = element.getAsJsonObject();
         this.entries.clear();

         for (String key : root.keySet()) {
            JsonElement value = root.get(key);
            if (value.isJsonObject()) {
               JsonObject o = value.getAsJsonObject();
               class_2248 block = (class_2248)class_7923.field_41175.method_63535(class_2960.method_60654(key));
               int r = o.has("r") ? o.get("r").getAsInt() : 255;
               int g = o.has("g") ? o.get("g").getAsInt() : 255;
               int b = o.has("b") ? o.get("b").getAsInt() : 255;
               int a = o.has("a") ? o.get("a").getAsInt() : 255;
               this.entries.put(block, new Color(r, g, b, a));
            }
         }

         this.fireChanged();
      }
   }
}
