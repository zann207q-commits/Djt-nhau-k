package com.krypton.theme.settings;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;

public class MacroListSetting extends Setting {
   public List<MacroEntry> entries = new ArrayList<>();

   public MacroListSetting(String name) {
      super(name);
   }

   public List<MacroEntry> copy() {
      return new ArrayList<>(this.entries);
   }

   public void setAll(List<MacroEntry> entries) {
      this.entries.clear();
      this.entries.addAll(entries);
      this.fireChanged();
   }

   public List<MacroEntry> getEntries() {
      return this.entries;
   }

   public void add(String text, int key) {
      this.entries.add(new MacroEntry(text, key));
      this.fireChanged();
   }

   public void removeAt(int index) {
      if (index >= 0 && index < this.entries.size()) {
         this.entries.remove(index);
         this.fireChanged();
      }
   }

   public int size() {
      return this.entries.size();
   }

   public void clear() {
      this.entries.clear();
      this.fireChanged();
   }

   public MacroEntry get(int index) {
      return index >= 0 && index < this.entries.size() ? this.entries.get(index) : null;
   }

   @Override
   public boolean isDefault() {
      return this.entries.isEmpty();
   }

   @Override
   public JsonElement toJson() {
      JsonArray array = new JsonArray();

      for (MacroEntry entry : this.entries) {
         JsonObject o = new JsonObject();
         o.addProperty("text", entry.text);
         o.addProperty("key", entry.key);
         array.add(o);
      }

      return array;
   }

   @Override
   public void fromJson(JsonElement element) {
      if (element.isJsonArray()) {
         JsonArray array = element.getAsJsonArray();
         this.clear();

         for (JsonElement e : array) {
            if (e.isJsonObject()) {
               JsonObject o = e.getAsJsonObject();
               String text = o.has("text") ? o.get("text").getAsString() : "";
               int key = o.has("key") ? o.get("key").getAsInt() : -1;
               this.entries.add(new MacroEntry(text, key));
            }
         }

         this.fireChanged();
      }
   }

   @Override
   public void reset() {
      this.clear();
   }

   public MacroListSetting description(String description) {
      super.description(description);
      return this;
   }

   public MacroListSetting noSerialize() {
      super.noSerialize();
      return this;
   }
}
