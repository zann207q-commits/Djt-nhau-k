package com.krypton.theme.settings;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.krypton.theme.util.Color;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import net.minecraft.class_1299;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class EntityColorSetting extends Setting {
   public Map<class_1299<?>, Color> defaults;
   public Map<class_1299<?>, Color> entries;
   public Runnable onEntriesChanged;

   public EntityColorSetting(String name, Map<class_1299<?>, Color> entries) {
      super(name);
      this.entries = new HashMap<>(entries);
      this.defaults = new HashMap<>(entries);
   }

   public EntityColorSetting(String name) {
      this(name, new HashMap<>());
   }

   public Map<class_1299<?>, Color> getEntries() {
      return this.entries;
   }

   public void setEntries(Map<class_1299<?>, Color> entries) {
      this.entries = new HashMap<>(entries);
      if (this.onEntriesChanged != null) {
         this.onEntriesChanged.run();
      }
   }

   public Set<class_1299<?>> keys() {
      return this.entries.keySet();
   }

   public Color getColor(class_1299<?> type) {
      return this.entries.get(type);
   }

   public void put(class_1299<?> type, Color color) {
      this.entries.put(type, color.copy());
      if (this.onEntriesChanged != null) {
         this.onEntriesChanged.run();
      }
   }

   public void putAlias(class_1299<?> type, Color color) {
      this.entries.put(type, color.copy());
      if (this.onEntriesChanged != null) {
         this.onEntriesChanged.run();
      }
   }

   public void remove(class_1299<?> type) {
      this.entries.remove(type);
      if (this.onEntriesChanged != null) {
         this.onEntriesChanged.run();
      }
   }

   public boolean contains(class_1299<?> type) {
      return this.entries.containsKey(type);
   }

   public Map<class_1299<?>, Color> getDefaults() {
      return this.defaults;
   }

   @Override
   public void reset() {
      this.entries = new HashMap<>(this.defaults);
   }

   public EntityColorSetting onEntriesChanged(Runnable listener) {
      this.onEntriesChanged = listener;
      return this;
   }

   @Override
   public boolean isDefault() {
      return this.entries.isEmpty() && this.defaults.isEmpty();
   }

   @Override
   public JsonElement toJson() {
      JsonObject root = new JsonObject();
      this.entries
         .entrySet()
         .stream()
         .sorted(Entry.comparingByKey(Comparator.comparing(t -> class_7923.field_41177.method_10221(t).toString())))
         .forEach(entry -> {
            JsonObject o = new JsonObject();
            Color c = entry.getValue();
            o.addProperty("r", c.r);
            o.addProperty("g", c.g);
            o.addProperty("b", c.b);
            o.addProperty("a", c.a);
            root.add(class_7923.field_41177.method_10221(entry.getKey()).toString(), o);
         });
      return root;
   }

   @Override
   public void fromJson(JsonElement element) {
      if (element.isJsonObject()) {
         JsonObject root = element.getAsJsonObject();
         this.entries.clear();

         for (String key : root.keySet()) {
            JsonElement value = root.get(key);
            if (value.isJsonObject()) {
               JsonObject o = value.getAsJsonObject();
               class_1299<?> type = (class_1299<?>)class_7923.field_41177.method_63535(class_2960.method_60654(key));
               int r = o.has("r") ? o.get("r").getAsInt() : 255;
               int g = o.has("g") ? o.get("g").getAsInt() : 255;
               int b = o.has("b") ? o.get("b").getAsInt() : 255;
               int a = o.has("a") ? o.get("a").getAsInt() : 255;
               this.entries.put(type, new Color(r, g, b, a));
            }
         }

         if (this.onEntriesChanged != null) {
            this.onEntriesChanged.run();
         }
      }
   }
}
