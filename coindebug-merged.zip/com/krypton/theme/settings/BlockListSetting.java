package com.krypton.theme.settings;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class BlockListSetting extends Setting {
   public Set<class_2248> defaults;
   public Set<class_2248> value;

   public BlockListSetting(String name, Set<class_2248> value) {
      super(name);
      this.value = new HashSet<>(value);
      this.defaults = new HashSet<>(value);
   }

   public Set<class_2248> get() {
      return this.value;
   }

   public void set(Set<class_2248> value) {
      this.value = new HashSet<>(value);
      this.fireChanged();
   }

   public Set<class_2248> getDefaults() {
      return this.defaults;
   }

   @Override
   public void reset() {
      this.value = new HashSet<>(this.defaults);
      this.fireChanged();
   }

   @Override
   public boolean isDefault() {
      return this.value.equals(this.defaults);
   }

   @Override
   public JsonElement toJson() {
      JsonArray array = new JsonArray();
      this.value.stream().map(b -> class_7923.field_41175.method_10221(b).toString()).sorted().forEach(array::add);
      return array;
   }

   @Override
   public void fromJson(JsonElement element) {
      if (element.isJsonArray()) {
         JsonArray array = element.getAsJsonArray();
         this.value.clear();

         for (JsonElement e : array) {
            if (e.isJsonPrimitive()) {
               this.value.add((class_2248)class_7923.field_41175.method_63535(class_2960.method_60654(e.getAsString())));
            }
         }

         this.fireChanged();
      }
   }
}
