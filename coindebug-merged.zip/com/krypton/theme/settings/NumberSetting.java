package com.krypton.theme.settings;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class NumberSetting extends Setting {
   public double min;
   public double max;
   public double step;
   public double defaultValue;
   public double value;

   public NumberSetting(String name, double min, double max, double value, double step) {
      super(name);
      this.min = min;
      this.max = max;
      this.value = value;
      this.step = step;
      this.defaultValue = value;
   }

   public double get() {
      return this.value;
   }

   public void set(double value) {
      double inverse = 1.0 / this.step;
      this.value = Math.round(Math.max(this.min, Math.min(this.max, value)) * inverse) / inverse;
      this.fireChanged();
   }

   public double getDefault() {
      return this.defaultValue;
   }

   public double getStep() {
      return this.step;
   }

   public double getMin() {
      return this.min;
   }

   public double getMax() {
      return this.max;
   }

   public int getInt() {
      return (int)this.value;
   }

   public float getFloat() {
      return (float)this.value;
   }

   public long getLong() {
      return (long)this.value;
   }

   @Override
   public boolean isDefault() {
      return this.value == this.defaultValue;
   }

   @Override
   public JsonElement toJson() {
      return new JsonPrimitive(this.value);
   }

   @Override
   public void fromJson(JsonElement element) {
      if (element.isJsonPrimitive()) {
         this.set(element.getAsDouble());
      }
   }

   @Override
   public void reset() {
      this.set(this.defaultValue);
   }

   public NumberSetting description(String description) {
      super.description(description);
      return this;
   }
}
