package com.krypton.theme.settings;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class KeybindSetting extends Setting {
   public boolean moduleBind;
   public int defaultKey;
   public int key;
   public boolean listening;

   public KeybindSetting(String name, int key, boolean moduleBind) {
      super(name);
      this.key = key;
      this.defaultKey = key;
      this.moduleBind = moduleBind;
   }

   public boolean isModuleBind() {
      return this.moduleBind;
   }

   public boolean isListening() {
      return this.listening;
   }

   public void setListening(boolean listening) {
      this.listening = listening;
   }

   public int getDefaultKey() {
      return this.defaultKey;
   }

   public int get() {
      return this.key;
   }

   public void set(int key) {
      this.key = key;
      this.fireChanged();
   }

   public void toggleListening() {
      this.listening = !this.listening;
   }

   @Override
   public boolean isDefault() {
      return this.key == this.defaultKey;
   }

   @Override
   public JsonElement toJson() {
      return new JsonPrimitive(this.key);
   }

   @Override
   public void fromJson(JsonElement element) {
      if (element.isJsonPrimitive()) {
         this.set(element.getAsInt());
      }
   }

   @Override
   public void reset() {
      this.set(this.defaultKey);
   }

   public KeybindSetting description(String description) {
      super.description(description);
      return this;
   }
}
