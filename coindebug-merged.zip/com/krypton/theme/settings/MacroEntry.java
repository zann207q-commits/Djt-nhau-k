package com.krypton.theme.settings;

public class MacroEntry {
   public String text;
   public int key;

   public MacroEntry(String text, int key) {
      this.text = text;
      this.key = key;
   }
}
