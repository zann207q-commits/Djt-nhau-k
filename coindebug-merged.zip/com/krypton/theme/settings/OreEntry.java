package com.krypton.theme.settings;

import com.krypton.theme.util.Color;
import net.minecraft.class_2248;

public record OreEntry(String name, Color color, class_2248 block) {
   @Override
   public String toString() {
      return this.name;
   }

   @Override
   public boolean equals(Object other) {
      return other instanceof OreEntry entry ? entry.name.equals(this.name) : false;
   }

   @Override
   public int hashCode() {
      return this.name.hashCode();
   }
}
