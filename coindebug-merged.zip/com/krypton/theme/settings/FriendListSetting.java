package com.krypton.theme.settings;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class FriendListSetting extends Setting {
   public List<String> defaults;
   public List<String> values;

   public FriendListSetting(String name, String... defaults) {
      super(name);
      this.defaults = Collections.unmodifiableList(new ArrayList<>(Arrays.asList(defaults)));
      this.values = new ArrayList<>(Arrays.asList(defaults));
   }

   public FriendListSetting(String name, List<String> defaults) {
      super(name);
      this.defaults = Collections.unmodifiableList(new ArrayList<>(defaults));
      this.values = new ArrayList<>(defaults);
   }

   public List<String> getDefaults() {
      return this.defaults;
   }

   public List<String> copy() {
      return new ArrayList<>(this.values);
   }

   public void setAll(List<String> values) {
      this.values = new ArrayList<>(values);
      this.fireChanged();
   }

   public void add(String value) {
      if (!this.values.contains(value)) {
         this.values.add(value);
         this.fireChanged();
      }
   }

   public void remove(String value) {
      this.values.remove(value);
      this.fireChanged();
   }

   public void removeAt(int index) {
      if (index >= 0 && index < this.values.size()) {
         this.values.remove(index);
         this.fireChanged();
      }
   }

   public boolean contains(String value) {
      return this.values.contains(value);
   }

   public int size() {
      return this.values.size();
   }

   public void clear() {
      this.values.clear();
      this.fireChanged();
   }

   public String get(int index) {
      return index >= 0 && index < this.values.size() ? this.values.get(index) : null;
   }

   public void set(int index, String value) {
      if (index >= 0 && index < this.values.size()) {
         this.values.set(index, value);
         this.fireChanged();
      }
   }

   @Override
   public boolean isDefault() {
      return this.values.equals(this.defaults);
   }

   @Override
   public JsonElement toJson() {
      JsonArray array = new JsonArray();

      for (String value : this.values) {
         array.add(value);
      }

      return array;
   }

   @Override
   public void fromJson(JsonElement element) {
      if (element.isJsonArray()) {
         JsonArray array = element.getAsJsonArray();
         this.clear();

         for (JsonElement entry : array) {
            if (entry.isJsonPrimitive()) {
               this.values.add(entry.getAsString());
            }
         }

         this.fireChanged();
      }
   }

   @Override
   public void reset() {
      this.setAll(new ArrayList<>(this.defaults));
   }

   public FriendListSetting description(String description) {
      super.description(description);
      return this;
   }

   public FriendListSetting noSerialize() {
      super.noSerialize();
      return this;
   }

   @Override
   public String toString() {
      return String.join(", ", this.values);
   }
}
