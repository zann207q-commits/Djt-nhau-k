package com.krypton.theme.settings;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

public class HudPosSetting extends Setting {
   public int defaultX = -1;
   public int defaultY = -1;
   public int x = -1;
   public int y = -1;

   public HudPosSetting(String name) {
      super(name);
   }

   public int getX() {
      return this.x;
   }

   public int getY() {
      return this.y;
   }

   public int getDefaultX() {
      return this.defaultX;
   }

   public int getDefaultY() {
      return this.defaultY;
   }

   public void set(int x, int y) {
      this.x = x;
      this.y = y;
      this.fireChanged();
   }

   @Override
   public void reset() {
      this.x = this.defaultX;
      this.y = this.defaultY;
      this.fireChanged();
   }

   public boolean isPlaced() {
      return this.x >= 0 && this.y >= 0;
   }

   @Override
   public boolean isDefault() {
      return this.x == this.defaultX && this.y == this.defaultY;
   }

   @Override
   public JsonElement toJson() {
      JsonObject o = new JsonObject();
      o.addProperty("x", this.x);
      o.addProperty("y", this.y);
      return o;
   }

   @Override
   public void fromJson(JsonElement element) {
      if (element.isJsonObject()) {
         JsonObject o = element.getAsJsonObject();
         this.set(o.has("x") ? o.get("x").getAsInt() : -1, o.has("y") ? o.get("y").getAsInt() : -1);
      }
   }

   public HudPosSetting description(String description) {
      super.description(description);
      return this;
   }
}
