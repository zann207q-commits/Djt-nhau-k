package com.krypton.theme.settings;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import java.util.HashSet;
import java.util.Set;

public class ItemFilterListSetting extends Setting {
   public Set<Object> defaults;
   public Set<Object> value;

   public ItemFilterListSetting(String name, Set<Object> value) {
      super(name);
      this.value = new HashSet<>(value);
      this.defaults = new HashSet<>(value);
   }

   public ItemFilterListSetting(String name) {
      this(name, new HashSet<>());
   }

   public Set<Object> get() {
      return this.value;
   }

   public void set(Set<Object> value) {
      this.value = new HashSet<>(value);
      this.fireChanged();
   }

   public Set<Object> getDefaults() {
      return this.defaults;
   }

   public void add(ItemFilter filter) {
      this.value.add(filter);
      this.fireChanged();
   }

   public void remove(ItemFilter filter) {
      this.value.remove(filter);
      this.fireChanged();
   }

   public boolean contains(ItemFilter filter) {
      return this.value.contains(filter);
   }

   public void toggle(ItemFilter filter) {
      if (this.contains(filter)) {
         this.remove(filter);
      } else {
         this.add(filter);
      }
   }

   @Override
   public void reset() {
      this.value = new HashSet<>(this.defaults);
      this.fireChanged();
   }

   @Override
   public boolean isDefault() {
      return this.value.equals(this.defaults);
   }

   @Override
   public JsonElement toJson() {
      JsonArray array = new JsonArray();
      this.value.stream().map(filter -> ((ItemFilter)filter).name()).sorted().forEach(array::add);
      return array;
   }

   @Override
   public void fromJson(JsonElement element) {
      if (element.isJsonArray()) {
         JsonArray array = element.getAsJsonArray();
         this.value.clear();

         for (JsonElement child : array) {
            if (child.isJsonPrimitive()) {
               ItemFilter filter = ItemFilters.byName(child.getAsString());
               if (filter != null) {
                  this.value.add(filter);
               }
            }
         }

         this.fireChanged();
      }
   }

   public ItemFilterListSetting description(String description) {
      super.description(description);
      return this;
   }
}
