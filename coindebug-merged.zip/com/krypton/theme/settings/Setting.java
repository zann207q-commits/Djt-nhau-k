package com.krypton.theme.settings;

import com.google.gson.JsonElement;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public abstract class Setting {
   public String name;
   public List<Runnable> changeListeners = new ArrayList<>();
   public String description;
   public Supplier<Boolean> visibleWhen = () -> true;
   public boolean serialize = true;

   public Setting(String name) {
      this.name = name;
   }

   public abstract boolean isDefault();

   public abstract JsonElement toJson();

   public abstract void fromJson(JsonElement var1);

   public abstract void reset();

   public String getName() {
      return this.name;
   }

   public String getDescription() {
      return this.description;
   }

   public Setting description(String description) {
      this.description = description;
      return this;
   }

   public boolean isVisible() {
      return this.visibleWhen.get();
   }

   public Setting visibleWhen(Supplier<Boolean> predicate) {
      this.visibleWhen = predicate;
      return this;
   }

   public boolean shouldSerialize() {
      return this.serialize;
   }

   public Setting noSerialize() {
      this.serialize = false;
      return this;
   }

   public Setting onChanged(Runnable listener) {
      this.changeListeners.add(listener);
      return this;
   }

   public void fireChanged() {
      for (Runnable listener : this.changeListeners) {
         listener.run();
      }
   }
}
