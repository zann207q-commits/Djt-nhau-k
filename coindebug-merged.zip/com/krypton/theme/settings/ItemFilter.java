package com.krypton.theme.settings;

import java.util.function.Predicate;
import net.minecraft.class_1799;

public record ItemFilter(String name, String searchText, Predicate<class_1799> predicate) {
   public ItemFilter(String name, String searchText, Predicate<class_1799> predicate) {
      searchText = searchText.toLowerCase();
      this.name = name;
      this.searchText = searchText;
      this.predicate = predicate;
   }

   public boolean matchesSearch(String query) {
      return query != null && !query.isEmpty() ? this.searchText.contains(query.toLowerCase()) : true;
   }

   public boolean test(class_1799 stack) {
      return this.predicate.test(stack);
   }
}
