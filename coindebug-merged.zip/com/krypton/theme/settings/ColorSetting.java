package com.krypton.theme.settings;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.krypton.theme.util.Color;

public class ColorSetting extends Setting {
   public Color defaultValue;
   public Color value;
   public double hue = 0.0;

   public ColorSetting(String name, Color color) {
      super(name);
      this.value = color.copy();
      this.defaultValue = color.copy();
      float[] hsb = Color.rgbToHsb(color.r, color.g, color.b, null);
      this.hue = hsb[0] * 360.0F;
   }

   public ColorSetting(String name, int r, int g, int b) {
      this(name, new Color(r, g, b, 255));
   }

   public ColorSetting(String name, int r, int g, int b, int a) {
      this(name, new Color(r, g, b, a));
   }

   public Color get() {
      return this.value;
   }

   public void set(Color color) {
      this.value.set(color);
      this.fireChanged();
   }

   public void set(int r, int g, int b, int a) {
      this.value.set(r, g, b, a);
      this.fireChanged();
   }

   public Color getDefault() {
      return this.defaultValue;
   }

   public int r() {
      return this.value.r;
   }

   public int g() {
      return this.value.g;
   }

   public int b() {
      return this.value.b;
   }

   public int a() {
      return this.value.a;
   }

   public int packed() {
      return this.value.packed();
   }

   public Color copy() {
      return new Color(this.value.r, this.value.g, this.value.b, this.value.a);
   }

   public double getHue() {
      return this.hue;
   }

   public void setHue(double hue) {
      this.hue = hue;
   }

   @Override
   public boolean isDefault() {
      return this.value.r == this.defaultValue.r
         && this.value.g == this.defaultValue.g
         && this.value.b == this.defaultValue.b
         && this.value.a == this.defaultValue.a;
   }

   @Override
   public JsonElement toJson() {
      JsonObject o = new JsonObject();
      o.addProperty("r", this.value.r);
      o.addProperty("g", this.value.g);
      o.addProperty("b", this.value.b);
      o.addProperty("a", this.value.a);
      o.addProperty("hue", this.hue);
      return o;
   }

   @Override
   public void fromJson(JsonElement element) {
      if (element.isJsonObject()) {
         JsonObject o = element.getAsJsonObject();
         int r = o.has("r") ? o.get("r").getAsInt() : 255;
         int g = o.has("g") ? o.get("g").getAsInt() : 255;
         int b = o.has("b") ? o.get("b").getAsInt() : 255;
         int a = o.has("a") ? o.get("a").getAsInt() : 255;
         this.set(r, g, b, a);
         if (o.has("hue")) {
            this.setHue(o.get("hue").getAsDouble());
         }
      }
   }

   @Override
   public void reset() {
      this.set(this.defaultValue.r, this.defaultValue.g, this.defaultValue.b, this.defaultValue.a);
   }

   public ColorSetting description(String description) {
      super.description(description);
      return this;
   }
}
