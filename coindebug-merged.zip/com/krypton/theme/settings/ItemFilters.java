package com.krypton.theme.settings;

import com.krypton.theme.util.EnchantmentUtils;
import java.util.Arrays;
import java.util.List;
import net.minecraft.class_1893;

public class ItemFilters {
   public static ItemFilter SHARPNESS = new ItemFilter(
      "Sharpness", "SHARPNESS 5", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9118, 5)
   );
   public static ItemFilter SMITE = new ItemFilter("Smite", "SMITE 5", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9123, 5));
   public static ItemFilter BANE_OF_ARTHROPODS = new ItemFilter(
      "Bane of Arthropods", "BANE_OF_ARTHROPODS 5", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9112, 5)
   );
   public static ItemFilter KNOCKBACK_1 = new ItemFilter(
      "Knockback 1", "KNOCKBACK 1", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9121, 2)
   );
   public static ItemFilter KNOCKBACK_2 = new ItemFilter(
      "Knockback 2", "KNOCKBACK 2", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9121, 2)
   );
   public static ItemFilter FIRE_ASPECT = new ItemFilter(
      "Fire Aspect", "FIRE_ASPECT 2", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9124, 2)
   );
   public static ItemFilter LOOTING = new ItemFilter("Looting", "LOOTING 3", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9110, 3));
   public static ItemFilter SWEEPING_EDGE = new ItemFilter(
      "Sweeping Edge", "SWEEPING_EDGE 3", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9115, 3)
   );
   public static ItemFilter EFFICIENCY = new ItemFilter(
      "Efficiency", "EFFICIENCY 5", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9131, 5)
   );
   public static ItemFilter SILK_TOUCH = new ItemFilter(
      "Silk Touch", "SILK_TOUCH 1", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9099, 1)
   );
   public static ItemFilter FORTUNE = new ItemFilter("Fortune", "FORTUNE 3", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9130, 3));
   public static ItemFilter PROTECTION = new ItemFilter(
      "Protection", "PROTECTION 4", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9111, 4)
   );
   public static ItemFilter FIRE_PROTECTION = new ItemFilter(
      "Fire Protection", "FIRE_PROTECTION 4", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9095, 4)
   );
   public static ItemFilter BLAST_PROTECTION = new ItemFilter(
      "Blast Protection", "BLAST_PROTECTION 4", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9107, 4)
   );
   public static ItemFilter PROJECTILE_PROTECTION = new ItemFilter(
      "Projectile Protection", "PROJECTILE_PROTECTION 4", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9096, 4)
   );
   public static ItemFilter RESPIRATION = new ItemFilter(
      "Respiration", "RESPIRATION 3", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9127, 3)
   );
   public static ItemFilter AQUA_AFFINITY = new ItemFilter(
      "Aqua Affinity", "AQUA_AFFINITY 1", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9105, 1)
   );
   public static ItemFilter THORNS = new ItemFilter("Thorns", "THORNS 3", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9097, 3));
   public static ItemFilter DEPTH_STRIDER = new ItemFilter(
      "Depth Strider", "DEPTH_STRIDER 3", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9128, 3)
   );
   public static ItemFilter FROST_WALKER = new ItemFilter(
      "Frost Walker", "FROST_WALKER 2", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9122, 2)
   );
   public static ItemFilter FEATHER_FALLING = new ItemFilter(
      "Feather Falling", "FEATHER_FALLING 4", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9129, 4)
   );
   public static ItemFilter POWER = new ItemFilter("Power", "POWER 5", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9103, 5));
   public static ItemFilter PUNCH = new ItemFilter("Punch", "PUNCH 2", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9116, 2));
   public static ItemFilter FLAME = new ItemFilter("Flame", "FLAME 1", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9126, 1));
   public static ItemFilter INFINITY = new ItemFilter(
      "Infinity", "INFINITY 1", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9125, 1)
   );
   public static ItemFilter LUCK_OF_THE_SEA = new ItemFilter(
      "Luck of the Sea", "LUCK_OF_THE_SEA 3", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9114, 3)
   );
   public static ItemFilter LURE = new ItemFilter("Lure", "LURE 3", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9100, 3));
   public static ItemFilter LOYALTY = new ItemFilter("Loyalty", "LOYALTY 3", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9120, 3));
   public static ItemFilter IMPALING = new ItemFilter(
      "Impaling", "IMPALING 5", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9106, 5)
   );
   public static ItemFilter RIPTIDE = new ItemFilter("Riptide", "RIPTIDE 3", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9104, 3));
   public static ItemFilter CHANNELING = new ItemFilter(
      "Channeling", "CHANNELING 1", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9117, 1)
   );
   public static ItemFilter QUICK_CHARGE = new ItemFilter(
      "Quick Charge", "QUICK_CHARGE 3", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9098, 3)
   );
   public static ItemFilter MULTISHOT = new ItemFilter(
      "Multishot", "MULTISHOT 1", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9108, 1)
   );
   public static ItemFilter PIERCING = new ItemFilter(
      "Piercing", "PIERCING 4", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9132, 4)
   );
   public static ItemFilter UNBREAKING = new ItemFilter(
      "Unbreaking", "UNBREAKING 3", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9119, 3)
   );
   public static ItemFilter MENDING = new ItemFilter("Mending", "MENDING 1", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9101, 1));
   public static ItemFilter CURSE_OF_BINDING = new ItemFilter(
      "Curse of Binding", "BINDING_CURSE 1", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9113, 1)
   );
   public static ItemFilter CURSE_OF_VANISHING = new ItemFilter(
      "Curse of Vanishing", "VANISHING_CURSE 1", stack -> EnchantmentUtils.hasEnchantmentAtLevel(stack, class_1893.field_9109, 1)
   );
   public static ItemFilter AMETHYST_DRILL = new ItemFilter("Amethyst Drill", "Amethyst Drill", stack -> true);
   public static ItemFilter AMETHYST_SELL_AXE = new ItemFilter("Amethyst Sell Axe", "Amethyst Sell Axe", stack -> true);
   public static ItemFilter AMETHYST_AXE = new ItemFilter("Amethyst Axe", "Amethyst Axe", stack -> true);
   public static ItemFilter AMETHYST_SHOVEL = new ItemFilter("Amethyst Shovel", "Amethyst Shovel", stack -> true);
   public static ItemFilter SHARD_BOOSTER = new ItemFilter("Shard Booster", "Shard Booster", stack -> true);
   public static ItemFilter AMETHYST_BUCKET = new ItemFilter("Amethyst Bucket", "Amethyst Bucket", stack -> true);
   public static List<ItemFilter> ALL = Arrays.asList(
      SHARPNESS,
      SMITE,
      BANE_OF_ARTHROPODS,
      KNOCKBACK_1,
      KNOCKBACK_2,
      FIRE_ASPECT,
      LOOTING,
      SWEEPING_EDGE,
      EFFICIENCY,
      SILK_TOUCH,
      FORTUNE,
      PROTECTION,
      FIRE_PROTECTION,
      BLAST_PROTECTION,
      PROJECTILE_PROTECTION,
      RESPIRATION,
      AQUA_AFFINITY,
      THORNS,
      DEPTH_STRIDER,
      FROST_WALKER,
      FEATHER_FALLING,
      POWER,
      PUNCH,
      FLAME,
      INFINITY,
      LUCK_OF_THE_SEA,
      LURE,
      LOYALTY,
      IMPALING,
      RIPTIDE,
      CHANNELING,
      QUICK_CHARGE,
      MULTISHOT,
      PIERCING,
      UNBREAKING,
      MENDING,
      CURSE_OF_BINDING,
      CURSE_OF_VANISHING,
      AMETHYST_DRILL,
      AMETHYST_SELL_AXE,
      AMETHYST_AXE,
      AMETHYST_SHOVEL,
      SHARD_BOOSTER,
      AMETHYST_BUCKET
   );

   public static ItemFilter byName(String name) {
      for (ItemFilter filter : ALL) {
         if (filter.name().equalsIgnoreCase(name)) {
            return filter;
         }
      }

      return null;
   }
}
