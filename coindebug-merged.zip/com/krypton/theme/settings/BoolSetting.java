package com.krypton.theme.settings;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class BoolSetting extends Setting {
   public boolean defaultValue;
   public boolean value;

   public BoolSetting(String name, boolean value) {
      super(name);
      this.value = value;
      this.defaultValue = value;
   }

   public void toggle() {
      this.set(!this.value);
   }

   public boolean getDefault() {
      return this.defaultValue;
   }

   public boolean get() {
      return this.value;
   }

   public void set(boolean value) {
      this.value = value;
      this.fireChanged();
   }

   @Override
   public boolean isDefault() {
      return this.value == this.defaultValue;
   }

   @Override
   public JsonElement toJson() {
      return new JsonPrimitive(this.value);
   }

   @Override
   public void fromJson(JsonElement element) {
      if (element.isJsonPrimitive()) {
         this.set(element.getAsBoolean());
      }
   }

   @Override
   public void reset() {
      this.set(this.defaultValue);
   }

   public BoolSetting description(String description) {
      super.description(description);
      return this;
   }
}
