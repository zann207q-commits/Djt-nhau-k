package com.krypton.theme.settings;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.util.Arrays;
import java.util.List;

public class EnumSetting<T extends Enum<T>> extends Setting {
   public List<T> values;
   public int defaultIndex;
   public int index;

   public EnumSetting(String name, T defaultValue, Class<T> type) {
      super(name);
      this.values = Arrays.asList(type.getEnumConstants());
      this.index = this.values.indexOf(defaultValue);
      this.defaultIndex = this.index;
   }

   public T get() {
      return this.values.get(this.index);
   }

   public void set(T value) {
      this.index = this.values.indexOf(value);
      this.fireChanged();
   }

   public int getIndex() {
      return this.index;
   }

   public void setIndex(int index) {
      this.index = index;
      this.fireChanged();
   }

   public int getDefaultIndex() {
      return this.defaultIndex;
   }

   public void next() {
      if (this.index < this.values.size() - 1) {
         this.index++;
      } else {
         this.index = 0;
      }

      this.fireChanged();
   }

   public void previous() {
      if (this.index > 0) {
         this.index--;
      } else {
         this.index = this.values.size() - 1;
      }

      this.fireChanged();
   }

   public boolean is(T value) {
      return this.index == this.values.indexOf(value);
   }

   @Override
   public boolean isDefault() {
      return this.index == this.defaultIndex;
   }

   public List<T> getValues() {
      return this.values;
   }

   @Override
   public JsonElement toJson() {
      return new JsonPrimitive(this.index);
   }

   @Override
   public void fromJson(JsonElement element) {
      if (element.isJsonPrimitive()) {
         int i = element.getAsInt();
         if (i != -1) {
            this.setIndex(i);
         } else {
            this.setIndex(this.defaultIndex);
         }
      }
   }

   @Override
   public void reset() {
      this.setIndex(this.defaultIndex);
   }

   public EnumSetting<T> description(String description) {
      super.description(description);
      return this;
   }
}
