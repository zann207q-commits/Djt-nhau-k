package com.krypton.theme.render;

import com.krypton.theme.util.Color;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat.class_5595;
import java.util.HashMap;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import net.minecraft.class_12137;
import net.minecraft.class_243;
import net.minecraft.class_276;
import net.minecraft.class_310;
import net.minecraft.class_3545;
import net.minecraft.class_4587;
import net.minecraft.class_9848;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Matrix4fStack;

public class MeshRenderer {
   public static MeshRenderer INSTANCE = new MeshRenderer();
   public static boolean inUse;
   public HashMap<String, GpuBufferSlice> uniforms = new HashMap<>();
   public HashMap<String, class_3545<GpuTextureView, class_12137>> textures = new HashMap<>();
   public GpuTextureView colorTarget;
   public GpuTextureView depthTarget;
   public Color clearColor;
   public RenderPipeline pipeline;
   @Nullable
   public Mesh mesh;
   @Nullable
   public GpuBuffer vertices;
   @Nullable
   public GpuBuffer indices;
   public Matrix4f matrix;

   public static MeshRenderer begin() {
      if (inUse) {
         throw new IllegalStateException("Previous instance of MeshRenderer was not ended");
      } else {
         inUse = true;
         return INSTANCE;
      }
   }

   public static void applyCameraYOffset() {
      class_243 camera = class_310.method_1551().field_1773.method_19418().method_71156();
      RenderSystem.getModelViewStack().translate(0.0F, (float)(-camera.field_1351), 0.0F);
   }

   public MeshRenderer target(GpuTextureView color, GpuTextureView depth) {
      this.colorTarget = color;
      this.depthTarget = depth;
      return this;
   }

   public MeshRenderer target(class_276 framebuffer) {
      this.colorTarget = framebuffer.method_71639();
      this.depthTarget = framebuffer.method_71640();
      return this;
   }

   public MeshRenderer clearColor(Color color) {
      this.clearColor = color;
      return this;
   }

   public MeshRenderer pipeline(RenderPipeline pipeline) {
      this.pipeline = pipeline;
      return this;
   }

   public MeshRenderer buffers(GpuBuffer vertices, GpuBuffer indices) {
      this.vertices = vertices;
      this.indices = indices;
      return this;
   }

   public MeshRenderer mesh(Mesh mesh) {
      this.mesh = mesh;
      return this;
   }

   public MeshRenderer mesh(Mesh mesh, Matrix4f matrix) {
      this.mesh = mesh;
      return this.matrix(matrix);
   }

   public MeshRenderer mesh(Mesh mesh, class_4587 matrices) {
      this.mesh = mesh;
      return this.matrix(matrices);
   }

   public MeshRenderer matrix(Matrix4f matrix) {
      this.matrix = matrix;
      return this;
   }

   public MeshRenderer matrix(class_4587 matrices) {
      this.matrix = matrices.method_23760().method_23761();
      return this;
   }

   public MeshRenderer fullscreenQuad() {
      return this.buffers(FullscreenQuad.VERTICES, FullscreenQuad.INDICES);
   }

   public MeshRenderer uniform(String name, GpuBufferSlice slice) {
      this.uniforms.put(name, slice);
      return this;
   }

   public MeshRenderer texture(String name, GpuTextureView view, class_12137 sampler) {
      if (name != null && view != null && sampler != null) {
         this.textures.put(name, new class_3545(view, sampler));
      }

      return this;
   }

   public void draw() {
      if (this.mesh != null && this.mesh.isBuilding()) {
         this.mesh.end();
      }

      int count = this.mesh != null ? this.mesh.indexCount() : (int)(this.indices != null ? this.indices.size() / 4L : -1L);
      if (count > 0) {
         if (RenderState.worldSpace || this.matrix != null) {
            RenderSystem.getModelViewStack().pushMatrix();
         }

         if (this.matrix != null) {
            RenderSystem.getModelViewStack().mul(this.matrix);
         }

         if (RenderState.worldSpace) {
            applyCameraYOffset();
         }

         GpuBuffer vertexBuffer = this.mesh != null ? this.mesh.uploadVertices() : this.vertices;
         GpuBuffer indexBuffer = this.mesh != null ? this.mesh.uploadIndices() : this.indices;
         OptionalInt clear = this.clearColor != null
            ? OptionalInt.of(class_9848.method_61324(this.clearColor.a, this.clearColor.r, this.clearColor.g, this.clearColor.b))
            : OptionalInt.empty();
         Matrix4f projection = RenderState.PROJECTION;
         Matrix4fStack modelView = RenderSystem.getModelViewStack();
         GpuBufferSlice meshData = MeshUniforms.write(projection, modelView);
         RenderPass pass = this.depthTarget != null && this.pipeline.wantsDepthTexture()
            ? RenderSystem.getDevice()
               .createCommandEncoder()
               .createRenderPass(() -> "Krypton MeshRenderer", this.colorTarget, clear, this.depthTarget, OptionalDouble.empty())
            : RenderSystem.getDevice().createCommandEncoder().createRenderPass(() -> "Krypton MeshRenderer", this.colorTarget, clear);
         pass.setPipeline(this.pipeline);
         pass.setUniform("MeshData", meshData);
         if (RenderState.scissorActive) {
            pass.enableScissor(RenderState.scissorX, RenderState.scissorY, RenderState.scissorWidth, RenderState.scissorHeight);
         }

         for (String name : this.uniforms.keySet()) {
            pass.setUniform(name, this.uniforms.get(name));
         }

         for (String name : this.textures.keySet()) {
            pass.bindTexture(name, (GpuTextureView)this.textures.get(name).method_15442(), (class_12137)this.textures.get(name).method_15441());
         }

         pass.setVertexBuffer(0, vertexBuffer);
         pass.setIndexBuffer(indexBuffer, class_5595.field_27373);
         pass.drawIndexed(0, 0, count, 1);
         pass.close();
         if (RenderState.worldSpace || this.matrix != null) {
            RenderSystem.getModelViewStack().popMatrix();
         }
      }

      this.colorTarget = null;
      this.depthTarget = null;
      this.clearColor = null;
      this.pipeline = null;
      this.mesh = null;
      this.vertices = null;
      this.indices = null;
      this.matrix = null;
      this.uniforms.clear();
      this.textures.clear();
      inUse = false;
   }
}
