package com.krypton.theme.render;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.buffers.Std140Builder;
import com.mojang.blaze3d.buffers.Std140SizeCalculator;
import java.nio.ByteBuffer;
import net.minecraft.class_11280;
import net.minecraft.class_11280.class_11281;

public class BlurSampleUniforms {
   public static int BLOCK_SIZE = new Std140SizeCalculator().putVec4().putVec4().putVec4().get();
   public static BlurSampleUniforms.Data DATA = new BlurSampleUniforms.Data();
   public static class_11280<BlurSampleUniforms.Data> STORAGE = new class_11280("Krypton - BlurSample UBO", BLOCK_SIZE, 256);

   public static void clear() {
      STORAGE.method_71100();
   }

   public static GpuBufferSlice write(
      float x1, float y1, float x2, float y2, float r1, float r2, float r3, float r4, float screenWidth, float screenHeight, float opacity
   ) {
      DATA.x1 = x1;
      DATA.y1 = y1;
      DATA.x2 = x2;
      DATA.y2 = y2;
      DATA.r1 = r1;
      DATA.r2 = r2;
      DATA.r3 = r3;
      DATA.r4 = r4;
      DATA.screenWidth = screenWidth;
      DATA.screenHeight = screenHeight;
      DATA.opacity = opacity;
      return STORAGE.method_71102(DATA);
   }

   public static class Data implements class_11281 {
      public float x1;
      public float y1;
      public float x2;
      public float y2;
      public float r1;
      public float r2;
      public float r3;
      public float r4;
      public float screenWidth;
      public float screenHeight;
      public float opacity;

      public void method_71104(ByteBuffer buffer) {
         Std140Builder.intoBuffer(buffer)
            .putVec4(this.x1, this.y1, this.x2, this.y2)
            .putVec4(this.r1, this.r2, this.r3, this.r4)
            .putVec4(this.screenWidth, this.screenHeight, this.opacity, 0.0F);
      }

      @Override
      public boolean equals(Object other) {
         return false;
      }
   }
}
