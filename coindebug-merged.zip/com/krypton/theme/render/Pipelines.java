package com.krypton.theme.render;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.shaders.ShaderType;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_10789;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import org.apache.commons.io.IOUtils;

public abstract class Pipelines {
   public static List<RenderPipeline> REGISTERED = new ArrayList<>();
   public static RenderPipeline POST_OUTLINE = new Pipelines.Builder()
      .withLocation(class_2960.method_60655("krypton", "pipeline/post/outline"))
      .withVertexFormat(KryptonVertexFormats.POSITION_2D, class_5596.field_27379)
      .withVertexShader(class_2960.method_60655("krypton", "shaders/post-process/base.vert"))
      .withFragmentShader(class_2960.method_60655("krypton", "shaders/post-process/outline.frag"))
      .withSampler("u_Texture")
      .withUniform("PostData", class_10789.field_60031)
      .withUniform("OutlineData", class_10789.field_60031)
      .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
      .withDepthWrite(false)
      .withBlend(BlendFunction.TRANSLUCENT)
      .withCull(false)
      .build();
   public static Snippet MESH_DATA_SNIPPET = RenderPipeline.builder(new Snippet[0]).withUniform("MeshData", class_10789.field_60031).buildSnippet();
   public static RenderPipeline WORLD_COLORED = register(
      new Pipelines.Builder(MESH_DATA_SNIPPET)
         .withLocation(class_2960.method_60655("krypton", "pipeline/world_colored"))
         .withVertexFormat(class_290.field_1576, class_5596.field_27379)
         .withVertexShader(class_2960.method_60655("krypton", "shaders/pos_color.vert"))
         .withFragmentShader(class_2960.method_60655("krypton", "shaders/pos_color.frag"))
         .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
         .withDepthWrite(false)
         .withBlend(BlendFunction.TRANSLUCENT)
         .withCull(false)
         .build()
   );
   public static RenderPipeline WORLD_COLORED_LINES = register(
      new Pipelines.Builder(MESH_DATA_SNIPPET)
         .smoothLines()
         .withLocation(class_2960.method_60655("krypton", "pipeline/world_colored_lines"))
         .withVertexFormat(class_290.field_1576, class_5596.field_29344)
         .withVertexShader(class_2960.method_60655("krypton", "shaders/pos_color.vert"))
         .withFragmentShader(class_2960.method_60655("krypton", "shaders/pos_color.frag"))
         .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
         .withDepthWrite(false)
         .withBlend(BlendFunction.TRANSLUCENT)
         .withCull(false)
         .build()
   );
   public static RenderPipeline WORLD_COLORED_DEPTH = register(
      new Pipelines.Builder(MESH_DATA_SNIPPET)
         .withLocation(class_2960.method_60655("krypton", "pipeline/world_colored_depth"))
         .withVertexFormat(class_290.field_1576, class_5596.field_27379)
         .withVertexShader(class_2960.method_60655("krypton", "shaders/pos_color.vert"))
         .withFragmentShader(class_2960.method_60655("krypton", "shaders/pos_color.frag"))
         .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
         .withDepthWrite(false)
         .withBlend(BlendFunction.TRANSLUCENT)
         .withCull(false)
         .build()
   );
   public static RenderPipeline WORLD_COLORED_LINES_DEPTH = register(
      new Pipelines.Builder(MESH_DATA_SNIPPET)
         .smoothLines()
         .withLocation(class_2960.method_60655("krypton", "pipeline/world_colored_lines_depth"))
         .withVertexFormat(class_290.field_1576, class_5596.field_29344)
         .withVertexShader(class_2960.method_60655("krypton", "shaders/pos_color.vert"))
         .withFragmentShader(class_2960.method_60655("krypton", "shaders/pos_color.frag"))
         .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
         .withDepthWrite(false)
         .withBlend(BlendFunction.TRANSLUCENT)
         .withCull(false)
         .build()
   );
   public static RenderPipeline UI_COLORED = register(
      new Pipelines.Builder(MESH_DATA_SNIPPET)
         .withLocation(class_2960.method_60655("krypton", "pipeline/ui_colored"))
         .withVertexFormat(KryptonVertexFormats.POSITION_2D_COLOR, class_5596.field_27379)
         .withVertexShader(class_2960.method_60655("krypton", "shaders/pos_color.vert"))
         .withFragmentShader(class_2960.method_60655("krypton", "shaders/pos_color.frag"))
         .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
         .withDepthWrite(false)
         .withBlend(BlendFunction.TRANSLUCENT)
         .withCull(true)
         .build()
   );
   public static RenderPipeline UI_COLORED_LINES = register(
      new Pipelines.Builder(MESH_DATA_SNIPPET)
         .withLocation(class_2960.method_60655("krypton", "pipeline/ui_colored_lines"))
         .withVertexFormat(KryptonVertexFormats.POSITION_2D_COLOR, class_5596.field_29344)
         .withVertexShader(class_2960.method_60655("krypton", "shaders/pos_color.vert"))
         .withFragmentShader(class_2960.method_60655("krypton", "shaders/pos_color.frag"))
         .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
         .withDepthWrite(false)
         .withBlend(BlendFunction.TRANSLUCENT)
         .withCull(true)
         .build()
   );
   public static RenderPipeline UI_TEXTURED = register(
      new Pipelines.Builder(MESH_DATA_SNIPPET)
         .withLocation(class_2960.method_60655("krypton", "pipeline/ui_textured"))
         .withVertexFormat(KryptonVertexFormats.POSITION_2D_TEXTURE_COLOR, class_5596.field_27379)
         .withVertexShader(class_2960.method_60655("krypton", "shaders/pos_tex_color.vert"))
         .withFragmentShader(class_2960.method_60655("krypton", "shaders/pos_tex_color.frag"))
         .withSampler("u_Texture")
         .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
         .withDepthWrite(false)
         .withBlend(BlendFunction.TRANSLUCENT)
         .withCull(true)
         .build()
   );
   public static RenderPipeline WORLD_TEXTURED = register(
      new Pipelines.Builder(MESH_DATA_SNIPPET)
         .withLocation(class_2960.method_60655("krypton", "pipeline/world_textured"))
         .withVertexFormat(KryptonVertexFormats.POSITION_TEXTURE_COLOR, class_5596.field_27379)
         .withVertexShader(class_2960.method_60655("krypton", "shaders/pos_tex_color.vert"))
         .withFragmentShader(class_2960.method_60655("krypton", "shaders/pos_tex_color.frag"))
         .withSampler("u_Texture")
         .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
         .withDepthWrite(false)
         .withBlend(BlendFunction.TRANSLUCENT)
         .withCull(false)
         .build()
   );
   public static RenderPipeline UI_TEXT = register(
      new Pipelines.Builder(MESH_DATA_SNIPPET)
         .withLocation(class_2960.method_60655("krypton", "pipeline/ui_text"))
         .withVertexFormat(KryptonVertexFormats.POSITION_2D_TEXTURE_COLOR, class_5596.field_27379)
         .withVertexShader(class_2960.method_60655("krypton", "shaders/text.vert"))
         .withFragmentShader(class_2960.method_60655("krypton", "shaders/text.frag"))
         .withSampler("u_Texture")
         .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
         .withDepthWrite(false)
         .withBlend(BlendFunction.TRANSLUCENT)
         .withCull(true)
         .build()
   );
   public static RenderPipeline POST_IMAGE = new Pipelines.Builder(MESH_DATA_SNIPPET)
      .withLocation(class_2960.method_60655("krypton", "pipeline/post/image"))
      .withVertexFormat(KryptonVertexFormats.POSITION_2D, class_5596.field_27379)
      .withVertexShader(class_2960.method_60655("krypton", "shaders/post-process/base.vert"))
      .withFragmentShader(class_2960.method_60655("krypton", "shaders/post-process/image.frag"))
      .withSampler("u_Texture")
      .withSampler("u_TextureI")
      .withUniform("PostData", class_10789.field_60031)
      .withUniform("ImageData", class_10789.field_60031)
      .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
      .withDepthWrite(false)
      .withBlend(BlendFunction.TRANSLUCENT)
      .withCull(false)
      .build();
   public static RenderPipeline BLUR_DOWN = register(
      new Pipelines.Builder(MESH_DATA_SNIPPET)
         .withLocation(class_2960.method_60655("krypton", "pipeline/blur/down"))
         .withVertexFormat(KryptonVertexFormats.POSITION_2D, class_5596.field_27379)
         .withVertexShader(class_2960.method_60655("krypton", "shaders/blur.vert"))
         .withFragmentShader(class_2960.method_60655("krypton", "shaders/blur_down.frag"))
         .withSampler("u_Texture")
         .withUniform("BlurData", class_10789.field_60031)
         .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
         .withDepthWrite(false)
         .withBlend(BlendFunction.TRANSLUCENT)
         .withCull(false)
         .build()
   );
   public static RenderPipeline BLUR_UP = register(
      new Pipelines.Builder(MESH_DATA_SNIPPET)
         .withLocation(class_2960.method_60655("krypton", "pipeline/blur/up"))
         .withVertexFormat(KryptonVertexFormats.POSITION_2D, class_5596.field_27379)
         .withVertexShader(class_2960.method_60655("krypton", "shaders/blur.vert"))
         .withFragmentShader(class_2960.method_60655("krypton", "shaders/blur_up.frag"))
         .withSampler("u_Texture")
         .withUniform("BlurData", class_10789.field_60031)
         .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
         .withDepthWrite(false)
         .withBlend(BlendFunction.TRANSLUCENT)
         .withCull(false)
         .build()
   );
   public static RenderPipeline ROUNDED_GLASS = register(
      new Pipelines.Builder(MESH_DATA_SNIPPET)
         .withLocation(class_2960.method_60655("krypton", "pipeline/rounded_glass"))
         .withVertexFormat(KryptonVertexFormats.POSITION_2D, class_5596.field_27379)
         .withVertexShader(class_2960.method_60655("krypton", "shaders/rounded_glass.vert"))
         .withFragmentShader(class_2960.method_60655("krypton", "shaders/rounded_glass.frag"))
         .withSampler("u_BlurTex")
         .withUniform("GlassData", class_10789.field_60031)
         .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
         .withDepthWrite(false)
         .withBlend(BlendFunction.TRANSLUCENT)
         .withCull(false)
         .build()
   );
   public static RenderPipeline BLUR_SAMPLE = register(
      new Pipelines.Builder(MESH_DATA_SNIPPET)
         .withLocation(class_2960.method_60655("krypton", "pipeline/blur_sample"))
         .withVertexFormat(KryptonVertexFormats.POSITION_2D, class_5596.field_27379)
         .withVertexShader(class_2960.method_60655("krypton", "shaders/blur_sample.vert"))
         .withFragmentShader(class_2960.method_60655("krypton", "shaders/blur_sample.frag"))
         .withSampler("u_BlurTex")
         .withUniform("BlurSampleData", class_10789.field_60031)
         .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
         .withDepthWrite(false)
         .withBlend(BlendFunction.TRANSLUCENT)
         .withCull(false)
         .build()
   );
   public static RenderPipeline PASSTHROUGH = register(
      new Pipelines.Builder(MESH_DATA_SNIPPET)
         .withLocation(class_2960.method_60655("krypton", "pipeline/blur/up"))
         .withVertexFormat(KryptonVertexFormats.POSITION_2D, class_5596.field_27379)
         .withVertexShader(class_2960.method_60655("krypton", "shaders/passthrough.vert"))
         .withFragmentShader(class_2960.method_60655("krypton", "shaders/passthrough.frag"))
         .withSampler("u_Texture")
         .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
         .withDepthWrite(false)
         .withBlend(BlendFunction.TRANSLUCENT)
         .withCull(false)
         .build()
   );

   public static RenderPipeline register(RenderPipeline pipeline) {
      REGISTERED.add(pipeline);
      return pipeline;
   }

   public static void precompileAll() {
      GpuDevice device = RenderSystem.getDevice();

      for (RenderPipeline pipeline : REGISTERED) {
         device.precompilePipeline(pipeline, Pipelines::loadShaderSource);
      }
   }

   public static String loadShaderSource(class_2960 location, ShaderType type) {
      String namespace = location.method_12836();
      String path = location.method_12832();
      String resource = "assets/" + namespace + "/" + path;

      try {
         label50: {
            String source;
            try (InputStream in = Pipelines.class.getClassLoader().getResourceAsStream(resource)) {
               if (in == null) {
                  break label50;
               }

               source = IOUtils.toString(in, StandardCharsets.UTF_8);
            }

            return source;
         }
      } catch (IOException var11) {
         throw new RuntimeException(var11);
      }

      path = String.valueOf(location);
      throw new RuntimeException("Shader not found: " + path);
   }

   public static class Builder {
      public com.mojang.blaze3d.pipeline.RenderPipeline.Builder builder;
      public boolean smoothLines;

      public Builder(Snippet... snippets) {
         this.builder = RenderPipeline.builder(snippets);
      }

      public Pipelines.Builder smoothLines() {
         this.smoothLines = true;
         return this;
      }

      public Pipelines.Builder withLocation(class_2960 location) {
         this.builder.withLocation(location);
         return this;
      }

      public Pipelines.Builder withVertexFormat(VertexFormat format, class_5596 drawMode) {
         this.builder.withVertexFormat(format, drawMode);
         return this;
      }

      public Pipelines.Builder withVertexShader(class_2960 shader) {
         this.builder.withVertexShader(shader);
         return this;
      }

      public Pipelines.Builder withFragmentShader(class_2960 shader) {
         this.builder.withFragmentShader(shader);
         return this;
      }

      public Pipelines.Builder withSampler(String name) {
         this.builder.withSampler(name);
         return this;
      }

      public Pipelines.Builder withUniform(String name, class_10789 type) {
         this.builder.withUniform(name, type);
         return this;
      }

      public Pipelines.Builder withDepthTestFunction(DepthTestFunction function) {
         this.builder.withDepthTestFunction(function);
         return this;
      }

      public Pipelines.Builder withDepthWrite(boolean write) {
         this.builder.withDepthWrite(write);
         return this;
      }

      public Pipelines.Builder withBlend(BlendFunction blend) {
         this.builder.withBlend(blend);
         return this;
      }

      public Pipelines.Builder withCull(boolean cull) {
         this.builder.withCull(cull);
         return this;
      }

      public RenderPipeline build() {
         return this.builder.build();
      }
   }
}
