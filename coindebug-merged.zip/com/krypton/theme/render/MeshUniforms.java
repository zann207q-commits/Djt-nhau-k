package com.krypton.theme.render;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.buffers.Std140Builder;
import com.mojang.blaze3d.buffers.Std140SizeCalculator;
import java.nio.ByteBuffer;
import net.minecraft.class_11280;
import net.minecraft.class_11280.class_11281;
import org.joml.Matrix4f;

public class MeshUniforms {
   public static int BLOCK_SIZE = new Std140SizeCalculator().putMat4f().putMat4f().get();
   public static MeshUniforms.Data DATA = new MeshUniforms.Data();
   public static class_11280<MeshUniforms.Data> STORAGE = new class_11280("Krypton - Mesh UBO", BLOCK_SIZE, 512);

   public static void clear() {
      STORAGE.method_71100();
   }

   public static GpuBufferSlice write(Matrix4f projection, Matrix4f modelView) {
      DATA.projection = projection;
      DATA.modelView = modelView;
      return STORAGE.method_71102(DATA);
   }

   public static class Data implements class_11281 {
      public Matrix4f projection;
      public Matrix4f modelView;

      public void method_71104(ByteBuffer buffer) {
         Std140Builder.intoBuffer(buffer).putMat4f(this.projection).putMat4f(this.modelView);
      }

      @Override
      public boolean equals(Object other) {
         return false;
      }
   }
}
