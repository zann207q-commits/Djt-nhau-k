package com.krypton.theme.render;

import org.joml.Matrix4f;

public final class RenderState {
   public static final Matrix4f PROJECTION = new Matrix4f();
   public static boolean worldSpace = true;
   public static boolean scissorActive;
   public static int scissorX;
   public static int scissorY;
   public static int scissorWidth;
   public static int scissorHeight;

   private RenderState() {
   }

   public static void enableScissor(int x, int y, int width, int height) {
      scissorX = x;
      scissorY = y;
      scissorWidth = width;
      scissorHeight = height;
      scissorActive = true;
   }

   public static void disableScissor() {
      scissorActive = false;
   }
}
