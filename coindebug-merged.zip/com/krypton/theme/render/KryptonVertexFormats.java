package com.krypton.theme.render;

import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormatElement;
import com.mojang.blaze3d.vertex.VertexFormatElement.Type;
import com.mojang.blaze3d.vertex.VertexFormatElement.Usage;

public abstract class KryptonVertexFormats {
   public static VertexFormatElement POSITION_2D_ELEMENT = VertexFormatElement.register(findFreeElementId(), 0, Type.FLOAT, Usage.POSITION, 2);
   public static VertexFormat POSITION_2D = VertexFormat.builder().add("Position", POSITION_2D_ELEMENT).build();
   public static VertexFormat POSITION_2D_COLOR = VertexFormat.builder().add("Position", POSITION_2D_ELEMENT).add("Color", VertexFormatElement.COLOR).build();
   public static VertexFormat POSITION_2D_TEXTURE_COLOR = VertexFormat.builder()
      .add("Position", POSITION_2D_ELEMENT)
      .add("Texture", VertexFormatElement.UV)
      .add("Color", VertexFormatElement.COLOR)
      .build();
   public static VertexFormat POSITION_TEXTURE_COLOR = VertexFormat.builder()
      .add("Position", VertexFormatElement.POSITION)
      .add("Texture", VertexFormatElement.UV)
      .add("Color", VertexFormatElement.COLOR)
      .build();

   public static int findFreeElementId() {
      int id = 0;

      while (VertexFormatElement.byId(id) != null) {
         if (++id >= 32) {
            throw new RuntimeException("Too many mods registering VertexFormatElements");
         }
      }

      return id;
   }
}
