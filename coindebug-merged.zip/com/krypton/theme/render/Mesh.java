package com.krypton.theme.render;

import com.krypton.theme.util.Color;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import java.nio.ByteBuffer;
import net.minecraft.class_243;
import net.minecraft.class_310;
import org.lwjgl.BufferUtils;
import org.lwjgl.system.MemoryUtil;

public class Mesh {
   public VertexFormat format;
   public int vertexSize;
   public double alphaMultiplier = 1.0;
   public ByteBuffer vertexBuffer = null;
   public long vertexBase;
   public long vertexPointer;
   public ByteBuffer indexBuffer = null;
   public long indexBase;
   public int vertexCount;
   public int indexCount;
   public boolean building;
   public double originX;
   public double originZ;

   public Mesh(RenderPipeline pipeline) {
      this(pipeline.getVertexFormat(), pipeline.getVertexFormatMode());
   }

   public Mesh(VertexFormat format, class_5596 drawMode) {
      this.format = format;
      this.vertexSize = format.getVertexSize();
   }

   public Mesh(VertexFormat format, class_5596 drawMode, int vertexCapacity, int indexCapacity) {
      this(format, drawMode);
      this.allocate(vertexCapacity, indexCapacity);
   }

   public void begin() {
      if (this.building) {
         throw new IllegalStateException("Mesh.begin() called while already building.");
      } else {
         this.vertexPointer = this.vertexBase;
         this.vertexCount = 0;
         this.indexCount = 0;
         this.building = true;
         if (RenderState.worldSpace) {
            class_243 camera = class_310.method_1551().field_1773.method_19418().method_71156();
            this.originX = camera.field_1352;
            this.originZ = camera.field_1350;
         } else {
            this.originX = 0.0;
            this.originZ = 0.0;
         }
      }
   }

   public Mesh vec3(double x, double y, double z) {
      long at = this.vertexPointer;
      MemoryUtil.memPutFloat(at, (float)(x - this.originX));
      MemoryUtil.memPutFloat(at + 4L, (float)y);
      MemoryUtil.memPutFloat(at + 8L, (float)(z - this.originZ));
      this.vertexPointer += 12L;
      return this;
   }

   public Mesh vec2(double x, double y) {
      long at = this.vertexPointer;
      MemoryUtil.memPutFloat(at, (float)x);
      MemoryUtil.memPutFloat(at + 4L, (float)y);
      this.vertexPointer += 8L;
      return this;
   }

   public Mesh vec2(float x, float y) {
      long at = this.vertexPointer;
      MemoryUtil.memPutFloat(at, x);
      MemoryUtil.memPutFloat(at + 4L, y);
      this.vertexPointer += 8L;
      return this;
   }

   public Mesh color(Color color) {
      long at = this.vertexPointer;
      MemoryUtil.memPutByte(at, (byte)color.r);
      MemoryUtil.memPutByte(at + 1L, (byte)color.g);
      MemoryUtil.memPutByte(at + 2L, (byte)color.b);
      MemoryUtil.memPutByte(at + 3L, (byte)(color.a * (float)this.alphaMultiplier));
      this.vertexPointer += 4L;
      return this;
   }

   public int nextIndex() {
      return this.vertexCount++;
   }

   public void line(int a, int b) {
      long at = this.indexBase + this.indexCount * 4L;
      MemoryUtil.memPutInt(at, a);
      MemoryUtil.memPutInt(at + 4L, b);
      this.indexCount += 2;
   }

   public void quad(int a, int b, int c, int d) {
      long at = this.indexBase + this.indexCount * 4L;
      MemoryUtil.memPutInt(at, a);
      MemoryUtil.memPutInt(at + 4L, b);
      MemoryUtil.memPutInt(at + 8L, c);
      MemoryUtil.memPutInt(at + 12L, c);
      MemoryUtil.memPutInt(at + 16L, d);
      MemoryUtil.memPutInt(at + 20L, a);
      this.indexCount += 6;
   }

   public void triangle(int a, int b, int c) {
      long at = this.indexBase + this.indexCount * 4L;
      MemoryUtil.memPutInt(at, a);
      MemoryUtil.memPutInt(at + 4L, b);
      MemoryUtil.memPutInt(at + 8L, c);
      this.indexCount += 3;
   }

   public void ensureQuad() {
      this.ensureCapacity(4, 6);
   }

   public void ensureTriangle() {
      this.ensureCapacity(3, 3);
   }

   public void ensureLine() {
      this.ensureCapacity(2, 2);
   }

   public void ensureCapacity(int vertices, int indices) {
      if (this.vertexBuffer != null && this.indexBuffer != null) {
         if ((this.vertexCount + vertices) * this.vertexSize >= this.vertexBuffer.capacity()) {
            int written = this.vertexBytes();
            int size = Math.max(this.vertexBuffer.capacity() * 2, this.vertexBuffer.capacity() + vertices * this.vertexSize);
            ByteBuffer grown = BufferUtils.createByteBuffer(size);
            MemoryUtil.memCopy(MemoryUtil.memAddress0(this.vertexBuffer), MemoryUtil.memAddress0(grown), written);
            this.vertexBuffer = grown;
            this.vertexBase = MemoryUtil.memAddress0(this.vertexBuffer);
            this.vertexPointer = this.vertexBase + written;
         }

         if ((this.indexCount + indices) * 4 >= this.indexBuffer.capacity()) {
            int size = Math.max(this.indexBuffer.capacity() * 2, this.indexBuffer.capacity() + indices * 4);
            ByteBuffer grown = BufferUtils.createByteBuffer(size);
            MemoryUtil.memCopy(MemoryUtil.memAddress0(this.indexBuffer), MemoryUtil.memAddress0(grown), this.indexCount * 4L);
            this.indexBuffer = grown;
            this.indexBase = MemoryUtil.memAddress0(this.indexBuffer);
         }
      } else {
         this.allocate(1024, 2048);
      }
   }

   public void allocate(int vertices, int indices) {
      this.vertexBuffer = BufferUtils.createByteBuffer(this.vertexSize * vertices);
      this.vertexPointer = this.vertexBase = MemoryUtil.memAddress0(this.vertexBuffer);
      this.indexBuffer = BufferUtils.createByteBuffer(indices * 4);
      this.indexBase = MemoryUtil.memAddress0(this.indexBuffer);
   }

   public void end() {
      if (!this.building) {
         throw new IllegalStateException("Mesh.end() called while not building.");
      } else {
         this.building = false;
      }
   }

   public boolean isBuilding() {
      return this.building;
   }

   public GpuBuffer uploadVertices() {
      this.vertexBuffer.limit(this.vertexBytes());
      return this.format.uploadImmediateVertexBuffer(this.vertexBuffer);
   }

   public GpuBuffer uploadIndices() {
      this.indexBuffer.limit(this.indexCount * 4);
      return this.format.uploadImmediateIndexBuffer(this.indexBuffer);
   }

   public int indexCount() {
      return this.indexCount;
   }

   public int vertexBytes() {
      return (int)(this.vertexPointer - this.vertexBase);
   }
}
