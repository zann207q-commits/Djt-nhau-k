package com.krypton.theme.render;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.buffers.Std140Builder;
import com.mojang.blaze3d.buffers.Std140SizeCalculator;
import java.nio.ByteBuffer;
import net.minecraft.class_11280;
import net.minecraft.class_11280.class_11281;

public class BlurUniforms {
   public static int BLOCK_SIZE = new Std140SizeCalculator().putVec2().putFloat().get();
   public static BlurUniforms.Data DATA = new BlurUniforms.Data();
   public static class_11280<BlurUniforms.Data> STORAGE = new class_11280("Krypton - Blur UBO", BLOCK_SIZE, 64);

   public static void clear() {
      STORAGE.method_71100();
   }

   public static GpuBufferSlice write(float halfTexelX, float halfTexelY, float offset) {
      DATA.halfTexelX = halfTexelX;
      DATA.halfTexelY = halfTexelY;
      DATA.offset = offset;
      return STORAGE.method_71102(DATA);
   }

   public static class Data implements class_11281 {
      public float halfTexelX;
      public float halfTexelY;
      public float offset;

      public void method_71104(ByteBuffer buffer) {
         Std140Builder.intoBuffer(buffer).putVec2(this.halfTexelX, this.halfTexelY).putFloat(this.offset);
      }

      @Override
      public boolean equals(Object other) {
         return false;
      }
   }
}
