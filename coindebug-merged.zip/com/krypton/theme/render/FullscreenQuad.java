package com.krypton.theme.render;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;

public class FullscreenQuad {
   public static GpuBuffer VERTICES;
   public static GpuBuffer INDICES;
   public static Mesh MESH;

   public static void init() {
      MESH = new Mesh(KryptonVertexFormats.POSITION_2D, class_5596.field_27379, 4, 6);
      MESH.begin();
      MESH.quad(MESH.vec2(-1.0, -1.0).nextIndex(), MESH.vec2(-1.0, 1.0).nextIndex(), MESH.vec2(1.0, 1.0).nextIndex(), MESH.vec2(1.0, -1.0).nextIndex());
      MESH.end();
      VERTICES = MESH.uploadVertices();
      INDICES = MESH.uploadIndices();
   }
}
