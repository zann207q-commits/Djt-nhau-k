package com.krypton.theme.gui;

public record Rect(double x, double y, double width, double height) {
}
