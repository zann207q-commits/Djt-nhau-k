package com.krypton.theme.gui;

import com.krypton.theme.render.RenderState;
import com.krypton.theme.util.Color;
import com.krypton.theme.util.Renderer3D;
import com.krypton.theme.util.Text;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_332;
import org.joml.Matrix3x2fStack;

public class Renderer2D {
   public static Renderer2D INSTANCE = new Renderer2D();
   public Deque<Rect> scissorStack = new ArrayDeque<>();
   public List<Runnable> postRenderQueue = new ArrayList<>();
   public Deque<Double> alphaStack = new ArrayDeque<>();
   public class_332 context;
   public double alpha = 1.0;
   public boolean scissorActive;
   public boolean active;

   public static void drawItem(class_332 context, class_1799 stack, int x, int y) {
      drawItem(context, stack, x, y, 1.0F, true);
   }

   public static void drawItem(class_332 context, class_1799 stack, int x, int y, float scale, boolean bridgeScaleFactor) {
      if (stack != null && !stack.method_7960()) {
         Matrix3x2fStack matrices = context.method_51448();
         matrices.pushMatrix();
         if (bridgeScaleFactor) {
            matrices.scale(1.0F / class_310.method_1551().method_22683().method_4495());
         }

         matrices.scale(scale, scale);
         int itemX = (int)(x / scale);
         int itemY = (int)(y / scale);
         context.method_51427(stack, itemX, itemY);
         matrices.popMatrix();
      }
   }

   public static void drawItemCentred(class_332 context, class_1799 stack, int x, int y, int box, float scale) {
      if (stack != null && !stack.method_7960()) {
         int size = (int)(16.0F * scale);
         int offsetX = (box - size) / 2;
         int offsetY = (box - size) / 2;
         drawItem(context, stack, x + offsetX, y + offsetY, scale, true);
      }
   }

   public void begin(class_332 context) {
      if (this.active) {
         throw new IllegalStateException("GuiRenderer.begin() called while already active");
      } else {
         this.context = context;
         this.active = true;
         this.alpha = 1.0;
         this.alphaStack.clear();
         this.scissorStack.clear();
         this.scissorActive = false;
         this.postRenderQueue.clear();
         Renderer3D.screenSpace();
         TextDriver.get().begin();
         Animations.SHAPES.beginBatch();
      }
   }

   public void end() {
      if (!this.active) {
         throw new IllegalStateException("GuiRenderer.end() called while not active");
      } else {
         while (!this.scissorStack.isEmpty()) {
            this.popScissor();
         }

         Animations.SHAPES.endBatch();

         for (Runnable runnable : this.postRenderQueue) {
            runnable.run();
         }

         this.postRenderQueue.clear();
         TextDriver.get().end();
         Renderer3D.worldSpace();
         this.context = null;
         this.active = false;
      }
   }

   public class_332 getContext() {
      return this.context;
   }

   public void pushAlpha(double factor) {
      this.alphaStack.push(this.alpha);
      this.setAlpha(this.alpha * factor);
   }

   public void popAlpha() {
      if (this.alphaStack.isEmpty()) {
         this.setAlpha(1.0);
      } else {
         this.setAlpha(this.alphaStack.pop());
      }
   }

   public double getAlpha() {
      return this.alpha;
   }

   public void setAlpha(double alpha) {
      this.alpha = Math.max(0.0, Math.min(1.0, alpha));
      Animations.SHAPES.setAlpha(this.alpha);
      TextDriver.get().setAlpha(this.alpha);
   }

   public void pushScissor(double x, double y, double width, double height) {
      double clipX = x;
      double clipY = y;
      double clipWidth = width;
      double clipHeight = height;
      if (!this.scissorStack.isEmpty()) {
         Rect parent = this.scissorStack.peek();
         double parentRight = parent.x() + parent.width();
         double parentBottom = parent.y() + parent.height();
         double right = x + width;
         double bottom = y + height;
         clipX = Math.max(x, parent.x());
         clipY = Math.max(y, parent.y());
         right = Math.min(right, parentRight);
         bottom = Math.min(bottom, parentBottom);
         clipWidth = Math.max(0.0, right - clipX);
         clipHeight = Math.max(0.0, bottom - clipY);
      }

      Animations.SHAPES.endBatch();
      TextDriver.get().end();
      Rect rect = new Rect(clipX, clipY, clipWidth, clipHeight);
      this.scissorStack.push(rect);
      this.applyScissor(rect);
      TextDriver.get().begin();
      Animations.SHAPES.beginBatch();
   }

   public void popScissor() {
      if (!this.scissorStack.isEmpty()) {
         Animations.SHAPES.endBatch();
         TextDriver.get().end();
         this.scissorStack.pop();
         if (this.scissorStack.isEmpty()) {
            this.clearScissor();
         } else {
            this.applyScissor(this.scissorStack.peek());
         }

         TextDriver.get().begin();
         Animations.SHAPES.beginBatch();
      }
   }

   public void applyScissor(Rect rect) {
      int framebufferHeight = class_310.method_1551().method_22683().method_4506();
      int x = (int)rect.x();
      int y = framebufferHeight - (int)(rect.y() + rect.height());
      int width = Math.max(0, (int)rect.width());
      int height = Math.max(0, (int)rect.height());
      if (this.scissorActive) {
         RenderState.disableScissor();
      }

      RenderState.enableScissor(x, y, width, height);
      this.scissorActive = true;
   }

   public void clearScissor() {
      if (this.scissorActive) {
         RenderState.disableScissor();
         this.scissorActive = false;
      }
   }

   public void postRender(Runnable runnable) {
      this.postRenderQueue.add(runnable);
   }

   public void fill(double x, double y, double width, double height, Color color) {
      Color faded = this.applyAlpha(color);
      if (faded.a != 0) {
         Animations.SHAPES.quad(x, y, width, height, faded);
      }
   }

   public void fillGradient(double x, double y, double width, double height, Color topLeft, Color topRight, Color bottomRight, Color bottomLeft) {
      Animations.SHAPES
         .gradientQuad(x, y, width, height, this.applyAlpha(topLeft), this.applyAlpha(topRight), this.applyAlpha(bottomRight), this.applyAlpha(bottomLeft));
   }

   public void roundedRect(Color color, double x1, double y1, double x2, double y2, double radius) {
      Animations.roundedRect(this.context, this.applyAlpha(color), x1, y1, x2, y2, radius);
   }

   public void roundedRect(Color color, double x1, double y1, double x2, double y2, double r1, double r2, double r3, double r4) {
      Animations.roundedRect(this.context, this.applyAlpha(color), x1, y1, x2, y2, r1, r2, r3, r4);
   }

   public void roundedRect(int packed, double x1, double y1, double x2, double y2, double radius) {
      Animations.roundedRect(this.context, this.applyAlpha(new Color(packed)), x1, y1, x2, y2, radius);
   }

   public void roundedRectPacked(int packed, double x1, double y1, double x2, double y2, double r1, double r2, double r3, double r4) {
      Animations.roundedRectPacked(this.context, this.applyAlpha(new Color(packed)).packed(), x1, y1, x2, y2, r1, r2, r3, r4);
   }

   public void roundedRectOutline(Color color, double x1, double y1, double x2, double y2, double r1, double r2, double r3, double r4, double thickness) {
      Animations.roundedRectOutline(this.context, this.applyAlpha(color), x1, y1, x2, y2, r1, r2, r3, r4, thickness);
   }

   public void circle(Color color, double centreX, double centreY, double radius) {
      Animations.circle(this.context, this.applyAlpha(color), centreX, centreY, radius);
   }

   public void circle(int packed, double centreX, double centreY, double radius) {
      Animations.circlePacked(this.context, this.applyAlpha(new Color(packed)).packed(), centreX, centreY, radius);
   }

   public void fillBounds(double x1, double y1, double x2, double y2, Color color) {
      Animations.fillRect(x1, y1, x2, y2, this.applyAlpha(color));
   }

   public void fillBounds(double x1, double y1, double x2, double y2, int packed) {
      Animations.fillRect(x1, y1, x2, y2, this.applyAlpha(new Color(packed)).packed());
   }

   public void line(double x1, double y1, double x2, double y2, Color color) {
      Animations.SHAPES.line(x1, y1, x2, y2, this.applyAlpha(color));
   }

   public void rectOutline(double x, double y, double width, double height, Color color) {
      Animations.SHAPES.rectOutline(x, y, width, height, this.applyAlpha(color));
   }

   public void triangle(double x1, double y1, double x2, double y2, double x3, double y3, Color color) {
      Animations.SHAPES.triangle(x1, y1, x2, y2, x3, y3, this.applyAlpha(color));
   }

   public double drawText(String text, double x, double y, Color color, boolean flag) {
      return TextDriver.get().draw(text, x, y, this.applyAlpha(color), flag);
   }

   public double drawText(String text, double x, double y, Color color) {
      return this.drawText(text, x, y, color, false);
   }

   public double textWidth(String text) {
      return TextDriver.get().width(text);
   }

   public double textHeight() {
      return TextDriver.get().height();
   }

   public void drawIcon(String name, double x, double y, double size, Color color) {
      if (Text.has(name)) {
         Color faded = this.applyAlpha(color);
         this.postRender(() -> Text.drawIcon(name, x, y, size, faded));
      }
   }

   public void queueItem(class_1799 stack, int x, int y) {
      class_332 context = this.context;
      this.postRender(() -> drawItem(context, stack, x, y));
   }

   public void queueItem(class_1799 stack, int x, int y, float scale, boolean bridgeScaleFactor) {
      class_332 context = this.context;
      this.postRender(() -> drawItem(context, stack, x, y, scale, bridgeScaleFactor));
   }

   public void queueItemCentred(class_1799 stack, int x, int y, int box, float scale) {
      class_332 context = this.context;
      this.postRender(() -> drawItemCentred(context, stack, x, y, box, scale));
   }

   public Color applyAlpha(Color color) {
      return this.alpha >= 1.0 ? color : new Color(color.r, color.g, color.b, (int)(color.a * this.alpha));
   }
}
