package com.krypton.theme.gui;

import java.util.Map;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_408;
import org.lwjgl.glfw.GLFW;

public class HudEditor {
   public static String dragging = null;
   public static int grabX = 0;
   public static int grabY = 0;
   public static boolean wasDown = false;

   public static boolean isEditing() {
      class_310 mc = class_310.method_1551();
      return mc.field_1755 instanceof class_408;
   }

   public static void render(class_332 context) {
      class_310 mc = class_310.method_1551();
      if (!isEditing()) {
         dragging = null;
      } else {
         int scaledWidth = mc.method_22683().method_4486();
         int scaledHeight = mc.method_22683().method_4502();
         double mouseX = mc.field_1729.method_1603() / mc.method_22683().method_4495();
         double mouseY = mc.field_1729.method_1604() / mc.method_22683().method_4495();
         boolean down = GLFW.glfwGetMouseButton(mc.method_22683().method_4490(), 0) == 1;
         Map<String, int[]> origins = HudPositions.getOrigins();
         Map<String, int[]> sizes = HudPositions.getSizes();
         if (down && !wasDown && dragging == null) {
            for (String name : origins.keySet()) {
               int[] origin = origins.get(name);
               int[] size = sizes.get(name);
               if (origin != null && size != null && mouseX >= origin[0] && mouseX < origin[0] + size[0] && mouseY >= origin[1] && mouseY < origin[1] + size[1]
                  )
                {
                  dragging = name;
                  grabX = (int)mouseX - origin[0];
                  grabY = (int)mouseY - origin[1];
                  break;
               }
            }
         }

         if (!down) {
            dragging = null;
         }

         if (dragging != null && down) {
            int[] size = sizes.get(dragging);
            int width = size != null ? size[0] : 50;
            int height = size != null ? size[1] : 30;
            int x = Math.max(0, Math.min(scaledWidth - width, (int)mouseX - grabX));
            int y = Math.max(0, Math.min(scaledHeight - height, (int)mouseY - grabY));
            HudPositions.move(dragging, x, y);
         }

         wasDown = down;
         if (dragging != null) {
            int[] origin = origins.get(dragging);
            int[] size = sizes.get(dragging);
            if (origin != null && size != null) {
               int x = origin[0];
               int y = origin[1];
               int width = size[0];
               int height = size[1];
               context.method_25294(x, y, x + width, y + 1, -2130706433);
               context.method_25294(x, y + height - 1, x + width, y + height, -2130706433);
               context.method_25294(x, y, x + 1, y + height, -2130706433);
               context.method_25294(x + width - 1, y, x + width, y + height, -2130706433);
            }
         }
      }
   }
}
