package com.krypton.theme.gui;

import com.krypton.theme.render.GlassUniforms;
import com.krypton.theme.render.KryptonVertexFormats;
import com.krypton.theme.render.Mesh;
import com.krypton.theme.render.MeshRenderer;
import com.krypton.theme.render.Pipelines;
import com.krypton.theme.util.Color;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class GlassRect {
   public static Color DEFAULT_FILL = new Color(18, 18, 22, 180);
   public static Color DEFAULT_BORDER_START = new Color(255, 255, 255, 140);
   public static Color DEFAULT_BORDER_END = new Color(255, 255, 255, 25);
   public static int BLUR_PASSES = 4;
   public static float BLUR_RADIUS = 4.0F;
   public static Mesh mesh;

   public static void panel(class_332 context, double x1, double y1, double x2, double y2, double radius) {
      draw(context, x1, y1, x2, y2, radius, radius, radius, radius, DEFAULT_FILL, DEFAULT_BORDER_START, DEFAULT_BORDER_END, 2.0, true);
   }

   public static void panelTinted(class_332 context, double x1, double y1, double x2, double y2, double radius, Color fill) {
      draw(context, x1, y1, x2, y2, radius, radius, radius, radius, fill, DEFAULT_BORDER_START, DEFAULT_BORDER_END, 2.0, true);
   }

   public static void draw(
      class_332 context,
      double x1,
      double y1,
      double x2,
      double y2,
      double r1,
      double r2,
      double r3,
      double r4,
      Color fill,
      Color borderStart,
      Color borderEnd,
      double borderWidth,
      boolean blur
   ) {
      render(context, x1, y1, x2, y2, r1, r2, r3, r4, fill, borderStart, borderEnd, borderWidth, blur, false);
   }

   public static void drawCached(
      class_332 context,
      double x1,
      double y1,
      double x2,
      double y2,
      double r1,
      double r2,
      double r3,
      double r4,
      Color fill,
      Color borderStart,
      Color borderEnd,
      double borderWidth
   ) {
      render(context, x1, y1, x2, y2, r1, r2, r3, r4, fill, borderStart, borderEnd, borderWidth, true, true);
   }

   public static void render(
      class_332 context,
      double x1,
      double y1,
      double x2,
      double y2,
      double r1,
      double r2,
      double r3,
      double r4,
      Color fill,
      Color borderStart,
      Color borderEnd,
      double borderWidth,
      boolean blur,
      boolean cached
   ) {
      if (x2 < x1) {
         double swap = x1;
         x1 = x2;
         x2 = swap;
      }

      if (y2 < y1) {
         double swap = y1;
         y1 = y2;
         y2 = swap;
      }

      double width = x2 - x1;
      double height = y2 - y1;
      if (!(width <= 0.0) && !(height <= 0.0)) {
         GpuTextureView blurTexture = null;
         if (blur) {
            blurTexture = cached ? Blur.cached() : Blur.blur(BLUR_PASSES, BLUR_RADIUS);
         }

         boolean haveBlur = blurTexture != null;
         if (blurTexture == null) {
            blurTexture = Blur.level0();
         }

         class_310 mc = class_310.method_1551();
         float framebufferWidth = mc.method_1522().field_1482;
         float framebufferHeight = mc.method_1522().field_1481;
         if (!(framebufferWidth <= 0.0F) && !(framebufferHeight <= 0.0F)) {
            if (mesh == null) {
               mesh = new Mesh(KryptonVertexFormats.POSITION_2D, class_5596.field_27379, 4, 6);
            }

            mesh.begin();
            int a = mesh.vec2(x1, y1).nextIndex();
            int b = mesh.vec2(x1, y2).nextIndex();
            int c = mesh.vec2(x2, y2).nextIndex();
            int d = mesh.vec2(x2, y1).nextIndex();
            mesh.quad(a, b, c, d);
            mesh.end();
            GpuBufferSlice glassData = GlassUniforms.write(
               (float)x1,
               (float)y1,
               (float)x2,
               (float)y2,
               (float)r1,
               (float)r2,
               (float)r3,
               (float)r4,
               fill,
               borderStart,
               borderEnd,
               (float)borderWidth,
               framebufferWidth,
               framebufferHeight,
               haveBlur
            );
            if (blurTexture != null) {
               MeshRenderer.begin()
                  .target(mc.method_1522())
                  .pipeline(Pipelines.ROUNDED_GLASS)
                  .mesh(mesh)
                  .uniform("GlassData", glassData)
                  .texture("u_BlurTex", blurTexture, Blur.sampler())
                  .draw();
            }
         }
      }
   }
}
