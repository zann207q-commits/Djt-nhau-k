package com.krypton.theme.gui;

import com.krypton.theme.render.BlurUniforms;
import com.krypton.theme.render.FullscreenQuad;
import com.krypton.theme.render.MeshUniforms;
import com.krypton.theme.render.Pipelines;
import com.krypton.theme.render.RenderState;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.AddressMode;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import com.mojang.blaze3d.vertex.VertexFormat.class_5595;
import java.util.OptionalInt;
import net.minecraft.class_12137;
import net.minecraft.class_276;
import net.minecraft.class_310;

public class Blur {
   public static int levels = 5;
   public static GpuTexture[] textures = new GpuTexture[5];
   public static GpuTextureView[] views = new GpuTextureView[5];
   public static int levelCount;
   public static int width;
   public static int height;
   public static boolean unsupported;
   public static class_12137 sampler;
   public static GpuTextureView cached;

   public static void noop() {
   }

   public static class_12137 sampler() {
      if (sampler == null) {
         sampler = RenderSystem.getSamplerCache()
            .method_75293(AddressMode.CLAMP_TO_EDGE, AddressMode.CLAMP_TO_EDGE, FilterMode.LINEAR, FilterMode.LINEAR, false);
      }

      return sampler;
   }

   public static GpuTextureView cached() {
      return cached;
   }

   public static GpuTextureView level0() {
      if (views[0] == null && !unsupported) {
         class_276 framebuffer = class_310.method_1551().method_1522();
         if (framebuffer != null && framebuffer.field_1482 > 0 && framebuffer.field_1481 > 0) {
            allocate(framebuffer.field_1482, framebuffer.field_1481);
         }
      }

      return views[0];
   }

   public static boolean hasBlur() {
      return cached != null;
   }

   public static void allocate(int framebufferWidth, int framebufferHeight) {
      if (textures[0] == null || width != framebufferWidth || height != framebufferHeight) {
         free();
         width = framebufferWidth;
         height = framebufferHeight;

         try {
            levelCount = 0;

            for (int level = 0; level < 5; level++) {
               int levelWidth = Math.max(1, framebufferWidth >> level + 1);
               int levelHeight = Math.max(1, framebufferHeight >> level + 1);
               if (levelWidth < 4 || levelHeight < 4) {
                  break;
               }

               textures[level] = RenderSystem.getDevice().createTexture("krypton-blur-l" + level, 15, TextureFormat.RGBA8, levelWidth, levelHeight, 1, 1);
               views[level] = RenderSystem.getDevice().createTextureView(textures[level]);
               levelCount++;
            }

            if (levelCount < 2) {
               unsupported = true;
               free();
               return;
            }

            unsupported = false;
         } catch (Throwable var5) {
            unsupported = true;
            free();
         }
      }
   }

   public static void free() {
      for (int level = 0; level < 5; level++) {
         try {
            if (views[level] != null) {
               views[level].close();
            }
         } catch (Throwable var3) {
         }

         try {
            if (textures[level] != null) {
               textures[level].close();
            }
         } catch (Throwable var2) {
         }

         views[level] = null;
         textures[level] = null;
      }

      levelCount = 0;
   }

   public static GpuTextureView blur(int passes, float radius) {
      if (unsupported) {
         cached = null;
         return null;
      } else {
         class_276 framebuffer = class_310.method_1551().method_1522();
         int framebufferWidth = framebuffer.field_1482;
         int framebufferHeight = framebuffer.field_1481;
         allocate(framebufferWidth, framebufferHeight);
         if (!unsupported && levelCount >= 2) {
            int depth = Math.max(1, Math.min(passes, levelCount - 1));

            try {
               copy(framebuffer.method_71639(), views[0], textures[0].getWidth(0), textures[0].getHeight(0));

               for (int level = 0; level < depth; level++) {
                  pass(Pipelines.BLUR_DOWN, views[level], views[level + 1], textures[level + 1].getWidth(0), textures[level + 1].getHeight(0), radius);
               }

               for (int level = depth; level > 0; level--) {
                  pass(Pipelines.BLUR_UP, views[level], views[level - 1], textures[level - 1].getWidth(0), textures[level - 1].getHeight(0), radius);
               }

               return cached = views[0];
            } catch (Throwable var7) {
               unsupported = true;
               cached = null;
               return null;
            }
         } else {
            cached = null;
            return null;
         }
      }
   }

   public static void copy(GpuTextureView source, GpuTextureView destination, int unusedWidth, int unusedHeight) {
      CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
      RenderPass pass = encoder.createRenderPass(() -> "Krypton Blur Copy", destination, OptionalInt.empty());

      try {
         pass.setPipeline(Pipelines.PASSTHROUGH);
         pass.setUniform("MeshData", MeshUniforms.write(RenderState.PROJECTION, RenderSystem.getModelViewStack()));
         pass.bindTexture("u_Texture", source, sampler());
         pass.setVertexBuffer(0, FullscreenQuad.VERTICES);
         pass.setIndexBuffer(FullscreenQuad.INDICES, class_5595.field_27373);
         pass.drawIndexed(0, 0, 6, 1);
      } finally {
         pass.close();
      }
   }

   public static void pass(
      RenderPipeline pipeline, GpuTextureView source, GpuTextureView destination, int destinationWidth, int destinationHeight, float radius
   ) {
      float halfTexelX = 0.5F / destinationWidth;
      float halfTexelY = 0.5F / destinationHeight;
      CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
      RenderPass pass = encoder.createRenderPass(() -> "Krypton Blur", destination, OptionalInt.empty());

      try {
         pass.setPipeline(pipeline);
         pass.setUniform("MeshData", MeshUniforms.write(RenderState.PROJECTION, RenderSystem.getModelViewStack()));
         pass.setUniform("BlurData", BlurUniforms.write(halfTexelX, halfTexelY, radius));
         pass.bindTexture("u_Texture", source, sampler());
         pass.setVertexBuffer(0, FullscreenQuad.VERTICES);
         pass.setIndexBuffer(FullscreenQuad.INDICES, class_5595.field_27373);
         pass.drawIndexed(0, 0, 6, 1);
      } finally {
         pass.close();
      }
   }
}
