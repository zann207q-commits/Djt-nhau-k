package com.krypton.theme.gui;

import com.krypton.theme.font.FontManager;
import com.krypton.theme.util.Color;

public interface TextDriver {
   static TextDriver get() {
      FontManager.init();
      return FontManager.driver;
   }

   void setAlpha(double var1);

   void begin(double var1, boolean var3, boolean var4);

   default void beginScaled(double scale) {
      this.begin(scale, false, false);
   }

   default void begin() {
      this.begin(1.0, false, false);
   }

   default void beginFlagged() {
      this.begin(1.0, false, true);
   }

   double width(String var1, int var2, boolean var3);

   default double width(String text, boolean flag) {
      return this.width(text, text.length(), flag);
   }

   default double width(String text) {
      return this.width(text, text.length(), false);
   }

   double height(boolean var1);

   default double height() {
      return this.height(false);
   }

   double draw(String var1, double var2, double var4, Color var6, boolean var7);

   default double draw(String text, double x, double y, Color color) {
      return this.draw(text, x, y, color, false);
   }

   boolean isCustom();

   void end();
}
