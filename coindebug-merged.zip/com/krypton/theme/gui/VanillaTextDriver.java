package com.krypton.theme.gui;

import com.krypton.theme.util.Color;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import org.joml.Matrix3x2fStack;

public class VanillaTextDriver implements TextDriver {
   public static final VanillaTextDriver INSTANCE = new VanillaTextDriver();
   public static final double SCALE = 1.5555555555555556;
   private double alpha = 1.0;

   private class_327 textRenderer() {
      return class_310.method_1551().field_1772;
   }

   @Override
   public void setAlpha(double alpha) {
      this.alpha = alpha;
   }

   @Override
   public void begin(double scale, boolean flagA, boolean flagB) {
   }

   @Override
   public double width(String text, int length, boolean flag) {
      if (text != null && !text.isEmpty() && length > 0) {
         int end = Math.min(length, text.length());
         return this.textRenderer().method_1727(text.substring(0, end)) * 1.5555555555555556;
      } else {
         return 0.0;
      }
   }

   @Override
   public double height(boolean flag) {
      return 9.0 * 1.5555555555555556;
   }

   @Override
   public double draw(String text, double x, double y, Color color, boolean flag) {
      if (text != null && !text.isEmpty()) {
         class_332 context = Renderer2D.INSTANCE.getContext();
         if (context == null) {
            return this.width(text);
         } else {
            Matrix3x2fStack matrices = context.method_51448();
            matrices.pushMatrix();
            matrices.scale(1.0F / class_310.method_1551().method_22683().method_4495());
            matrices.translate((float)x, (float)y);
            matrices.scale(1.5555556F, 1.5555556F);
            context.method_51433(this.textRenderer(), text, 0, 0, color.packed(), false);
            matrices.popMatrix();
            return this.width(text);
         }
      } else {
         return 0.0;
      }
   }

   @Override
   public boolean isCustom() {
      return false;
   }

   @Override
   public void end() {
   }

   public double getAlpha() {
      return this.alpha;
   }
}
