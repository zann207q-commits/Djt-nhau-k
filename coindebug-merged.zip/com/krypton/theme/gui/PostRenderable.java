package com.krypton.theme.gui;

import net.minecraft.class_332;

public interface PostRenderable {
   void postRender(class_332 var1, int var2, int var3, float var4);
}
