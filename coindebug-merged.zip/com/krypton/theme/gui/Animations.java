package com.krypton.theme.gui;

import com.krypton.theme.render.Mesh;
import com.krypton.theme.render.MeshRenderer;
import com.krypton.theme.render.Pipelines;
import com.krypton.theme.util.Color;
import com.krypton.theme.util.IconUv;
import com.mojang.blaze3d.textures.GpuTextureView;
import net.minecraft.class_12137;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;

public class Animations {
   public static Animations SHAPES;
   public static Animations TEXTURED;
   public Mesh mesh;
   public Mesh lineMesh;
   public boolean textured;
   public boolean batching = false;

   public Animations(boolean textured) {
      this.textured = textured;
      this.mesh = new Mesh(textured ? Pipelines.UI_TEXTURED : Pipelines.UI_COLORED);
      this.lineMesh = new Mesh(Pipelines.UI_COLORED_LINES);
   }

   public static void init() {
      SHAPES = new Animations(false);
      TEXTURED = new Animations(true);
   }

   public static void fillRect(double x1, double y1, double x2, double y2, int packed) {
      Color color = new Color(packed);
      if (color.a != 0) {
         boolean wasBatching = SHAPES.isBatching();
         if (!wasBatching) {
            SHAPES.beginMeshes();
         }

         SHAPES.quad(x1, y1, x2 - x1, y2 - y1, color);
         if (!wasBatching) {
            SHAPES.flush();
         }
      }
   }

   public static void fillRect(double x1, double y1, double x2, double y2, Color color) {
      fillRect(x1, y1, x2, y2, color.packed());
   }

   public static void roundedRect(class_332 context, Color color, double x1, double y1, double x2, double y2, double radius) {
      roundedRect(context, color, x1, y1, x2, y2, radius, radius, radius, radius);
   }

   public static void roundedRect(class_332 context, Color color, double x1, double y1, double x2, double y2, double r1, double r2, double r3, double r4) {
      if (color.a != 0) {
         if (x2 < x1) {
            double swap = x1;
            x1 = x2;
            x2 = swap;
         }

         if (y2 < y1) {
            double swap = y1;
            y1 = y2;
            y2 = swap;
         }

         double width = x2 - x1;
         double height = y2 - y1;
         if (!(width <= 0.0) && !(height <= 0.0)) {
            double maxRadius = Math.min(width, height) / 2.0;
            r1 = clampRadius(r1, maxRadius);
            r2 = clampRadius(r2, maxRadius);
            r3 = clampRadius(r3, maxRadius);
            r4 = clampRadius(r4, maxRadius);
            Color fill = new Color(color.r, color.g, color.b, color.a);
            int top = (int)Math.ceil(y1);
            int bottom = (int)Math.floor(y2);
            boolean wasBatching = SHAPES.isBatching();
            if (!wasBatching) {
               SHAPES.beginMeshes();
            }

            for (int y = top; y < bottom; y++) {
               double centre = y + 0.5;
               double left = leftEdge(x1, y1, y2, centre, r1, r3);
               double right = rightEdge(x2, y1, y2, centre, r2, r4);
               int spanLeft = (int)Math.ceil(left);
               int spanRight = (int)Math.floor(right);
               if (spanRight > spanLeft) {
                  SHAPES.quad(spanLeft, y, spanRight - spanLeft, 1.0, fill);
               }
            }

            if (!wasBatching) {
               SHAPES.flush();
            }
         }
      }
   }

   public static void roundedRectOutline(
      class_332 context, Color color, double x1, double y1, double x2, double y2, double r1, double r2, double r3, double r4, double thickness
   ) {
      if (color.a != 0 && !(thickness <= 0.0)) {
         if (x2 < x1) {
            double swap = x1;
            x1 = x2;
            x2 = swap;
         }

         if (y2 < y1) {
            double swap = y1;
            y1 = y2;
            y2 = swap;
         }

         double width = x2 - x1;
         double height = y2 - y1;
         if (!(width <= 0.0) && !(height <= 0.0)) {
            thickness = Math.min(thickness, Math.min(width, height) / 2.0);
            double maxRadius = Math.min(width, height) / 2.0;
            r1 = clampRadius(r1, maxRadius);
            r2 = clampRadius(r2, maxRadius);
            r3 = clampRadius(r3, maxRadius);
            r4 = clampRadius(r4, maxRadius);
            double innerX1 = x1 + thickness;
            double innerY1 = y1 + thickness;
            double innerX2 = x2 - thickness;
            double innerY2 = y2 - thickness;
            if (!(innerX2 <= innerX1) && !(innerY2 <= innerY1)) {
               double innerR1 = Math.max(0.0, r1 - thickness);
               double innerR2 = Math.max(0.0, r2 - thickness);
               double innerR3 = Math.max(0.0, r3 - thickness);
               double innerR4 = Math.max(0.0, r4 - thickness);
               Color fill = new Color(color.r, color.g, color.b, color.a);
               int top = (int)Math.ceil(y1);
               int bottom = (int)Math.floor(y2);
               int innerTop = (int)Math.ceil(innerY1);
               int innerBottom = (int)Math.floor(innerY2);
               boolean wasBatching = SHAPES.isBatching();
               if (!wasBatching) {
                  SHAPES.beginMeshes();
               }

               for (int y = top; y < bottom; y++) {
                  double centre = y + 0.5;
                  double left = leftEdge(x1, y1, y2, centre, r1, r3);
                  double right = rightEdge(x2, y1, y2, centre, r2, r4);
                  int spanLeft = (int)Math.ceil(left);
                  int spanRight = (int)Math.floor(right);
                  if (spanRight > spanLeft) {
                     if (y >= innerTop && y < innerBottom) {
                        double innerLeft = leftEdge(innerX1, innerY1, innerY2, centre, innerR1, innerR3);
                        double innerRight = rightEdge(innerX2, innerY1, innerY2, centre, innerR2, innerR4);
                        int innerSpanLeft = (int)Math.ceil(innerLeft);
                        int innerSpanRight = (int)Math.floor(innerRight);
                        if (innerSpanLeft > spanLeft) {
                           SHAPES.quad(spanLeft, y, Math.min(innerSpanLeft, spanRight) - spanLeft, 1.0, fill);
                        }

                        if (spanRight > innerSpanRight) {
                           SHAPES.quad(Math.max(innerSpanRight, spanLeft), y, spanRight - Math.max(innerSpanRight, spanLeft), 1.0, fill);
                        }
                     } else {
                        SHAPES.quad(spanLeft, y, spanRight - spanLeft, 1.0, fill);
                     }
                  }
               }

               if (!wasBatching) {
                  SHAPES.flush();
               }
            } else {
               roundedRect(context, color, x1, y1, x2, y2, r1, r2, r3, r4);
            }
         }
      }
   }

   public static void circle(class_332 context, Color color, double centreX, double centreY, double radius) {
      if (color.a != 0 && !(radius <= 0.0)) {
         Color fill = new Color(color.r, color.g, color.b, color.a);
         int top = (int)Math.ceil(centreY - radius);
         int bottom = (int)Math.floor(centreY + radius);
         double radiusSq = radius * radius;
         boolean wasBatching = SHAPES.isBatching();
         if (!wasBatching) {
            SHAPES.beginMeshes();
         }

         for (int y = top; y < bottom; y++) {
            double dy = y + 0.5 - centreY;
            double remainder = radiusSq - dy * dy;
            if (!(remainder <= 0.0)) {
               double dx = Math.sqrt(remainder);
               int spanLeft = (int)Math.ceil(centreX - dx);
               int spanRight = (int)Math.floor(centreX + dx);
               if (spanRight > spanLeft) {
                  SHAPES.quad(spanLeft, y, spanRight - spanLeft, 1.0, fill);
               }
            }
         }

         if (!wasBatching) {
            SHAPES.flush();
         }
      }
   }

   public static void roundedRectPacked(class_332 context, int packed, double x1, double y1, double x2, double y2, double r1, double r2, double r3, double r4) {
      int a = packed >> 24 & 0xFF;
      if (a != 0) {
         if (x2 < x1) {
            double swap = x1;
            x1 = x2;
            x2 = swap;
         }

         if (y2 < y1) {
            double swap = y1;
            y1 = y2;
            y2 = swap;
         }

         double width = x2 - x1;
         double height = y2 - y1;
         if (!(width <= 0.0) && !(height <= 0.0)) {
            double maxRadius = Math.min(width, height) / 2.0;
            r1 = clampRadius(r1, maxRadius);
            r2 = clampRadius(r2, maxRadius);
            r3 = clampRadius(r3, maxRadius);
            r4 = clampRadius(r4, maxRadius);
            int r = packed >> 16 & 0xFF;
            int g = packed >> 8 & 0xFF;
            int b = packed & 0xFF;
            Color fill = new Color(r, g, b, a);
            int top = (int)Math.ceil(y1);
            int bottom = (int)Math.floor(y2);
            boolean wasBatching = SHAPES.isBatching();
            if (!wasBatching) {
               SHAPES.beginMeshes();
            }

            for (int y = top; y < bottom; y++) {
               double centre = y + 0.5;
               double left = leftEdge(x1, y1, y2, centre, r1, r3);
               double right = rightEdge(x2, y1, y2, centre, r2, r4);
               int spanLeft = (int)Math.ceil(left);
               int spanRight = (int)Math.floor(right);
               if (spanRight > spanLeft) {
                  SHAPES.quad(spanLeft, y, spanRight - spanLeft, 1.0, fill);
               }
            }

            if (!wasBatching) {
               SHAPES.flush();
            }
         }
      }
   }

   public static void circlePacked(class_332 context, int packed, double centreX, double centreY, double radius) {
      int a = packed >> 24 & 0xFF;
      if (a != 0 && !(radius <= 0.0)) {
         int r = packed >> 16 & 0xFF;
         int g = packed >> 8 & 0xFF;
         int b = packed & 0xFF;
         Color fill = new Color(r, g, b, a);
         int top = (int)Math.ceil(centreY - radius);
         int bottom = (int)Math.floor(centreY + radius);
         double radiusSq = radius * radius;
         boolean wasBatching = SHAPES.isBatching();
         if (!wasBatching) {
            SHAPES.beginMeshes();
         }

         for (int y = top; y < bottom; y++) {
            double dy = y + 0.5 - centreY;
            double remainder = radiusSq - dy * dy;
            if (!(remainder <= 0.0)) {
               double dx = Math.sqrt(remainder);
               int spanLeft = (int)Math.ceil(centreX - dx);
               int spanRight = (int)Math.floor(centreX + dx);
               if (spanRight > spanLeft) {
                  SHAPES.quad(spanLeft, y, spanRight - spanLeft, 1.0, fill);
               }
            }
         }

         if (!wasBatching) {
            SHAPES.flush();
         }
      }
   }

   public static double leftEdge(double x, double top, double bottom, double y, double rTop, double rBottom) {
      if (rTop > 0.0 && y < top + rTop) {
         double centreX = x + rTop;
         double centreY = top + rTop;
         double dy = y - centreY;
         double dx = Math.sqrt(Math.max(0.0, rTop * rTop - dy * dy));
         return centreX - dx;
      } else if (rBottom > 0.0 && y > bottom - rBottom) {
         double centreX = x + rBottom;
         double centreY = bottom - rBottom;
         double dy = y - centreY;
         double dx = Math.sqrt(Math.max(0.0, rBottom * rBottom - dy * dy));
         return centreX - dx;
      } else {
         return x;
      }
   }

   public static double rightEdge(double x, double top, double bottom, double y, double rTop, double rBottom) {
      if (rTop > 0.0 && y < top + rTop) {
         double centreX = x - rTop;
         double centreY = top + rTop;
         double dy = y - centreY;
         double dx = Math.sqrt(Math.max(0.0, rTop * rTop - dy * dy));
         return centreX + dx;
      } else if (rBottom > 0.0 && y > bottom - rBottom) {
         double centreX = x - rBottom;
         double centreY = bottom - rBottom;
         double dy = y - centreY;
         double dx = Math.sqrt(Math.max(0.0, rBottom * rBottom - dy * dy));
         return centreX + dx;
      } else {
         return x;
      }
   }

   public static double clampRadius(double radius, double max) {
      return Double.isNaN(radius) ? 0.0 : class_3532.method_15350(radius, 0.0, max);
   }

   public void setAlpha(double alpha) {
      this.mesh.alphaMultiplier = alpha;
   }

   public void beginMeshes() {
      this.mesh.begin();
      this.lineMesh.begin();
   }

   public void endMeshes() {
      this.mesh.end();
      this.lineMesh.end();
   }

   public void beginBatch() {
      this.batching = true;
      this.beginMeshes();
   }

   public void endBatch() {
      this.batching = false;
      this.flush();
   }

   public boolean isBatching() {
      return this.batching;
   }

   public void flush() {
      this.submit(null, null, null);
   }

   public void drawWithTexture(GpuTextureView view, class_12137 sampler) {
      if (!this.textured) {
         throw new IllegalStateException("Tried to render with a texture with a non-textured Renderer2D");
      } else {
         this.submit("u_Texture", view, sampler);
      }
   }

   public void submit(String samplerName, GpuTextureView view, class_12137 sampler) {
      if (this.lineMesh.isBuilding()) {
         this.lineMesh.end();
      }

      if (this.mesh.isBuilding()) {
         this.mesh.end();
      }

      MeshRenderer.begin().target(class_310.method_1551().method_1522()).pipeline(Pipelines.UI_COLORED_LINES).mesh(this.lineMesh).draw();
      MeshRenderer.begin()
         .target(class_310.method_1551().method_1522())
         .pipeline(this.textured ? Pipelines.UI_TEXTURED : Pipelines.UI_COLORED)
         .mesh(this.mesh)
         .texture(samplerName, view, sampler)
         .draw();
   }

   public void triangle(double x1, double y1, double x2, double y2, double x3, double y3, Color color) {
      this.mesh.ensureTriangle();
      this.mesh
         .triangle(
            this.mesh.vec2(x1, y1).color(color).nextIndex(), this.mesh.vec2(x2, y2).color(color).nextIndex(), this.mesh.vec2(x3, y3).color(color).nextIndex()
         );
   }

   public void line(double x1, double y1, double x2, double y2, Color color) {
      this.lineMesh.ensureLine();
      this.lineMesh.line(this.lineMesh.vec2(x1, y1).color(color).nextIndex(), this.lineMesh.vec2(x2, y2).color(color).nextIndex());
   }

   public void rectOutline(double x, double y, double width, double height, Color color) {
      this.lineMesh.ensureCapacity(4, 8);
      int topLeft = this.lineMesh.vec2(x, y).color(color).nextIndex();
      int bottomLeft = this.lineMesh.vec2(x, y + height).color(color).nextIndex();
      int bottomRight = this.lineMesh.vec2(x + width, y + height).color(color).nextIndex();
      int topRight = this.lineMesh.vec2(x + width, y).color(color).nextIndex();
      this.lineMesh.line(topLeft, bottomLeft);
      this.lineMesh.line(bottomLeft, bottomRight);
      this.lineMesh.line(bottomRight, topRight);
      this.lineMesh.line(topRight, topLeft);
   }

   public void gradientQuad(double x, double y, double width, double height, Color topLeft, Color topRight, Color bottomRight, Color bottomLeft) {
      this.mesh.ensureQuad();
      this.mesh
         .quad(
            this.mesh.vec2(x, y).color(topLeft).nextIndex(),
            this.mesh.vec2(x, y + height).color(bottomLeft).nextIndex(),
            this.mesh.vec2(x + width, y + height).color(bottomRight).nextIndex(),
            this.mesh.vec2(x + width, y).color(topRight).nextIndex()
         );
   }

   public void quad(double x, double y, double width, double height, Color color) {
      this.gradientQuad(x, y, width, height, color, color, color, color);
   }

   public void texturedQuad(double x, double y, double width, double height, Color color) {
      this.mesh.ensureQuad();
      this.mesh
         .quad(
            this.mesh.vec2(x, y).vec2(0.0, 0.0).color(color).nextIndex(),
            this.mesh.vec2(x, y + height).vec2(0.0, 1.0).color(color).nextIndex(),
            this.mesh.vec2(x + width, y + height).vec2(1.0, 1.0).color(color).nextIndex(),
            this.mesh.vec2(x + width, y).vec2(1.0, 0.0).color(color).nextIndex()
         );
   }

   public void texturedQuad(double x, double y, double width, double height, IconUv uv, Color color) {
      this.mesh.ensureQuad();
      this.mesh
         .quad(
            this.mesh.vec2(x, y).vec2(uv.u0, uv.v0).color(color).nextIndex(),
            this.mesh.vec2(x, y + height).vec2(uv.u0, uv.v1).color(color).nextIndex(),
            this.mesh.vec2(x + width, y + height).vec2(uv.u1, uv.v1).color(color).nextIndex(),
            this.mesh.vec2(x + width, y).vec2(uv.u1, uv.v0).color(color).nextIndex()
         );
   }

   public void rotatedTexturedQuad(double x, double y, double width, double height, double degrees, double u0, double v0, double u1, double v1, Color color) {
      this.mesh.ensureQuad();
      double radians = Math.toRadians(degrees);
      double cos = Math.cos(radians);
      double sin = Math.sin(radians);
      double centreX = x + width / 2.0;
      double centreY = y + height / 2.0;
      double topLeftX = (x - centreX) * cos - (y - centreY) * sin + centreX;
      double topLeftY = (y - centreY) * cos + (x - centreX) * sin + centreY;
      int topLeft = this.mesh.vec2(topLeftX, topLeftY).vec2(u0, v0).color(color).nextIndex();
      double bottomLeftX = (x - centreX) * cos - (y + height - centreY) * sin + centreX;
      double bottomLeftY = (y + height - centreY) * cos + (x - centreX) * sin + centreY;
      int bottomLeft = this.mesh.vec2(bottomLeftX, bottomLeftY).vec2(u0, v1).color(color).nextIndex();
      double bottomRightX = (x + width - centreX) * cos - (y + height - centreY) * sin + centreX;
      double bottomRightY = (y + height - centreY) * cos + (x + width - centreX) * sin + centreY;
      int bottomRight = this.mesh.vec2(bottomRightX, bottomRightY).vec2(u1, v1).color(color).nextIndex();
      double topRightX = (x + width - centreX) * cos - (y - centreY) * sin + centreX;
      double topRightY = (y - centreY) * cos + (x + width - centreX) * sin + centreY;
      int topRight = this.mesh.vec2(topRightX, topRightY).vec2(u1, v0).color(color).nextIndex();
      this.mesh.quad(topLeft, bottomLeft, bottomRight, topRight);
   }

   public void rotatedTexturedQuad(double x, double y, double width, double height, double degrees, IconUv uv, Color color) {
      this.rotatedTexturedQuad(x, y, width, height, degrees, uv.u0, uv.v0, uv.u1, uv.v1, color);
   }

   static {
      init();
   }
}
