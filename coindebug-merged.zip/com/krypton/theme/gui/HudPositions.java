package com.krypton.theme.gui;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BiConsumer;

public class HudPositions {
   public static Map<String, int[]> origins = new LinkedHashMap<>();
   public static Map<String, int[]> sizes = new LinkedHashMap<>();
   public static Map<String, BiConsumer<Integer, Integer>> listeners = new LinkedHashMap<>();

   public static void bounds(String name, int x, int y, int width, int height) {
      int[] size = new int[]{width, height};
      sizes.put(name, size);
      int[] origin = new int[]{x, y};
      origins.put(name, origin);
   }

   public static void register(String name, BiConsumer<Integer, Integer> listener) {
      listeners.put(name, listener);
   }

   public static void move(String name, int x, int y) {
      int[] origin = new int[]{x, y};
      origins.put(name, origin);
      BiConsumer<Integer, Integer> listener = listeners.get(name);
      if (listener != null) {
         listener.accept(x, y);
      }
   }

   public static Map<String, int[]> getOrigins() {
      return origins;
   }

   public static Map<String, int[]> getSizes() {
      return sizes;
   }
}
