package com.krypton.theme.gui;

import java.util.Map;
import java.util.function.BiConsumer;

public class HudLayout {
   public static final Map<String, int[]> POSITIONS = HudPositions.origins;
   public static final Map<String, int[]> SIZES = HudPositions.sizes;
   public static final Map<String, BiConsumer<Integer, Integer>> MOVERS = HudPositions.listeners;

   private HudLayout() {
   }

   public static void report(String name, int x, int y, int width, int height) {
      HudPositions.bounds(name, x, y, width, height);
   }

   public static void onMove(String name, BiConsumer<Integer, Integer> mover) {
      HudPositions.register(name, mover);
   }

   public static void move(String name, int x, int y) {
      HudPositions.move(name, x, y);
   }

   public static Map<String, int[]> positions() {
      return HudPositions.getOrigins();
   }

   public static Map<String, int[]> sizes() {
      return HudPositions.getSizes();
   }
}
