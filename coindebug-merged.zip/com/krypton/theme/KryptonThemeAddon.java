package com.krypton.theme;

import com.krypton.theme.modules.render.Hud;
import meteordevelopment.meteorclient.addons.GithubRepo;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;

public class KryptonThemeAddon extends MeteorAddon {
   public static final Category CATEGORY = new Category("kr hud skid");

   public void onInitialize() {
      Modules.get().add(new Hud());
   }

   public void onRegisterCategories() {
      Modules.registerCategory(CATEGORY);
   }

   public String getPackage() {
      return "com.krypton.theme";
   }

   public GithubRepo getRepo() {
      return new GithubRepo("sub5larp", "skidded-krypton-hud");
   }
}
