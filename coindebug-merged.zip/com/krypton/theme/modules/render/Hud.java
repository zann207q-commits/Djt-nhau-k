package com.krypton.theme.modules.render;

import com.krypton.theme.KryptonThemeAddon;
import com.krypton.theme.gui.Animations;
import com.krypton.theme.gui.GlassRect;
import com.krypton.theme.gui.HudEditor;
import com.krypton.theme.gui.HudLayout;
import com.krypton.theme.gui.HudPositions;
import com.krypton.theme.gui.Renderer2D;
import com.krypton.theme.gui.TextDriver;
import com.krypton.theme.render.FullscreenQuad;
import com.krypton.theme.render.Pipelines;
import com.krypton.theme.settings.HudPosSetting;
import com.krypton.theme.util.Color;
import com.krypton.theme.util.Colors;
import com.krypton.theme.util.MathUtil;
import com.krypton.theme.util.Renderer3D;
import com.krypton.theme.util.Text;
import com.mojang.blaze3d.systems.RenderSystem;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Queue;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import meteordevelopment.meteorclient.events.meteor.ActiveModulesChangedEvent;
import meteordevelopment.meteorclient.events.meteor.MouseClickEvent;
import meteordevelopment.meteorclient.events.render.Render2DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.gui.WidgetScreen;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.BoolSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.misc.input.KeyAction;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1041;
import net.minecraft.class_10799;
import net.minecraft.class_1109;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_634;
import net.minecraft.class_640;
import org.joml.Matrix3x2fStack;
import org.lwjgl.glfw.GLFW;

public class Hud extends Module {
   public static String WATERMARK_TEXT = "KRYPTON+";
   public static SimpleDateFormat CLOCK = new SimpleDateFormat("HH:mm:ss");
   public static int MAX_NOTIFICATIONS = 5;
   public Setting<Boolean> resetPositions;
   public Setting<Boolean> watermark;
   public Setting<Boolean> infoBar;
   public Setting<Boolean> playerName;
   public Setting<Boolean> fps;
   public Setting<Boolean> time;
   public Setting<Boolean> ping;
   public Setting<Boolean> tps;
   public Setting<Boolean> bps;
   public Setting<Boolean> modules;
   public Setting<Boolean> coordinates;
   public Setting<Boolean> radar;
   public Setting<Boolean> potions;
   public Setting<Boolean> hotkeys;
   public Setting<Boolean> notifications;
   public Setting<Double> opacity;
   public Setting<Hud.SortMode> sortMode;
   public Setting<Boolean> rainbow;
   public Setting<Double> radarSize;
   public Setting<Double> radarRange;
   public Setting<Boolean> radarPlayers;
   public Setting<Double> notificationDuration;
   public Setting<Hud.NotificationCorner> notificationCorner;
   public Setting<Boolean> notificationSound;
   public Setting<SettingColor> accent;
   public HudPosSetting watermarkPosition;
   public HudPosSetting infoPosition;
   public HudPosSetting pingPosition;
   public HudPosSetting tpsPosition;
   public HudPosSetting bpsPosition;
   public HudPosSetting radarPosition;
   public HudPosSetting modulesPosition;
   public HudPosSetting potionsPosition;
   public HudPosSetting coordsPosition;
   public HudPosSetting hotkeysPosition;
   public List<Hud.Notification> visibleNotifications;
   public Queue<Hud.Notification> pendingNotifications;
   public Map<String, Hud.ModuleAnimation> moduleAnimations;
   public Map<UUID, float[]> radarBlips;
   public boolean listenersAttached;
   public static int TPS_SAMPLES = 20;
   public long[] tickTimes;
   public int tickIndex;
   public int tickCount;
   public double serverTps;
   public double blocksPerSecond;
   public class_243 lastPosition;
   public static Color TEXT_PRIMARY = new Color(255, 255, 255, 255);
   public static Color TEXT_SECONDARY = new Color(195, 185, 235, 255);
   public static float PADDING = 10.0F;
   public static float PILL_HEIGHT = 26.0F;
   public static float ICON_SIZE = 18.0F;
   public static float SMALL_GAP = 5.0F;
   public static float PANEL_PADDING = 12.0F;
   public static float PILL_RADIUS = 3.0F;
   public static float MARGIN = 8.0F;
   public static float SECOND_ROW_Y = 42.0F;
   public static float ELEMENT_GAP = 4.0F;
   public float topRowX;
   public float secondRowX;
   public Color panelFill;
   public Color accentFill;
   public static Color SEPARATOR = new Color(140, 90, 255, 90);
   public float[] notificationBounds;
   public int notificationBoundsCount;
   private Set<Module> lastActiveModules = new HashSet<>();
   private boolean kryptonRenderStackReady;

   public Hud() {
      super(KryptonThemeAddon.CATEGORY, "krypton-hud", "Customizable Display for client information");
      SettingGroup var1 = this.settings.getDefaultGroup();
      SettingGroup var2 = this.settings.createGroup("Radar");
      SettingGroup var3 = this.settings.createGroup("Notifications");
      this.watermark = var1.add(
         ((Builder)((Builder)((Builder)new Builder().name("watermark")).description("Shows client name watermark")).defaultValue(false)).build()
      );
      this.infoBar = var1.add(
         ((Builder)((Builder)((Builder)new Builder().name("info-bar")).description("Shows the combined info pill (player/fps/time)")).defaultValue(true))
            .build()
      );
      this.playerName = var1.add(
         ((Builder)((Builder)((Builder)new Builder().name("player-name")).description("Shows player name in info bar")).defaultValue(true)).build()
      );
      this.fps = var1.add(((Builder)((Builder)((Builder)new Builder().name("fps")).description("Shows FPS in info bar")).defaultValue(true)).build());
      this.time = var1.add(((Builder)((Builder)((Builder)new Builder().name("time")).description("Shows time in info bar")).defaultValue(true)).build());
      this.ping = var1.add(
         ((Builder)((Builder)((Builder)new Builder().name("ping")).description("Shows ping as a separate element")).defaultValue(true)).build()
      );
      this.tps = var1.add(
         ((Builder)((Builder)((Builder)new Builder().name("tps")).description("Shows server TPS as a separate element")).defaultValue(true)).build()
      );
      this.bps = var1.add(
         ((Builder)((Builder)((Builder)new Builder().name("bps")).description("Shows blocks per second as a separate element")).defaultValue(true)).build()
      );
      this.modules = var1.add(
         ((Builder)((Builder)((Builder)new Builder().name("modules")).description("Renders module array list")).defaultValue(true)).build()
      );
      this.coordinates = var1.add(
         ((Builder)((Builder)((Builder)new Builder().name("coordinates")).description("Shows player coordinates")).defaultValue(true)).build()
      );
      this.radar = var1.add(
         ((Builder)((Builder)((Builder)new Builder().name("radar")).description("Shows radar with nearby entities")).defaultValue(true)).build()
      );
      this.potions = var1.add(
         ((Builder)((Builder)((Builder)new Builder().name("potions")).description("Shows active potion effects")).defaultValue(true)).build()
      );
      this.hotkeys = var1.add(((Builder)((Builder)((Builder)new Builder().name("hotkeys")).description("Shows module keybinds")).defaultValue(true)).build());
      this.notifications = var1.add(
         ((Builder)((Builder)((Builder)new Builder().name("notifications")).description("Shows toggle notifications")).defaultValue(true)).build()
      );
      this.opacity = var1.add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                  .name("opacity"))
               .description("Controls the opacity of HUD elements"))
            .defaultValue(0.75)
            .range(0.0, 1.0)
            .sliderRange(0.0, 1.0)
            .build()
      );
      this.sortMode = var1.add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                     .name("sort-mode"))
                  .description("How to sort the module list"))
               .defaultValue(Hud.SortMode.LENGTH))
            .build()
      );
      this.rainbow = var1.add(
         ((Builder)((Builder)((Builder)new Builder().name("rainbow")).description("Enables rainbow coloring effect")).defaultValue(false)).build()
      );
      this.radarSize = var2.add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                  .name("radar-size"))
               .description("Controls the size of the radar"))
            .defaultValue(120.0)
            .range(60.0, 200.0)
            .sliderRange(60.0, 200.0)
            .build()
      );
      this.radarRange = var2.add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                  .name("radar-range"))
               .description("Controls the detection range of the radar"))
            .defaultValue(64.0)
            .range(16.0, 128.0)
            .sliderRange(16.0, 128.0)
            .build()
      );
      this.radarPlayers = var2.add(
         ((Builder)((Builder)((Builder)new Builder().name("radar-players")).description("Show players on radar")).defaultValue(true)).build()
      );
      this.notificationDuration = var3.add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                  .name("notification-duration"))
               .description("How long notifications stay visible (ms)"))
            .defaultValue(2500.0)
            .range(1000.0, 5000.0)
            .sliderRange(1000.0, 5000.0)
            .build()
      );
      this.notificationCorner = var3.add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                     .name("notification-corner"))
                  .description("Corner of the screen where notifications appear"))
               .defaultValue(Hud.NotificationCorner.BOTTOM_RIGHT))
            .build()
      );
      this.notificationSound = var3.add(
         ((Builder)((Builder)((Builder)new Builder().name("notification-sound")).description("Play a sound when notifications appear (per-severity)"))
               .defaultValue(false))
            .build()
      );
      this.accent = var1.add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                  .name("accent"))
               .description("Primary accent color across the HUD"))
            .defaultValue(new SettingColor(155, 100, 255, 255))
            .build()
      );
      this.resetPositions = var1.add(
         ((Builder)((Builder)((Builder)new Builder().name("reset-positions")).description("Put every HUD element back where it started. Not part of Krypton."))
               .defaultValue(false))
            .build()
      );
      this.watermarkPosition = new HudPosSetting("Watermark Position");
      this.infoPosition = new HudPosSetting("Info Position");
      this.pingPosition = new HudPosSetting("Ping Position");
      this.tpsPosition = new HudPosSetting("TPS Position");
      this.bpsPosition = new HudPosSetting("BPS Position");
      this.radarPosition = new HudPosSetting("Radar Position");
      this.modulesPosition = new HudPosSetting("Modules Position");
      this.potionsPosition = new HudPosSetting("Potions Position");
      this.coordsPosition = new HudPosSetting("Coords Position");
      this.hotkeysPosition = new HudPosSetting("Hotkeys Position");
      this.visibleNotifications = new ArrayList<>();
      this.pendingNotifications = new LinkedList<>();
      this.moduleAnimations = new LinkedHashMap<>();
      this.radarBlips = new HashMap<>();
      this.listenersAttached = false;
      this.tickTimes = new long[20];
      this.tickIndex = 0;
      this.tickCount = 0;
      this.serverTps = 20.0;
      this.blocksPerSecond = 0.0;
      this.lastPosition = null;
      this.topRowX = 8.0F;
      this.secondRowX = 8.0F;
      this.panelFill = new Color(0, 0, 0, 0);
      this.accentFill = new Color(0, 0, 0, 0);
      this.notificationBounds = new float[20];
      this.notificationBoundsCount = 0;
      HudLayout.onMove("Watermark", (var1x, var2x) -> this.watermarkPosition.set(var1x, var2x));
      HudLayout.onMove("Info", (var1x, var2x) -> this.infoPosition.set(var1x, var2x));
      HudLayout.onMove("Ping", (var1x, var2x) -> this.pingPosition.set(var1x, var2x));
      HudLayout.onMove("TPS", (var1x, var2x) -> this.tpsPosition.set(var1x, var2x));
      HudLayout.onMove("BPS", (var1x, var2x) -> this.bpsPosition.set(var1x, var2x));
      HudLayout.onMove("Radar", (var1x, var2x) -> this.radarPosition.set(var1x, var2x));
      HudLayout.onMove("Modules", (var1x, var2x) -> this.modulesPosition.set(var1x, var2x));
      HudLayout.onMove("Potions", (var1x, var2x) -> this.potionsPosition.set(var1x, var2x));
      HudLayout.onMove("Coords", (var1x, var2x) -> this.coordsPosition.set(var1x, var2x));
      HudLayout.onMove("Hotkeys", (var1x, var2x) -> this.hotkeysPosition.set(var1x, var2x));
   }

   public void onActivate() {
      this.lastActiveModules = new HashSet<>(Modules.get().getActive());
      this.listenersAttached = true;
   }

   public void onDeactivate() {
   }

   public void notify(String var1, String var2, class_1799 var3, Color var4, long var5) {
      if ((Boolean)this.notifications.get() && this.isActive()) {
         this.push(new Hud.Notification(this, var1, var2, var3, var4, var5));
      }
   }

   public void notify(Hud.Severity var1, String var2, String var3, class_1799 var4, long var5) {
      if ((Boolean)this.notifications.get() && this.isActive()) {
         this.push(new Hud.Notification(this, var1, var2, var3, var4, var5));
      }
   }

   public void push(Hud.Notification var1) {
      if (this.visibleNotifications.size() < 5) {
         this.visibleNotifications.add(var1);
      } else {
         this.pendingNotifications.offer(var1);
      }

      this.playSound(var1);
   }

   public void playSound(Hud.Notification var1) {
      if ((Boolean)this.notificationSound.get() && this.mc != null && this.mc.method_1483() != null) {
         Hud.Severity var2 = var1.severity();
         class_3414 var3 = var2 != null ? var2.sound : (class_3414)class_3417.field_15204.comp_349();
         if (var3 == null) {
            return;
         }

         this.mc.method_1483().method_4873(class_1109.method_4757(var3, 1.0F, 0.8F));
      }
   }

   @EventHandler
   private void onActiveModulesChanged(ActiveModulesChangedEvent var1) {
      HashSet var2 = new HashSet(Modules.get().getActive());

      for (Module var4 : var2) {
         if (!this.lastActiveModules.contains(var4)) {
            this.onModuleToggled(var4, true);
         }
      }

      for (Module var6 : this.lastActiveModules) {
         if (!var2.contains(var6)) {
            this.onModuleToggled(var6, false);
         }
      }

      this.lastActiveModules = var2;
   }

   public void onModuleToggled(Module var1, boolean var2) {
      String var3 = var1.title.toLowerCase();
      Hud.ModuleAnimation var4 = this.moduleAnimations.computeIfAbsent(var1.title, var0 -> new Hud.ModuleAnimation());
      var4.visible = var2;
      if (var2) {
         var4.dead = false;
      }

      if (!var3.contains("gui")
         && !var3.contains("hud")
         && !var3.contains("click")
         && !var3.contains("krypton+")
         && !var3.contains("krypton +")
         && (Boolean)this.notifications.get()
         && this.isActive()) {
         this.push(new Hud.Notification(this, var1.title, var2, var1.category.name));
      }
   }

   @EventHandler
   public void onTick(Post var1) {
      long var2 = System.currentTimeMillis();
      this.tickTimes[this.tickIndex % 20] = var2;
      this.tickIndex++;
      this.tickCount++;
      if (this.tickCount >= 20) {
         int var4 = this.tickIndex % 20;
         long var5 = var2 - this.tickTimes[var4];
         if (var5 > 0L) {
            this.serverTps = Math.min(20.0, 19000.0 / var5);
         }
      }

      if (this.mc.field_1724 != null) {
         class_243 var9 = this.mc.field_1724.method_73189();
         if (this.lastPosition != null) {
            double var10 = var9.field_1352 - this.lastPosition.field_1352;
            double var7 = var9.field_1350 - this.lastPosition.field_1350;
            this.blocksPerSecond = Math.sqrt(var10 * var10 + var7 * var7) * 20.0;
         }

         this.lastPosition = var9;
      }
   }

   private void initKryptonRenderStack() {
      if (RenderSystem.isOnRenderThread()) {
         try {
            Pipelines.precompileAll();
         } catch (IllegalStateException var2) {
            return;
         }

         if (!this.kryptonRenderStackReady) {
            this.kryptonRenderStackReady = true;
            FullscreenQuad.init();
         }
      }
   }

   @EventHandler
   public void onRender2D(Render2DEvent var1) {
      this.initKryptonRenderStack();
      if ((Boolean)this.resetPositions.get()) {
         for (HudPosSetting var5 : new HudPosSetting[]{
            this.watermarkPosition,
            this.infoPosition,
            this.pingPosition,
            this.tpsPosition,
            this.bpsPosition,
            this.radarPosition,
            this.modulesPosition,
            this.potionsPosition,
            this.coordsPosition,
            this.hotkeysPosition
         }) {
            var5.reset();
         }

         HudPositions.getOrigins().clear();
         HudPositions.getSizes().clear();
         this.resetPositions.set(false);
      }

      class_332 var8 = var1.drawContext;
      Renderer2D var9 = Renderer2D.INSTANCE;
      var9.begin(var8);
      class_1041 var10 = this.mc.method_22683();
      int var11 = var10.method_4489();
      int var6 = this.mc.method_22683().method_4506();
      this.topRowX = 8.0F;
      this.secondRowX = 8.0F;
      int var7 = (int)(((Double)this.opacity.get()).floatValue() * 255.0F);
      this.panelFill = new Color(8, 18, 60, var7);
      this.accentFill = this.rainbow.get() ? Colors.rainbow(2, 255) : this.kryptonAccent();
      if ((Boolean)this.radar.get() && this.mc.field_1724 != null && this.mc.field_1687 != null) {
         this.drawRadar(var8, var11, var6);
      }

      if ((Boolean)this.watermark.get()) {
         this.drawWatermark(var8);
      }

      if ((Boolean)this.infoBar.get()) {
         this.drawInfoBar(var8);
      }

      if ((Boolean)this.coordinates.get() && this.mc.field_1724 != null) {
         this.drawCoordinates(var8);
      }

      if ((Boolean)this.ping.get()) {
         this.drawPing(var8);
      }

      if ((Boolean)this.tps.get()) {
         this.drawTps(var8);
      }

      if ((Boolean)this.bps.get()) {
         this.drawBps(var8);
      }

      if ((Boolean)this.hotkeys.get()) {
         this.drawHotkeys(var8, var6);
      }

      if ((Boolean)this.potions.get() && this.mc.field_1724 != null) {
         this.drawPotions(var8, var6);
      }

      if ((Boolean)this.modules.get()) {
         this.drawModuleList(var8, var11);
      }

      this.drawNotifications(var8, var11, var6);
      var9.end();
      HudEditor.render(var8);
   }

   public void drawIcon(String var1, float var2, float var3, float var4, Color var5) {
      Text.init();
      if (Text.has(var1)) {
         Text.drawIcon(var1, var2, var3 - 1.0F, var4, var5);
      }
   }

   public void reportBounds(String var1, float var2, float var3, float var4, float var5) {
      double var6 = this.mc.method_22683().method_4495();
      HudLayout.report(var1, (int)(var2 / var6), (int)(var3 / var6), (int)(var4 / var6), (int)(var5 / var6));
   }

   public float positionX(HudPosSetting var1, float var2) {
      return var1.isPlaced() ? var1.getX() * this.mc.method_22683().method_4495() : var2;
   }

   public float positionY(HudPosSetting var1, float var2) {
      return var1.isPlaced() ? var1.getY() * this.mc.method_22683().method_4495() : var2;
   }

   public Color panelColor() {
      return this.panelFill;
   }

   public Color kryptonAccent() {
      meteordevelopment.meteorclient.utils.render.color.Color var1 = (meteordevelopment.meteorclient.utils.render.color.Color)this.accent.get();
      return new Color(var1.r, var1.g, var1.b, var1.a);
   }

   public Color accentColor() {
      return this.accentFill;
   }

   public Color primaryText() {
      return TEXT_PRIMARY;
   }

   public Color secondaryText() {
      return TEXT_SECONDARY;
   }

   public void drawWatermark(class_332 var1) {
      String var2 = "KRYPTON+ cracked by sub5larp";
      float var3 = Text.has("client") ? 30.0F : 0.0F;
      float var4 = 10.0F + var3 + (int)TextDriver.get().width(var2) + 10.0F;
      float var5 = this.positionX(this.watermarkPosition, this.topRowX);
      float var6 = this.positionY(this.watermarkPosition, 8.0F);
      this.reportBounds("Watermark", var5, var6, var4, 26.0F);
      if (!this.watermarkPosition.isPlaced()) {
         this.topRowX = var5 + var4 + 4.0F;
      }

      Animations.roundedRect(var1, this.panelColor(), var5, var6, var5 + var4, var6 + 26.0F, 0.0);
      float var7 = var5 + 10.0F;
      float var8 = var6 + 13.0F;
      Color var9 = this.accentColor();
      if (Text.has("client")) {
         this.drawIcon("client", var7, var8 - 9.0F, 18.0F, var9);
         var7 += 23.0F;
         Animations.fillRect((int)var7, (int)(var6 + 4.0F), (int)(var7 + 2.0F), (int)(var6 + 26.0F - 4.0F), SEPARATOR.packed());
         var7 += 7.0F;
      }

      TextDriver.get().draw(var2, (int)var7, (int)(var8 - 8.0F), new Color(var9.packed()), false);
   }

   public void drawInfoBar(class_332 var1) {
      boolean var2 = (Boolean)this.playerName.get() && this.mc.field_1724 != null;
      boolean var3 = (Boolean)this.fps.get();
      boolean var4 = (Boolean)this.time.get();
      if (var2 || var3 || var4) {
         String var5 = var2 ? this.mc.field_1724.method_5477().getString() : null;
         String var6 = var3 ? this.mc.method_47599() + " Fps" : null;
         String var7 = var4 ? CLOCK.format(new Date()) : null;
         float var8 = 10.0F;
         boolean var9 = true;
         if (var2) {
            var8 += (Text.has("player") ? 30.0F : 0.0F) + (int)TextDriver.get().width(var5);
            var9 = false;
         }

         if (var3) {
            if (!var9) {
               var8 += 14.0F;
            }

            var8 += (Text.has("frame") ? 30.0F : 0.0F) + (int)TextDriver.get().width(var6);
            var9 = false;
         }

         if (var4) {
            if (!var9) {
               var8 += 14.0F;
            }

            var8 += (Text.has("time") ? 30.0F : 0.0F) + (int)TextDriver.get().width(var7);
         }

         var8 += 10.0F;
         float var10 = this.positionX(this.infoPosition, this.topRowX);
         float var11 = this.positionY(this.infoPosition, 8.0F);
         this.reportBounds("Info", var10, var11, var8, 26.0F);
         if (!this.infoPosition.isPlaced()) {
            this.topRowX = var10 + var8 + 4.0F;
         }

         Animations.roundedRect(var1, this.panelColor(), var10, var11, var10 + var8, var11 + 26.0F, 3.0);
         float var12 = var10 + 10.0F;
         float var13 = var11 + 13.0F;
         var9 = true;
         if (var2) {
            if (Text.has("player")) {
               this.drawIcon("player", var12, var13 - 9.0F, 18.0F, this.accentColor());
               var12 += 23.0F;
               var12 = this.separator(var1, var12, var11);
            }

            TextDriver.get().draw(var5, (int)var12, (int)(var13 - 8.0F), new Color(this.secondaryText().packed()), false);
            var12 += (int)TextDriver.get().width(var5);
            var9 = false;
         }

         if (var3) {
            if (!var9) {
               var12 = this.spacedSeparator(var1, var12, var11);
            }

            if (Text.has("frame")) {
               this.drawIcon("frame", var12, var13 - 9.0F, 18.0F, this.accentColor());
               var12 += 23.0F;
               var12 = this.separator(var1, var12, var11);
            }

            TextDriver.get().draw(var6, (int)var12, (int)(var13 - 8.0F), new Color(this.secondaryText().packed()), false);
            var12 += (int)TextDriver.get().width(var6);
            var9 = false;
         }

         if (var4) {
            if (!var9) {
               var12 = this.spacedSeparator(var1, var12, var11);
            }

            if (Text.has("time")) {
               this.drawIcon("time", var12, var13 - 9.0F, 18.0F, this.accentColor());
               var12 += 23.0F;
               var12 = this.separator(var1, var12, var11);
            }

            TextDriver.get().draw(var7, (int)var12, (int)(var13 - 8.0F), new Color(this.secondaryText().packed()), false);
         }
      }
   }

   public float separator(class_332 var1, float var2, float var3) {
      Animations.fillRect((int)var2, (int)(var3 + 4.0F), (int)(var2 + 2.0F), (int)(var3 + 26.0F - 4.0F), SEPARATOR.packed());
      return var2 + 2.0F + 5.0F;
   }

   public float spacedSeparator(class_332 var1, float var2, float var3) {
      var2 += 6.0F;
      Animations.fillRect((int)var2, (int)(var3 + 4.0F), (int)(var2 + 2.0F), (int)(var3 + 26.0F - 4.0F), SEPARATOR.packed());
      return var2 + 8.0F;
   }

   public void drawPill(class_332 var1, String var2, String var3, HudPosSetting var4, String var5) {
      boolean var6 = Text.has(var2);
      float var7 = var6 ? 30.0F : 0.0F;
      float var8 = 10.0F + var7 + (int)TextDriver.get().width(var3) + 10.0F;
      float var9 = this.positionX(var4, this.secondRowX);
      float var10 = this.positionY(var4, 42.0F);
      this.reportBounds(var5, var9, var10, var8, 26.0F);
      if (!var4.isPlaced()) {
         this.secondRowX = var9 + var8 + 4.0F;
      }

      Animations.roundedRect(var1, this.panelColor(), var9, var10, var9 + var8, var10 + 26.0F, 3.0);
      float var11 = var9 + 10.0F;
      float var12 = var10 + 13.0F;
      if (var6) {
         this.drawIcon(var2, var11, var12 - 9.0F, 18.0F, this.accentColor());
         var11 += 23.0F;
         Animations.fillRect((int)var11, (int)(var10 + 4.0F), (int)(var11 + 2.0F), (int)(var10 + 26.0F - 4.0F), SEPARATOR.packed());
         var11 += 7.0F;
      }

      TextDriver.get().draw(var3, (int)var11, (int)(var12 - 8.0F), new Color(this.secondaryText().packed()), false);
   }

   public void drawPing(class_332 var1) {
      this.drawPill(var1, "ping", this.ping() + " Ping", this.pingPosition, "Ping");
   }

   public void drawTps(class_332 var1) {
      this.drawPill(var1, "ticks", String.format("%.1f Ticks", this.serverTps), this.tpsPosition, "TPS");
   }

   public void drawBps(class_332 var1) {
      this.drawPill(var1, "bps", String.format("%.1f Bps", this.blocksPerSecond), this.bpsPosition, "BPS");
   }

   public void drawCoordinates(class_332 var1) {
      String var2 = String.format("%.0f | %.0f | %.0f", this.mc.field_1724.method_23317(), this.mc.field_1724.method_23318(), this.mc.field_1724.method_23321());
      boolean var3 = Text.has("compass");
      float var4 = var3 ? 30.0F : 0.0F;
      float var5 = 10.0F + var4 + (int)TextDriver.get().width(var2) + 10.0F;
      float var6 = this.positionX(this.coordsPosition, this.secondRowX);
      float var7 = this.positionY(this.coordsPosition, 42.0F);
      this.reportBounds("Coords", var6, var7, var5, 26.0F);
      if (!this.coordsPosition.isPlaced()) {
         this.secondRowX = var6 + var5 + 4.0F;
      }

      Animations.roundedRect(var1, this.panelColor(), var6, var7, var6 + var5, var7 + 26.0F, 3.0);
      float var8 = var7 + 13.0F;
      float var9 = var6 + 10.0F;
      if (var3) {
         this.drawIcon("compass", var9, var8 - 9.0F, 18.0F, this.accentColor());
         var9 += 23.0F;
         Animations.fillRect((int)var9, (int)(var7 + 4.0F), (int)(var9 + 2.0F), (int)(var7 + 26.0F - 4.0F), SEPARATOR.packed());
         var9 += 7.0F;
      }

      TextDriver.get().draw(var2, (int)var9, (int)(var8 - 8.0F), new Color(this.secondaryText().packed()), false);
   }

   public int potionsAnchorY() {
      if ((Boolean)this.radar.get()) {
         float var6 = ((Double)this.radarSize.get()).floatValue();
         float var2 = var6 + 120.0F - var6;
         float var3 = this.positionY(this.radarPosition, var2);
         float var4 = var3 + var6 * 2.0F;
         int var5 = this.coordinates.get() ? 22 : 10;
         return (int)(var4 + var5 + 30.0F);
      } else {
         byte var1 = 94;
         if ((Boolean)this.coordinates.get()) {
            var1 += 22;
         }

         return var1 + 30;
      }
   }

   public void drawPotions(class_332 var1, int var2) {
      Collection var3 = this.mc.field_1724.method_6026();
      if (!var3.isEmpty()) {
         ArrayList var4 = new ArrayList(var3);
         var4.sort(Comparator.comparing(var0 -> ((class_1291)var0.method_5579().comp_349()).method_5567()));
         int var5 = (int)(((Double)this.opacity.get()).floatValue() * 255.0F);
         Color var6 = new Color(30, 30, 40, var5);
         Color var7 = new Color(0, 0, 0, 0);
         Color var8 = this.rainbow.get() ? Colors.rainbow(2, 255) : this.kryptonAccent();
         byte var9 = 10;
         int var10 = this.potionsAnchorY();
         int var11 = (int)this.positionX(this.potionsPosition, var9);
         int var12 = (int)this.positionY(this.potionsPosition, var10);
         float var13 = 22.0F;
         float var14 = 8.0F;
         float var15 = 14.0F;
         float var16 = 22.0F;
         float var17 = 14.0F;
         float var18 = 28.0F;
         float var19 = 20.0F;
         String var20 = "Active potions";
         float var21 = var14 + var19 + 7.0F + 1.0F + 7.0F + (int)TextDriver.get().width(var20) + var14;
         float var22 = 0.0F;

         for (class_1293 var24 : var4) {
            String var25 = this.effectName(var24);
            String var26 = this.effectDuration(var24);
            float var27 = var16 + (int)TextDriver.get().width(var25) + var17 + (int)TextDriver.get().width(var26);
            var22 = Math.max(var22, var27);
         }

         float var40 = Math.max(var22 + var14 + var15, var21);
         float var41 = var18 + 3.0F + var4.size() * var13 + var14;
         this.reportBounds("Potions", var11, var12, var40, var41);
         GlassRect.draw(var1, var11, var12, var11 + var40, var12 + var18, 5.0, 5.0, 5.0, 5.0, var6, var7, var7, 0.0, true);
         float var42 = var12 + var18 / 2.0F;
         this.drawIcon("potions", var11 + var14, var42 - var19 / 2.0F, var19, var8);
         float var43 = var11 + var14 + var19 + 7.0F;
         Animations.fillRect((int)var43, var12 + 5, (int)(var43 + 1.0F), (int)(var12 + var18 - 5.0F), new Color(255, 255, 255, 40).packed());
         TextDriver.get().draw(var20, (int)(var43 + 7.0F), (int)(var42 - 8.0F), new Color(this.primaryText().packed()), false);
         int var44 = (int)(var12 + var18 + 3.0F);
         float var28 = var4.size() * var13 + var14;
         GlassRect.draw(var1, var11, var44, var11 + var40, var44 + var28, 5.0, 5.0, 5.0, 5.0, var6, var7, var7, 0.0, false);

         for (int var29 = 0; var29 < var4.size(); var29++) {
            class_1293 var30 = (class_1293)var4.get(var29);
            String var31 = this.effectName(var30);
            String var32 = this.effectDuration(var30);
            int var33 = (int)(var44 + var14 / 2.0F + var29 * var13);
            class_2960 var34 = this.effectIcon(var30);
            if (var34 != null) {
               Renderer3D.worldSpace();
               double var35 = this.mc.method_22683().method_4495();
               int var37 = (int)Math.round((var11 + var14) / var35);
               int var38 = (int)Math.round(var33 / var35);
               int var39 = (int)Math.round(18.0 / var35);
               var1.method_52706(class_10799.field_56883, var34, var37, var38, var39, var39);
               Renderer3D.screenSpace();
            }

            Color var45 = this.rainbow.get() ? Colors.rainbow(2 + var29 * 5, 255) : this.kryptonAccent();
            TextDriver.get().draw(var31, (int)(var11 + var14 + var16), var33 + 5, new Color(this.primaryText().packed()), false);
            float var36 = (int)TextDriver.get().width(var32);
            TextDriver.get()
               .draw(var32, (int)(var11 + var40 - var36 - var15), var33 + 5, new Color(var45.getRed(), var45.getGreen(), var45.getBlue(), 180), false);
         }
      }
   }

   public void drawHotkeys(class_332 var1, int var2) {
      ArrayList var3 = new ArrayList();

      for (Module var5 : Modules.get().getAll()) {
         if (var5.keybind.isSet()) {
            String var6 = var5.title.toLowerCase();
            if (!var6.contains("krypton") && !var6.contains("gui") && !var6.contains("click")) {
               var3.add(var5);
            }
         }
      }

      if (!var3.isEmpty()) {
         float var34 = ((Double)this.opacity.get()).floatValue() * 255.0F;
         int var35 = (int)var34;
         Color var36 = new Color(30, 28, 24, var35);
         Color var7 = new Color(0, 0, 0, 0);
         Color var8 = this.rainbow.get() ? Colors.rainbow(2, 255) : this.kryptonAccent();
         Color var9 = new Color(180, 175, 170, 255);
         float var10 = 12.0F;
         float var11 = 20.0F;
         float var12 = 8.0F;
         float var13 = 28.0F;
         float var14 = 22.0F;
         float var15 = 2.0F;
         float var16 = 0.0F;
         float var17 = 0.0F;

         for (Module var19 : var3) {
            var16 = Math.max(var16, (float)((int)TextDriver.get().width(var19.title)));
            String var20 = var19.keybind.toString();
            var17 = Math.max(var17, (float)((int)TextDriver.get().width(var20)));
         }

         float var37 = var10 + var11 + var12 + (int)TextDriver.get().width("Hotkeys") + var10;
         float var38 = var10 + var16 + 24.0F + var17 + var10;
         float var39 = Math.max(var37, var38);
         float var21 = var13 + 3.0F + var3.size() * (var14 + var15);
         float var22 = 8.0F;
         float var23 = var2 - var21 - 40.0F;
         float var24 = this.positionX(this.hotkeysPosition, var22);
         float var25 = this.positionY(this.hotkeysPosition, var23);
         this.reportBounds("Hotkeys", var24, var25, var39, var21);
         GlassRect.draw(var1, var24, var25, var24 + var39, var25 + var13, 5.0, 5.0, 5.0, 5.0, var36, var7, var7, 0.0, true);
         float var26 = var25 + var13 / 2.0F;
         this.drawIcon("keybinds", var24 + var10, var26 - var11 / 2.0F, var11, var8);
         float var27 = var24 + var10 + var11 + 7.0F;
         Animations.fillRect((int)var27, (int)(var25 + 5.0F), (int)(var27 + 1.0F), (int)(var25 + var13 - 5.0F), new Color(255, 255, 255, 40).packed());
         TextDriver.get().draw("Hotkeys", (int)(var27 + 7.0F), (int)(var26 - 8.0F), new Color(this.primaryText().packed()), false);
         float var28 = var25 + var13 + 3.0F;

         for (int var29 = 0; var29 < var3.size(); var29++) {
            Module var30 = (Module)var3.get(var29);
            String var31 = var30.keybind.toString();
            Color var32 = new Color(25, 23, 20, (int)(var34 * 0.8F));
            GlassRect.draw(var1, var24, var28, var24 + var39, var28 + var14, 3.0, 3.0, 3.0, 3.0, var32, var7, var7, 0.0, false);
            Color var33 = var30.isActive() ? this.primaryText() : var9;
            TextDriver.get().draw(var30.title, (int)(var24 + var10), (int)(var28 + 5.0F), new Color(var33.packed()), false);
            TextDriver.get()
               .draw(var31, (int)(var24 + var39 - (int)TextDriver.get().width(var31) - var10), (int)(var28 + 5.0F), new Color(var9.packed()), false);
            var28 += var14 + var15;
         }
      }
   }

   public String keyName(int var1) {
      if (var1 == -1) {
         return "None";
      } else {
         try {
            String var2 = GLFW.glfwGetKeyName(var1, 0);
            if (var2 != null) {
               return var2.substring(0, 1).toUpperCase() + var2.substring(1);
            }
         } catch (Exception var3) {
         }
         return switch (var1) {
            case 32 -> "Space";
            case 96 -> "Grave";
            case 256 -> "Esc";
            case 257 -> "Enter";
            case 258 -> "Tab";
            case 259 -> "Backspace";
            case 260 -> "Insert";
            case 261 -> "Delete";
            case 262 -> "Right";
            case 263 -> "Left";
            case 264 -> "Down";
            case 265 -> "Up";
            case 266 -> "PgUp";
            case 267 -> "PgDn";
            case 268 -> "Home";
            case 269 -> "End";
            case 280 -> "Caps";
            case 340 -> "LShift";
            case 341 -> "LCtrl";
            case 342 -> "LAlt";
            case 344 -> "RShift";
            case 345 -> "RCtrl";
            case 346 -> "RAlt";
            default -> var1 >= 290 && var1 <= 314 ? "F" + (var1 - 290 + 1) : "Key " + var1;
         };
      }
   }

   public class_2960 effectIcon(class_1293 var1) {
      Optional var2 = var1.method_5579().method_40230();
      class_2960 var3 = var2.<class_2960>map(var0 -> var0.method_29177()).orElse(null);
      return var3 == null ? null : class_2960.method_60655(var3.method_12836(), "mob_effect/" + var3.method_12832());
   }

   public String effectName(class_1293 var1) {
      String var2 = ((class_1291)var1.method_5579().comp_349()).method_5567();
      String var3 = class_2561.method_43471(var2).getString();
      int var4 = var1.method_5578();
      if (var4 > 0) {
         var3 = var3 + " " + this.roman(var4 + 1);
      }

      return var3;
   }

   public String effectDuration(class_1293 var1) {
      if (var1.method_48559()) {
         return "**:**";
      } else {
         int var2 = var1.method_5584();
         int var3 = var2 / 1200;
         int var4 = var2 % 1200 / 20;
         return var3 + ":" + String.format("%02d", var4);
      }
   }

   public String roman(int var1) {
      if (var1 >= 1 && var1 <= 10) {
         String[] var2 = new String[]{"I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
         return var2[var1 - 1];
      } else {
         return String.valueOf(var1);
      }
   }

   public void drawRadar(class_332 var1, int var2, int var3) {
      float var4 = ((Double)this.radarSize.get()).floatValue();
      float var5 = var4 * 2.0F;
      float var6 = var4 + 20.0F;
      float var7 = var4 + 120.0F;
      float var8 = this.positionX(this.radarPosition, var6 - var4);
      float var9 = this.positionY(this.radarPosition, var7 - var4);
      float var10 = var8 + var4;
      float var11 = var9 + var4;
      this.reportBounds("Radar", var8, var9, var5, var5);
      float var12 = ((Double)this.opacity.get()).floatValue() * 100.0F;
      Color var13 = new Color(0, 0, 0, 0);
      Color var14 = this.rainbow.get() ? Colors.rainbow(2, 255) : this.kryptonAccent();
      Color var15 = new Color(var14.getRed(), var14.getGreen(), var14.getBlue(), 100);
      GlassRect.draw(
         var1,
         var10 - var4 - 1.0F,
         var11 - var4 - 1.0F,
         var10 + var4 + 1.0F,
         var11 + var4 + 1.0F,
         var4 + 1.0F,
         var4 + 1.0F,
         var4 + 1.0F,
         var4 + 1.0F,
         var15,
         var13,
         var13,
         0.0,
         false
      );
      GlassRect.draw(
         var1, var10 - var4, var11 - var4, var10 + var4, var11 + var4, var4, var4, var4, var4, new Color(20, 20, 30, (int)var12), var13, var13, 0.0, true
      );
      float var16 = var4 * 0.85F;
      Color var17 = new Color(255, 255, 255, 50);
      Animations.fillRect((int)(var10 - var16), (int)var11, (int)(var10 + var16), (int)var11 + 1, var17.packed());
      Animations.fillRect((int)var10, (int)(var11 - var16), (int)var10 + 1, (int)(var11 + var16), var17.packed());

      for (int var18 = 1; var18 <= 2; var18++) {
         float var19 = (var4 - 10.0F) * var18 / 2.0F;
         GlassRect.draw(
            var1,
            var10 - var19,
            var11 - var19,
            var10 + var19,
            var11 + var19,
            var19,
            var19,
            var19,
            var19,
            new Color(255, 255, 255, 30),
            var13,
            var13,
            0.0,
            false
         );
      }

      Color var79 = new Color(255, 255, 255, 100);
      Color var80 = new Color(var14.getRed(), var14.getGreen(), var14.getBlue(), 200);
      float var20 = var4 - 14.0F;
      float var21 = this.mc.field_1724.method_36454();
      float var22 = (float)Math.toRadians(var21);
      float var23 = var10 + (float)(Math.sin(var22) * var20);
      float var24 = var11 + (float)(Math.cos(var22) * var20);
      String var25 = "N";
      float var26 = (int)TextDriver.get().width(var25);
      TextDriver.get().draw(var25, (int)(var23 - var26 / 2.0F), (int)(var24 - 4.0F), new Color(var80.packed()), false);
      float var27 = var22 + (float) Math.PI;
      float var28 = var10 + (float)(Math.sin(var27) * var20);
      float var29 = var11 + (float)(Math.cos(var27) * var20);
      String var30 = "S";
      float var31 = (int)TextDriver.get().width(var30);
      TextDriver.get().draw(var30, (int)(var28 - var31 / 2.0F), (int)(var29 - 4.0F), new Color(var79.packed()), false);
      float var32 = var22 - (float) (Math.PI / 2);
      float var33 = var10 + (float)(Math.sin(var32) * var20);
      float var34 = var11 + (float)(Math.cos(var32) * var20);
      String var35 = "E";
      float var36 = (int)TextDriver.get().width(var35);
      TextDriver.get().draw(var35, (int)(var33 - var36 / 2.0F), (int)(var34 - 4.0F), new Color(var79.packed()), false);
      float var37 = var22 + (float) (Math.PI / 2);
      float var38 = var10 + (float)(Math.sin(var37) * var20);
      float var39 = var11 + (float)(Math.cos(var37) * var20);
      String var40 = "W";
      float var41 = (int)TextDriver.get().width(var40);
      TextDriver.get().draw(var40, (int)(var38 - var41 / 2.0F), (int)(var39 - 4.0F), new Color(var79.packed()), false);
      HashSet var42 = new HashSet();
      if (this.mc.field_1687 != null) {
         for (class_1297 var44 : this.mc.field_1687.method_18112()) {
            if (var44 != this.mc.field_1724 && var44 instanceof class_1657 var45 && (Boolean)this.radarPlayers.get()) {
               class_243 var46 = this.mc.field_1724.method_73189();
               class_243 var47 = var44.method_73189();
               double var48 = var46.method_1022(var47);
               if (!(var48 > ((Double)this.radarRange.get()).floatValue())) {
                  double var50 = var47.field_1352 - var46.field_1352;
                  double var52 = var47.field_1350 - var46.field_1350;
                  double var54 = Math.toRadians(var21);
                  double var56 = var50 * Math.cos(var54) + var52 * Math.sin(var54);
                  double var58 = var52 * Math.cos(var54) - var50 * Math.sin(var54);
                  double var60 = (var4 - 15.0F) / ((Double)this.radarRange.get()).floatValue();
                  float var62 = (float)(var10 - var56 * var60);
                  float var63 = (float)(var11 - var58 * var60);
                  UUID var64 = var45.method_5667();
                  var42.add(var64);
                  float[] var65 = this.radarBlips.get(var64);
                  float var66;
                  float var67;
                  if (var65 != null) {
                     var66 = (float)MathUtil.lerp(0.15, var65[0], var62);
                     var67 = (float)MathUtil.lerp(0.15, var65[1], var63);
                  } else {
                     var66 = var62;
                     var67 = var63;
                  }

                  this.radarBlips.put(var64, new float[]{var66, var67});
                  double var68 = Math.pow(var66 - var10, 2.0) + Math.pow(var67 - var11, 2.0);
                  float var70 = (float)Math.sqrt(var68);
                  if (var70 <= var4 - 15.0F) {
                     float var71 = this.mc.method_22683().method_4495();
                     byte var72 = 7;
                     float var73 = var72 * var71 / 2.0F;
                     GlassRect.draw(
                        var1,
                        var66 - var73 - 2.0F,
                        var67 - var73 - 2.0F,
                        var66 + var73 + 2.0F,
                        var67 + var73 + 2.0F,
                        var73 + 2.0F,
                        var73 + 2.0F,
                        var73 + 2.0F,
                        var73 + 2.0F,
                        new Color(var14.getRed(), var14.getGreen(), var14.getBlue(), 70),
                        var13,
                        var13,
                        0.0,
                        false
                     );
                     GlassRect.draw(
                        var1,
                        var66 - var73,
                        var67 - var73,
                        var66 + var73,
                        var67 + var73,
                        2.0,
                        2.0,
                        2.0,
                        2.0,
                        new Color(10, 10, 15, 220),
                        var13,
                        var13,
                        0.0,
                        false
                     );
                     class_634 var74 = this.mc.method_1562();
                     class_640 var75 = var74.method_2871(var45.method_5667());
                     if (var75 != null) {
                        class_2960 var76 = var75.method_52810().comp_1626().comp_3627();
                        int var77 = Math.round((var66 - var73) / var71);
                        int var78 = Math.round((var67 - var73) / var71);
                        Renderer3D.worldSpace();
                        var1.method_25302(class_10799.field_56883, var76, var77, var78, 8.0F, 8.0F, var72, var72, 8, 8, 64, 64);
                        var1.method_25302(class_10799.field_56883, var76, var77, var78, 40.0F, 8.0F, var72, var72, 8, 8, 64, 64);
                        Renderer3D.screenSpace();
                     }
                  }
               }
            }
         }
      }

      Set var81 = this.radarBlips.keySet();
      var81.retainAll(var42);
      Color var82 = this.rainbow.get() ? Colors.rainbow(2, 255) : this.kryptonAccent();
      Color var83 = new Color(var82.getRed(), var82.getGreen(), var82.getBlue(), 120);
      GlassRect.draw(var1, var10 - 6.0F, var11 - 6.0F, var10 + 6.0F, var11 + 6.0F, 6.0, 6.0, 6.0, 6.0, var83, var13, var13, 0.0, false);
      GlassRect.draw(var1, var10 - 4.0F, var11 - 4.0F, var10 + 4.0F, var11 + 4.0F, 4.0, 4.0, 4.0, 4.0, var82, var13, var13, 0.0, false);
      float var84 = 6.0F;
      float var85 = var11 - var4 + 11.0F;
      int var86 = var82.packed();
      GlassRect.draw(
         var1,
         var10 - var84 - 1.0F,
         var85 - var84 - 2.0F,
         var10 + var84 + 2.0F,
         var85 + 2.0F,
         4.0,
         4.0,
         4.0,
         4.0,
         new Color(var82.getRed(), var82.getGreen(), var82.getBlue(), 40),
         var13,
         var13,
         0.0,
         false
      );

      for (int var49 = 0; var49 < var84; var49++) {
         Animations.fillRect((int)var10 - var49, (int)(var85 - var84 + var49), (int)var10 + var49 + 1, (int)(var85 - var84 + var49 + 1.0F), var86);
      }
   }

   public void drawModuleList(class_332 var1, int var2) {
      List var3 = this.sortedModules();
      float var4 = 8.0F;
      float var5 = 20.0F;
      float var6 = ((Double)this.opacity.get()).floatValue() * 255.0F;
      float var7 = 10.0F;
      HashSet var8 = new HashSet();

      for (Module var10 : var3) {
         var8.add(var10.title);
      }

      for (Module var35 : var3) {
         Hud.ModuleAnimation var11 = this.moduleAnimations.computeIfAbsent(var35.title, var0 -> new Hud.ModuleAnimation());
         var11.visible = true;
         var11.dead = false;
         var11.slide = MathUtil.frameLerp(var11.slide, 1.0F, var7);
         var11.alpha = MathUtil.frameLerp(var11.alpha, 1.0F, var7);
      }

      Iterator var34 = this.moduleAnimations.entrySet().iterator();

      while (var34.hasNext()) {
         Entry var36 = (Entry)var34.next();
         if (!var8.contains(var36.getKey())) {
            Hud.ModuleAnimation var38 = (Hud.ModuleAnimation)var36.getValue();
            var38.visible = false;
            var38.slide = MathUtil.frameLerp(var38.slide, 0.0F, var7);
            var38.alpha = MathUtil.frameLerp(var38.alpha, 0.0F, var7);
            if (var38.slide < 0.02F && var38.alpha < 0.02F) {
               var38.dead = true;
               var34.remove();
            }
         }
      }

      float var37 = 0.0F;

      for (Module var12 : var3) {
         var37 = Math.max(var37, (int)TextDriver.get().width(var12.title.toLowerCase()) + var4 * 2.0F);
      }

      float var40 = var3.isEmpty() ? 20.0F : var3.size() * (var5 + 2.0F);
      float var41 = this.positionX(this.modulesPosition, var2 - var37 - 8.0F);
      float var13 = this.positionY(this.modulesPosition, 8.0F);
      this.reportBounds("Modules", var41, var13, var37, var40);
      float var14 = var13;

      for (int var15 = 0; var15 < var3.size(); var15++) {
         Module var16 = (Module)var3.get(var15);
         String var17 = var16.title.toLowerCase();
         float var18 = (int)TextDriver.get().width(var17);
         Hud.ModuleAnimation var19 = this.moduleAnimations.get(var16.title);
         float var20 = var19 != null ? var19.slide : 1.0F;
         float var21 = var19 != null ? var19.alpha : 1.0F;
         float var22 = var41 + var37;
         float var23 = var22 - var18 - var4 * 2.0F;
         float var24 = (var37 + 10.0F) * (1.0F - var20);
         float var25 = var23 + var24;
         float var26 = var22 + var24;
         int var27 = (int)(var6 * var21);
         Color var28 = new Color(30, 30, 40, var27);
         Color var29 = new Color(0, 0, 0, 0);
         GlassRect.draw(var1, var25, var14, var26, var14 + var5, 3.0, 3.0, 3.0, 3.0, var28, var29, var29, 0.0, false);
         Color var30 = this.rainbow.get() ? Colors.rainbow(2 + var15 * 5, 255) : this.kryptonAccent();

         for (int var31 = 0; var31 < 3; var31++) {
            Color var32 = new Color(var30.getRed(), var30.getGreen(), var30.getBlue(), (int)((255 - var31 * 60) * var21));
            Animations.fillRect((int)var26 - 3 + var31, (int)var14, (int)var26 - 2 + var31, (int)(var14 + var5), var32.packed());
         }

         Color var42 = this.rainbow.get() ? Colors.rainbow(var15, 255) : this.primaryText();
         Color var43 = new Color(var42.r, var42.g, var42.b, (int)(var42.a * var21));
         TextDriver.get().draw(var17, (int)(var25 + var4), (int)var14 + 3, new Color(var43.packed()), false);
         var14 += var5 + 2.0F;
      }
   }

   public void drawNotifications(class_332 var1, int var2, int var3) {
      this.visibleNotifications.removeIf(var0 -> var0.isExpired());

      while (this.visibleNotifications.size() < 5 && !this.pendingNotifications.isEmpty()) {
         this.visibleNotifications.add(this.pendingNotifications.poll());
      }

      this.notificationBoundsCount = 0;
      if (!this.visibleNotifications.isEmpty()) {
         float var4 = 280.0F;
         float var5 = 65.0F;
         float var6 = 12.0F;
         Hud.NotificationCorner var7 = (Hud.NotificationCorner)this.notificationCorner.get();
         boolean var8 = var7 == Hud.NotificationCorner.TOP_RIGHT || var7 == Hud.NotificationCorner.BOTTOM_RIGHT;
         boolean var9 = var7 == Hud.NotificationCorner.BOTTOM_LEFT || var7 == Hud.NotificationCorner.BOTTOM_RIGHT;
         float var10 = 15.0F;
         float var11 = var8 ? var2 - var4 - var10 : var10;
         float var12 = var9 ? var3 - var5 - var10 : var10;
         int var13 = 0;

         for (Hud.Notification var15 : this.visibleNotifications) {
            var15.tick();
            float var16 = var15.fade();
            if (!(var16 <= 0.0F)) {
               float var17 = var15.slide();
               float var18 = (var4 + var10) * (1.0F - var17);
               float var19;
               if (var15.isCustom() && var15.severity() == null) {
                  var19 = (var2 - var4) / 2.0F;
               } else if (var8) {
                  var19 = var11 + var18;
               } else {
                  var19 = var11 - var18;
               }

               float var20 = var9 ? var12 - var13 * (var5 + var6) : var12 + var13 * (var5 + var6);
               this.drawNotification(var1, var15, var19, var20, var4, var5, var16);
               if (var13 < 5) {
                  this.notificationBounds[var13 * 4] = var19;
                  this.notificationBounds[var13 * 4 + 1] = var20;
                  this.notificationBounds[var13 * 4 + 2] = var4;
                  this.notificationBounds[var13 * 4 + 3] = var5;
               }

               var13++;
            }
         }

         this.notificationBoundsCount = var13;
      }
   }

   public void drawNotification(class_332 var1, Hud.Notification var2, float var3, float var4, float var5, float var6, float var7) {
      float var8 = 8.0F;
      Color var9 = new Color(18, 18, 22, (int)(200.0F * var7));
      Color var10 = new Color(0, 0, 0, 0);
      GlassRect.draw(var1, var3, var4, var3 + var5, var4 + var6, var8, var8, var8, var8, var9, var10, var10, 0.0, true);
      float var11 = var3 + 35.0F;
      float var12 = var4 + var6 / 2.0F;
      float var13 = 18.0F;
      Color var14 = var2.badgeColor(var7);
      GlassRect.draw(var1, var11 - var13, var12 - var13, var11 + var13, var12 + var13, var13, var13, var13, var13, var14, var10, var10, 0.0, false);
      class_1799 var15 = var2.icon();
      double var16 = this.mc.method_22683().method_4495();
      int var18 = (int)Math.round(var11 / var16 - 8.0);
      int var19 = (int)Math.round(var12 / var16 - 8.0);
      Renderer3D.worldSpace();
      var1.method_51427(var15, var18, var19);
      Renderer3D.screenSpace();
      float var20 = var5 - 16.0F;
      float var21 = 3.0F;
      float var22 = var3 + 8.0F;
      float var23 = var4 + var6 - var21 - 4.0F;
      Color var24 = new Color(30, 30, 35, (int)(150.0F * var7));
      Animations.fillRect((int)var22, (int)var23, (int)(var22 + var20), (int)(var23 + var21), var24.packed());
      float var25 = var2.progress();
      float var26 = var20 * var25;
      Color var27 = var2.barColor(var7);
      if (var26 > 0.0F) {
         Animations.fillRect((int)var22, (int)var23, (int)(var22 + var26), (int)(var23 + var21), var27.packed());
      }

      Color var28 = new Color(this.primaryText().r, this.primaryText().g, this.primaryText().b, (int)(255.0F * var7));
      Matrix3x2fStack var29 = var1.method_51448();
      var29.pushMatrix();
      float var30 = 1.1F;
      int var31 = (int)(var3 + 68.0F);
      int var32 = (int)(var4 + 14.0F);
      var29.translate(var31, var32);
      var29.scale(var30, var30);
      var29.translate(-var31, -var32);
      TextDriver.get().draw(var2.title(), var31, var32, new Color(var28.packed()), false);
      var29.popMatrix();
      String var33 = var2.subtitle();
      Color var34 = new Color(this.secondaryText().r, this.secondaryText().g, this.secondaryText().b, (int)(220.0F * var7));
      Matrix3x2fStack var35 = var1.method_51448();
      var35.pushMatrix();
      float var36 = 0.85F;
      int var37 = (int)(var3 + 68.0F);
      int var38 = (int)(var4 + 36.0F);
      var35.translate(var37, var38);
      var35.scale(var36, var36);
      var35.translate(-var37, -var38);
      TextDriver.get().draw(var33, var37, var38, new Color(var34.packed()), false);
      var35.popMatrix();
   }

   @EventHandler
   public void onMouseClick(MouseClickEvent var1) {
      if (this.isActive() && (Boolean)this.notifications.get()) {
         if (var1.action != KeyAction.Press) {
            return;
         }

         if (var1.click.method_74245() != 0) {
            return;
         }

         if (this.mc.field_1755 instanceof WidgetScreen) {
            return;
         }

         double var2 = this.mc.method_22683().method_4495();
         float var4 = (float)(var1.click.comp_4798() * var2);
         float var5 = (float)(var1.click.comp_4799() * var2);
         int var6 = Math.min(this.notificationBoundsCount, this.visibleNotifications.size());

         for (int var7 = 0; var7 < var6; var7++) {
            float var8 = this.notificationBounds[var7 * 4];
            float var9 = this.notificationBounds[var7 * 4 + 1];
            float var10 = this.notificationBounds[var7 * 4 + 2];
            float var11 = this.notificationBounds[var7 * 4 + 3];
            if (var4 >= var8 && var4 <= var8 + var10 && var5 >= var9 && var5 <= var9 + var11) {
               this.visibleNotifications.get(var7).dismiss();
               var1.cancel();
               return;
            }
         }
      }
   }

   public List<Module> sortedModules() {
      List var1 = Modules.get().getAll().stream().filter(Module::isActive).toList();

      return switch ((Hud.SortMode)this.sortMode.get()) {
         case LENGTH -> var1.stream()
            .sorted((var0, var1x) -> Integer.compare((int)TextDriver.get().width(var1x.title), (int)TextDriver.get().width(var0.title)))
            .toList();
         case ALPHABETICAL -> var1.stream().sorted(Comparator.comparing(var0 -> var0.title)).toList();
         case CATEGORY -> var1.stream().sorted(Comparator.<Module, String>comparing(var0 -> var0.category.name).thenComparing(var0 -> var0.title)).toList();
      };
   }

   public String ping() {
      if (this.mc != null && this.mc.field_1724 != null && this.mc.method_1562() != null) {
         class_640 var1 = this.mc.method_1562().method_2871(this.mc.field_1724.method_5667());
         if (var1 != null) {
            return String.valueOf(var1.method_2959());
         }
      }

      return "0";
   }

   public static class ModuleAnimation {
      public float slide = 0.0F;
      public float alpha = 0.0F;
      public boolean visible = false;
      public boolean dead = false;
   }

   public static class Notification {
      public final Hud hud;
      public String moduleName;
      public boolean enabled;
      public String category;
      public long createdAt;
      public float slideProgress;
      public boolean dismissed;
      public String customTitle;
      public String customSubtitle;
      public class_1799 customIcon;
      public Color customColor;
      public long customDuration;
      public Hud.Severity severity;

      public Notification(Hud var1, String var2, boolean var3, String var4) {
         this.hud = var1;
         this.slideProgress = 0.0F;
         this.dismissed = false;
         this.moduleName = var2;
         this.enabled = var3;
         this.category = var4;
         this.createdAt = System.currentTimeMillis();
         this.customTitle = null;
         this.customSubtitle = null;
         this.customIcon = null;
         this.customColor = null;
         this.customDuration = 0L;
         this.severity = null;
      }

      public Notification(Hud var1, String var2, String var3, class_1799 var4, Color var5, long var6) {
         this.hud = var1;
         this.slideProgress = 0.0F;
         this.dismissed = false;
         this.moduleName = null;
         this.enabled = true;
         this.category = null;
         this.createdAt = System.currentTimeMillis();
         this.customTitle = var2;
         this.customSubtitle = var3;
         this.customIcon = var4;
         this.customColor = var5;
         this.customDuration = var6;
         this.severity = null;
      }

      public Notification(Hud var1, Hud.Severity var2, String var3, String var4, class_1799 var5, long var6) {
         this.hud = var1;
         this.slideProgress = 0.0F;
         this.dismissed = false;
         this.moduleName = null;
         this.enabled = true;
         this.category = null;
         this.createdAt = System.currentTimeMillis();
         this.customTitle = var3;
         this.customSubtitle = var4;
         this.customIcon = var5;
         this.customColor = var2 != null ? var2.copyColor() : null;
         this.customDuration = var6;
         this.severity = var2;
      }

      public Hud.Severity severity() {
         return this.severity;
      }

      public void dismiss() {
         this.dismissed = true;
      }

      public boolean isCustom() {
         return this.customTitle != null;
      }

      public long duration() {
         return this.isCustom() ? this.customDuration : ((Double)this.hud.notificationDuration.get()).intValue();
      }

      public String title() {
         return this.isCustom() ? this.customTitle : this.moduleName;
      }

      public String subtitle() {
         if (this.isCustom()) {
            return this.customSubtitle;
         } else {
            return this.enabled ? "Has been enabled." : "Has been disabled.";
         }
      }

      public class_1799 icon() {
         if (this.isCustom()) {
            return this.customIcon;
         } else {
            String var1 = this.category == null ? "" : this.category;

            return switch (var1) {
               case "Combat" -> new class_1799(class_1802.field_22022);
               case "Misc" -> new class_1799(class_1802.field_8619);
               case "Render" -> new class_1799(class_1802.field_8449);
               case "Player" -> new class_1799(class_1802.field_8137);
               case "Movement" -> new class_1799(class_1802.field_17532);
               default -> new class_1799(class_1802.field_8106);
            };
         }
      }

      public Color badgeColor(float var1) {
         if (this.isCustom()) {
            return new Color(50, 55, 60, (int)(220.0F * var1));
         } else {
            return this.enabled ? new Color(50, 55, 60, (int)(220.0F * var1)) : new Color(55, 45, 45, (int)(220.0F * var1));
         }
      }

      public Color barColor(float var1) {
         if (this.isCustom()) {
            return new Color(this.customColor.getRed(), this.customColor.getGreen(), this.customColor.getBlue(), (int)(255.0F * var1));
         } else {
            return this.enabled ? new Color(40, 200, 80, (int)(255.0F * var1)) : new Color(240, 70, 70, (int)(255.0F * var1));
         }
      }

      public void tick() {
         long var1 = System.currentTimeMillis() - this.createdAt;
         long var3 = this.duration();
         if (var1 < 300L) {
            this.slideProgress = MathUtil.frameLerp(this.slideProgress, 1.0F, 20.0F);
         } else if (var1 < var3 - 300L) {
            this.slideProgress = 1.0F;
         } else {
            this.slideProgress = MathUtil.frameLerp(this.slideProgress, 0.0F, 20.0F);
         }
      }

      public float fade() {
         long var1 = System.currentTimeMillis() - this.createdAt;
         long var3 = this.duration();
         if (var1 < 200L) {
            return (float)var1 / 200.0F;
         } else {
            return var1 > var3 - 200L ? 1.0F - (float)(var1 - (var3 - 200L)) / 200.0F : 1.0F;
         }
      }

      public float slide() {
         return this.slideProgress;
      }

      public float progress() {
         long var1 = System.currentTimeMillis() - this.createdAt;
         long var3 = this.duration();
         return Math.max(0.0F, Math.min(1.0F, 1.0F - (float)var1 / (float)var3));
      }

      public boolean isExpired() {
         return this.dismissed || System.currentTimeMillis() - this.createdAt > this.duration();
      }

      public boolean contains(float var1, float var2, float var3, float var4, float var5, float var6) {
         return var1 >= var3 && var1 <= var3 + var5 && var2 >= var4 && var2 <= var4 + var6;
      }
   }

   public static enum NotificationCorner {
      TOP_LEFT("Top Left"),
      TOP_RIGHT("Top Right"),
      BOTTOM_LEFT("Bottom Left"),
      BOTTOM_RIGHT("Bottom Right");

      public String displayName;

      private NotificationCorner(String nullxx) {
         this.displayName = nullxx;
      }

      @Override
      public String toString() {
         return this.displayName;
      }
   }

   public static enum Severity {
      INFO("Info", new Color(120, 170, 255, 255), class_1802.field_8407, (class_3414)class_3417.field_15204.comp_349()),
      SUCCESS("Success", new Color(90, 210, 120, 255), class_1802.field_8687, (class_3414)class_3417.field_14793.comp_349()),
      WARN("Warning", new Color(245, 200, 80, 255), class_1802.field_8601, (class_3414)class_3417.field_14624.comp_349()),
      ERROR("Error", new Color(240, 90, 90, 255), class_1802.field_8077, class_3417.field_14833);

      public String label;
      public Color color;
      public class_1792 item;
      public class_3414 sound;

      private Severity(String nullxx, Color nullxxx, class_1792 nullxxxx, class_3414 nullxxxxx) {
         this.label = nullxx;
         this.color = nullxxx;
         this.item = nullxxxx;
         this.sound = nullxxxxx;
      }

      public String label() {
         return this.label;
      }

      public Color copyColor() {
         return new Color(this.color.r, this.color.g, this.color.b, this.color.a);
      }

      public class_1799 stack() {
         return new class_1799(this.item);
      }

      public class_3414 sound() {
         return this.sound;
      }
   }

   public static enum SortMode {
      LENGTH("Length"),
      ALPHABETICAL("Alphabetical"),
      CATEGORY("Category");

      public String name;

      private SortMode(String nullxx) {
         this.name = nullxx;
      }

      @Override
      public String toString() {
         return this.name;
      }
   }
}
