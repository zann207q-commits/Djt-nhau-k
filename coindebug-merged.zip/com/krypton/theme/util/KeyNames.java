package com.krypton.theme.util;

import net.minecraft.class_310;
import org.apache.commons.lang3.StringUtils;
import org.lwjgl.glfw.GLFW;

public class KeyNames {
   public static String get(int key) {
      switch (key) {
         case -1:
            return "Unknown";
         case 0:
            return "LMB";
         case 1:
            return "RMB";
         case 2:
            return "MMB";
         case 3:
            return "Mouse 4";
         case 4:
            return "Mouse 5";
         case 5:
            return "Mouse 6";
         case 6:
            return "Mouse 7";
         case 7:
            return "Mouse 8";
         case 8:
         case 9:
         case 10:
         case 11:
         case 12:
         case 13:
         case 14:
         case 15:
         case 16:
         case 17:
         case 18:
         case 19:
         case 20:
         case 21:
         case 22:
         case 23:
         case 24:
         case 25:
         case 26:
         case 27:
         case 28:
         case 29:
         case 30:
         case 31:
         case 33:
         case 34:
         case 35:
         case 36:
         case 37:
         case 38:
         case 40:
         case 41:
         case 42:
         case 43:
         case 45:
         case 46:
         case 47:
         case 48:
         case 49:
         case 50:
         case 51:
         case 52:
         case 53:
         case 54:
         case 55:
         case 56:
         case 57:
         case 58:
         case 60:
         case 62:
         case 63:
         case 64:
         case 65:
         case 66:
         case 67:
         case 68:
         case 69:
         case 70:
         case 71:
         case 72:
         case 73:
         case 74:
         case 75:
         case 76:
         case 77:
         case 78:
         case 79:
         case 80:
         case 81:
         case 82:
         case 83:
         case 84:
         case 85:
         case 86:
         case 87:
         case 88:
         case 89:
         case 90:
         case 94:
         case 95:
         case 97:
         case 98:
         case 99:
         case 100:
         case 101:
         case 102:
         case 103:
         case 104:
         case 105:
         case 106:
         case 107:
         case 108:
         case 109:
         case 110:
         case 111:
         case 112:
         case 113:
         case 114:
         case 115:
         case 116:
         case 117:
         case 118:
         case 119:
         case 120:
         case 121:
         case 122:
         case 123:
         case 124:
         case 125:
         case 126:
         case 127:
         case 128:
         case 129:
         case 130:
         case 131:
         case 132:
         case 133:
         case 134:
         case 135:
         case 136:
         case 137:
         case 138:
         case 139:
         case 140:
         case 141:
         case 142:
         case 143:
         case 144:
         case 145:
         case 146:
         case 147:
         case 148:
         case 149:
         case 150:
         case 151:
         case 152:
         case 153:
         case 154:
         case 155:
         case 156:
         case 157:
         case 158:
         case 159:
         case 160:
         case 163:
         case 164:
         case 165:
         case 166:
         case 167:
         case 168:
         case 169:
         case 170:
         case 171:
         case 172:
         case 173:
         case 174:
         case 175:
         case 176:
         case 177:
         case 178:
         case 179:
         case 180:
         case 181:
         case 182:
         case 183:
         case 184:
         case 185:
         case 186:
         case 187:
         case 188:
         case 189:
         case 190:
         case 191:
         case 192:
         case 193:
         case 194:
         case 195:
         case 196:
         case 197:
         case 198:
         case 199:
         case 200:
         case 201:
         case 202:
         case 203:
         case 204:
         case 205:
         case 206:
         case 207:
         case 208:
         case 209:
         case 210:
         case 211:
         case 212:
         case 213:
         case 214:
         case 215:
         case 216:
         case 217:
         case 218:
         case 219:
         case 220:
         case 221:
         case 222:
         case 223:
         case 224:
         case 225:
         case 226:
         case 227:
         case 228:
         case 229:
         case 230:
         case 231:
         case 232:
         case 233:
         case 234:
         case 235:
         case 236:
         case 237:
         case 238:
         case 239:
         case 240:
         case 241:
         case 242:
         case 243:
         case 244:
         case 245:
         case 246:
         case 247:
         case 248:
         case 249:
         case 250:
         case 251:
         case 252:
         case 253:
         case 254:
         case 255:
         case 270:
         case 271:
         case 272:
         case 273:
         case 274:
         case 275:
         case 276:
         case 277:
         case 278:
         case 279:
         case 285:
         case 286:
         case 287:
         case 288:
         case 289:
         case 315:
         case 316:
         case 317:
         case 318:
         case 319:
         case 320:
         case 321:
         case 322:
         case 323:
         case 324:
         case 325:
         case 326:
         case 327:
         case 328:
         case 329:
         case 330:
         case 331:
         case 332:
         case 333:
         case 334:
         case 336:
         case 337:
         case 338:
         case 339:
         default:
            String name = GLFW.glfwGetKeyName(key, 0);
            if (name == null) {
               return "None";
            }

            return StringUtils.capitalize(name);
         case 32:
            return "Space";
         case 39:
            return "Apostrophe";
         case 44:
            return "Comma";
         case 59:
            return "Semicolon";
         case 61:
            return "Equals";
         case 91:
            return "Left Bracket";
         case 92:
            return "Backslash";
         case 93:
            return "Right Bracket";
         case 96:
            return "Grave Accent";
         case 161:
            return "World 1";
         case 162:
            return "World 2";
         case 256:
            return "Esc";
         case 257:
            return "Enter";
         case 258:
            return "Tab";
         case 259:
            return "Backspace";
         case 260:
            return "Insert";
         case 261:
            return "Delete";
         case 262:
            return "Arrow Right";
         case 263:
            return "Arrow Left";
         case 264:
            return "Arrow Down";
         case 265:
            return "Arrow Up";
         case 266:
            return "Page Up";
         case 267:
            return "Page Down";
         case 268:
            return "Home";
         case 269:
            return "End";
         case 280:
            return "Caps Lock";
         case 281:
            return "Scroll Lock";
         case 282:
            return "Num Lock";
         case 283:
            return "Print Screen";
         case 284:
            return "Pause";
         case 290:
            return "F1";
         case 291:
            return "F2";
         case 292:
            return "F3";
         case 293:
            return "F4";
         case 294:
            return "F5";
         case 295:
            return "F6";
         case 296:
            return "F7";
         case 297:
            return "F8";
         case 298:
            return "F9";
         case 299:
            return "F10";
         case 300:
            return "F11";
         case 301:
            return "F12";
         case 302:
            return "F13";
         case 303:
            return "F14";
         case 304:
            return "F15";
         case 305:
            return "F16";
         case 306:
            return "F17";
         case 307:
            return "F18";
         case 308:
            return "F19";
         case 309:
            return "F20";
         case 310:
            return "F21";
         case 311:
            return "F22";
         case 312:
            return "F23";
         case 313:
            return "F24";
         case 314:
            return "F25";
         case 335:
            return "Numpad Enter";
         case 340:
            return "Left Shift";
         case 341:
            return "Left Control";
         case 342:
            return "Left Alt";
         case 343:
            return "Left Super";
         case 344:
            return "Right Shift";
         case 345:
            return "Right Control";
         case 346:
            return "Right Alt";
         case 347:
            return "Right Super";
         case 348:
            return "Menu";
      }
   }

   public static boolean isPressed(int key) {
      return key <= 8
         ? GLFW.glfwGetMouseButton(class_310.method_1551().method_22683().method_4490(), key) == 1
         : GLFW.glfwGetKey(class_310.method_1551().method_22683().method_4490(), key) == 1;
   }

   public static void setSneaking(boolean pressed) {
      class_310.method_1551()
         .field_1690
         .field_1832
         .method_23481(
            class_310.method_1551().field_1690.method_42449().method_41753() ? class_310.method_1551().field_1690.field_1832.method_1434() != pressed : pressed
         );
   }
}
