package com.krypton.theme.util;

import net.minecraft.class_243;
import net.minecraft.class_310;
import org.joml.Vector3d;

public class MathUtil {
   public static double roundToMultiple(double value, double multiple) {
      return multiple * Math.round(value / multiple);
   }

   public static double stepTowards(float t, double from, double to) {
      double delta = to - from;
      int step = (int)Math.ceil(Math.abs(delta) * t);
      return from < to ? Math.min(from + step, to) : Math.max(from - step, to);
   }

   public static double lerp(double t, double from, double to) {
      return from + (to - from) * t;
   }

   public static double smoothLerp(double t, double from, double to) {
      double s = clamp(t, 0.0, 1.0);
      s = s * s * (3.0 - 2.0 * s);
      return from + (to - from) * s;
   }

   public static double damp(double from, double to, double factor, double exponent) {
      return lerp(1.0F - (float)Math.pow(factor, exponent), from, to);
   }

   public static double clamp(double value, double min, double max) {
      return Math.max(min, Math.min(value, max));
   }

   public static int clamp(int value, int min, int max) {
      return Math.max(min, Math.min(value, max));
   }

   public static float frameLerp(float from, float to, float speed) {
      double t1 = (float)(frameDelta() * speed);
      double a = (1.0 - clamp(t1, 0.0, 1.0)) * from;
      double t2 = (float)(frameDelta() * speed);
      return (float)(a + clamp(t2, 0.0, 1.0) * to);
   }

   public static double frameDelta() {
      class_310 mc = class_310.method_1551();
      if (mc.method_47599() > 0) {
         mc = class_310.method_1551();
         return 1.0 / mc.method_47599();
      } else {
         return 1.0;
      }
   }

   public static double parseSuffixed(String text) {
      if (text != null && !text.isEmpty()) {
         String value = text.replace(",", "").trim().toUpperCase();
         double multiplier = 1.0;
         if (value.endsWith("T")) {
            multiplier = 1.0E12;
            value = value.substring(0, value.length() - 1);
         } else if (value.endsWith("B")) {
            multiplier = 1.0E9;
            value = value.substring(0, value.length() - 1);
         } else if (value.endsWith("M")) {
            multiplier = 1000000.0;
            value = value.substring(0, value.length() - 1);
         } else if (value.endsWith("K")) {
            multiplier = 1000.0;
            value = value.substring(0, value.length() - 1);
         }

         try {
            return Double.parseDouble(value) * multiplier;
         } catch (NumberFormatException var5) {
            return -1.0;
         }
      } else {
         return -1.0;
      }
   }

   public static Vector3d copyInto(Vector3d dest, class_243 src) {
      dest.x = src.field_1352;
      dest.y = src.field_1351;
      dest.z = src.field_1350;
      return dest;
   }
}
