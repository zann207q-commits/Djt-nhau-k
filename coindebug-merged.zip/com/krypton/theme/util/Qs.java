package com.krypton.theme.util;

public interface Qs {
   boolean yrn();

   void wlr();
}
