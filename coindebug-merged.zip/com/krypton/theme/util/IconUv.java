package com.krypton.theme.util;

public class IconUv {
   public double u0;
   public double v0;
   public double u1;
   public double v1;
   public double diagonal;

   public IconUv(double width, double height) {
      this.diagonal = Math.sqrt(width * width + height * height);
   }
}
