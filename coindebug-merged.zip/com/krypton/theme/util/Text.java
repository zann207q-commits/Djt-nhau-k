package com.krypton.theme.util;

import com.krypton.theme.gui.Animations;
import com.mojang.blaze3d.platform.TextureUtil;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.TextureFormat;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.util.HashMap;
import java.util.Map;
import org.lwjgl.stb.STBImage;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;

public class Text {
   public static String ATLAS_PNG = "assets/krypton/icon_atlas.png";
   public static String ATLAS_INDEX = "assets/krypton/icon_atlas.txt";
   public static Map<String, IconUv> icons = new HashMap<>();
   public static IconTexture atlas;
   public static boolean loaded = false;

   public static void init() {
      if (!loaded) {
         loaded = true;

         try {
            loadIndex();
            loadTexture();
         } catch (Exception var1) {
            var1.printStackTrace();
         }
      }
   }

   public static void loadIndex() throws Exception {
      InputStream stream = Text.class.getClassLoader().getResourceAsStream("assets/krypton/icon_atlas.txt");
      if (stream == null) {
         throw new RuntimeException("Missing assets/krypton/icon_atlas.txt");
      } else {
         String line;
         try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream))) {
            while ((line = reader.readLine()) != null) {
               line = line.trim();
               if (!line.isEmpty() && !line.startsWith("#")) {
                  String[] parts = line.split(",");
                  String name = parts[0];
                  int x = Integer.parseInt(parts[1]);
                  int y = Integer.parseInt(parts[2]);
                  int width = Integer.parseInt(parts[3]);
                  int height = Integer.parseInt(parts[4]);
                  IconUv uv = new IconUv(1.0, 1.0);
                  uv.u0 = (double)x / width;
                  uv.v0 = (double)y / height;
                  uv.u1 = (double)(x + 1) / width;
                  uv.v1 = (double)(y + 1) / height;
                  icons.put(name, uv);
               }
            }
         }
      }
   }

   public static void loadTexture() throws Exception {
      InputStream stream = Text.class.getClassLoader().getResourceAsStream("assets/krypton/icon_atlas.png");
      if (stream == null) {
         throw new RuntimeException("Missing assets/krypton/icon_atlas.png");
      } else {
         ByteBuffer encoded = TextureUtil.readResource(stream);
         encoded.rewind();
         MemoryStack stack = MemoryStack.stackPush();

         try {
            IntBuffer width = stack.mallocInt(1);
            IntBuffer height = stack.mallocInt(1);
            IntBuffer channels = stack.mallocInt(1);
            ByteBuffer pixels = STBImage.stbi_load_from_memory(encoded, width, height, channels, 4);
            if (pixels == null) {
               throw new RuntimeException("Failed to decode icon atlas: " + STBImage.stbi_failure_reason());
            }

            atlas = new IconTexture(width.get(0), height.get(0), TextureFormat.RGBA8, FilterMode.LINEAR, FilterMode.LINEAR);
            atlas.upload(pixels);
            STBImage.stbi_image_free(pixels);
         } catch (Throwable var8) {
            if (stack != null) {
               try {
                  stack.close();
               } catch (Throwable var7) {
                  var8.addSuppressed(var7);
               }
            }

            throw var8;
         }

         if (stack != null) {
            stack.close();
         }

         MemoryUtil.memFree(encoded);
      }
   }

   public static void drawIcon(String name, double x, double y, double size, Color color) {
      if (atlas != null) {
         IconUv uv = icons.get(name);
         if (uv != null) {
            boolean wasBatching = Animations.SHAPES.isBatching();
            if (wasBatching) {
               Animations.SHAPES.endBatch();
            }

            Animations.TEXTURED.beginMeshes();
            Animations.TEXTURED.texturedQuad(x, y, size, size, uv, color);
            Animations.TEXTURED.drawWithTexture(atlas.method_71659(), atlas.method_75484());
            if (wasBatching) {
               Animations.SHAPES.beginBatch();
            }
         }
      }
   }

   public static boolean has(String name) {
      return icons.containsKey(name);
   }
}
