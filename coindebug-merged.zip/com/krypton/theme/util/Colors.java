package com.krypton.theme.util;

import com.krypton.theme.modules.render.Hud;
import meteordevelopment.meteorclient.systems.modules.Modules;

public class Colors {
   private static Hud hud() {
      return (Hud)Modules.get().get(Hud.class);
   }

   public static Color accent(int alpha, int index) {
      Color base = hud().kryptonAccent();
      int r = base.r;
      int g = base.g;
      int b = base.b;
      return hud().rainbow.get() ? rainbow(index, alpha) : new Color(r, g, b, alpha);
   }

   public static Color rainbow(int index, int alpha) {
      Color color = Color.fromHsb((float)((System.currentTimeMillis() * 3L + index * 175) % 7200L) / 7200.0F, 0.6F, 1.0F);
      return new Color(color.r, color.g, color.b, alpha);
   }

   public static Color breathe(Color color, int index, int count) {
      float[] hsb = new float[3];
      Color.rgbToHsb(color.r, color.g, color.b, hsb);
      float phase = Math.abs(((float)(System.currentTimeMillis() % 2000L) / 1000.0F + (float)index / count * 2.0F) % 2.0F - 1.0F);
      hsb[2] = 0.25F + 0.75F * phase % 2.0F;
      int argb = Color.hsbToArgb(hsb[0], hsb[1], hsb[2]);
      return new Color(argb >> 16 & 0xFF, argb >> 8 & 0xFF, argb & 0xFF, color.a);
   }

   public static Color approach(float speed, Color target, Color current) {
      return new Color(
         (int)MathUtil.stepTowards(speed, current.r, target.r),
         (int)MathUtil.stepTowards(speed, current.g, target.g),
         (int)MathUtil.stepTowards(speed, current.b, target.b)
      );
   }

   public static Color approachAlpha(float speed, int targetAlpha, Color current) {
      return new Color(current.r, current.g, current.b, (int)MathUtil.stepTowards(speed, current.a, targetAlpha));
   }

   public static Color lerp(Color from, Color to, float t) {
      int r = clamp(Math.round(from.r + t * (to.r - from.r)), 0, 255);
      int g = clamp(Math.round(from.g + t * (to.g - from.g)), 0, 255);
      int b = clamp(Math.round(from.b + t * (to.b - from.b)), 0, 255);
      int a = clamp(Math.round(from.a + t * (to.a - from.a)), 0, 255);
      return new Color(r, g, b, a);
   }

   public static int clamp(int value, int min, int max) {
      return Math.max(min, Math.min(max, value));
   }

   public static int lerpPacked(int from, int to, float t) {
      int fromA = from >> 24 & 0xFF;
      int toA = to >> 24 & 0xFF;
      int fromR = from >> 16 & 0xFF;
      int toR = to >> 16 & 0xFF;
      int fromG = from >> 8 & 0xFF;
      int toG = to >> 8 & 0xFF;
      int fromB = from & 0xFF;
      int toB = to & 0xFF;
      int a = clamp(Math.round(fromA + t * (toA - fromA)), 0, 255);
      int r = clamp(Math.round(fromR + t * (toR - fromR)), 0, 255);
      int g = clamp(Math.round(fromG + t * (toG - fromG)), 0, 255);
      int b = clamp(Math.round(fromB + t * (toB - fromB)), 0, 255);
      return a << 24 | r << 16 | g << 8 | b;
   }
}
