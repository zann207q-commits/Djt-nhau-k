package com.krypton.theme.util;

public interface Tw {
   boolean ei();

   void gx(boolean var1);
}
