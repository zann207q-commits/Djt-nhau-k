package com.krypton.theme.util;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.AddressMode;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.TextureFormat;
import java.nio.ByteBuffer;
import net.minecraft.class_1011;
import net.minecraft.class_1044;
import net.minecraft.class_1011.class_1012;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.BufferUtils;
import org.lwjgl.system.MemoryUtil;

public class IconTexture extends class_1044 {
   public IconTexture(int width, int height, TextureFormat format, FilterMode minFilter, FilterMode magFilter) {
      this.field_56974 = RenderSystem.getDevice().createTexture("", 15, format, width, height, 1, 1);
      this.field_63613 = RenderSystem.getSamplerCache().method_75293(AddressMode.REPEAT, AddressMode.REPEAT, minFilter, magFilter, false);
      this.field_60597 = RenderSystem.getDevice().createTextureView(this.field_56974);
   }

   public int getWidth() {
      return this.method_68004().getWidth(0);
   }

   public int getHeight() {
      return this.method_68004().getHeight(0);
   }

   public void upload(byte[] bytes) {
      this.upload(BufferUtils.createByteBuffer(bytes.length).put(bytes));
   }

   public void upload(ByteBuffer buffer) {
      class_1011 image = this.createImage();
      buffer.rewind();
      MemoryUtil.memCopy(MemoryUtil.memAddress(buffer), image.method_67769(), buffer.remaining());
      RenderSystem.getDevice().createCommandEncoder().writeToTexture(this.field_56974, image);
      image.close();
   }

   @NotNull
   public class_1011 createImage() {
      class_1012 format = switch (this.field_56974.getFormat()) {
         case RGBA8 -> class_1012.field_4997;
         case RED8 -> class_1012.field_4998;
         default -> throw new IllegalArgumentException();
      };
      return new class_1011(format, this.getWidth(), this.getHeight(), false);
   }
}
