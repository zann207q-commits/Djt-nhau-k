package com.krypton.theme.util;

import com.krypton.theme.mixin.CountPlacementModifierAccessor;
import com.krypton.theme.mixin.HeightRangePlacementModifierAccessor;
import com.krypton.theme.mixin.RarityFilterPlacementModifierAccessor;
import com.krypton.theme.settings.OreEntry;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_1959;
import net.minecraft.class_2246;
import net.minecraft.class_2794;
import net.minecraft.class_2975;
import net.minecraft.class_3124;
import net.minecraft.class_5317;
import net.minecraft.class_5321;
import net.minecraft.class_5363;
import net.minecraft.class_5539;
import net.minecraft.class_5868;
import net.minecraft.class_5875;
import net.minecraft.class_6016;
import net.minecraft.class_6017;
import net.minecraft.class_6122;
import net.minecraft.class_6793;
import net.minecraft.class_6795;
import net.minecraft.class_6796;
import net.minecraft.class_6797;
import net.minecraft.class_6799;
import net.minecraft.class_6816;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_7145;
import net.minecraft.class_7510;
import net.minecraft.class_7887;
import net.minecraft.class_7924;
import net.minecraft.class_7225.class_7226;
import net.minecraft.class_7225.class_7874;
import net.minecraft.class_7510.class_6827;

public class OrePlacement {
   public static List<OreEntry> TABLE = Arrays.asList(
      new OreEntry("Coal Ore", new Color(47, 44, 54), class_2246.field_10418),
      new OreEntry("Iron Ore", new Color(236, 173, 119), class_2246.field_10212),
      new OreEntry("Gold Ore", new Color(247, 229, 30), class_2246.field_10571),
      new OreEntry("Diamond Ore", new Color(33, 244, 255), class_2246.field_10442),
      new OreEntry("Emerald Ore", new Color(27, 209, 45), class_2246.field_10013),
      new OreEntry("Lapis Ore", new Color(8, 26, 189), class_2246.field_10090),
      new OreEntry("Redstone Ore", new Color(245, 7, 23), class_2246.field_10080),
      new OreEntry("Copper Ore", new Color(239, 151, 0), class_2246.field_27120),
      new OreEntry("Nether Gold Ore", new Color(255, 200, 0), class_2246.field_23077),
      new OreEntry("Ancient Debris", new Color(130, 98, 83), class_2246.field_22109),
      new OreEntry("Nether Quartz Ore", new Color(230, 225, 215), class_2246.field_10213)
   );
   public int step;
   public int index;
   public class_6017 count = class_6016.method_34998(1);
   public class_6122 height;
   public class_5868 heightContext;
   public float rarityChance = 1.0F;
   public float discardOnAirChance;
   public int size;
   public Color color;
   public boolean scattered;

   public OrePlacement(class_6796 feature, int step, int index, Color color, int bottomY, int height) {
      this.step = step;
      this.index = index;
      this.color = color;
      class_5539 view = class_5539.method_39034(bottomY, height);
      this.heightContext = new class_5868((class_2794)null, view);

      for (class_6797 modifier : feature.comp_335()) {
         if (modifier instanceof class_6793) {
            this.count = ((CountPlacementModifierAccessor)modifier).getCount();
         } else if (modifier instanceof class_6795) {
            this.height = ((HeightRangePlacementModifierAccessor)modifier).getHeight();
         } else if (modifier instanceof class_6799) {
            this.rarityChance = ((RarityFilterPlacementModifierAccessor)modifier).getChance();
         }
      }

      class_2975<?, ?> configured = (class_2975<?, ?>)feature.comp_334().comp_349();
      if (configured.comp_333() instanceof class_3124 oreConfig) {
         this.discardOnAirChance = oreConfig.field_29064;
         this.size = oreConfig.field_13723;
         if (((class_2975)feature.comp_334().comp_349()).comp_332() instanceof class_5875) {
            this.scattered = true;
         }
      } else {
         throw new IllegalStateException("config for " + feature + "is not OreFeatureConfig.class");
      }
   }

   public static Map<class_5321<class_1959>, List<OrePlacement>> buildBiomeTable() {
      class_7874 lookup = class_7887.method_46817();
      class_7226<class_6796> placedFeatures = lookup.method_46762(class_7924.field_41245);
      Map<class_5321<class_5363>, class_5363> dimensions = ((class_7145)lookup.method_46762(class_7924.field_41250)
            .method_46747(class_5317.field_25050)
            .comp_349())
         .method_45546()
         .comp_1014();
      HashMap<class_5321<class_1959>, List<OrePlacement>> byBiome = new HashMap<>();
      class_5363 overworld = dimensions.get(class_5363.field_25412);
      Set<class_6880<class_1959>> overworldBiomeSet = overworld.comp_1013().method_12098().method_28443();
      List<class_6880<class_1959>> overworldBiomes = overworldBiomeSet.stream().toList();
      List<class_6827> overworldIndexed = class_7510.method_44210(overworldBiomes, entry -> ((class_1959)entry.comp_349()).method_30970().method_30983(), true);
      HashMap<class_6796, OrePlacement> overworldFeatures = new HashMap<>();
      register(overworldFeatures, overworldIndexed, placedFeatures, class_6816.field_36070, 6, new Color(47, 44, 54), -64, 384);
      register(overworldFeatures, overworldIndexed, placedFeatures, class_6816.field_36069, 6, new Color(47, 44, 54), -64, 384);
      register(overworldFeatures, overworldIndexed, placedFeatures, class_6816.field_36072, 6, new Color(236, 173, 119), -64, 384);
      register(overworldFeatures, overworldIndexed, placedFeatures, class_6816.field_36073, 6, new Color(236, 173, 119), -64, 384);
      register(overworldFeatures, overworldIndexed, placedFeatures, class_6816.field_36071, 6, new Color(236, 173, 119), -64, 384);
      register(overworldFeatures, overworldIndexed, placedFeatures, class_6816.field_36075, 6, new Color(247, 229, 30), -64, 384);
      register(overworldFeatures, overworldIndexed, placedFeatures, class_6816.field_36076, 6, new Color(247, 229, 30), -64, 384);
      register(overworldFeatures, overworldIndexed, placedFeatures, class_6816.field_36074, 6, new Color(247, 229, 30), -64, 384);
      register(overworldFeatures, overworldIndexed, placedFeatures, class_6816.field_36077, 6, new Color(245, 7, 23), -64, 384);
      register(overworldFeatures, overworldIndexed, placedFeatures, class_6816.field_36039, 6, new Color(245, 7, 23), -64, 384);
      register(overworldFeatures, overworldIndexed, placedFeatures, class_6816.field_36040, 6, new Color(33, 244, 255), -64, 384);
      register(overworldFeatures, overworldIndexed, placedFeatures, class_6816.field_36042, 6, new Color(33, 244, 255), -64, 384);
      register(overworldFeatures, overworldIndexed, placedFeatures, class_6816.field_36041, 6, new Color(33, 244, 255), -64, 384);
      register(overworldFeatures, overworldIndexed, placedFeatures, class_6816.field_45664, 6, new Color(33, 244, 255), -64, 384);
      register(overworldFeatures, overworldIndexed, placedFeatures, class_6816.field_36043, 6, new Color(8, 26, 189), -64, 384);
      register(overworldFeatures, overworldIndexed, placedFeatures, class_6816.field_36044, 6, new Color(8, 26, 189), -64, 384);
      register(overworldFeatures, overworldIndexed, placedFeatures, class_6816.field_36049, 6, new Color(239, 151, 0), -64, 384);
      register(overworldFeatures, overworldIndexed, placedFeatures, class_6816.field_36050, 6, new Color(239, 151, 0), -64, 384);
      register(overworldFeatures, overworldIndexed, placedFeatures, class_6816.field_36046, 6, new Color(27, 209, 45), -64, 384);
      overworldBiomes.forEach(
         biomeEntry -> {
            class_5321<class_1959> biomeKey = (class_5321<class_1959>)biomeEntry.method_40230().get();
            byBiome.put(biomeKey, new ArrayList<>());
            ((class_1959)biomeEntry.comp_349())
               .method_30970()
               .method_30983()
               .stream()
               .flatMap(class_6885::method_40239)
               .<class_6796>map(class_6880::comp_349)
               .filter(overworldFeatures::containsKey)
               .forEach(placed -> byBiome.get(biomeEntry.method_40230().get()).add(overworldFeatures.get(placed)));
         }
      );
      class_5363 nether = dimensions.get(class_5363.field_25413);
      Set<class_6880<class_1959>> netherBiomeSet = nether.comp_1013().method_12098().method_28443();
      List<class_6880<class_1959>> netherBiomes = netherBiomeSet.stream().toList();
      List<class_6827> netherIndexed = class_7510.method_44210(netherBiomes, entry -> ((class_1959)entry.comp_349()).method_30970().method_30983(), true);
      HashMap<class_6796, OrePlacement> netherFeatures = new HashMap<>();
      register(netherFeatures, netherIndexed, placedFeatures, class_6816.field_36056, 7, new Color(255, 200, 0), 0, 128);
      register(netherFeatures, netherIndexed, placedFeatures, class_6816.field_36054, 7, new Color(255, 200, 0), 0, 128);
      register(netherFeatures, netherIndexed, placedFeatures, class_6816.field_36048, 7, new Color(130, 98, 83), 0, 128);
      register(netherFeatures, netherIndexed, placedFeatures, class_6816.field_36047, 7, new Color(130, 98, 83), 0, 128);
      register(netherFeatures, netherIndexed, placedFeatures, class_6816.field_36057, 7, new Color(230, 225, 215), 0, 128);
      register(netherFeatures, netherIndexed, placedFeatures, class_6816.field_36055, 7, new Color(230, 225, 215), 0, 128);
      netherBiomes.forEach(
         biomeEntry -> {
            class_5321<class_1959> biomeKey = (class_5321<class_1959>)biomeEntry.method_40230().get();
            byBiome.put(biomeKey, new ArrayList<>());
            ((class_1959)biomeEntry.comp_349())
               .method_30970()
               .method_30983()
               .stream()
               .flatMap(class_6885::method_40239)
               .<class_6796>map(class_6880::comp_349)
               .filter(netherFeatures::containsKey)
               .forEach(placed -> byBiome.get(biomeEntry.method_40230().get()).add(netherFeatures.get(placed)));
         }
      );
      return byBiome;
   }

   public static void register(
      Map<class_6796, OrePlacement> out,
      List<class_6827> indexed,
      class_7226<class_6796> wrapper,
      class_5321<class_6796> key,
      int step,
      Color color,
      int bottomY,
      int height
   ) {
      try {
         class_6796 feature = (class_6796)wrapper.method_46747(key).comp_349();
         int index = indexed.get(step).comp_304().applyAsInt(feature);
         OrePlacement placement = new OrePlacement(feature, step, index, color, bottomY, height);
         out.put(feature, placement);
      } catch (Exception var11) {
      }
   }
}
