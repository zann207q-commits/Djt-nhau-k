package com.krypton.theme.util;

import com.krypton.theme.mixin.ProjectionMatrix2Accessor;
import com.krypton.theme.render.Mesh;
import com.krypton.theme.render.MeshRenderer;
import com.krypton.theme.render.RenderState;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_10366;
import net.minecraft.class_11278;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;

public class Renderer3D {
   public static Matrix4f projectionMatrix = RenderState.PROJECTION;
   public static class_11278 projectionMatrix2 = new class_11278("krypton-projection-matrix", -10.0F, 100.0F, true);
   public static Matrix4f modelViewMatrix = new Matrix4f();
   private static final Matrix4f worldProjection = new Matrix4f();
   public static Vector4f SCRATCH = new Vector4f();
   public static class_243 crosshairTarget;
   public Mesh lines;
   public Mesh triangles;
   public RenderPipeline linesPipeline;
   public RenderPipeline trianglesPipeline;

   public Renderer3D(RenderPipeline linesPipeline, RenderPipeline trianglesPipeline) {
      this.lines = new Mesh(linesPipeline);
      this.triangles = new Mesh(trianglesPipeline);
      this.linesPipeline = linesPipeline;
      this.trianglesPipeline = trianglesPipeline;
   }

   public static void guiSpace() {
      float width = class_310.method_1551().method_22683().method_4489() / class_310.method_1551().method_22683().method_4495();
      float height = class_310.method_1551().method_22683().method_4506() / class_310.method_1551().method_22683().method_4495();
      RenderSystem.setProjectionMatrix(projectionMatrix2.method_71092(width, height), class_10366.field_54953);
      projectionMatrix.set(((ProjectionMatrix2Accessor)projectionMatrix2).krypton$callGetMatrix(width, height));
      RenderState.worldSpace = false;
   }

   public static void screenSpace() {
      float width = class_310.method_1551().method_22683().method_4489();
      float height = class_310.method_1551().method_22683().method_4506();
      RenderSystem.setProjectionMatrix(projectionMatrix2.method_71092(width, height), class_10366.field_54953);
      projectionMatrix.set(((ProjectionMatrix2Accessor)projectionMatrix2).krypton$callGetMatrix(width, height));
      RenderState.worldSpace = false;
   }

   public static void worldSpace() {
      float width = class_310.method_1551().method_22683().method_4489() / class_310.method_1551().method_22683().method_4495();
      float height = class_310.method_1551().method_22683().method_4506() / class_310.method_1551().method_22683().method_4495();
      RenderSystem.setProjectionMatrix(projectionMatrix2.method_71092(width, height), class_10366.field_54953);
      projectionMatrix.set(((ProjectionMatrix2Accessor)projectionMatrix2).krypton$callGetMatrix(width, height));
      RenderState.worldSpace = true;
   }

   public static Vector3f worldToScreen(double x, double y, double z) {
      class_243 camera = class_310.method_1551().field_1773.method_19418().method_71156();
      SCRATCH.set((float)(x - camera.field_1352), (float)(y - camera.field_1351), (float)(z - camera.field_1350), 1.0F);
      SCRATCH.mul(modelViewMatrix);
      SCRATCH.mul(worldProjection);
      if (SCRATCH.w <= 0.0F) {
         return null;
      } else {
         float inverseW = 1.0F / SCRATCH.w;
         float ndcX = SCRATCH.x * inverseW;
         float ndcY = SCRATCH.y * inverseW;
         float scale = class_310.method_1551().method_22683().method_4495();
         float screenX = (ndcX * 0.5F + 0.5F) * class_310.method_1551().method_22683().method_4489() / scale;
         float screenY = (1.0F - (ndcY * 0.5F + 0.5F)) * class_310.method_1551().method_22683().method_4506() / scale;
         return new Vector3f(screenX, screenY, SCRATCH.z * inverseW);
      }
   }

   public static void updateCrosshairTarget(Matrix4f projection, Matrix4f modelView) {
      projectionMatrix.set(projection);
      modelViewMatrix.set(modelView);
      worldProjection.set(projection);
      Matrix4f inverseProjection = new Matrix4f(projection).invert();
      Matrix4f inverseModelView = new Matrix4f(modelView).invert();
      Vector4f origin = new Vector4f(0.0F, 0.0F, 0.0F, 1.0F).mul(inverseProjection).mul(inverseModelView);
      origin.div(origin.w);
      class_243 cameraPos = class_310.method_1551().field_1773.method_19418().method_71156();
      crosshairTarget = new class_243(cameraPos.field_1352 + origin.x, cameraPos.field_1351 + origin.y, cameraPos.field_1350 + origin.z);
   }

   public void begin() {
      this.lines.begin();
      this.triangles.begin();
   }

   public void render(class_4587 matrices) {
      MeshRenderer.begin().target(class_310.method_1551().method_1522()).pipeline(this.linesPipeline).mesh(this.lines, matrices).draw();
      MeshRenderer.begin().target(class_310.method_1551().method_1522()).pipeline(this.trianglesPipeline).mesh(this.triangles, matrices).draw();
   }

   private static boolean bit(int value, byte mask) {
      return (value & mask) != mask;
   }

   public void lineGradient(double x1, double y1, double z1, double x2, double y2, double z2, Color c1, Color c2) {
      this.lines.ensureLine();
      this.lines.line(this.lines.vec3(x1, y1, z1).color(c1).nextIndex(), this.lines.vec3(x2, y2, z2).color(c2).nextIndex());
   }

   public void line(double x1, double y1, double z1, double x2, double y2, double z2, Color color) {
      this.lineGradient(x1, y1, z1, x2, y2, z2, color, color);
   }

   public void boxLines(double x1, double y1, double z1, double x2, double y2, double z2, Color color, int excludeDir) {
      this.lines.ensureCapacity(8, 24);
      int v1 = this.lines.vec3(x1, y1, z1).color(color).nextIndex();
      int v2 = this.lines.vec3(x1, y1, z2).color(color).nextIndex();
      int v3 = this.lines.vec3(x2, y1, z1).color(color).nextIndex();
      int v4 = this.lines.vec3(x2, y1, z2).color(color).nextIndex();
      int v5 = this.lines.vec3(x1, y2, z1).color(color).nextIndex();
      int v6 = this.lines.vec3(x1, y2, z2).color(color).nextIndex();
      int v7 = this.lines.vec3(x2, y2, z1).color(color).nextIndex();
      int v8 = this.lines.vec3(x2, y2, z2).color(color).nextIndex();
      if (excludeDir == 0) {
         this.lines.line(v1, v5);
         this.lines.line(v2, v6);
         this.lines.line(v3, v7);
         this.lines.line(v4, v8);
         this.lines.line(v1, v2);
         this.lines.line(v3, v4);
         this.lines.line(v1, v3);
         this.lines.line(v2, v4);
         this.lines.line(v5, v6);
         this.lines.line(v7, v8);
         this.lines.line(v5, v7);
         this.lines.line(v6, v8);
      } else {
         if (bit(excludeDir, (byte)32) && bit(excludeDir, (byte)8)) {
            this.lines.line(v1, v5);
         }

         if (bit(excludeDir, (byte)32) && bit(excludeDir, (byte)16)) {
            this.lines.line(v2, v6);
         }

         if (bit(excludeDir, (byte)64) && bit(excludeDir, (byte)8)) {
            this.lines.line(v3, v7);
         }

         if (bit(excludeDir, (byte)64) && bit(excludeDir, (byte)16)) {
            this.lines.line(v4, v8);
         }

         if (bit(excludeDir, (byte)32) && bit(excludeDir, (byte)4)) {
            this.lines.line(v1, v2);
         }

         if (bit(excludeDir, (byte)64) && bit(excludeDir, (byte)4)) {
            this.lines.line(v3, v4);
         }

         if (bit(excludeDir, (byte)8) && bit(excludeDir, (byte)4)) {
            this.lines.line(v1, v3);
         }

         if (bit(excludeDir, (byte)16) && bit(excludeDir, (byte)4)) {
            this.lines.line(v2, v4);
         }

         if (bit(excludeDir, (byte)32) && bit(excludeDir, (byte)2)) {
            this.lines.line(v5, v6);
         }

         if (bit(excludeDir, (byte)64) && bit(excludeDir, (byte)2)) {
            this.lines.line(v7, v8);
         }

         if (bit(excludeDir, (byte)8) && bit(excludeDir, (byte)2)) {
            this.lines.line(v5, v7);
         }

         if (bit(excludeDir, (byte)16) && bit(excludeDir, (byte)2)) {
            this.lines.line(v6, v8);
         }
      }
   }

   public void blockLines(int x, int y, int z, Color color, int excludeDir) {
      this.boxLines(x, y, z, x + 1, y + 1, z + 1, color, excludeDir);
   }

   public void quadGradient(
      double x1,
      double y1,
      double z1,
      double x2,
      double y2,
      double z2,
      double x3,
      double y3,
      double z3,
      double x4,
      double y4,
      double z4,
      Color c1,
      Color c2,
      Color c3,
      Color c4
   ) {
      this.triangles.ensureQuad();
      this.triangles
         .quad(
            this.triangles.vec3(x1, y1, z1).color(c4).nextIndex(),
            this.triangles.vec3(x2, y2, z2).color(c1).nextIndex(),
            this.triangles.vec3(x3, y3, z3).color(c2).nextIndex(),
            this.triangles.vec3(x4, y4, z4).color(c3).nextIndex()
         );
   }

   public void quad(
      double x1, double y1, double z1, double x2, double y2, double z2, double x3, double y3, double z3, double x4, double y4, double z4, Color color
   ) {
      this.quadGradient(x1, y1, z1, x2, y2, z2, x3, y3, z3, x4, y4, z4, color, color, color, color);
   }

   public void sideVertical(double x1, double y1, double z1, double x2, double y2, double z2, Color color) {
      this.quad(x1, y1, z1, x1, y2, z1, x2, y2, z2, x2, y1, z2, color);
   }

   public void sideHorizontal(double x1, double y1, double z1, double x2, double z2, Color color) {
      this.quad(x1, y1, z1, x1, y1, z2, x2, y1, z2, x2, y1, z1, color);
   }

   public void sideGradient(double x1, double y1, double z1, double x2, double y2, double z2, Color c1, Color c2) {
      this.quadGradient(x1, y1, z1, x1, y2, z1, x2, y2, z2, x2, y1, z2, c1, c1, c2, c2);
   }

   public void side(
      double x1,
      double y1,
      double z1,
      double x2,
      double y2,
      double z2,
      double x3,
      double y3,
      double z3,
      double x4,
      double y4,
      double z4,
      Color sideColor,
      Color lineColor,
      ShapeMode mode
   ) {
      if (mode.lines()) {
         this.lines.ensureCapacity(4, 8);
         int v1 = this.lines.vec3(x1, y1, z1).color(lineColor).nextIndex();
         int v2 = this.lines.vec3(x2, y2, z2).color(lineColor).nextIndex();
         int v3 = this.lines.vec3(x3, y3, z3).color(lineColor).nextIndex();
         int v4 = this.lines.vec3(x4, y4, z4).color(lineColor).nextIndex();
         this.lines.line(v1, v2);
         this.lines.line(v2, v3);
         this.lines.line(v3, v4);
         this.lines.line(v4, v1);
      }

      if (mode.sides()) {
         this.quad(x1, y1, z1, x2, y2, z2, x3, y3, z3, x4, y4, z4, sideColor);
      }
   }

   public void sideVertical(double x1, double y1, double z1, double x2, double y2, double z2, Color sideColor, Color lineColor, ShapeMode mode) {
      this.side(x1, y1, z1, x1, y2, z1, x2, y2, z2, x2, y1, z2, sideColor, lineColor, mode);
   }

   public void sideHorizontal(double x1, double y1, double z1, double x2, double z2, Color sideColor, Color lineColor, ShapeMode mode) {
      this.side(x1, y1, z1, x1, y1, z2, x2, y1, z2, x2, y1, z1, sideColor, lineColor, mode);
   }

   public void boxSides(double x1, double y1, double z1, double x2, double y2, double z2, Color color, int excludeDir) {
      this.triangles.ensureCapacity(8, 36);
      int v1 = this.triangles.vec3(x1, y1, z1).color(color).nextIndex();
      int v2 = this.triangles.vec3(x1, y1, z2).color(color).nextIndex();
      int v3 = this.triangles.vec3(x2, y1, z1).color(color).nextIndex();
      int v4 = this.triangles.vec3(x2, y1, z2).color(color).nextIndex();
      int v5 = this.triangles.vec3(x1, y2, z1).color(color).nextIndex();
      int v6 = this.triangles.vec3(x1, y2, z2).color(color).nextIndex();
      int v7 = this.triangles.vec3(x2, y2, z1).color(color).nextIndex();
      int v8 = this.triangles.vec3(x2, y2, z2).color(color).nextIndex();
      if (excludeDir == 0) {
         this.triangles.quad(v1, v2, v6, v5);
         this.triangles.quad(v3, v7, v8, v4);
         this.triangles.quad(v1, v5, v7, v3);
         this.triangles.quad(v2, v4, v8, v6);
         this.triangles.quad(v1, v3, v4, v2);
         this.triangles.quad(v5, v6, v8, v7);
      } else {
         if (bit(excludeDir, (byte)32)) {
            this.triangles.quad(v1, v2, v6, v5);
         }

         if (bit(excludeDir, (byte)64)) {
            this.triangles.quad(v3, v7, v8, v4);
         }

         if (bit(excludeDir, (byte)8)) {
            this.triangles.quad(v1, v5, v7, v3);
         }

         if (bit(excludeDir, (byte)16)) {
            this.triangles.quad(v2, v4, v8, v6);
         }

         if (bit(excludeDir, (byte)4)) {
            this.triangles.quad(v1, v3, v4, v2);
         }

         if (bit(excludeDir, (byte)2)) {
            this.triangles.quad(v5, v6, v8, v7);
         }
      }
   }

   public void blockSides(int x, int y, int z, Color color, int excludeDir) {
      this.boxSides(x, y, z, x + 1, y + 1, z + 1, color, excludeDir);
   }

   public void box(double x1, double y1, double z1, double x2, double y2, double z2, Color sideColor, Color lineColor, ShapeMode mode, int excludeDir) {
      if (mode.lines()) {
         this.boxLines(x1, y1, z1, x2, y2, z2, lineColor, excludeDir);
      }

      if (mode.sides()) {
         this.boxSides(x1, y1, z1, x2, y2, z2, sideColor, excludeDir);
      }
   }

   public void box(class_2338 pos, Color sideColor, Color lineColor, ShapeMode mode, int excludeDir) {
      if (mode.lines()) {
         this.boxLines(
            pos.method_10263(),
            pos.method_10264(),
            pos.method_10260(),
            pos.method_10263() + 1,
            pos.method_10264() + 1,
            pos.method_10260() + 1,
            lineColor,
            excludeDir
         );
      }

      if (mode.sides()) {
         this.boxSides(
            pos.method_10263(),
            pos.method_10264(),
            pos.method_10260(),
            pos.method_10263() + 1,
            pos.method_10264() + 1,
            pos.method_10260() + 1,
            sideColor,
            excludeDir
         );
      }
   }

   public void box(class_238 box, Color sideColor, Color lineColor, ShapeMode mode, int excludeDir) {
      if (mode.lines()) {
         this.boxLines(box.field_1323, box.field_1322, box.field_1321, box.field_1320, box.field_1325, box.field_1324, lineColor, excludeDir);
      }

      if (mode.sides()) {
         this.boxSides(box.field_1323, box.field_1322, box.field_1321, box.field_1320, box.field_1325, box.field_1324, sideColor, excludeDir);
      }
   }
}
