package com.krypton.theme.util;

import it.unimi.dsi.fastutil.objects.Object2IntArrayMap;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import it.unimi.dsi.fastutil.objects.ObjectSet;
import it.unimi.dsi.fastutil.objects.Object2IntMap.Entry;
import java.util.Set;
import net.minecraft.class_10192;
import net.minecraft.class_1304;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import net.minecraft.class_9331;
import net.minecraft.class_9334;

public class EnchantmentUtils {
   public static boolean hasEnchantment(class_1799 stack, class_5321<class_1887> key) {
      if (stack.method_7960()) {
         return false;
      } else {
         Object2IntArrayMap<class_6880<class_1887>> enchantments = new Object2IntArrayMap();
         collectEnchantments(stack, enchantments);
         return mapContainsEnchantment(enchantments, key);
      }
   }

   public static boolean hasEnchantmentAtLevel(class_1799 stack, class_5321<class_1887> key, int level) {
      if (stack.method_7960()) {
         return false;
      } else {
         Object2IntArrayMap<class_6880<class_1887>> enchantments = new Object2IntArrayMap();
         collectEnchantments(stack, enchantments);
         ObjectSet<Entry<class_6880<class_1887>>> entries = enchantments.object2IntEntrySet();
         ObjectIterator<Entry<class_6880<class_1887>>> it = entries.iterator();

         while (it.hasNext()) {
            Entry<class_6880<class_1887>> entry = (Entry<class_6880<class_1887>>)it.next();
            class_6880<class_1887> enchantment = (class_6880<class_1887>)entry.getKey();
            if (enchantment.method_40225(key) && entry.getIntValue() == level) {
               return true;
            }
         }

         return false;
      }
   }

   public static boolean mapContainsEnchantment(Object2IntMap<class_6880<class_1887>> enchantments, class_5321<class_1887> key) {
      ObjectSet<class_6880<class_1887>> keys = enchantments.keySet();
      ObjectIterator<class_6880<class_1887>> it = keys.iterator();

      while (it.hasNext()) {
         class_6880<class_1887> entry = (class_6880<class_1887>)it.next();
         if (entry.method_40225(key)) {
            return true;
         }
      }

      return false;
   }

   public static void collectEnchantments(class_1799 stack, Object2IntMap<class_6880<class_1887>> out) {
      out.clear();
      if (!stack.method_7960()) {
         Set<Entry<class_6880<class_1887>>> entries;
         if (stack.method_7909() == class_1802.field_8598) {
            class_9331<class_9304> type = class_9334.field_49643;
            class_9304 component = (class_9304)stack.method_58694(type);
            entries = component.method_57539();
         } else {
            class_9304 component = stack.method_58657();
            entries = component.method_57539();
         }

         for (Entry<class_6880<class_1887>> entry : entries) {
            class_6880<class_1887> enchantment = (class_6880<class_1887>)entry.getKey();
            int level = entry.getIntValue();
            out.put(enchantment, level);
         }
      }
   }

   public static boolean isChestEquippable(class_1792 item) {
      class_1799 stack = item.method_7854();
      class_10192 equippable = (class_10192)stack.method_58694(class_9334.field_54196);
      return equippable != null && equippable.comp_3174() == class_1304.field_6174 && !item.equals(class_1802.field_8833);
   }
}
