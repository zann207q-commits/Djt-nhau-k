package com.krypton.theme.util;

import net.minecraft.class_124;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2583;
import net.minecraft.class_5251;
import org.joml.Vector3f;
import org.joml.Vector4f;

public class Color {
   public static Color WHITE = new Color(255, 255, 255);
   public static Color LIGHT_GRAY = new Color(192, 192, 192);
   public static Color GRAY = new Color(128, 128, 128);
   public static Color DARK_GRAY = new Color(64, 64, 64);
   public static Color BLACK = new Color(0, 0, 0);
   public static Color RED = new Color(255, 0, 0);
   public static Color PINK = new Color(255, 175, 175);
   public static Color ORANGE = new Color(255, 200, 0);
   public static Color YELLOW = new Color(255, 255, 0);
   public static Color GREEN = new Color(0, 255, 0);
   public static Color MAGENTA = new Color(255, 0, 255);
   public static Color CYAN = new Color(0, 255, 255);
   public static Color BLUE = new Color(0, 0, 255);
   public int r;
   public int g;
   public int b;
   public int a;

   public Color() {
      this(255, 255, 255, 255);
   }

   public Color(int r, int g, int b) {
      this.r = r;
      this.g = g;
      this.b = b;
      this.a = 255;
      this.clamp();
   }

   public Color(int r, int g, int b, int a) {
      this.r = r;
      this.g = g;
      this.b = b;
      this.a = a;
      this.clamp();
   }

   public Color(float r, float g, float b, float a) {
      this.r = (int)(r * 255.0F);
      this.g = (int)(g * 255.0F);
      this.b = (int)(b * 255.0F);
      this.a = (int)(a * 255.0F);
      this.clamp();
   }

   public Color(int packed) {
      this.r = red(packed);
      this.g = green(packed);
      this.b = blue(packed);
      this.a = alpha(packed);
   }

   public Color(Color other) {
      this.r = other.r;
      this.g = other.g;
      this.b = other.b;
      this.a = other.a;
   }

   public Color(class_124 formatting) {
      if (formatting.method_543()) {
         this.r = red(formatting.method_532());
         this.g = green(formatting.method_532());
         this.b = blue(formatting.method_532());
         this.a = alpha(formatting.method_532());
      } else {
         this.r = 255;
         this.g = 255;
         this.b = 255;
         this.a = 255;
      }
   }

   public Color(class_5251 textColor) {
      this.r = red(textColor.method_27716());
      this.g = green(textColor.method_27716());
      this.b = blue(textColor.method_27716());
      this.a = alpha(textColor.method_27716());
   }

   public Color(class_2583 style) {
      class_5251 color = style.method_10973();
      if (color == null) {
         this.r = 255;
         this.g = 255;
         this.b = 255;
         this.a = 255;
      } else {
         this.r = red(color.method_27716());
         this.g = green(color.method_27716());
         this.b = blue(color.method_27716());
         this.a = alpha(color.method_27716());
      }
   }

   public static int pack(int r, int g, int b, int a) {
      return (r << 16) + (g << 8) + b + (a << 24);
   }

   public static int red(int packed) {
      return packed >> 16 & 0xFF;
   }

   public static int green(int packed) {
      return packed >> 8 & 0xFF;
   }

   public static int blue(int packed) {
      return packed & 0xFF;
   }

   public static int alpha(int packed) {
      return packed >> 24 & 0xFF;
   }

   public static Color fromHsv(double hue, double saturation, double value) {
      if (saturation <= 0.0) {
         return new Color((int)(value * 255.0), (int)(value * 255.0), (int)(value * 255.0), 255);
      } else {
         double h = hue;
         if (hue >= 360.0) {
            h = 0.0;
         }

         h /= 60.0;
         int i = (int)h;
         double f = h - i;
         double p = value * (1.0 - saturation);
         double q = value * (1.0 - saturation * f);
         double t = value * (1.0 - saturation * (1.0 - f));
         double rr;
         double gg;
         double bb;
         switch (i) {
            case 0:
               rr = value;
               gg = t;
               bb = p;
               break;
            case 1:
               rr = q;
               gg = value;
               bb = p;
               break;
            case 2:
               rr = p;
               gg = value;
               bb = t;
               break;
            case 3:
               rr = p;
               gg = q;
               bb = value;
               break;
            case 4:
               rr = t;
               gg = p;
               bb = value;
               break;
            case 5:
            default:
               rr = value;
               gg = p;
               bb = q;
         }

         return new Color((int)(rr * 255.0), (int)(gg * 255.0), (int)(bb * 255.0), 255);
      }
   }

   public static float[] rgbToHsb(int r, int g, int b, float[] out) {
      if (out == null) {
         out = new float[3];
      }

      int max = Math.max(r, Math.max(g, b));
      int min = Math.min(r, Math.min(g, b));
      float brightness = max / 255.0F;
      float saturation;
      if (max != 0) {
         saturation = (float)(max - min) / max;
      } else {
         saturation = 0.0F;
      }

      float hue;
      if (saturation == 0.0F) {
         hue = 0.0F;
      } else {
         float rc = (float)(max - r) / (max - min);
         float gc = (float)(max - g) / (max - min);
         float bc = (float)(max - b) / (max - min);
         if (r == max) {
            hue = bc - gc;
         } else if (g == max) {
            hue = 2.0F + rc - bc;
         } else {
            hue = 4.0F + gc - rc;
         }

         hue /= 6.0F;
         if (hue < 0.0F) {
            hue++;
         }
      }

      out[0] = hue;
      out[1] = saturation;
      out[2] = brightness;
      return out;
   }

   public static int hsbToArgb(float hue, float saturation, float brightness) {
      int r = 0;
      int g = 0;
      int b = 0;
      if (saturation == 0.0F) {
         r = g = b = (int)(brightness * 255.0F + 0.5F);
      } else {
         float h = (hue - (float)Math.floor(hue)) * 6.0F;
         float f = h - (float)Math.floor(h);
         float p = brightness * (1.0F - saturation);
         float q = brightness * (1.0F - saturation * f);
         float t = brightness * (1.0F - saturation * (1.0F - f));
         switch ((int)h) {
            case 0:
               r = (int)(brightness * 255.0F + 0.5F);
               g = (int)(t * 255.0F + 0.5F);
               b = (int)(p * 255.0F + 0.5F);
               break;
            case 1:
               r = (int)(q * 255.0F + 0.5F);
               g = (int)(brightness * 255.0F + 0.5F);
               b = (int)(p * 255.0F + 0.5F);
               break;
            case 2:
               r = (int)(p * 255.0F + 0.5F);
               g = (int)(brightness * 255.0F + 0.5F);
               b = (int)(t * 255.0F + 0.5F);
               break;
            case 3:
               r = (int)(p * 255.0F + 0.5F);
               g = (int)(q * 255.0F + 0.5F);
               b = (int)(brightness * 255.0F + 0.5F);
               break;
            case 4:
               r = (int)(t * 255.0F + 0.5F);
               g = (int)(p * 255.0F + 0.5F);
               b = (int)(brightness * 255.0F + 0.5F);
               break;
            case 5:
               r = (int)(brightness * 255.0F + 0.5F);
               g = (int)(p * 255.0F + 0.5F);
               b = (int)(q * 255.0F + 0.5F);
         }
      }

      return 0xFF000000 | r << 16 | g << 8 | b;
   }

   public static Color fromHsb(float hue, float saturation, float brightness) {
      int packed = hsbToArgb(hue, saturation, brightness);
      return new Color(packed >> 16 & 0xFF, packed >> 8 & 0xFF, packed & 0xFF, 255);
   }

   public Color set(int r, int g, int b, int a) {
      this.r = r;
      this.g = g;
      this.b = b;
      this.a = a;
      this.clamp();
      return this;
   }

   public Color setRed(int r) {
      this.r = r;
      this.clamp();
      return this;
   }

   public Color setGreen(int g) {
      this.g = g;
      this.clamp();
      return this;
   }

   public Color setBlue(int b) {
      this.b = b;
      this.clamp();
      return this;
   }

   public Color setAlpha(int a) {
      this.a = a;
      this.clamp();
      return this;
   }

   public Color set(Color other) {
      this.r = other.r;
      this.g = other.g;
      this.b = other.b;
      this.a = other.a;
      this.clamp();
      return this;
   }

   public boolean parse(String text) {
      String[] parts = text.split(",");
      if (parts.length != 3 && parts.length != 4) {
         return false;
      } else {
         try {
            int r = Integer.parseInt(parts[0]);
            int g = Integer.parseInt(parts[1]);
            int b = Integer.parseInt(parts[2]);
            int a = parts.length == 4 ? Integer.parseInt(parts[3]) : this.a;
            this.r = r;
            this.g = g;
            this.b = b;
            this.a = a;
            return true;
         } catch (NumberFormatException var7) {
            return false;
         }
      }
   }

   public Color copy() {
      return new Color(this.r, this.g, this.b, this.a);
   }

   public class_5251 toTextColor() {
      return class_5251.method_27717(this.packed());
   }

   public class_2583 toStyle() {
      return class_2583.field_24360.method_27703(this.toTextColor());
   }

   public class_2583 applyTo(class_2583 style) {
      return style.method_27703(this.toTextColor());
   }

   public int getRed() {
      return this.r;
   }

   public int getGreen() {
      return this.g;
   }

   public int getBlue() {
      return this.b;
   }

   public int getAlpha() {
      return this.a;
   }

   public int getPacked() {
      return this.packed();
   }

   public Color brighter() {
      int min = 3;
      int r = this.r;
      int g = this.g;
      int b = this.b;
      if (r == 0 && g == 0 && b == 0) {
         return new Color(min, min, min, this.a);
      } else {
         if (r > 0 && r < min) {
            r = min;
         }

         if (g > 0 && g < min) {
            g = min;
         }

         if (b > 0 && b < min) {
            b = min;
         }

         return new Color(Math.min((int)(r / 0.7), 255), Math.min((int)(g / 0.7), 255), Math.min((int)(b / 0.7), 255), this.a);
      }
   }

   public Color darker() {
      return new Color(Math.max((int)(this.r * 0.7), 0), Math.max((int)(this.g * 0.7), 0), Math.max((int)(this.b * 0.7), 0), this.a);
   }

   public void clamp() {
      if (this.r < 0) {
         this.r = 0;
      } else if (this.r > 255) {
         this.r = 255;
      }

      if (this.g < 0) {
         this.g = 0;
      } else if (this.g > 255) {
         this.g = 255;
      }

      if (this.b < 0) {
         this.b = 0;
      } else if (this.b > 255) {
         this.b = 255;
      }

      if (this.a < 0) {
         this.a = 0;
      } else if (this.a > 255) {
         this.a = 255;
      }
   }

   public class_243 toVec3d() {
      return new class_243(this.r / 255.0, this.g / 255.0, this.b / 255.0);
   }

   public Vector3f toVector3f() {
      return new Vector3f(this.r / 255.0F, this.g / 255.0F, this.b / 255.0F);
   }

   public Vector4f toVector4f() {
      return new Vector4f(this.r / 255.0F, this.g / 255.0F, this.b / 255.0F, this.a / 255.0F);
   }

   public int packed() {
      return pack(this.r, this.g, this.b, this.a);
   }

   public class_2487 toNbt() {
      class_2487 nbt = new class_2487();
      nbt.method_10569("r", this.r);
      nbt.method_10569("g", this.g);
      nbt.method_10569("b", this.b);
      nbt.method_10569("a", this.a);
      return nbt;
   }

   public Color fromNbt(class_2487 nbt) {
      this.r = nbt.method_68083("r", 0);
      this.g = nbt.method_68083("g", 0);
      this.b = nbt.method_68083("b", 0);
      this.a = nbt.method_68083("a", 0);
      this.clamp();
      return this;
   }

   @Override
   public String toString() {
      return this.r + " " + this.g + " " + this.b + " " + this.a;
   }

   @Override
   public boolean equals(Object other) {
      if (this == other) {
         return true;
      } else if (other != null && this.getClass() == other.getClass()) {
         Color c = (Color)other;
         return this.r == c.r && this.g == c.g && this.b == c.b && this.a == c.a;
      } else {
         return false;
      }
   }

   @Override
   public int hashCode() {
      int result = this.r;
      result = 31 * result + this.g;
      result = 31 * result + this.b;
      return 31 * result + this.a;
   }
}
