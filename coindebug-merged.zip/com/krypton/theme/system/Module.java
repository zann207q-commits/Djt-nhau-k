package com.krypton.theme.system;

import com.krypton.theme.settings.KeybindSetting;
import com.krypton.theme.settings.Setting;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.BiConsumer;
import net.minecraft.class_310;

public abstract class Module {
   public List<Setting> settings = new ArrayList<>();
   public List<BiConsumer<Module, Boolean>> toggleListeners = new ArrayList<>();
   public String name;
   public String description;
   public Category category;
   public class_310 mc = class_310.method_1551();
   public boolean enabled;
   public int keybind;
   public KeybindSetting keybindSetting;

   public Module(String name, String description, int keybind, Category category) {
      this.name = name;
      this.description = description;
      this.enabled = false;
      this.keybind = keybind;
      this.category = category;
      this.keybindSetting = new KeybindSetting("Keybind", keybind, true);
      this.settings.add(this.keybindSetting);
   }

   public void toggle() {
      this.setEnabled(!this.enabled);
   }

   public String getName() {
      return this.name;
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public void setEnabled(boolean value) {
      if (this.enabled != value) {
         this.enabled = value;
         if (value) {
            this.onEnable();
         } else {
            this.onDisable();
         }

         for (BiConsumer<Module, Boolean> listener : this.toggleListeners) {
            listener.accept(this, value);
         }
      }
   }

   public String getDescription() {
      return this.description;
   }

   public int getKeybind() {
      return this.keybind;
   }

   public void setKeybind(int keybind) {
      this.keybind = keybind;
   }

   public Category getCategory() {
      return this.category;
   }

   public List<Setting> getSettings() {
      return this.settings;
   }

   public void onEnable() {
   }

   public void onDisable() {
   }

   public void addSetting(Setting setting) {
      this.settings.add(setting);
   }

   public void addSettings(Setting... settings) {
      this.settings.addAll(Arrays.asList(settings));
   }

   public void setEnabledSilently(boolean value) {
      this.enabled = value;
   }

   public void onToggle(BiConsumer<Module, Boolean> listener) {
      this.toggleListeners.add(listener);
   }
}
