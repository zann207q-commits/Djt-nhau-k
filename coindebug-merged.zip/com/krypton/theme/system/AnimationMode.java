package com.krypton.theme.system;

public enum AnimationMode {
   Normal,
   Positive,
   Off;
}
