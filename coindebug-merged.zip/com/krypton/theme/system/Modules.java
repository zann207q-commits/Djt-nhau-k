package com.krypton.theme.system;

import java.util.ArrayList;
import java.util.List;

public class Modules {
   private static final List<Module> MODULES = new ArrayList<>();

   public static void register(Module module) {
      MODULES.add(module);
   }

   public static List<Module> all() {
      return MODULES;
   }

   public static List<Module> byCategory(Category category) {
      List<Module> result = new ArrayList<>();

      for (Module module : MODULES) {
         if (module.getCategory() == category) {
            result.add(module);
         }
      }

      return result;
   }

   public static <T extends Module> T get(Class<T> type) {
      for (Module module : MODULES) {
         if (type.isInstance(module)) {
            return (T)module;
         }
      }

      return null;
   }
}
