package com.krypton.theme.system;

public enum Category {
   COMBAT("cracked by sub5larp", "swords"),
   MISC("cracked by sub5larp", "misc"),
   DONUT("cracked by sub5larp", "donut"),
   BASE_FINDING("cracked by sub5larp", "basefinder"),
   RENDER("cracked by sub5larp", "render"),
   CLIENT("cracked by sub5larp", "client"),
   LARP("larp v5", "candy-cane");

   public String displayName;
   public String icon;

   private Category(String displayName, String icon) {
      this.displayName = displayName;
      this.icon = icon;
   }
}
