package dev.bypass.mixin;

import dev.bypass.light.PacketIntake;
import net.minecraft.class_2672;
import net.minecraft.class_2676;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_634.class})
public abstract class MixinClientPlayNetworkHandler {
   @Inject(
      method = {"method_11128"},
      at = {@At("HEAD")}
   )
   private void bypass$onChunkData(class_2672 pkt, CallbackInfo ci) {
      PacketIntake.offer(pkt.method_11523(), pkt.method_11524(), pkt.method_38599());
   }

   @Inject(
      method = {"method_11143"},
      at = {@At("HEAD")}
   )
   private void bypass$onLightUpdate(class_2676 pkt, CallbackInfo ci) {
      PacketIntake.offer(pkt.method_11558(), pkt.method_11554(), pkt.method_38600());
   }
}
