package dev.bypass;

import com.mojang.logging.LogUtils;
import dev.bypass.light.LightCache;
import dev.bypass.modules.AutoRtp;
import dev.bypass.modules.Bypass;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;
import org.slf4j.Logger;
import x10n.flatslice.FlatSliceAddon;

public class BypassAddon extends MeteorAddon {
   public static final Logger LOG = LogUtils.getLogger();
   public static final Category CATEGORY = FlatSliceAddon.CATEGORY;

   public void onInitialize() {
      LOG.info("[Player Debug V2] Initializing");
      Modules.get().add(new Bypass());
      Modules.get().add(new AutoRtp());
      LightCache.register();
   }

   public String getPackage() {
      return "dev.bypass";
   }
}
