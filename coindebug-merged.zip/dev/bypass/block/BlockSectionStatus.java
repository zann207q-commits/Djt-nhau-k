package dev.bypass.block;

public enum BlockSectionStatus {
   UNKNOWN(80, 80, 80),
   MIXED(0, 220, 0),
   HOMOGENEOUS_NONSOLID(140, 140, 140),
   HOMOGENEOUS_SOLID(255, 140, 0);

   private final int r;
   private final int g;
   private final int b;

   private BlockSectionStatus(int r, int g, int b) {
      this.r = r;
      this.g = g;
      this.b = b;
   }

   public int r() {
      return this.r;
   }

   public int g() {
      return this.g;
   }

   public int b() {
      return this.b;
   }
}
