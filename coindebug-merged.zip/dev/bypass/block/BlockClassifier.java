package dev.bypass.block;

import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_638;

public final class BlockClassifier {
   private BlockClassifier() {
   }

   public static boolean apply(class_638 world, int chunkX, int chunkZ, BlockChunkSnapshot snap, long nowNanos) {
      class_2818 chunk = world.method_8497(chunkX, chunkZ);
      if (chunk == null) {
         return false;
      } else {
         class_2826[] sections = chunk.method_12006();
         int n = Math.min(sections.length, snap.status.length);

         for (int i = 0; i < n; i++) {
            class_2826 section = sections[i];
            if (section == null) {
               snap.status[i] = BlockSectionStatus.UNKNOWN;
            } else {
               snap.status[i] = classifySection(section);
               snap.updatedNanos[i] = nowNanos;
            }
         }

         return true;
      }
   }

   private static BlockSectionStatus classifySection(class_2826 section) {
      class_2680 first = section.method_12254(0, 0, 0);

      for (int dx = 0; dx < 16; dx++) {
         for (int dy = 0; dy < 16; dy++) {
            for (int dz = 0; dz < 16; dz++) {
               class_2680 s = section.method_12254(dx, dy, dz);
               if (!s.equals(first)) {
                  return BlockSectionStatus.MIXED;
               }
            }
         }
      }

      return !first.method_26215() && first.method_26227().method_15769() ? BlockSectionStatus.HOMOGENEOUS_SOLID : BlockSectionStatus.HOMOGENEOUS_NONSOLID;
   }
}
