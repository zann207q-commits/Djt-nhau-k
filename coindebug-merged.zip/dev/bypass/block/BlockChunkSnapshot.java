package dev.bypass.block;

import java.util.Arrays;

public final class BlockChunkSnapshot {
   public final int chunkX;
   public final int chunkZ;
   public final int sectionCount;
   public final int bottomSectionY;
   public final BlockSectionStatus[] status;
   public final long[] updatedNanos;

   public BlockChunkSnapshot(int chunkX, int chunkZ, int sectionCount, int bottomSectionY) {
      this.chunkX = chunkX;
      this.chunkZ = chunkZ;
      this.sectionCount = sectionCount;
      this.bottomSectionY = bottomSectionY;
      this.status = new BlockSectionStatus[sectionCount];
      this.updatedNanos = new long[sectionCount];
      Arrays.fill(this.status, BlockSectionStatus.UNKNOWN);
   }
}
