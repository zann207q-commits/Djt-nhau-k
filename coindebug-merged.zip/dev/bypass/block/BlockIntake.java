package dev.bypass.block;

import java.util.concurrent.ConcurrentLinkedQueue;

public final class BlockIntake {
   public static final ConcurrentLinkedQueue<BlockIntake.PendingChunk> QUEUE = new ConcurrentLinkedQueue<>();

   private BlockIntake() {
   }

   public static void offer(int chunkX, int chunkZ) {
      QUEUE.offer(new BlockIntake.PendingChunk(chunkX, chunkZ, System.nanoTime()));
   }

   public record PendingChunk(int chunkX, int chunkZ, long arrivalNanos) {
   }
}
