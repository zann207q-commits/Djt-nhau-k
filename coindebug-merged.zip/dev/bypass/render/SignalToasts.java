package dev.bypass.render;

import meteordevelopment.meteorclient.utils.render.MeteorToast;
import net.minecraft.class_1109;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3414;

public final class SignalToasts {
   private static final class_3414 FLAG_SOUND = class_3414.method_47908(class_2960.method_60655("peace-debug-v2", "flag_found"));

   private SignalToasts() {
   }

   public static void add(int var0, int var1) {
      class_310 var2 = class_310.method_1551();
      MeteorToast var3 = new MeteorToast.Builder("PLAYER DEBUG V2 MIGHT BE A BASE HERE").text("X: " + var0 + "  Z: " + var1).duration(5000L).build();
      var2.method_1566().method_1999(var3);
      if (var2.method_1483() != null) {
         var2.method_1483().method_4873(class_1109.method_4757(FLAG_SOUND, 1.0F, 1.0F));
      }
   }
}
