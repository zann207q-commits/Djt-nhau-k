package dev.bypass.render;

public enum PlateAnimation {
   All,
   Pulse,
   Scanner,
   Spin,
   Waves,
   Static;
}
