package dev.bypass.render;

import dev.bypass.light.ChunkLightSnapshot;
import dev.bypass.light.LightCache;
import dev.bypass.light.SectionStatus;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.utils.render.color.Color;
import net.minecraft.class_1923;

public final class LightInspectorRenderer {
   private static final double MARKER_Y = 64.0;
   private static final long TEST_LIFETIME = 15000L;
   private static volatile int testChunkX;
   private static volatile int testChunkZ;
   private static volatile long testUntil;

   private LightInspectorRenderer() {
   }

   public static void showTestPlate(int var0, int var1) {
      testChunkX = var0;
      testChunkZ = var1;
      testUntil = System.currentTimeMillis() + 15000L;
   }

   public static void draw(
      Render3DEvent var0,
      Long2ObjectOpenHashMap<ChunkLightSnapshot> var1,
      int var2,
      int var3,
      int var4,
      double var5,
      Color var7,
      PlateAnimation var8
   ) {
      long var11 = System.currentTimeMillis();
      boolean var13 = var11 < testUntil;

      for (int var14 = var2 - var4; var14 <= var2 + var4; var14++) {
         for (int var15 = var3 - var4; var15 <= var3 + var4; var15++) {
            long var16 = class_1923.method_8331(var14, var15);
            ChunkLightSnapshot var18 = (ChunkLightSnapshot)var1.get(var16);
            if (var18 != null && (LightCache.isChunkAlerted(var16) || hasBaseSignal(var18))) {
               drawPlate(var0, var14, var15, var5, var7, var8, var11);
            }
         }
      }

      if (var13) {
         long var19 = class_1923.method_8331(testChunkX, testChunkZ);
         ChunkLightSnapshot var20 = (ChunkLightSnapshot)var1.get(var19);
         boolean var17 = var20 != null && (LightCache.isChunkAlerted(var19) || hasBaseSignal(var20));
         if (!var17) {
            drawPlate(var0, testChunkX, testChunkZ, var5, var7, var8, var11);
         }
      }
   }

   private static void drawPlate(Render3DEvent var0, int var1, int var2, double var3, Color var5, PlateAnimation var6, long var7) {
      double var9 = (var1 << 4) + 8.0;
      double var11 = (var2 << 4) + 8.0;
      double var13 = var3 * 0.5;
      double var15 = Math.floorMod(var1 * 31L + var2 * 17L, 1200L);
      double var17 = (var7 + var15) % 3600.0 / 3600.0 * Math.PI * 2.0;
      boolean var19 = var6 == PlateAnimation.All;
      boolean var20 = var19 || var6 == PlateAnimation.Pulse;
      boolean var21 = var19 || var6 == PlateAnimation.Scanner;
      boolean var22 = var19 || var6 == PlateAnimation.Spin;
      boolean var23 = var19 || var6 == PlateAnimation.Waves;
      double var24 = var20 ? 0.8 + 0.2 * Math.sin(var17) : 1.0;
      double var26 = 63.0;
      double var28 = var13 * var24;
      Color var30 = color(var5, 1.0, alpha(var5, 0.16 + var24 * 0.12));
      disc(var0, var9, var26, var11, var28, var30);
      Color var32 = color(var5, 1.28, alpha(var5, 0.85));
      circle(var0, var9, var26 + 0.06, var11, var28 * 1.02, var32);
      Color var34 = color(var5, 1.15, alpha(var5, 0.55 + var24 * 0.3));
      circle(var0, var9, var26 + 0.12, var11, var28 * (0.42 + 0.2 * var24), var34);
      if (var21) {
         double var36 = (var7 + (long)var15) % 2400L / 2400.0;
         double var38 = var26 + 0.08 + Math.sin(Math.PI * var36) * var28;
         int var40 = alpha(var5, 0.95 * Math.sin(Math.PI * var36));
         Color var42 = color(var5, 1.4, var40);
         line(var0, var9 - var28, var38, var11, var9 + var28, var38, var11, var42);
      }

      if (var22) {
         double var44 = var13 * (0.28 + 0.05 * var24);
         Color var46 = color(var5, 1.1, alpha(var5, 0.75));
         rotatingDiamond(var0, var9, var26 + 0.1, var11, var44, var17 * 0.72, var46);
      }

      if (var23) {
         double var48 = var13 * (0.24 + 0.74 * ((var7 + (long)var15) % 1800L / 1800.0));
         Color var50 = color(var5, 1.3, alpha(var5, 0.6 * (1.0 - var48 / var13)));
         circle(var0, var9, var26 + 0.09, var11, var48, var50);
      }
   }

   private static void circle(Render3DEvent var0, double var1, double var3, double var5, double var7, Color var9) {
      double var10 = Math.PI * 2.0 / 40.0;

      for (int var12 = 0; var12 < 40; var12++) {
         double var14 = var12 * var10;
         double var16 = (var12 + 1) % 40 * var10;
         line(var0, var1 + Math.cos(var14) * var7, var3, var5 + Math.sin(var14) * var7, var1 + Math.cos(var16) * var7, var3, var5 + Math.sin(var16) * var7, var9);
      }
   }

   private static void disc(Render3DEvent var0, double var1, double var3, double var5, double var7, Color var9) {
      var0.renderer.triangles.ensureCapacity(42, 120);
      int var10 = var0.renderer.triangles.vec3(var1, var3, var5).color(var9).next();
      int var11 = -1;
      int var12 = -1;

      for (int var13 = 0; var13 <= 40; var13++) {
         double var14 = var13 % 40 * (Math.PI * 2.0 / 40.0);
         int var15 = var0.renderer.triangles.vec3(var1 + Math.cos(var14) * var7, var3, var5 + Math.sin(var14) * var7).color(var9).next();
         if (var11 == -1) {
            var11 = var15;
         }

         if (var12 != -1) {
            var0.renderer.triangles.triangle(var10, var12, var15);
         }

         var12 = var15;
      }
   }

   private static void line(Render3DEvent var0, double var1, double var3, double var5, double var7, double var9, double var11, Color var13) {
      var0.renderer.line(var1, var3, var5, var7, var9, var11, var13);
   }

   private static void perimeter(Render3DEvent var0, double var1, double var3, double var5, double var7, double var9, Color var11) {
      line(var0, var1, var3, var5, var7, var3, var5, var11);
      line(var0, var7, var3, var5, var7, var3, var9, var11);
      line(var0, var7, var3, var9, var1, var3, var9, var11);
      line(var0, var1, var3, var9, var1, var3, var5, var11);
   }

   private static void drawScanner(
      Render3DEvent var0, double var1, double var3, double var5, double var7, double var9, double var11, Color var13, long var14, double var16
   ) {
      double var18 = (var14 + (long)var16) % 2400L / 2400.0;
      double var20 = var1 + (var3 - var1) * var18;
      double var22 = var7 - (var7 - var5) * var18;
      int var24 = alpha(var13, 0.9 * Math.sin(Math.PI * var18));
      Color var25 = color(var13, 1.38, var24);
      var0.renderer.line(var20, var11 + 0.27, var5 + var9, var20, var11 + 0.27, var7 - var9, var25);
      var0.renderer.line(var1 + var9, var11 + 0.28, var22, var3 - var9, var11 + 0.28, var22, var25);
   }

   private static void drawSpinner(Render3DEvent var0, double var1, double var3, double var5, double var7, Color var9, double var10, double var12) {
      double var14 = var5 * (0.29 + var12 * 0.025);
      Color var16 = color(var9, 1.06, alpha(var9, 0.68 + var12 * 0.3));
      Color var17 = color(var9, 1.32, alpha(var9, 0.46 + var12 * 0.25));
      rotatingDiamond(var0, var1, var7 + 0.31, var3, var14, var10 * 0.72, var16);
      rotatingDiamond(var0, var1, var7 + 0.34, var3, var14 * 0.62, -var10 * 1.08, var17);
   }

   private static void drawWave(Render3DEvent var0, double var1, double var3, double var5, double var7, Color var9, long var10, double var12) {
      double var14 = (var10 + (long)var12) % 1800L / 1800.0;
      double var16 = var5 * (0.64 + 0.34 * var14);
      Color var18 = color(var9, 1.15, alpha(var9, 0.72 * (1.0 - var14)));
      rectangle(var0, var1 - var16, var7 + 0.34 + var14 * 0.58, var3 - var16, var1 + var16, var3 + var16, var18);
   }

   private static void rectangle(Render3DEvent var0, double var1, double var3, double var5, double var7, double var9, Color var11) {
      var0.renderer.line(var1, var3, var5, var7, var3, var5, var11);
      var0.renderer.line(var7, var3, var5, var7, var3, var9, var11);
      var0.renderer.line(var7, var3, var9, var1, var3, var9, var11);
      var0.renderer.line(var1, var3, var9, var1, var3, var5, var11);
   }

   private static void rotatingDiamond(Render3DEvent var0, double var1, double var3, double var5, double var7, double var9, Color var11) {
      double[] var12 = new double[4];
      double[] var13 = new double[4];

      for (int var14 = 0; var14 < 4; var14++) {
         double var15 = var9 + (Math.PI / 2) * var14;
         var12[var14] = var1 + Math.cos(var15) * var7;
         var13[var14] = var5 + Math.sin(var15) * var7;
      }

      for (int var17 = 0; var17 < 4; var17++) {
         int var18 = var17 + 1 & 3;
         var0.renderer.line(var12[var17], var3, var13[var17], var12[var18], var3, var13[var18], var11);
      }
   }

   private static Color color(Color var0, double var1, int var3) {
      return new Color(clamp((int)Math.round(var0.r * var1)), clamp((int)Math.round(var0.g * var1)), clamp((int)Math.round(var0.b * var1)), clamp(var3));
   }

   private static int alpha(Color var0, double var1) {
      return clamp((int)Math.round(var0.a * var1));
   }

   private static int clamp(int var0) {
      return Math.max(0, Math.min(255, var0));
   }

   private static boolean hasBaseSignal(ChunkLightSnapshot var0) {
      int var1 = var0.sectionCount + 1;

      for (int var2 = 1; var2 < var1; var2++) {
         int var3 = (var0.bottomSectionY + (var2 - 1)) * 16 + 15;
         if (var3 < 62 && var0.sky[var2] == SectionStatus.ZEROED_PRESENT) {
            return true;
         }
      }

      return false;
   }
}
