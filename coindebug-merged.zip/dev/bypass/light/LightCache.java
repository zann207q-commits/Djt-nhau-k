package dev.bypass.light;

import dev.bypass.BypassAddon;
import dev.bypass.modules.Bypass;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1923;
import net.minecraft.class_310;
import net.minecraft.class_638;

public final class LightCache {
   public static final LightCache INSTANCE = new LightCache();
   public static final Long2ObjectOpenHashMap<ChunkLightSnapshot> SNAPSHOTS = new Long2ObjectOpenHashMap();
   private static final LongOpenHashSet ALERTED = new LongOpenHashSet();
   public static final int ALERT_MIN_Y = -64;
   public static final int ALERT_MAX_Y = 184;
   public static final int BASE_DETECT_CEILING_Y = 62;
   private static final int MAX_DRAIN_PER_TICK = 4096;
   private class_638 lastWorld = null;

   private LightCache() {
   }

   public static void register() {
      MeteorClient.EVENT_BUS.subscribe(INSTANCE);
   }

   public static boolean isChunkAlerted(long chunkKey) {
      return ALERTED.contains(chunkKey);
   }

   @EventHandler
   private void onTickPre(Pre event) {
      class_310 mc = class_310.method_1551();
      class_638 world = mc.field_1687;
      if (world != this.lastWorld) {
         if (!SNAPSHOTS.isEmpty()) {
            SNAPSHOTS.clear();
         }

         if (!ALERTED.isEmpty()) {
            ALERTED.clear();
         }

         PacketIntake.QUEUE.clear();
         this.lastWorld = world;
      }

      if (world != null) {
         if (mc.field_1724 != null && mc.field_1724.method_23318() < 0.0) {
            PacketIntake.QUEUE.clear();
         } else {
            int sectionCount = world.method_32890();
            int bottomSectionY = world.method_32891();
            int drained = 0;

            PacketIntake.PendingLight pending;
            while ((pending = PacketIntake.QUEUE.poll()) != null) {
               ingest(pending, sectionCount, bottomSectionY);
               if (++drained >= 4096) {
                  break;
               }
            }
         }
      }
   }

   private static void ingest(PacketIntake.PendingLight p, int sectionCount, int bottomSectionY) {
      long key = class_1923.method_8331(p.chunkX(), p.chunkZ());
      ChunkLightSnapshot snap = (ChunkLightSnapshot)SNAPSHOTS.get(key);
      if (snap == null || snap.sectionCount != sectionCount || snap.bottomSectionY != bottomSectionY) {
         snap = new ChunkLightSnapshot(p.chunkX(), p.chunkZ(), sectionCount, bottomSectionY);
         SNAPSHOTS.put(key, snap);
      }

      try {
         LightDataClassifier.apply(p.data(), snap, p.arrivalNanos());
      } catch (Throwable var7) {
         BypassAddon.LOG.error("[Player Debug V2] LightDataClassifier crashed on chunk " + p.chunkX() + "," + p.chunkZ(), var7);
         return;
      }

      maybeAlert(p.chunkX(), p.chunkZ(), key, snap);
   }

   private static void maybeAlert(int cx, int cz, long key, ChunkLightSnapshot snap) {
      if (!ALERTED.contains(key)) {
         Bypass module = (Bypass)Modules.get().get(Bypass.class);
         if (module != null && module.isActive()) {
            int last = snap.sectionCount + 1;

            for (int i = 1; i < last; i++) {
               int sectionTopY = (snap.bottomSectionY + (i - 1)) * 16 + 15;
               int sectionBottomY = (snap.bottomSectionY + (i - 1)) * 16;
               if (sectionTopY >= -64 && sectionBottomY <= 184 && sectionTopY < 62 && snap.sky[i] == SectionStatus.ZEROED_PRESENT) {
                  ALERTED.add(key);
                  module.onChunkSpotted(cx, cz);
                  return;
               }
            }
         }
      }
   }
}
