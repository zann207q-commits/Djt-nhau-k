package dev.bypass.light;

import java.util.BitSet;
import java.util.List;
import net.minecraft.class_6606;

public final class LightDataClassifier {
   private static final int NIBBLES_PER_SECTION = 2048;

   private LightDataClassifier() {
   }

   public static SectionStatus classifyPayload(byte[] nibbles) {
      if (nibbles != null && nibbles.length == 2048) {
         boolean allZero = true;
         boolean allFf = true;

         for (byte b : nibbles) {
            if (b != 0) {
               allZero = false;
            }

            if (b != -1) {
               allFf = false;
            }

            if (!allZero && !allFf) {
               return SectionStatus.NORMAL;
            }
         }

         if (allZero) {
            return SectionStatus.ZEROED_PRESENT;
         } else {
            return allFf ? SectionStatus.UNIFORM_MAX : SectionStatus.NORMAL;
         }
      } else {
         return SectionStatus.UNKNOWN;
      }
   }

   public static void apply(class_6606 data, ChunkLightSnapshot snap, long nowNanos) {
      applyTrack(data.method_38608(), data.method_38609(), data.method_38610(), snap.block, snap.blockUpdatedNanos, nowNanos);
      applyTrack(data.method_38601(), data.method_38604(), data.method_38606(), snap.sky, snap.skyUpdatedNanos, nowNanos);
   }

   private static void applyTrack(BitSet inited, BitSet uninited, List<byte[]> nibbleList, SectionStatus[] out, long[] updatedNanos, long nowNanos) {
      int payloadIdx = 0;
      int n = out.length;

      for (int i = 0; i < n; i++) {
         if (inited.get(i)) {
            byte[] nibbles = payloadIdx < nibbleList.size() ? nibbleList.get(payloadIdx) : null;
            payloadIdx++;
            out[i] = classifyPayload(nibbles);
            updatedNanos[i] = nowNanos;
         } else if (uninited.get(i)) {
            out[i] = SectionStatus.EMPTY_MASK;
            updatedNanos[i] = nowNanos;
         }
      }
   }
}
