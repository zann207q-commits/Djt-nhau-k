package dev.bypass.modules;

import dev.bypass.BypassAddon;
import meteordevelopment.meteorclient.systems.modules.Module;

public class BlockAnomalyDebug extends Module {
   public BlockAnomalyDebug() {
      super(BypassAddon.CATEGORY, "block-anomaly-debug", "Detects block anomaly signatures.");
   }

   public int getMinY() {
      return -64;
   }

   public int getMaxY() {
      return 320;
   }

   public void onChunkSpotted(int cx, int cz) {
   }
}
