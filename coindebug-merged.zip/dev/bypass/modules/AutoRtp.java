package dev.bypass.modules;

import dev.bypass.BypassAddon;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent.Pre;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;

public class AutoRtp extends Module {
   private static final String[] REGIONS = new String[]{"/rtp asia", "/rtp eu central", "/rtp eu west", "/rtp eu oceania", "/rtp east", "/rtp west"};
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final Setting<String> command = this.sgGeneral
      .add(
         ((Builder)((Builder)((Builder)new Builder().name("command")).description("The command run on each interval when rtp-to-random-region is off."))
               .defaultValue("/rtp"))
            .build()
      );
   private final Setting<Double> delay = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)((meteordevelopment.meteorclient.settings.DoubleSetting.Builder)new meteordevelopment.meteorclient.settings.DoubleSetting.Builder()
                  .name("delay"))
               .description("Delay between /rtp commands in seconds."))
            .defaultValue(1.0)
            .min(0.05)
            .sliderRange(0.05, 10.0)
            .decimalPlaces(2)
            .build()
      );
   private final Setting<Boolean> rtpToRandomRegion = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("rtp-to-random-region"))
                  .description("Cycle through every region in a random order instead of a plain /rtp."))
               .defaultValue(false))
            .build()
      );
   private final List<String> queue = new ArrayList<>();
   private long lastSent;

   public AutoRtp() {
      super(BypassAddon.CATEGORY, "auto-rtp", "Runs /rtp on a timer.");
   }

   public void onActivate() {
      this.lastSent = 0L;
      this.queue.clear();
   }

   @EventHandler
   private void onTick(Pre var1) {
      if (this.mc.field_1724 != null && this.mc.method_1562() != null) {
         long var2 = System.currentTimeMillis();
         if (var2 - this.lastSent >= (long)((Double)this.delay.get() * 1000.0)) {
            this.lastSent = var2;
            if ((Boolean)this.rtpToRandomRegion.get()) {
               if (this.queue.isEmpty()) {
                  Collections.addAll(this.queue, REGIONS);
                  Collections.shuffle(this.queue);
               }

               ChatUtils.sendPlayerMsg(this.queue.remove(0));
            } else {
               ChatUtils.sendPlayerMsg((String)this.command.get());
            }
         }
      }
   }
}
