package dev.bypass.modules;

import dev.bypass.BypassAddon;
import dev.bypass.license.LicenseConfig;
import dev.bypass.license.LicenseGate;
import dev.bypass.light.LightCache;
import dev.bypass.render.LightInspectorRenderer;
import dev.bypass.render.PlateAnimation;
import dev.bypass.render.SignalToasts;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.concurrent.CompletableFuture;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.widgets.WWidget;
import meteordevelopment.meteorclient.gui.widgets.containers.WVerticalList;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.DoubleSetting.Builder;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_1923;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public class Bypass extends Module {
   private static final int RENDER_DISTANCE_CHUNKS = 16;
   private static final Path DISCONNECTED_CHUNKS_PATH = Path.of("signal_debug_disconnected_chunks.txt");
   private static LongOpenHashSet disconnectedChunks;
   private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
   private final SettingGroup sgAlerts = this.settings.createGroup("Alerts");
   private final Setting<Double> plateSize = this.sgGeneral
      .add(
         ((Builder)((Builder)new Builder().name("size")).description("Size of the animated chunk plate in blocks."))
            .defaultValue(28.0)
            .range(16.0, 96.0)
            .sliderRange(16.0, 64.0)
            .decimalPlaces(1)
            .build()
      );
   private final Setting<SettingColor> flagColor = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.ColorSetting.Builder)((meteordevelopment.meteorclient.settings.ColorSetting.Builder)new meteordevelopment.meteorclient.settings.ColorSetting.Builder()
                  .name("flag-color"))
               .description("Color of the plate and all of its animation effects."))
            .defaultValue(new SettingColor(255, 210, 25, 210))
            .build()
      );
   private final Setting<PlateAnimation> plateAnimation = this.sgGeneral
      .add(
         ((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)((meteordevelopment.meteorclient.settings.EnumSetting.Builder)new meteordevelopment.meteorclient.settings.EnumSetting.Builder()
                     .name("plate-animation"))
                  .description("Animation style for spotted and test plates. All combines every effect."))
               .defaultValue(PlateAnimation.All))
            .build()
      );
   private final Setting<Boolean> kickOnFlag = this.sgAlerts
      .add(
         ((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)((meteordevelopment.meteorclient.settings.BoolSetting.Builder)new meteordevelopment.meteorclient.settings.BoolSetting.Builder()
                     .name("disconnect-on-chunk"))
                  .description("Disconnect immediately when a new chunk is spotted."))
               .defaultValue(false))
            .build()
      );

   private static LongOpenHashSet loadDisconnectedChunks() {
      if (disconnectedChunks == null) {
         disconnectedChunks = new LongOpenHashSet();

         try {
            if (Files.exists(DISCONNECTED_CHUNKS_PATH)) {
               for (String var1 : Files.readAllLines(DISCONNECTED_CHUNKS_PATH)) {
                  String var2 = var1.trim();
                  if (!var2.isEmpty()) {
                     try {
                        disconnectedChunks.add(Long.parseLong(var2));
                     } catch (NumberFormatException var4) {
                     }
                  }
               }
            }
         } catch (IOException var5) {
         }
      }

      return disconnectedChunks;
   }

   private static void rememberDisconnectedChunk(long var0) {
      LongOpenHashSet var2 = loadDisconnectedChunks();
      if (var2.add(var0)) {
         try {
            Files.writeString(DISCONNECTED_CHUNKS_PATH, var0 + System.lineSeparator(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
         } catch (IOException var4) {
         }
      }
   }

   public Bypass() {
      super(BypassAddon.CATEGORY, "player-debug-v2", "Player Debug V2");
   }

   public void onActivate() {
      CompletableFuture.runAsync(() -> {
         LicenseGate.Result var1 = LicenseGate.check();
         this.mc.execute(() -> {
            if (var1 != LicenseGate.Result.OK) {
               String var2 = switch (var1) {
                  case NO_KEY_FILE -> "No license key found. Add yours to: " + LicenseConfig.getPath();
                  case DENIED -> "License invalid or revoked.";
                  case NETWORK_ERROR -> "Could not reach license server.";
                  default -> "License check failed.";
               };
               ChatUtils.error("(Player Debug V2) " + var2, new Object[0]);
               if (this.isActive()) {
                  this.toggle();
               }
            }
         });
      });
   }

   public void onChunkSpotted(int var1, int var2) {
      int var3 = (var1 << 4) + 8;
      int var4 = (var2 << 4) + 8;
      sendFlagChat(var3, var4, false);
      SignalToasts.add(var3, var4);
      if ((Boolean)this.kickOnFlag.get()) {
         long var5 = class_1923.method_8331(var1, var2);
         if (!loadDisconnectedChunks().contains(var5)) {
            rememberDisconnectedChunk(var5);
            ChatUtils.warning("(Player Debug V2) Disconnect-on-chunk triggered. Saving the coordinates and disconnecting.", new Object[0]);
            this.mc.execute(() -> this.mc.method_73360(class_2561.method_43470("Player Debug V2: chunk spotted at X: " + var3 + " Z: " + var4)));
         }
      }
   }

   private static void sendFlagChat(int var0, int var1, boolean var2) {
      class_5250 var3 = class_2561.method_43470("✦ PLAYER DEBUG V2 ✦ ").method_27695(new class_124[]{class_124.field_1076, class_124.field_1067});
      var3.method_10852(
         class_2561.method_43470(var2 ? "TEST FLAG " : "FLAG SPOTTED ").method_27695(new class_124[]{class_124.field_1054, class_124.field_1067})
      );
      var3.method_10852(class_2561.method_43470("• X: " + var0 + "  Z: " + var1).method_27692(class_124.field_1068));
      ChatUtils.sendMsg(var3);
   }

   @EventHandler
   private void onRender3d(Render3DEvent var1) {
      if (this.mc.field_1687 != null && this.mc.field_1724 != null) {
         int var2 = this.mc.field_1724.method_24515().method_10263() >> 4;
         int var3 = this.mc.field_1724.method_24515().method_10260() >> 4;
         LightInspectorRenderer.draw(
            var1,
            LightCache.SNAPSHOTS,
            var2,
            var3,
            16,
            (Double)this.plateSize.get(),
            (Color)this.flagColor.get(),
            (PlateAnimation)this.plateAnimation.get()
         );
      }
   }
}
