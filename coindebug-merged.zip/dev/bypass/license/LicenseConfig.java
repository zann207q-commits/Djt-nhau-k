package dev.bypass.license;

import java.nio.file.Path;

public final class LicenseConfig {
   private LicenseConfig() {
   }

   public static Path getPath() {
      return Path.of("license.key");
   }
}
