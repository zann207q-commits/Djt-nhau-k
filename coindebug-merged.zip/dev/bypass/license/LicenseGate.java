package dev.bypass.license;

public final class LicenseGate {
   private LicenseGate() {
   }

   public static LicenseGate.Result check() {
      return LicenseGate.Result.OK;
   }

   public static enum Result {
      OK,
      NO_KEY_FILE,
      DENIED,
      NETWORK_ERROR;
   }
}
