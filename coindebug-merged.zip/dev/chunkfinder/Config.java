package dev.chunkfinder;

/** All tunables in one place. Values mirror the behaviour of the original module. */
public final class Config {
    private Config() {}

    // Vertical scan window
    public static final int MIN_Y = 20;
    public static final int MAX_Y = 60;

    // Detection thresholds
    public static final int MIN_PISTONS = 5;
    public static final int MIN_DRIPSTONE_LENGTH = 16;
    public static final int MIN_PLUG_COLUMN = 25;
    public static final int MIN_HOLE_DEPTH = 8;
    public static final int MIN_UNDERGROUND_COVER = 3;

    // Features
    public static boolean holeEsp = true;
    public static boolean detectTraders = false;
    public static boolean detectCherryGrove = true;
    public static boolean chatNotifications = true;

    // Cherry grove
    public static final long CHERRY_DELAY_MS = 200L;
    public static final int CHERRY_MIN_DISTANCE = 100;

    // Performance
    public static final int LOW_FPS = 8;
    public static final long LAG_PAUSE_MS = 10_000L;
    public static final long CLEANUP_INTERVAL_MS = 5_000L;
    public static final long HOLE_SCAN_COOLDOWN_MS = 1_000L;
    public static final long TRADER_SCAN_COOLDOWN_MS = 2_000L;

    // Render colours (ARGB as floats 0..1)
    public static final float[] COL_ROTATED_DEEPSLATE = {0.78f, 0.00f, 1.00f, 0.47f};
    public static final float[] COL_DRIPSTONE         = {1.00f, 0.71f, 0.39f, 0.47f};
    public static final float[] COL_PISTON            = {0.00f, 0.78f, 1.00f, 0.47f};
    public static final float[] COL_PLUG              = {0.00f, 1.00f, 0.00f, 0.47f};
    public static final float[] COL_HOLE              = {0.00f, 0.00f, 0.00f, 0.39f};
    public static final float[] COL_CHUNK             = {1.00f, 1.00f, 1.00f, 0.31f};
    public static final float[] COL_TRADER            = {0.00f, 1.00f, 0.00f, 0.47f};
}
