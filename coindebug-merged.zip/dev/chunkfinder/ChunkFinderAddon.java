package dev.chunkfinder;

import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Modules;
import x10n.flatslice.FlatSliceAddon;

public class ChunkFinderAddon extends MeteorAddon {
    @Override
    public void onInitialize() {
        Modules.get().add(new ChunkFinderModule(FlatSliceAddon.CATEGORY));
    }

    @Override
    public String getPackage() {
        return "dev.chunkfinder";
    }
}
