package dev.chunkfinder;

import net.minecraft.util.math.BlockPos;

public record Finding(BlockPos pos, Type type) {
    public enum Type {
        ROTATED_DEEPSLATE("Rotated deepslate", Config.COL_ROTATED_DEEPSLATE),
        LONG_DRIPSTONE("Long dripstone column", Config.COL_DRIPSTONE),
        PISTONS("Pistons", Config.COL_PISTON),
        PLUGGED_SHAFT("Plugged shaft", Config.COL_PLUG);

        public final String label;
        public final float[] color;

        Type(String label, float[] color) {
            this.label = label;
            this.color = color;
        }
    }
}
