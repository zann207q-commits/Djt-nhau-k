package dev.chunkfinder;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.PillarBlock;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.BooleanSupplier;

/**
 * Pure world-reading detection logic. Safe to call from a background thread.
 * Block sets marked APPROXIMATE were reconstructed and may need tuning.
 */
public final class Scanner {
    private Scanner() {}

    private static final Direction[] ALL = Direction.values();

    // APPROXIMATE: blocks players use to plug a shaft.
    private static boolean isPlugBlock(Block b) {
        return b == Blocks.DIRT || b == Blocks.GRAVEL || b == Blocks.COBBLESTONE || b == Blocks.STONE
                || b == Blocks.DEEPSLATE || b == Blocks.COBBLED_DEEPSLATE;
    }

    private static boolean isRotatedDeepslate(BlockState s) {
        if (s.getBlock() != Blocks.DEEPSLATE || !s.contains(PillarBlock.AXIS)) return false;
        Direction.Axis axis = s.get(PillarBlock.AXIS);
        return axis == Direction.Axis.X || axis == Direction.Axis.Z;
    }

    private static boolean solid(ClientWorld w, BlockPos p) {
        BlockState s = w.getBlockState(p);
        return !s.isAir() && s.isFullCube(w, p);
    }

    /** All six neighbours are non-air solid blocks. */
    private static boolean isCovered(ClientWorld w, BlockPos p) {
        for (Direction d : ALL) {
            if (!solid(w, p.offset(d))) return false;
        }
        return true;
    }

    /** At least a few solid blocks overhead within 50..80 blocks. */
    private static boolean isUnderground(ClientWorld w, BlockPos p) {
        int top = Math.min(p.getY() + 50, 80);
        int count = 0;
        for (int y = p.getY() + 1; y <= top; y++) {
            if (solid(w, new BlockPos(p.getX(), y, p.getZ()))) count++;
        }
        return count >= Config.MIN_UNDERGROUND_COVER;
    }

    private static int dripstoneLength(WorldChunk chunk, BlockPos start) {
        int len = 0;
        BlockPos.Mutable m = start.mutableCopy();
        int top = chunk.getBottomY() + chunk.getHeight();
        while (m.getY() < top && chunk.getBlockState(m).getBlock() == Blocks.DRIPSTONE_BLOCK) {
            len++;
            m.move(Direction.UP);
        }
        m.set(start).move(Direction.DOWN);
        while (m.getY() >= chunk.getBottomY() && chunk.getBlockState(m).getBlock() == Blocks.DRIPSTONE_BLOCK) {
            len++;
            m.move(Direction.DOWN);
        }
        return len;
    }

    /** Scan one chunk for structure indicators. */
    public static List<Finding> scanChunk(ClientWorld world, WorldChunk chunk, BooleanSupplier stop) {
        List<Finding> out = new ArrayList<>();
        int startX = chunk.getPos().getStartX();
        int startZ = chunk.getPos().getStartZ();
        int minY = Math.max(chunk.getBottomY(), Config.MIN_Y);
        int maxY = Math.min(chunk.getBottomY() + chunk.getHeight(), Config.MAX_Y);
        int pistons = 0;

        for (int x = startX; x < startX + 16; x++) {
            for (int z = startZ; z < startZ + 16; z++) {
                for (int y = minY; y < maxY; y++) {
                    if (stop.getAsBoolean()) return out;
                    BlockPos p = new BlockPos(x, y, z);
                    BlockState s;
                    try {
                        s = chunk.getBlockState(p);
                    } catch (Exception e) {
                        continue;
                    }
                    Block b = s.getBlock();
                    if (b == Blocks.PISTON || b == Blocks.STICKY_PISTON) pistons++;

                    if (y > Config.MIN_Y && y < Config.MAX_Y && isRotatedDeepslate(s)
                            && isCovered(world, p) && isUnderground(world, p)) {
                        out.add(new Finding(p, Finding.Type.ROTATED_DEEPSLATE));
                    }
                    if (b == Blocks.DRIPSTONE_BLOCK
                            && dripstoneLength(chunk, p) >= Config.MIN_DRIPSTONE_LENGTH
                            && isCovered(world, p) && isUnderground(world, p)) {
                        out.add(new Finding(p, Finding.Type.LONG_DRIPSTONE));
                    }
                }
            }
        }

        // Plugged shafts: >= 25 identical plug blocks stacked vertically, fully enclosed.
        for (int x = startX; x < startX + 16; x++) {
            for (int z = startZ; z < startZ + 16; z++) {
                int run = 0;
                Block last = null;
                List<BlockPos> column = new ArrayList<>();
                for (int y = minY; y <= maxY; y++) {
                    if (stop.getAsBoolean()) return out;
                    BlockPos p = new BlockPos(x, y, z);
                    Block b = chunk.getBlockState(p).getBlock();
                    if (!isPlugBlock(b)) {
                        run = 0;
                        last = null;
                        column.clear();
                        continue;
                    }
                    if (last != null && b != last) {
                        run = 1;
                        column.clear();
                    } else {
                        run++;
                    }
                    last = b;
                    column.add(p);
                    if (run >= Config.MIN_PLUG_COLUMN && columnEnclosed(world, column)) {
                        for (BlockPos c : column) {
                            if (isUnderground(world, c)) out.add(new Finding(c, Finding.Type.PLUGGED_SHAFT));
                        }
                        column.clear();
                        run = 0;
                    }
                }
            }
        }

        if (pistons >= Config.MIN_PISTONS) {
            for (int x = startX; x < startX + 16; x++)
                for (int z = startZ; z < startZ + 16; z++)
                    for (int y = minY; y < maxY; y++) {
                        BlockPos p = new BlockPos(x, y, z);
                        Block b = chunk.getBlockState(p).getBlock();
                        if (b == Blocks.PISTON || b == Blocks.STICKY_PISTON)
                            out.add(new Finding(p, Finding.Type.PISTONS));
                    }
        }
        return out;
    }

    private static boolean columnEnclosed(ClientWorld w, List<BlockPos> column) {
        for (BlockPos p : column) {
            for (Direction d : Direction.Type.HORIZONTAL) {
                BlockPos n = p.offset(d);
                if (!solid(w, n)) return false;
            }
        }
        return true;
    }

    // ---------------------------------------------------------------- holes

    private static boolean air(ClientWorld w, BlockPos p) {
        return w.getBlockState(p).isAir();
    }

    /** Scan a chunk for deep 1x1 and 3x1 air shafts. */
    public static void scanHoles(ClientWorld world, WorldChunk chunk, Set<Box> holes1x1, Set<Box> holes3x1,
                                 BooleanSupplier stop) {
        int startX = chunk.getPos().getStartX();
        int startZ = chunk.getPos().getStartZ();
        int minY = Math.max(chunk.getBottomY(), Config.MIN_Y);
        int maxY = Math.min(chunk.getBottomY() + chunk.getHeight(), Config.MAX_Y);
        for (int x = startX; x < startX + 16; x++)
            for (int z = startZ; z < startZ + 16; z++)
                for (int y = minY; y < maxY; y++) {
                    if (stop.getAsBoolean()) return;
                    BlockPos p = new BlockPos(x, y, z);
                    try {
                        check1x1(world, p, holes1x1);
                        check3x1(world, p, holes3x1);
                    } catch (Exception ignored) {
                    }
                }
    }

    private static boolean valid1x1(ClientWorld w, BlockPos p) {
        if (!air(w, p)) return false;
        for (Direction d : Direction.Type.HORIZONTAL) {
            if (air(w, p.offset(d))) return false;
        }
        return true;
    }

    private static void check1x1(ClientWorld w, BlockPos p, Set<Box> out) {
        if (!valid1x1(w, p)) return;
        BlockPos.Mutable m = p.mutableCopy();
        while (valid1x1(w, m)) m.move(Direction.UP);
        if (m.getY() - p.getY() >= Config.MIN_HOLE_DEPTH) {
            out.add(new Box(p.getX(), p.getY(), p.getZ(), p.getX() + 1, m.getY(), p.getZ() + 1));
        }
    }

    private static boolean valid3x1X(ClientWorld w, BlockPos p) {
        return air(w, p) && air(w, p.east()) && air(w, p.east(2))
                && !air(w, p.west()) && !air(w, p.east(3))
                && !air(w, p.north()) && !air(w, p.south())
                && !air(w, p.east().north()) && !air(w, p.east().south())
                && !air(w, p.east(2).north()) && !air(w, p.east(2).south());
    }

    private static boolean valid3x1Z(ClientWorld w, BlockPos p) {
        return air(w, p) && air(w, p.south()) && air(w, p.south(2))
                && !air(w, p.north()) && !air(w, p.south(3))
                && !air(w, p.west()) && !air(w, p.east())
                && !air(w, p.south().west()) && !air(w, p.south().east())
                && !air(w, p.south(2).west()) && !air(w, p.south(2).east());
    }

    private static void check3x1(ClientWorld w, BlockPos p, Set<Box> out) {
        if (valid3x1X(w, p)) {
            BlockPos.Mutable m = p.mutableCopy();
            while (valid3x1X(w, m)) m.move(Direction.UP);
            if (m.getY() - p.getY() >= Config.MIN_HOLE_DEPTH) {
                out.add(new Box(p.getX(), p.getY(), p.getZ(), p.getX() + 3, m.getY(), p.getZ() + 1));
            }
        }
        if (valid3x1Z(w, p)) {
            BlockPos.Mutable m = p.mutableCopy();
            while (valid3x1Z(w, m)) m.move(Direction.UP);
            if (m.getY() - p.getY() >= Config.MIN_HOLE_DEPTH) {
                out.add(new Box(p.getX(), p.getY(), p.getZ(), p.getX() + 1, m.getY(), p.getZ() + 3));
            }
        }
    }
}
