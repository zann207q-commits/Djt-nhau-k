package dev.chunkfinder;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.TraderLlamaEntity;
import net.minecraft.entity.passive.WanderingTraderEntity;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeKeys;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * ChunkFinder ported from the standalone Fabric mod to a Meteor module.
 * Scanning logic lives in {@link Scanner}; this class only schedules scans and draws results.
 * The G keybind is replaced by the normal Meteor module bind.
 */
public class ChunkFinderModule extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Boolean> holeEsp = sg.add(new BoolSetting.Builder()
        .name("hole-esp").description("Highlight deep 1x1 and 3x1 air shafts.").defaultValue(true).build());
    private final Setting<Boolean> traders = sg.add(new BoolSetting.Builder()
        .name("wandering-traders").description("Flag chunks with wandering traders / trader llamas.").defaultValue(false).build());
    private final Setting<Boolean> cherry = sg.add(new BoolSetting.Builder()
        .name("cherry-grove").description("Flag Cherry Grove chunks (at least 100 blocks apart).").defaultValue(true).build());
    private final Setting<Boolean> chat = sg.add(new BoolSetting.Builder()
        .name("chat-notifications").description("Print findings in chat.").defaultValue(true).build());

    private final Set<ChunkPos> scanned = ConcurrentHashMap.newKeySet();
    private final Set<ChunkPos> holeScanned = ConcurrentHashMap.newKeySet();
    private final Set<ChunkPos> notified = ConcurrentHashMap.newKeySet();
    private final Set<ChunkPos> cherryChunks = ConcurrentHashMap.newKeySet();
    private final Set<ChunkPos> traderChunks = ConcurrentHashMap.newKeySet();
    private final Set<Integer> notifiedTraders = ConcurrentHashMap.newKeySet();
    private final Map<ChunkPos, List<Finding>> flagged = new ConcurrentHashMap<>();
    private final Set<Box> holes1x1 = ConcurrentHashMap.newKeySet();
    private final Set<Box> holes3x1 = ConcurrentHashMap.newKeySet();

    private ExecutorService worker;
    private Future<?> scanTask, holeTask;
    private volatile boolean stop;
    private boolean pausedForLag;
    private long lagPauseStart, lastHoleScan, lastCleanup, lastTraderScan;

    private boolean inCherry, cherryPending;
    private long cherryEnter;
    private ChunkPos lastCherryFlag;

    public ChunkFinderModule(Category category) {
        super(category, "chunk-finder", "Scans loaded chunks (Y20-60) for rotated deepslate, long dripstone, pistons, plugged shafts, deep holes and cherry groves.");
    }

    // ------------------------------------------------------------ lifecycle

    @Override
    public void onActivate() {
        clearAll();
        stop = false;
        pausedForLag = false;
        worker = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "ChunkFinder-Scanner");
            t.setDaemon(true);
            t.setPriority(Thread.MIN_PRIORITY);
            return t;
        });
    }

    @Override
    public void onDeactivate() {
        stop = true;
        cancel(scanTask);
        cancel(holeTask);
        if (worker != null) worker.shutdownNow();
        worker = null;
        clearAll();
    }

    private void clearAll() {
        scanned.clear(); holeScanned.clear(); notified.clear(); cherryChunks.clear();
        traderChunks.clear(); notifiedTraders.clear(); flagged.clear(); holes1x1.clear(); holes3x1.clear();
        lastCherryFlag = null; inCherry = false; cherryPending = false;
    }

    private static void cancel(Future<?> f) {
        if (f != null && !f.isDone()) f.cancel(true);
    }

    // ----------------------------------------------------------------- tick

    @EventHandler
    private void onTick(TickEvent.Post event) {
        ClientWorld world = mc.world;
        if (world == null || mc.player == null || worker == null) return;

        Config.holeEsp = holeEsp.get();
        Config.detectTraders = traders.get();
        Config.detectCherryGrove = cherry.get();
        Config.chatNotifications = chat.get();

        long now = System.currentTimeMillis();

        if (mc.getCurrentFps() < Config.LOW_FPS && mc.player.age > 100 && !pausedForLag) {
            pausedForLag = true;
            lagPauseStart = now;
            cancel(scanTask);
            cancel(holeTask);
        }
        if (pausedForLag) {
            if (now - lagPauseStart < Config.LAG_PAUSE_MS) return;
            pausedForLag = false;
        }

        if (Config.detectCherryGrove) checkCherry(world, now);
        if (Config.detectTraders && now - lastTraderScan > Config.TRADER_SCAN_COOLDOWN_MS) {
            scanTraders(world);
            lastTraderScan = now;
        }

        if (scanTask == null || scanTask.isDone()) scanTask = worker.submit(() -> scanChunks(world));
        if (Config.holeEsp && now - lastHoleScan > Config.HOLE_SCAN_COOLDOWN_MS
            && (holeTask == null || holeTask.isDone())) {
            holeTask = worker.submit(() -> scanHoles(world));
            lastHoleScan = now;
        }
        if (now - lastCleanup > Config.CLEANUP_INTERVAL_MS) {
            cleanupDistant();
            lastCleanup = now;
        }
    }

    // ----------------------------------------------------------- scanning

    private List<WorldChunk> loadedChunks(ClientWorld world) {
        List<WorldChunk> list = new ArrayList<>();
        if (mc.player == null) return list;
        int r = mc.options.getViewDistance().getValue();
        int cx = mc.player.getChunkPos().x, cz = mc.player.getChunkPos().z;
        for (int x = cx - r; x <= cx + r; x++)
            for (int z = cz - r; z <= cz + r; z++) {
                WorldChunk c = world.getChunkManager().getChunk(x, z, ChunkStatus.FULL, false);
                if (c != null && !c.isEmpty()) list.add(c);
            }
        return list;
    }

    private void scanChunks(ClientWorld world) {
        try {
            for (WorldChunk chunk : loadedChunks(world)) {
                if (stop || pausedForLag) return;
                ChunkPos pos = chunk.getPos();
                if (scanned.contains(pos)) continue;
                List<Finding> found = Scanner.scanChunk(world, chunk, () -> stop || pausedForLag);
                if (stop || pausedForLag) return;
                if (!found.isEmpty()) {
                    flagged.put(pos, found);
                    if (notified.add(pos)) notifyChunk(pos, found);
                } else {
                    flagged.remove(pos);
                }
                scanned.add(pos);
                Thread.sleep(5);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (Exception ignored) {
        }
    }

    private void scanHoles(ClientWorld world) {
        try {
            for (WorldChunk chunk : loadedChunks(world)) {
                if (stop || pausedForLag) return;
                ChunkPos pos = chunk.getPos();
                if (holeScanned.contains(pos)) continue;
                Scanner.scanHoles(world, chunk, holes1x1, holes3x1, () -> stop || pausedForLag);
                holeScanned.add(pos);
                Thread.sleep(10);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (Exception ignored) {
        }
    }

    private void scanTraders(ClientWorld world) {
        for (Entity e : world.getEntities()) {
            if (e instanceof WanderingTraderEntity || e instanceof TraderLlamaEntity) {
                ChunkPos cp = e.getChunkPos();
                traderChunks.add(cp);
                if (notifiedTraders.add(e.getId())) {
                    msg("Trader found in chunk " + cp.x + ", " + cp.z + " (" + cp.getStartX() + ", " + cp.getStartZ() + ")");
                }
            }
        }
    }

    // --------------------------------------------------------- cherry grove

    private static boolean isCherry(RegistryEntry<Biome> entry) {
        if (entry == null) return false;
        RegistryKey<Biome> key = entry.getKey().orElse(null);
        return key != null && key.equals(BiomeKeys.CHERRY_GROVE);
    }

    private void checkCherry(ClientWorld world, long now) {
        BlockPos pos = mc.player.getBlockPos();
        boolean nowIn = isCherry(world.getBiome(pos));
        if (nowIn && !inCherry) {
            inCherry = true; cherryEnter = now; cherryPending = true;
        } else if (!nowIn && inCherry) {
            inCherry = false; cherryPending = false;
        }
        if (cherryPending && inCherry && now - cherryEnter >= Config.CHERRY_DELAY_MS) {
            ChunkPos cp = new ChunkPos(pos);
            if (shouldFlagCherry(cp)) {
                cherryChunks.add(cp);
                lastCherryFlag = cp;
                msg("Cherry grove chunk flagged at " + cp.getStartX() + ", " + cp.getStartZ());
            }
            cherryPending = false;
        }
    }

    private boolean shouldFlagCherry(ChunkPos cp) {
        if (cherryChunks.contains(cp)) return false;
        if (lastCherryFlag == null) return true;
        double dx = cp.x * 16 - lastCherryFlag.x * 16;
        double dz = cp.z * 16 - lastCherryFlag.z * 16;
        return Math.sqrt(dx * dx + dz * dz) >= Config.CHERRY_MIN_DISTANCE;
    }

    // ---------------------------------------------------------------- misc

    private void cleanupDistant() {
        if (mc.player == null) return;
        int r = mc.options.getViewDistance().getValue();
        int px = mc.player.getChunkPos().x, pz = mc.player.getChunkPos().z;
        scanned.removeIf(c -> far(c, px, pz, r));
        holeScanned.removeIf(c -> far(c, px, pz, r));
        cherryChunks.removeIf(c -> far(c, px, pz, r));
        traderChunks.removeIf(c -> far(c, px, pz, r));
        flagged.keySet().removeIf(c -> far(c, px, pz, r));
        holes1x1.removeIf(b -> far(new ChunkPos(BlockPos.ofFloored(b.minX, b.minY, b.minZ)), px, pz, r));
        holes3x1.removeIf(b -> far(new ChunkPos(BlockPos.ofFloored(b.minX, b.minY, b.minZ)), px, pz, r));
    }

    private static boolean far(ChunkPos c, int px, int pz, int r) {
        return Math.abs(c.x - px) > r || Math.abs(c.z - pz) > r;
    }

    private void notifyChunk(ChunkPos pos, List<Finding> found) {
        Finding first = found.get(0);
        BlockPos p = first.pos();
        String block = mc.world != null ? mc.world.getBlockState(p).getBlock().getName().getString() : "?";
        msg("Found " + first.type().label + " [" + block + "] at " + p.getX() + ", " + p.getY() + ", " + p.getZ()
            + " (" + found.size() + " blocks, chunk " + pos.x + ", " + pos.z + ")");
    }

    private void msg(String text) {
        if (!Config.chatNotifications) return;
        mc.execute(() -> {
            if (mc.player != null) info(text);
        });
    }

    // -------------------------------------------------------------- render

    private static Color color(float[] c) {
        return new Color((int) (c[0] * 255), (int) (c[1] * 255), (int) (c[2] * 255), (int) (Math.max(c[3], 0.8f) * 255));
    }

    private static void box(Render3DEvent e, double x1, double y1, double z1, double x2, double y2, double z2, float[] c) {
        Color col = color(c);
        e.renderer.box(x1, y1, z1, x2, y2, z2, col, col, ShapeMode.Lines, 0);
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (mc.player == null) return;

        for (Map.Entry<ChunkPos, List<Finding>> e : flagged.entrySet()) {
            ChunkPos c = e.getKey();
            box(event, c.getStartX(), 60, c.getStartZ(), c.getStartX() + 16, 61, c.getStartZ() + 16, Config.COL_CHUNK);
            for (Finding f : e.getValue()) {
                BlockPos p = f.pos();
                box(event, p.getX(), p.getY(), p.getZ(), p.getX() + 1, p.getY() + 1, p.getZ() + 1, f.type().color);
            }
        }
        for (ChunkPos c : cherryChunks)
            box(event, c.getStartX(), 60, c.getStartZ(), c.getStartX() + 16, 61, c.getStartZ() + 16, Config.COL_CHUNK);
        for (ChunkPos c : traderChunks)
            box(event, c.getStartX(), 60, c.getStartZ(), c.getStartX() + 16, 61, c.getStartZ() + 16, Config.COL_TRADER);
        if (Config.holeEsp) {
            for (Box b : holes1x1) box(event, b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ, Config.COL_HOLE);
            for (Box b : holes3x1) box(event, b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ, Config.COL_HOLE);
        }
    }
}
