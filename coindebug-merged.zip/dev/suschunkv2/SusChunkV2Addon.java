package dev.suschunkv2;

import com.mojang.logging.LogUtils;
import dev.suschunkv2.modules.SusChunkFinderV2;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Modules;
import org.slf4j.Logger;
import x10n.flatslice.FlatSliceAddon;

/** Sus Chunk Finder V2, merged into the Player Debug category. */
public class SusChunkV2Addon extends MeteorAddon {
    public static final Logger LOG = LogUtils.getLogger();

    @Override
    public void onInitialize() {
        try {
            Modules.get().add(new SusChunkFinderV2(FlatSliceAddon.CATEGORY));
        } catch (Throwable t) {
            LOG.error("SusChunkFinderV2 failed to initialise", t);
        }
    }

    @Override
    public String getPackage() {
        return "dev.suschunkv2";
    }
}
