# Z Debug V4 integration

- Embedded the `dev.zv3.modules.Bypass` module and its required obfuscated helper classes from `z-v4.jar` under `src/main/resources/`.
- Registered the module in `kren.debug.KrenDebug` using reflection, so the project does not need the original obfuscated class files on its compile classpath.
- Renamed the embedded module category to `Z Debug V4`.
- The original `dev.zv3.BypassAddon.onInitialize()` is intentionally not invoked, because it starts its own license/welcome flow. The module is registered from the existing Kren Debug addon instead.
- The obfuscated addon classes are embedded as `.class` resources, not reconstructed Java source.
- Build was not verified in this environment: Gradle wrapper attempted to download Gradle but network DNS access was unavailable. Please run `./gradlew build` in an environment with Gradle distribution/dependencies available, then test in Minecraft.
