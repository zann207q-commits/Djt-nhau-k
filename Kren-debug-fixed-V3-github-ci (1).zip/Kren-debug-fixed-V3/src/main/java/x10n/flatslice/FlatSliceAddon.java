package x10n.flatslice;

import kren.debug.KrenDebug;
import meteordevelopment.meteorclient.systems.modules.Category;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Compatibility category bridge for imported FlatSlice modules. */
public final class FlatSliceAddon {
    public static final Category CATEGORY = KrenDebug.CATEGORY;
    public static final Logger LOG = LoggerFactory.getLogger("FlatSlice");
    private FlatSliceAddon() {}
}
