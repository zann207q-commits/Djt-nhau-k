# Zinc modules integrated into Kren Debug

Integrated as Kren Debug modules: AdvancedStashFinder, BlockNotifier, ChunkFinderV2, KelpESP, LightESP, PlayerDetection, and BaseDigger.

Zinc's ChunkFinder is merged into the existing Kaze Chunk Finder instead of registering a duplicate finder. Kaze keeps its original scan/render engine and gains Zinc's above-natural-range normal-deepslate signal plus Trial Chamber suppression (configurable threshold). Existing Kaze checks already overlap with Zinc for cobbled/rotated deepslate and suspicious vertical block lines.

The added modules appear under `Zinc ESP` and `Zinc`. Webhook, auto-disconnect, and chat/payment-related options are user-configurable; keep them disabled unless intentionally needed.
