# Build validation

Source-level checks completed: module registration, package paths, and balanced Java braces. A Gradle build could not be completed in this environment because the Gradle wrapper distribution was not cached and network access to services.gradle.org was unavailable. Please run `gradlew build` in an environment with Gradle distribution access before loading the addon in-game.
