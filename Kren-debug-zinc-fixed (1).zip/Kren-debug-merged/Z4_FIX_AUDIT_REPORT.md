# Z Debug V4 Fix & Module Audit

## Fix applied
- Registered an Orbit lambda factory for the `dev.zv3` package in `KrenDebug.onInitialize()`.
- Registration is performed before `Bypass` and `LightCache` are loaded/registered.
- This directly addresses the supplied log's `NoLambdaFactoryException` for `dev.zv3.modules.Bypass` and `dev.zv3.light.LightCache`.
- Kept the original Z4 bytecode, event handlers, `LightCache` registration, mixin config, and module settings intact. No feature was disabled.

## Checks performed
- Confirmed the original ZIP archive can be read and its source/resource tree extracted.
- Checked Java source files for gross brace-balance issues: none found.
- Parsed the three top-level JSON files (`fabric.mod.json`, `kren-debug.mixins.json`, `z-v3.mixins.json`): all valid JSON.
- Reviewed the supplied runtime log: the repeated fatal errors point to the Z4 Orbit lambda factory; no other Kren Debug module is named in the crash stack.
- Identified unrelated log issues: two resource packs are missing required `min_format`/`max_format` metadata; `.DS_Store` files inside packs are ignored as invalid paths; missing classes for optional mods appear as warnings and are not the shown crash cause.

## Not verified
- A full Gradle build could not run because the wrapper needs Gradle 9.5.1 from `services.gradle.org`, and this environment cannot resolve that host. A direct `javac` check also cannot compile without Minecraft/Fabric/Meteor dependencies. Therefore this is a source/log-level fix, not a confirmed in-game test.
- The Windows native DLL bundled with the original Z4 resources was not audited or changed.

## Recommended in-game verification
1. Replace the old addon with the rebuilt JAR from this project after a successful local Gradle build.
2. Launch Minecraft 1.21.11 with the matching Meteor version.
3. Confirm the log prints `Registered Z Debug Z4 module.` without `NoLambdaFactoryException`.
4. Toggle Z Debug Z4 on and off, enter a world/server, and check `latest.log` for new exceptions.
