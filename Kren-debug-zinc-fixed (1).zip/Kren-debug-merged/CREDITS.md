# Kren Debug by Saki

Meteor Client addon for Minecraft 1.21.11.

Modules (category "Kren Debug"):
Chunk Finder, Chunk Finder Better, Prime Chunk Finder, Rtp Base Finder, Tunnel Base Finder,
Sus Chunk Finder, Sus Chunk V2, Player Bypass, Anti Vanish, Region Map.

The module logic under `kren.debug.core` is derived from the Krispy client sources
(Krispy b1.3). Original authorship and any original license terms of that code remain
with its author(s); make sure you have the right to use and redistribute it.

## Merged from Glazed (Kren Misc category)
Modules from Glazed Selected by nnpg and AR3 (SwingSpeed, AdminHud, AdminList, AntiVanish, AutoRelog, FakeScoreboard, HomeMethod, UdRelog, TabDetector, SpawnerNotifier, RegionMap), ported to Yarn mappings.
