package dev.zv3;

import kren.debug.KrenDebug;
import meteordevelopment.meteorclient.systems.modules.Category;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Compatibility bridge for the imported Z v4 module bytecode.
 * The module is registered by KrenDebug; the original addon/license bootstrap is not loaded.
 */
public final class BypassAddon {
    public static final Category 星 = KrenDebug.CATEGORY;
    public static final Logger 雲 = LoggerFactory.getLogger("Z Debug V4");

    private BypassAddon() {}
}
