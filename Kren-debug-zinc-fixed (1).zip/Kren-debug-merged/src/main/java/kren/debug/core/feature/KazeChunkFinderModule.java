package kren.debug.core.feature;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import kren.debug.core.event.EventListener;
import kren.debug.core.event.events.Render3DEvent;
import kren.debug.core.event.events.TickEvent;
import kren.debug.core.module.Category;
import kren.debug.core.module.Module;
import kren.debug.core.module.setting.BooleanSetting;
import kren.debug.core.module.setting.NumberSetting;
import kren.debug.core.utils.EncryptedString;
import kren.debug.core.utils.RenderUtils;
import kren.debug.core.utils.ToastUtil;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Chunk Finder (merged) - gộp "Chunk Finder" (bản gốc, hard-coded) và "Chunk Finder 2" (bản threshold).
 * Kiến trúc lấy theo Chunk Finder 2 (quét theo ChunkSection, ngưỡng cấu hình được, Hit theo loại),
 * cộng thêm các tính năng chỉ có ở bản gốc: plug column, piston, dripstone, hole ESP, cherry grove,
 * tự tạm dừng khi lag.
 *
 * Bản này gộp thêm từ Vortex ChunkFinder: cột dọc 1 loại block (obsidian, cobble, tuff, andesite,
 * diorite, calcite, gravel, granite, deepslate) và ore sai chỗ (diamond / deepslate diamond /
 * ancient debris). Kill switch (2 toạ độ chest) đã bị xoá.
 */
public class KazeChunkFinderModule extends Module {

    private enum Type {
        NORMAL_DEEPSLATE, COBBLED, ROTATED, AIR_POCKET, PLUG, PISTON, DRIPSTONE, LINE, MIS_ORE
    }

    private record Hit(BlockPos pos, Type type, int length) {
        Hit(BlockPos pos, Type type) {
            this(pos, type, 1);
        }
    }

    /** Một loại cột dọc cần tìm (lấy từ Vortex ChunkFinder). */
    private record LineSpec(Block block, int minY, int maxY, int minLen, int radius, boolean stoneOnly) {}

    // ---- hằng số (lấy từ hai bản gốc)
    private static final int MAX_HITS_PER_CHUNK = 2000;
    private static final long NOTIFY_COOLDOWN = 45000L;

    private static final int HOLE_MIN_Y = 20;
    private static final int HOLE_MAX_Y = 60;
    private static final int MIN_HOLE_DEPTH = 8;

    private static final int PLUG_MIN_LENGTH = 25;
    private static final int DRIPSTONE_MIN_LENGTH = 5;

    private static final int LOW_FPS_THRESHOLD = 8;
    private static final long LAG_PAUSE_DURATION = 10000L;

    private static final long CHERRY_GROVE_DELAY = 200L;
    private static final double CHERRY_MIN_DISTANCE = 100.0;

    // Cột dọc: chỉ tính từ Y=16 trở lên; ore sai chỗ: quét tới Y=63
    private static final int LINE_SCAN_MIN_Y = 16;
    private static final int ORE_SCAN_MAX_Y = 63;

    // ---- settings: detection
    private final BooleanSetting detectNormalDeepslate = new BooleanSetting(EncryptedString.of("Normal Deepslate (Zinc)"), true)
        .setDescription(EncryptedString.of("Zinc ChunkFinder: flag placed normal deepslate above its natural range"));
    private final NumberSetting normalDeepslateThreshold = new NumberSetting(EncryptedString.of("Normal Deepslate Min (Zinc)"), 1, 30, 3, 1);
    private final BooleanSetting ignoreTrialChambers = new BooleanSetting(EncryptedString.of("Ignore Trial Chambers (Zinc)"), true)
        .setDescription(EncryptedString.of("Suppress chunk alerts when enough Trial Chamber blocks are detected"));
    private final NumberSetting trialChamberThreshold = new NumberSetting(EncryptedString.of("Trial Chamber Block Min (Zinc)"), 10, 200, 40, 10);

    private final BooleanSetting detectCobbled = new BooleanSetting(EncryptedString.of("Cobbled Deepslate"), true)
        .setDescription(EncryptedString.of("Flag chunks with cobbled deepslate"));
    private final BooleanSetting detectRotated = new BooleanSetting(EncryptedString.of("Rotated Deepslate"), true)
        .setDescription(EncryptedString.of("Flag deepslate placed sideways (axis X or Z)"));
    private final BooleanSetting detectAirPockets = new BooleanSetting(EncryptedString.of("Air Pockets"), false)
        .setDescription(EncryptedString.of("Find artificial air pockets inside solid stone"));
    private final BooleanSetting detectPlugs = new BooleanSetting(EncryptedString.of("Plug Columns"), true)
        .setDescription(EncryptedString.of("Find 25+ tall enclosed columns of dirt/granite/diorite/andesite"));
    private final BooleanSetting detectPistons = new BooleanSetting(EncryptedString.of("Pistons"), true)
        .setDescription(EncryptedString.of("Flag chunks with many pistons"));
    private final BooleanSetting detectDripstone = new BooleanSetting(EncryptedString.of("Long Dripstone"), false)
        .setDescription(EncryptedString.of("Flag long pointed dripstone columns underground"));
    private final BooleanSetting coveredOnly = new BooleanSetting(EncryptedString.of("Covered Only"), true)
        .setDescription(EncryptedString.of("Deepslate types only count when fully covered and underground"));
    private final BooleanSetting cherryGrove = new BooleanSetting(EncryptedString.of("Cherry Grove"), true)
        .setDescription(EncryptedString.of("Flag chunks you stand in inside a cherry grove (DonutSMP only)"));
    private final BooleanSetting holeESP = new BooleanSetting(EncryptedString.of("HoleESP"), false)
        .setDescription(EncryptedString.of("Enable hole detection and rendering"));

    private final BooleanSetting detectLines = new BooleanSetting(EncryptedString.of("Vertical Lines"), true)
        .setDescription(EncryptedString.of("Find enclosed single-block vertical columns (obsidian, cobble, tuff, andesite, diorite, calcite, gravel, granite, deepslate), Y16+"));
    private final BooleanSetting detectOres = new BooleanSetting(EncryptedString.of("Misplaced Ores"), true)
        .setDescription(EncryptedString.of("Stone diamond ore below Y-5, deepslate diamond ore above Y10, any ancient debris (Y<63)"));
    private final BooleanSetting rotatedLineOnly = new BooleanSetting(EncryptedString.of("Rotated Line Only"), false)
        .setDescription(EncryptedString.of("Rotated deepslate only counts if 3+ sideways blocks are in a row (fewer false flags)"));
    private final BooleanSetting lagPause = new BooleanSetting(EncryptedString.of("Lag Pause"), true)
        .setDescription(EncryptedString.of("Pause scanning for 10s when FPS drops below 8"));

    // ---- settings: thresholds
    private final NumberSetting cobbledThreshold = new NumberSetting(EncryptedString.of("Cobbled Min"), 1, 25, 11, 1);
    private final NumberSetting rotatedThreshold = new NumberSetting(EncryptedString.of("Rotated Min"), 1, 25, 1, 1);
    private final NumberSetting airPocketThreshold = new NumberSetting(EncryptedString.of("Air Pocket Min"), 1, 8, 4, 1);
    private final NumberSetting plugThreshold = new NumberSetting(EncryptedString.of("Plug Min"), 1, 50, 1, 1);
    private final NumberSetting pistonThreshold = new NumberSetting(EncryptedString.of("Piston Min"), 1, 20, 5, 1);
    private final NumberSetting dripstoneThreshold = new NumberSetting(EncryptedString.of("Dripstone Min"), 1, 20, 1, 1);
    private final NumberSetting lineThreshold = new NumberSetting(EncryptedString.of("Line Min"), 1, 10, 1, 1);
    private final NumberSetting oreThreshold = new NumberSetting(EncryptedString.of("Ore Min"), 1, 10, 1, 1);
    private final NumberSetting scanSleep = new NumberSetting(EncryptedString.of("Scan Sleep (ms)"), 0, 20, 1, 1);

    // ---- settings: range
    private final NumberSetting minScanY = new NumberSetting(EncryptedString.of("Min Y"), -64, 64, -20, 1);
    private final NumberSetting maxScanY = new NumberSetting(EncryptedString.of("Max Y"), -32, 128, 42, 1);

    // ---- settings: render
    private final NumberSetting renderY = new NumberSetting(EncryptedString.of("Chunk Render Y"), -64, 320, 64, 1);
    private final BooleanSetting highlightBlocks = new BooleanSetting(EncryptedString.of("Highlight Blocks"), true);
    private final BooleanSetting fillBlocks = new BooleanSetting(EncryptedString.of("Fill Blocks"), true);
    private final NumberSetting maxBlocksRender = new NumberSetting(EncryptedString.of("Max Blocks Render"), 50, 1000, 200, 10);
    private final BooleanSetting tracers = new BooleanSetting(EncryptedString.of("Tracers"), false);

    // ---- settings: notifications
    private final BooleanSetting toastNotify = new BooleanSetting(EncryptedString.of("Toast"), true)
        .setDescription(EncryptedString.of("Shows a popup in the top-right corner when a chunk is found"));
    private final BooleanSetting chatNotify = new BooleanSetting(EncryptedString.of("Chat Message"), false)
        .setDescription(EncryptedString.of("Also prints the coordinates in chat"));
    private final BooleanSetting soundNotify = new BooleanSetting(EncryptedString.of("Sound"), true);

    // ---- màu
    private static final Color CHUNK_COLOR = new Color(0, 255, 0, 120);
    private static final Color CHERRY_COLOR = new Color(255, 105, 180, 120);
    private static final Color TRACER_COLOR = new Color(255, 69, 0, 180);
    private static final Color HOLE_COLOR = new Color(255, 255, 255, 100);

    // ---- state
    private final ConcurrentMap<ChunkPos, WorldChunk> scannedChunks = new ConcurrentHashMap<>();
    private final ConcurrentMap<ChunkPos, WorldChunk> holeScannedChunks = new ConcurrentHashMap<>();
    private final Set<ChunkPos> flaggedChunks = ConcurrentHashMap.newKeySet();
    private final Set<ChunkPos> cherryChunks = ConcurrentHashMap.newKeySet();
    private final ConcurrentMap<ChunkPos, List<Hit>> chunkHits = new ConcurrentHashMap<>();
    private final ConcurrentMap<ChunkPos, Long> notifyTimes = new ConcurrentHashMap<>();
    private final Set<Box> holes1x1 = Collections.newSetFromMap(new ConcurrentHashMap<>());
    private final Set<Box> holes3x1 = Collections.newSetFromMap(new ConcurrentHashMap<>());

    private final Map<Block, LineSpec> lineSpecs = Map.of(
        Blocks.OBSIDIAN,     new LineSpec(Blocks.OBSIDIAN,     16, 45, 3, 8, false),
        Blocks.COBBLESTONE,  new LineSpec(Blocks.COBBLESTONE,  16, 45, 5, 8, false),
        Blocks.DEEPSLATE,    new LineSpec(Blocks.DEEPSLATE,    16, 45, 3, 8, false),
        Blocks.GRANITE,      new LineSpec(Blocks.GRANITE,      16, 320, 4, 8, false),
        Blocks.TUFF,         new LineSpec(Blocks.TUFF,         16, 60, 10, 3, true),
        Blocks.ANDESITE,     new LineSpec(Blocks.ANDESITE,     16, 60, 10, 8, true),
        Blocks.DIORITE,      new LineSpec(Blocks.DIORITE,      16, 60, 10, 8, true),
        Blocks.CALCITE,      new LineSpec(Blocks.CALCITE,      16, 60, 6, 8, true),
        Blocks.GRAVEL,       new LineSpec(Blocks.GRAVEL,       16, 60, 6, 8, true)
    );

    private ExecutorService scanner;
    private Future<?> scanTask;
    private volatile boolean running = false;
    private volatile boolean lagPaused = false;
    private long lagPauseStart = 0L;
    private long lastScan = 0L;
    private long lastCleanup = 0L;

    private boolean isDonutSMP = false;
    private boolean serverChecked = false;

    private boolean inCherryGrove = false;
    private boolean cherryPending = false;
    private long cherryEnterTime = 0L;
    private ChunkPos lastCherryChunk = null;

    public KazeChunkFinderModule() {
        super(EncryptedString.of("Kaze Chunk Finder"),
            EncryptedString.of("Finds suspicious chunks, deep holes and artificial structures"),
            -1, Category.DONUT);
        this.addSettings(
            detectNormalDeepslate, normalDeepslateThreshold, ignoreTrialChambers, trialChamberThreshold,
            detectCobbled, detectRotated, detectAirPockets,
            detectPlugs, detectPistons, detectDripstone, detectLines, detectOres,
            coveredOnly, rotatedLineOnly, cherryGrove, holeESP, lagPause,
            cobbledThreshold, rotatedThreshold, airPocketThreshold,
            plugThreshold, pistonThreshold, dripstoneThreshold, lineThreshold, oreThreshold, scanSleep,
            minScanY, maxScanY,
            renderY, highlightBlocks, fillBlocks, maxBlocksRender, tracers,
            toastNotify, chatNotify, soundNotify
        );
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    public void onEnable() {
        clearAll();
        running = true;
        lagPaused = false;
        serverChecked = false;
        scanner = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "ChunkFinder-Scanner");
            t.setDaemon(true);
            t.setPriority(Thread.MIN_PRIORITY);
            return t;
        });
        lastScan = 0L;
    }

    @Override
    public void onDisable() {
        running = false;
        cancelScan();
        if (scanner != null) scanner.shutdownNow();
        scanner = null;
        scanTask = null;
        clearAll();
    }

    private void cancelScan() {
        if (scanTask != null && !scanTask.isDone()) scanTask.cancel(true);
    }

    private void clearAll() {
        scannedChunks.clear();
        holeScannedChunks.clear();
        flaggedChunks.clear();
        cherryChunks.clear();
        chunkHits.clear();
        notifyTimes.clear();
        holes1x1.clear();
        holes3x1.clear();
        inCherryGrove = false;
        cherryPending = false;
        cherryEnterTime = 0L;
        lastCherryChunk = null;
    }

    // ------------------------------------------------------------------ tick

    @EventListener
    public void onTick(TickEvent event) {
        if (mc.world == null || mc.player == null || scanner == null) return;

        checkServer();

        long now = System.currentTimeMillis();

        if (isDonutSMP && cherryGrove.getValue()) checkCherryGrove(now);

        if (lagPause.getValue() && mc.getCurrentFps() < LOW_FPS_THRESHOLD
            && mc.player.age > 100 && !lagPaused) {
            lagPaused = true;
            lagPauseStart = now;
            cancelScan();
        }

        if (lagPaused) {
            if (now - lagPauseStart < LAG_PAUSE_DURATION) return;
            lagPaused = false;
        }

        if (now - lastScan >= 500L && (scanTask == null || scanTask.isDone())) {
            lastScan = now;
            scanTask = scanner.submit(this::scanLoop);
        }

        if (now - lastCleanup >= 5000L) {
            lastCleanup = now;
            cleanup();
        }
    }

    private void checkServer() {
        if (serverChecked) return;
        try {
            var info = mc.getCurrentServerEntry();
            if (info != null) {
                String address = info.address;
                isDonutSMP = address != null && address.toLowerCase().endsWith("donutsmp.net");
                serverChecked = true;
            } else if (mc.isInSingleplayer()) {
                isDonutSMP = false;
                serverChecked = true;
            }
        } catch (Exception e) {
            isDonutSMP = false;
            serverChecked = true;
        }
    }

    private boolean scanPaused() {
        return !running || lagPaused;
    }

    // ------------------------------------------------------------------ cherry grove

    private void checkCherryGrove(long now) {
        if (mc.world == null || mc.player == null) return;

        BlockPos blockPos = mc.player.getBlockPos();
        boolean inGrove = isCherryBiome(blockPos);

        if (inGrove && !inCherryGrove) {
            inCherryGrove = true;
            cherryEnterTime = now;
            cherryPending = true;
        } else if (!inGrove && inCherryGrove) {
            inCherryGrove = false;
            cherryPending = false;
        }

        if (cherryPending && inCherryGrove && now - cherryEnterTime >= CHERRY_GROVE_DELAY) {
            ChunkPos pos = new ChunkPos(blockPos);
            if (shouldFlagCherry(pos)) {
                cherryChunks.add(pos);
                lastCherryChunk = pos;
                notifyFound(pos, "Cherry Grove");
            }
            cherryPending = false;
        }
    }

    private boolean isCherryBiome(BlockPos pos) {
        try {
            var entry = mc.world.getBiome(pos);
            if (entry == null) return false;
            String id = entry.getKey().map(key -> key.getValue().toString()).orElse("");
            return id.contains("cherry");
        } catch (Exception e) {
            return false;
        }
    }

    private boolean shouldFlagCherry(ChunkPos pos) {
        if (cherryChunks.contains(pos)) return false;
        if (lastCherryChunk == null) return true;
        double dx = (pos.x * 16 + 8) - (lastCherryChunk.x * 16 + 8);
        double dz = (pos.z * 16 + 8) - (lastCherryChunk.z * 16 + 8);
        return Math.sqrt(dx * dx + dz * dz) >= CHERRY_MIN_DISTANCE;
    }

    // ------------------------------------------------------------------ scanning

    private List<WorldChunk> loadedChunks() {
        List<WorldChunk> list = new ArrayList<>();
        ClientWorld world = mc.world;
        if (world == null || mc.player == null) return list;

        int view = mc.options.getViewDistance().getValue();
        ChunkPos center = mc.player.getChunkPos();

        for (int dx = -view; dx <= view; dx++) {
            for (int dz = -view; dz <= view; dz++) {
                WorldChunk chunk = world.getChunkManager().getWorldChunk(center.x + dx, center.z + dz);
                if (chunk != null && !chunk.isEmpty()) list.add(chunk);
            }
        }

        list.sort((a, b) -> Integer.compare(distSq(a.getPos(), center), distSq(b.getPos(), center)));
        return list;
    }

    private static int distSq(ChunkPos a, ChunkPos b) {
        int dx = a.x - b.x;
        int dz = a.z - b.z;
        return dx * dx + dz * dz;
    }

    private void scanLoop() {
        try {
            List<WorldChunk> chunks = loadedChunks();

            // Pass 1: phát hiện chunk khả nghi
            for (WorldChunk chunk : chunks) {
                if (scanPaused()) return;

                ChunkPos pos = chunk.getPos();
                // Quét lại nếu object chunk bị thay (server gửi lại chunk)
                if (scannedChunks.get(pos) == chunk) continue;

                boolean done;
                try {
                    done = analyzeChunk(chunk);
                } catch (Exception ignored) {
                    done = true;
                }
                // Bị tạm dừng giữa chừng thì không đánh dấu đã quét, lần sau quét lại
                if (done) scannedChunks.put(pos, chunk);

                Thread.sleep(scanSleep.getIntValue());
            }

            // Pass 2: hole ESP (nặng hơn nên chạy sau)
            if (holeESP.getValue()) {
                for (WorldChunk chunk : chunks) {
                    if (scanPaused()) return;

                    ChunkPos pos = chunk.getPos();
                    if (holeScannedChunks.get(pos) == chunk) continue;

                    boolean done;
                    try {
                        done = scanChunkForHoles(chunk);
                    } catch (Exception ignored) {
                        done = true;
                    }
                    if (done) holeScannedChunks.put(pos, chunk);

                    // HoleESP does more work per chunk; keep a short cooperative pause.
                    Thread.sleep(Math.max(4, scanSleep.getIntValue()));
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private boolean analyzeChunk(WorldChunk chunk) {
        ChunkPos pos = chunk.getPos();
        int bottom = chunk.getBottomY();
        int minY = Math.max(bottom, minScanY.getIntValue());
        int maxY = Math.min(bottom + chunk.getHeight() - 1, maxScanY.getIntValue());

        // Dải Y của Min/Max Y chỉ áp cho nhóm block; cột dọc và ore có dải riêng
        boolean blockRange = minY <= maxY;

        int[] counts = new int[Type.values().length];
        int trialChamberBlocks = 0;
        List<Hit> hits = new ArrayList<>();

        ChunkSection[] sections = chunk.getSectionArray();
        int startX = pos.getStartX();
        int startZ = pos.getStartZ();

        for (int index = 0; blockRange && index < sections.length; index++) {
            if (scanPaused()) return false;

            ChunkSection section = sections[index];
            if (section == null || section.isEmpty()) continue;

            int sectionY = bottom + index * 16;
            int fromY = Math.max(0, minY - sectionY);
            int toY = Math.min(15, maxY - sectionY);
            if (fromY > 15 || toY < 0) continue;

            for (int x = 0; x < 16; x++) {
                for (int z = 0; z < 16; z++) {
                    for (int y = fromY; y <= toY; y++) {
                        BlockState state = section.getBlockState(x, y, z);
                        int worldY = sectionY + y;

                        if (state.isAir()) {
                            if (detectAirPockets.getValue() && state.isOf(Blocks.AIR)) {
                                BlockPos bp = new BlockPos(startX + x, worldY, startZ + z);
                                if (isArtificialAirPocket(bp)) {
                                    record(hits, counts, bp, Type.AIR_POCKET);
                                }
                            }
                            continue;
                        }

                        Block block = state.getBlock();
                        if (ignoreTrialChambers.getValue() && isTrialChamberBlock(state)) {
                            trialChamberBlocks++;
                        }

                        if (block == Blocks.DEEPSLATE) {
                            boolean sideways = state.contains(Properties.AXIS)
                                && state.get(Properties.AXIS) != Direction.Axis.Y;
                            BlockPos bp = new BlockPos(startX + x, worldY, startZ + z);
                            if (sideways && detectRotated.getValue()) {
                                if (passesCover(bp)) record(hits, counts, bp, Type.ROTATED);
                            } else if (!sideways && detectNormalDeepslate.getValue() && worldY >= 16) {
                                // Zinc ChunkFinder's additional signal: normal deepslate placed above its natural range.
                                if (passesCover(bp)) record(hits, counts, bp, Type.NORMAL_DEEPSLATE);
                            }
                        } else if (block == Blocks.COBBLED_DEEPSLATE) {
                            if (detectCobbled.getValue()) {
                                BlockPos bp = new BlockPos(startX + x, worldY, startZ + z);
                                if (passesCover(bp)) record(hits, counts, bp, Type.COBBLED);
                            }
                        } else if (block == Blocks.PISTON || block == Blocks.STICKY_PISTON) {
                            if (detectPistons.getValue()) {
                                record(hits, counts, new BlockPos(startX + x, worldY, startZ + z), Type.PISTON);
                            }
                        } else if (block == Blocks.POINTED_DRIPSTONE) {
                            if (detectDripstone.getValue()) {
                                BlockPos bp = new BlockPos(startX + x, worldY, startZ + z);
                                if (dripstoneLength(bp) >= DRIPSTONE_MIN_LENGTH && isPositionUnderground(bp)) {
                                    record(hits, counts, bp, Type.DRIPSTONE);
                                }
                            }
                        }
                    }
                }
            }
        }

        // Zinc ChunkFinder behavior: avoid classifying Trial Chambers as player-built bases.
        if (ignoreTrialChambers.getValue() && trialChamberBlocks >= trialChamberThreshold.getIntValue()) {
            unflag(pos);
            return true;
        }

        if (blockRange && detectPlugs.getValue()) {
            scanPlugColumns(chunk, minY, maxY, hits, counts);
        }
        if (detectLines.getValue()) scanLines(chunk, hits, counts);
        if (detectOres.getValue()) scanOres(chunk, hits, counts);

        // Bị tạm dừng giữa chừng: kết quả chưa đầy đủ, bỏ và quét lại sau
        if (scanPaused()) return false;

        if (rotatedLineOnly.getValue() && counts[Type.ROTATED.ordinal()] > 0 && !hasRotatedLine(hits)) {
            counts[Type.ROTATED.ordinal()] = 0;
            hits.removeIf(hit -> hit.type() == Type.ROTATED);
        }

        // Loại nào đạt ngưỡng thì mới được tính
        EnumSet<Type> passed = EnumSet.noneOf(Type.class);
        for (Type type : Type.values()) {
            if (isEnabled(type) && counts[type.ordinal()] >= threshold(type)) passed.add(type);
        }

        if (passed.isEmpty()) {
            unflag(pos);
            return true;
        }

        StringBuilder reasons = new StringBuilder();
        for (Type type : passed) {
            reasons.append(label(type)).append('[').append(counts[type.ordinal()]).append("] ");
        }

        List<Hit> kept = new ArrayList<>();
        for (Hit hit : hits) {
            if (passed.contains(hit.type())) kept.add(hit);
        }
        chunkHits.put(pos, kept);

        if (flaggedChunks.add(pos)) {
            notifyFound(pos, reasons.toString().trim());
        }
        return true;
    }


    private static boolean isTrialChamberBlock(BlockState state) {
        Block block = state.getBlock();
        return block == Blocks.TUFF || block == Blocks.TUFF_BRICKS
            || block == Blocks.CHISELED_TUFF || block == Blocks.CHISELED_TUFF_BRICKS
            || block == Blocks.POLISHED_TUFF || block == Blocks.TRIAL_SPAWNER
            || block == Blocks.VAULT || block == Blocks.COPPER_BULB;
    }

    private void record(List<Hit> hits, int[] counts, BlockPos pos, Type type) {
        record(hits, counts, pos, type, 1);
    }

    private void record(List<Hit> hits, int[] counts, BlockPos pos, Type type, int length) {
        counts[type.ordinal()]++;
        if (hits.size() < MAX_HITS_PER_CHUNK) hits.add(new Hit(pos, type, length));
    }

    /** Có ít nhất 3 block deepslate nằm ngang liền nhau theo trục X hoặc Z. */
    private boolean hasRotatedLine(List<Hit> hits) {
        Set<Long> set = new HashSet<>();
        for (Hit hit : hits) {
            if (hit.type() == Type.ROTATED) set.add(hit.pos().asLong());
        }
        for (long key : set) {
            BlockPos p = BlockPos.fromLong(key);
            if (set.contains(p.east().asLong()) && set.contains(p.east(2).asLong())) return true;
            if (set.contains(p.south().asLong()) && set.contains(p.south(2).asLong())) return true;
        }
        return false;
    }

    // ------------------------------------------------------------------ vertical lines (từ Vortex)

    /**
     * Cột dọc 1 loại block, kín (không chạm air/fluid), không có block cùng loại ở gần (isolation),
     * và với nhóm đá thì 4 mặt bên phải là stone. Mỗi cột đạt chuẩn là 1 hit.
     */
    private void scanLines(WorldChunk chunk, List<Hit> hits, int[] counts) {
        ClientWorld world = mc.world;
        if (world == null) return;

        ChunkSection[] sections = chunk.getSectionArray();
        int bottom = chunk.getBottomY();
        int topY = bottom + chunk.getHeight() - 1;
        int startY = Math.max(LINE_SCAN_MIN_Y, bottom);
        if (startY > topY) return;

        int startX = chunk.getPos().getStartX();
        int startZ = chunk.getPos().getStartZ();
        BlockPos.Mutable m = new BlockPos.Mutable();

        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                if (scanPaused()) return;

                LineSpec run = null;
                int runStart = 0;
                int runLen = 0;

                for (int y = startY; y <= topY + 1; y++) {
                    LineSpec spec = null;
                    if (y <= topY) {
                        int index = (y - bottom) >> 4;
                        ChunkSection section = index >= 0 && index < sections.length ? sections[index] : null;
                        if (section != null && !section.isEmpty()) {
                            Block block = section.getBlockState(x, (y - bottom) & 15, z).getBlock();
                            LineSpec candidate = lineSpecs.get(block);
                            if (candidate != null && y >= candidate.minY() && y <= candidate.maxY()
                                && !lineExposed(world, m.set(startX + x, y, startZ + z))) {
                                spec = candidate;
                            }
                        }
                    }

                    if (spec != null && spec == run) {
                        runLen++;
                        continue;
                    }

                    // run vừa kết thúc ở y - 1
                    if (run != null) {
                        evaluateLine(world, run, startX + x, startZ + z, runStart, runLen, hits, counts);
                    }
                    run = spec;
                    runStart = y;
                    runLen = spec != null ? 1 : 0;
                }
            }
        }
    }

    private void evaluateLine(ClientWorld world, LineSpec spec, int wx, int wz, int startY, int length,
                              List<Hit> hits, int[] counts) {
        if (length < spec.minLen()) return;
        if (!lineIsolated(world, spec, wx, wz, startY, length)) return;
        if (spec.stoneOnly() && !lineSurroundedByStone(world, wx, wz, startY, length)) return;
        record(hits, counts, new BlockPos(wx, startY, wz), Type.LINE, length);
    }

    private boolean lineExposed(ClientWorld world, BlockPos pos) {
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (Direction dir : Direction.values()) {
            BlockState adjacent = world.getBlockState(m.set(pos, dir));
            if (adjacent.isAir() || !adjacent.getFluidState().isEmpty()) return true;
        }
        return false;
    }

    /** Không có block cùng loại trong bán kính quanh cột (ngoài chính cột đó). */
    private boolean lineIsolated(ClientWorld world, LineSpec spec, int wx, int wz, int startY, int length) {
        int radius = spec.radius();
        if (radius <= 0) return true;

        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                for (int dy = -radius; dy < length + radius; dy++) {
                    if (dx == 0 && dz == 0 && dy >= 0 && dy < length) continue;
                    int y = startY + dy;
                    if (y < world.getBottomY() || y >= (world.getBottomY() + world.getHeight())) continue;
                    if (world.getBlockState(m.set(wx + dx, y, wz + dz)).isOf(spec.block())) return false;
                }
            }
        }
        return true;
    }

    /** Cả 4 mặt bên của cột (suốt chiều dài) đều là stone. */
    private boolean lineSurroundedByStone(ClientWorld world, int wx, int wz, int startY, int length) {
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dy = 0; dy < length; dy++) {
            int y = startY + dy;
            if (y < world.getBottomY() || y >= (world.getBottomY() + world.getHeight())) return false;
            for (Direction dir : Direction.Type.HORIZONTAL) {
                m.set(wx, y, wz).move(dir);
                if (!world.getBlockState(m).isOf(Blocks.STONE)) return false;
            }
        }
        return true;
    }

    // ------------------------------------------------------------------ misplaced ores (từ Vortex)

    private void scanOres(WorldChunk chunk, List<Hit> hits, int[] counts) {
        ChunkSection[] sections = chunk.getSectionArray();
        int bottom = chunk.getBottomY();
        int startX = chunk.getPos().getStartX();
        int startZ = chunk.getPos().getStartZ();

        for (int index = 0; index < sections.length; index++) {
            if (scanPaused()) return;

            ChunkSection section = sections[index];
            if (section == null || section.isEmpty()) continue;

            int sectionY = bottom + index * 16;
            if (sectionY >= ORE_SCAN_MAX_Y) break;

            if (!section.hasAny(state -> state.isOf(Blocks.DIAMOND_ORE)
                || state.isOf(Blocks.DEEPSLATE_DIAMOND_ORE)
                || state.isOf(Blocks.ANCIENT_DEBRIS))) {
                continue;
            }

            for (int x = 0; x < 16; x++) {
                for (int z = 0; z < 16; z++) {
                    for (int y = 0; y < 16; y++) {
                        int worldY = sectionY + y;
                        if (worldY >= ORE_SCAN_MAX_Y) break;

                        Block block = section.getBlockState(x, y, z).getBlock();
                        boolean sus = (block == Blocks.DIAMOND_ORE && worldY < -5)
                            || (block == Blocks.DEEPSLATE_DIAMOND_ORE && worldY > 10)
                            || block == Blocks.ANCIENT_DEBRIS;
                        if (sus) {
                            record(hits, counts, new BlockPos(startX + x, worldY, startZ + z), Type.MIS_ORE);
                        }
                    }
                }
            }
        }
    }

    private void unflag(ChunkPos pos) {
        flaggedChunks.remove(pos);
        chunkHits.remove(pos);
        notifyTimes.remove(pos);
    }

    private boolean isEnabled(Type type) {
        return switch (type) {
            case NORMAL_DEEPSLATE -> detectNormalDeepslate.getValue();
            case COBBLED -> detectCobbled.getValue();
            case ROTATED -> detectRotated.getValue();
            case AIR_POCKET -> detectAirPockets.getValue();
            case PLUG -> detectPlugs.getValue();
            case PISTON -> detectPistons.getValue();
            case DRIPSTONE -> detectDripstone.getValue();
            case LINE -> detectLines.getValue();
            case MIS_ORE -> detectOres.getValue();
        };
    }

    private int threshold(Type type) {
        return switch (type) {
            case NORMAL_DEEPSLATE -> normalDeepslateThreshold.getIntValue();
            case COBBLED -> cobbledThreshold.getIntValue();
            case ROTATED -> rotatedThreshold.getIntValue();
            case AIR_POCKET -> airPocketThreshold.getIntValue();
            case PLUG -> plugThreshold.getIntValue();
            case PISTON -> pistonThreshold.getIntValue();
            case DRIPSTONE -> dripstoneThreshold.getIntValue();
            case LINE -> lineThreshold.getIntValue();
            case MIS_ORE -> oreThreshold.getIntValue();
        };
    }

    private static String label(Type type) {
        return switch (type) {
            case NORMAL_DEEPSLATE -> "NormalDeepslate(Zinc)";
            case COBBLED -> "Cobbled";
            case ROTATED -> "Rotated";
            case AIR_POCKET -> "AirPockets";
            case PLUG -> "Plugs";
            case PISTON -> "Pistons";
            case DRIPSTONE -> "Dripstone";
            case LINE -> "Lines";
            case MIS_ORE -> "Ores";
        };
    }

    // ------------------------------------------------------------------ plug columns

    private void scanPlugColumns(WorldChunk chunk, int minY, int maxY, List<Hit> hits, int[] counts) {
        int startX = chunk.getPos().getStartX();
        int startZ = chunk.getPos().getStartZ();
        BlockPos.Mutable m = new BlockPos.Mutable();

        for (int x = startX; x < startX + 16; x++) {
            for (int z = startZ; z < startZ + 16; z++) {
                if (scanPaused()) return;

                Block runBlock = null;
                int runStart = 0;

                for (int y = minY; y <= maxY + 1; y++) {
                    Block b = null;
                    if (y <= maxY) {
                        b = chunk.getBlockState(m.set(x, y, z)).getBlock();
                        if (!isPlugBlock(b)) b = null;
                    }

                    if (b != null && b == runBlock) continue;

                    // run vừa kết thúc ở y - 1
                    if (runBlock != null && y - runStart >= PLUG_MIN_LENGTH
                        && isCoveredColumn(x, z, runStart, y - 1, runBlock)) {
                        for (int yy = runStart; yy < y; yy++) {
                            BlockPos bp = new BlockPos(x, yy, z);
                            if (isBlockCovered(bp) && isPositionUnderground(bp)) {
                                record(hits, counts, bp, Type.PLUG);
                            }
                        }
                    }

                    runBlock = b;
                    runStart = y;
                }
            }
        }
    }

    private boolean isPlugBlock(Block block) {
        return block == Blocks.DIRT || block == Blocks.GRANITE
            || block == Blocks.DIORITE || block == Blocks.ANDESITE;
    }

    private boolean isCoveredColumn(int x, int z, int fromY, int toY, Block block) {
        ClientWorld world = mc.world;
        if (world == null) return false;

        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int y = fromY; y <= toY; y++) {
            BlockPos pos = new BlockPos(x, y, z);
            if (!world.getBlockState(pos).isOf(block)) return false;

            for (Direction dir : Direction.values()) {
                m.set(pos, dir);
                BlockState adjacent = world.getBlockState(m);
                if (adjacent.isAir() || !adjacent.isSolidBlock(world, m)) return false;
            }
        }
        return true;
    }

    // ------------------------------------------------------------------ block checks

    /** Với nhóm deepslate: nếu bật "Covered Only" thì block phải bị che kín và nằm dưới lòng đất. */
    private boolean passesCover(BlockPos pos) {
        return !coveredOnly.getValue() || (isBlockCovered(pos) && isPositionUnderground(pos));
    }

    /**
     * Cả 6 mặt đều là block đặc, opaque (bản gốc dùng danh sách "transparent block" hard-coded,
     * ở đây thay bằng isOpaque()).
     */
    private boolean isBlockCovered(BlockPos pos) {
        ClientWorld world = mc.world;
        if (world == null) return false;

        BlockPos.Mutable m = new BlockPos.Mutable();
        for (Direction dir : Direction.values()) {
            m.set(pos, dir);
            try {
                BlockState adjacent = world.getBlockState(m);
                if (adjacent.isAir() || !adjacent.isOpaque() || !adjacent.isSolidBlock(world, m)) return false;
            } catch (Exception e) {
                return false;
            }
        }
        return true;
    }

    /** Phía trên (tối đa 50 block, dừng ở Y=80) có ít nhất 3 block đặc. */
    private boolean isPositionUnderground(BlockPos pos) {
        ClientWorld world = mc.world;
        if (world == null) return false;

        int top = Math.min(pos.getY() + 50, 80);
        int solid = 0;
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int y = pos.getY() + 1; y <= top; y++) {
            m.set(pos.getX(), y, pos.getZ());
            BlockState state = world.getBlockState(m);
            if (!state.isAir() && state.isSolidBlock(world, m)) solid++;
        }
        return solid >= 3;
    }

    private int dripstoneLength(BlockPos start) {
        ClientWorld world = mc.world;
        if (world == null) return 0;

        int length = 0;
        BlockPos.Mutable m = start.mutableCopy();
        while (length < 64 && world.getBlockState(m).isOf(Blocks.POINTED_DRIPSTONE)) {
            length++;
            m.move(Direction.UP);
        }
        m.set(start).move(Direction.DOWN);
        while (length < 64 && world.getBlockState(m).isOf(Blocks.POINTED_DRIPSTONE)) {
            length++;
            m.move(Direction.DOWN);
        }
        return length;
    }

    private boolean isArtificialAirPocket(BlockPos pos) {
        ClientWorld world = mc.world;
        if (world == null) return false;
        if (pos.getY() <= 2 || pos.getY() > maxScanY.getIntValue()) return false;

        BlockPos.Mutable m = new BlockPos.Mutable();

        // 1) cả 6 hướng đều phải đặc
        for (Direction dir : Direction.values()) {
            m.set(pos, dir);
            if (!world.getBlockState(m).isSolidBlock(world, m)) return false;
        }

        // 2) không còn air nào khác trong 3x3x3
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                for (int dz = -1; dz <= 1; dz++) {
                    if (dx == 0 && dy == 0 && dz == 0) continue;
                    m.set(pos.getX() + dx, pos.getY() + dy, pos.getZ() + dz);
                    if (world.getBlockState(m).isOf(Blocks.AIR)) return false;
                }
            }
        }

        // 3) lớp vỏ 5x5x5 xung quanh phải >= 80% là đá tự nhiên
        int natural = 0;
        int total = 0;
        for (int dx = -2; dx <= 2; dx++) {
            for (int dy = -2; dy <= 2; dy++) {
                for (int dz = -2; dz <= 2; dz++) {
                    if (Math.abs(dx) <= 1 && Math.abs(dy) <= 1 && Math.abs(dz) <= 1) continue;
                    m.set(pos.getX() + dx, pos.getY() + dy, pos.getZ() + dz);
                    Block b = world.getBlockState(m).getBlock();
                    total++;
                    if (b == Blocks.STONE || b == Blocks.DEEPSLATE
                        || b == Blocks.COBBLESTONE || b == Blocks.COBBLED_DEEPSLATE) {
                        natural++;
                    }
                }
            }
        }
        return total > 0 && (natural * 100 / total) >= 80;
    }

    // ------------------------------------------------------------------ holes

    private boolean scanChunkForHoles(WorldChunk chunk) {
        ChunkPos pos = chunk.getPos();
        int startX = pos.getStartX();
        int startZ = pos.getStartZ();
        int minY = Math.max(chunk.getBottomY(), HOLE_MIN_Y);
        int maxY = Math.min(chunk.getBottomY() + chunk.getHeight(), HOLE_MAX_Y);

        for (int x = startX; x < startX + 16; x++) {
            for (int z = startZ; z < startZ + 16; z++) {
                for (int y = minY; y < maxY; y++) {
                    if (scanPaused()) return false;

                    BlockPos bp = new BlockPos(x, y, z);
                    if (!isAir(bp)) continue; // mọi dạng hole đều bắt đầu từ một ô air

                    try {
                        checkHole1x1(bp);
                        checkHole3x1(bp);
                    } catch (Exception ignored) {
                    }
                }
            }
        }
        return true;
    }

    private void checkHole1x1(BlockPos pos) {
        if (!isValidHoleSection(pos)) return;

        BlockPos.Mutable top = pos.mutableCopy();
        while (isValidHoleSection(top)) top.move(Direction.UP);

        if (top.getY() - pos.getY() >= MIN_HOLE_DEPTH) {
            addHole(holes1x1, new Box(pos.getX(), pos.getY(), pos.getZ(),
                pos.getX() + 1, top.getY(), pos.getZ() + 1));
        }
    }

    private void checkHole3x1(BlockPos pos) {
        if (isValid3x1SectionX(pos)) {
            BlockPos.Mutable top = pos.mutableCopy();
            while (isValid3x1SectionX(top)) top.move(Direction.UP);

            if (top.getY() - pos.getY() >= MIN_HOLE_DEPTH) {
                addHole(holes3x1, new Box(pos.getX(), pos.getY(), pos.getZ(),
                    pos.getX() + 3, top.getY(), pos.getZ() + 1));
            }
        }

        if (isValid3x1SectionZ(pos)) {
            BlockPos.Mutable top = pos.mutableCopy();
            while (isValid3x1SectionZ(top)) top.move(Direction.UP);

            if (top.getY() - pos.getY() >= MIN_HOLE_DEPTH) {
                addHole(holes3x1, new Box(pos.getX(), pos.getY(), pos.getZ(),
                    pos.getX() + 1, top.getY(), pos.getZ() + 3));
            }
        }
    }

    /** Chỉ thêm nếu chưa có hole nào trùng/chồng lên. */
    private void addHole(Set<Box> set, Box box) {
        if (set.contains(box)) return;
        for (Box other : set) {
            if (other.intersects(box)) return;
        }
        set.add(box);
    }

    private boolean isValidHoleSection(BlockPos p) {
        return isAir(p)
            && !isAir(p.north()) && !isAir(p.south()) && !isAir(p.east()) && !isAir(p.west());
    }

    private boolean isValid3x1SectionX(BlockPos p) {
        return isAir(p) && isAir(p.east()) && isAir(p.east(2))
            && !isAir(p.north()) && !isAir(p.south())
            && !isAir(p.east(3)) && !isAir(p.west())
            && !isAir(p.east().north()) && !isAir(p.east().south())
            && !isAir(p.east(2).north()) && !isAir(p.east(2).south());
    }

    private boolean isValid3x1SectionZ(BlockPos p) {
        return isAir(p) && isAir(p.south()) && isAir(p.south(2))
            && !isAir(p.east()) && !isAir(p.west())
            && !isAir(p.south(3)) && !isAir(p.north())
            && !isAir(p.south().east()) && !isAir(p.south().west())
            && !isAir(p.south(2).east()) && !isAir(p.south(2).west());
    }

    private boolean isAir(BlockPos pos) {
        ClientWorld world = mc.world;
        return world != null && world.getBlockState(pos).isAir();
    }

    // ------------------------------------------------------------------ notifications / cleanup

    private void notifyFound(ChunkPos pos, String details) {
        long now = System.currentTimeMillis();
        Long last = notifyTimes.get(pos);
        if (last != null && now - last < NOTIFY_COOLDOWN) return;
        notifyTimes.put(pos, now);

        int x = pos.getStartX() + 8;
        int z = pos.getStartZ() + 8;
        int total = flaggedChunks.size() + cherryChunks.size();

        mc.execute(() -> {
            try {
                if (soundNotify.getValue() && mc.player != null) {
                    mc.player.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.5f);
                }

                boolean shown = false;
                if (toastNotify.getValue()) {
                    shown = ToastUtil.show("Chunk Finder (" + total + ")",
                        "X: " + x + "  Z: " + z + "  " + details);
                }

                boolean wantChat = chatNotify.getValue() || (toastNotify.getValue() && !shown);
                if (wantChat && mc.inGameHud != null) {
                    mc.inGameHud.getChatHud().addMessage(
                        Text.literal("[ChunkFinder] X: " + x + "  Z: " + z + " - " + details));
                }
            } catch (Exception ignored) {
            }
        });
    }

    private void cleanup() {
        if (mc.player == null) return;

        int view = mc.options.getViewDistance().getValue();
        ChunkPos center = mc.player.getChunkPos();

        flaggedChunks.removeIf(pos -> {
            boolean far = Math.abs(pos.x - center.x) > view + 5 || Math.abs(pos.z - center.z) > view + 5;
            if (far) {
                chunkHits.remove(pos);
                notifyTimes.remove(pos);
            }
            return far;
        });
        chunkHits.keySet().removeIf(pos -> !flaggedChunks.contains(pos));

        cherryChunks.removeIf(pos -> {
            boolean far = Math.abs(pos.x - center.x) > view || Math.abs(pos.z - center.z) > view;
            if (far) notifyTimes.remove(pos);
            return far;
        });

        scannedChunks.keySet().removeIf(pos ->
            Math.abs(pos.x - center.x) > view + 3 || Math.abs(pos.z - center.z) > view + 3);
        holeScannedChunks.keySet().removeIf(pos ->
            Math.abs(pos.x - center.x) > view + 3 || Math.abs(pos.z - center.z) > view + 3);

        holes1x1.removeIf(box -> holeFar(box, center, view));
        holes3x1.removeIf(box -> holeFar(box, center, view));
    }

    private static boolean holeFar(Box box, ChunkPos center, int view) {
        Vec3d c = box.getCenter();
        int cx = Math.floorDiv((int) Math.floor(c.x), 16);
        int cz = Math.floorDiv((int) Math.floor(c.z), 16);
        return Math.abs(cx - center.x) > view || Math.abs(cz - center.z) > view;
    }

    // ------------------------------------------------------------------ rendering

    @EventListener
    public void onRender3D(Render3DEvent event) {
        if (mc.player == null || mc.world == null || event.matrixStack == null) return;
        if (flaggedChunks.isEmpty() && cherryChunks.isEmpty() && holes1x1.isEmpty() && holes3x1.isEmpty()) return;

        Camera camera = RenderUtils.getCamera();
        Vec3d cameraPos = RenderUtils.getCameraPos();
        if (camera == null || cameraPos == null) return;

        // Everything below is queued in world coordinates and drawn once per frame by RenderUtils.
        MatrixStack stack = event.matrixStack;
        Vec3d tracerStart = RenderUtils.getTracerStart(camera);
        float y = (float) renderY.getValue();

        int drawnChunks = 0;
        for (ChunkPos pos : flaggedChunks) {
            if (drawnChunks++ >= 50) break;
            renderChunkPlane(stack, pos, y, CHUNK_COLOR, tracerStart);
        }
        for (ChunkPos pos : cherryChunks) {
            renderChunkPlane(stack, pos, y, CHERRY_COLOR, tracerStart);
        }

        if (highlightBlocks.getValue()) {
            renderBlocks(stack);
        }

        if (holeESP.getValue()) {
            for (Box box : holes1x1) renderHole(stack, box);
            for (Box box : holes3x1) renderHole(stack, box);
        }
    }

    private void renderChunkPlane(MatrixStack stack, ChunkPos pos, float y, Color color, Vec3d tracerStart) {
        float x1 = pos.getStartX();
        float z1 = pos.getStartZ();
        float x2 = x1 + 16;
        float z2 = z1 + 16;

        RenderUtils.renderFilledBox(stack, x1, y, z1, x2, y + 0.3f, z2, color);
        outline(stack, x1, y, z1, x2, y + 0.3f, z2, color);

        if (tracers.getValue()) {
            RenderUtils.renderLine(stack, TRACER_COLOR, tracerStart, new Vec3d(x1 + 8, y + 0.15, z1 + 8));
        }
    }

    private void renderHole(MatrixStack stack, Box box) {
        float x1 = (float) box.minX, y1 = (float) box.minY, z1 = (float) box.minZ;
        float x2 = (float) box.maxX, y2 = (float) box.maxY, z2 = (float) box.maxZ;
        RenderUtils.renderFilledBox(stack, x1, y1, z1, x2, y2, z2, HOLE_COLOR);
        outline(stack, x1, y1, z1, x2, y2, z2,
            new Color(HOLE_COLOR.getRed(), HOLE_COLOR.getGreen(), HOLE_COLOR.getBlue(), 255));
    }

    private void renderBlocks(MatrixStack stack) {
        double maxDist = mc.options.getViewDistance().getValue() * 16.0;
        double maxDistSq = maxDist * maxDist;
        int limit = maxBlocksRender.getIntValue();
        int drawn = 0;
        Vec3d player = mc.player.getEntityPos();

        for (ChunkPos chunk : flaggedChunks) {
            List<Hit> hits = chunkHits.get(chunk);
            if (hits == null) continue;

            for (Hit hit : hits) {
                if (drawn >= limit) return;

                BlockPos p = hit.pos();
                if (player.squaredDistanceTo(p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5) > maxDistSq) continue;

                Color color = colorFor(hit.type());
                float x = p.getX(), y = p.getY(), z = p.getZ();

                if (fillBlocks.getValue()) {
                    RenderUtils.renderFilledBox(stack, x, y, z, x + 1, y + hit.length(), z + 1,
                        new Color(color.getRed(), color.getGreen(), color.getBlue(), 80));
                }
                outline(stack, x, y, z, x + 1, y + hit.length(), z + 1, color);
                drawn++;
            }
        }
    }

    private Color colorFor(Type type) {
        return switch (type) {
            case NORMAL_DEEPSLATE -> new Color(60, 60, 90, 200);
            case COBBLED -> new Color(80, 80, 80, 200);
            case ROTATED -> new Color(120, 0, 120, 255);
            case AIR_POCKET -> new Color(255, 255, 255, 200);
            case PLUG -> new Color(255, 140, 0, 220);
            case PISTON -> new Color(255, 40, 40, 230);
            case DRIPSTONE -> new Color(200, 170, 120, 220);
            case LINE -> new Color(0, 200, 255, 220);
            case MIS_ORE -> new Color(255, 215, 0, 230);
        };
    }

    private void outline(MatrixStack stack, float x1, float y1, float z1, float x2, float y2, float z2, Color c) {
        java.util.List<RenderUtils.ColoredLine> lines = new java.util.ArrayList<>();
        RenderUtils.addBoxOutline(lines, x1, y1, z1, x2, y2, z2, c, 2.0f);
        RenderUtils.renderLines(stack, lines);
    }
}
