package kren.debug.misc.modules;

import kren.debug.KrenDebug;
import meteordevelopment.meteorclient.events.world.TickEvent.Post;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.network.packet.s2c.common.DisconnectS2CPacket;
import net.minecraft.text.Text;

public class AutoRelog extends Module {
    private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
    private final Setting<Integer> height =
            this.sgGeneral.add(
                    new IntSetting.Builder()
                            .name("height")
                            .description("Reconnect when your Y coordinate is at or below this height.")
                            .defaultValue(-2)
                            .sliderRange(-64, 320)
                            .build());

    private ServerInfo pendingServer;

    public AutoRelog() {
        super(KrenDebug.MISC, "auto-relog", "Disconnects at the selected height and immediately reconnects.");
        this.runInMainMenu = true;
    }

    @Override
    public void onActivate() {
        this.pendingServer = null;
    }

    @Override
    public void onDeactivate() {
        this.pendingServer = null;
    }

    @EventHandler
    private void onTick(Post event) {
        if (!this.isActive()) return;

        if (this.pendingServer != null) {
            this.reconnectIfReady();
            return;
        }

        if (this.mc.player == null || this.mc.world == null || this.mc.getNetworkHandler() == null) return;
        if (this.mc.player.getY() > this.height.get()) return;

        ServerInfo server = this.mc.getCurrentServerEntry();
        if (server == null || server.address == null || server.address.isBlank()) {
            this.error("Cannot reconnect: no multiplayer server address is available.");
            this.toggle();
            return;
        }

        this.pendingServer = server;
        this.mc.getNetworkHandler().onDisconnect(
                new DisconnectS2CPacket(Text.literal("AutoRelog: reached Y " + this.height.get())));
        this.reconnectIfReady();
    }

    private void reconnectIfReady() {
        if (this.pendingServer == null || this.mc.player != null || this.mc.world != null) return;

        ServerInfo server = this.pendingServer;
        this.toggle();
        ConnectScreen.connect(
                new TitleScreen(), this.mc, ServerAddress.parse(server.address), server, false, null);
    }
}
