package kren.debug.misc.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import kren.debug.misc.modules.SwingSpeed;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(LivingEntity.class)
public abstract class SwingDurationMixin {

    @ModifyReturnValue(method = "getHandSwingDuration", at = @At("RETURN"))
    private int kren$modifySwingDuration(int original) {
        if (!((Object) this instanceof ClientPlayerEntity)) return original;
        if (SwingSpeed.INSTANCE == null || !SwingSpeed.INSTANCE.isActive()) return original;

        int modified = (int) Math.round(original / SwingSpeed.INSTANCE.getMultiplier());
        return Math.max(1, modified);
    }
}
