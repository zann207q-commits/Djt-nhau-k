package kren.debug.misc.antivanish;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.DefaultSkinHelper;
import net.minecraft.entity.player.SkinTextures;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

/**
 * Resolves a player skin for the staff HUD. Players that are in the tab list use their real skin,
 * anyone else (fully vanished staff) falls back to the default skin for their UUID.
 * (The original Glazed version downloaded the skin from minotar.net into a custom texture; that part
 * was dropped in the Yarn port because it relies on texture-registration internals that differ per mapping.)
 */
public final class FaceSkins {
    public record Skin(SkinTextures textures, boolean pending) {
    }

    private FaceSkins() {
    }

    public static Skin get(UUID id, String name) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayNetworkHandler connection = mc.getNetworkHandler();

        if (connection != null) {
            PlayerListEntry info = id == null ? null : connection.getPlayerListEntry(id);

            if (info == null && name != null) {
                for (PlayerListEntry entry : connection.getPlayerList()) {
                    if (entry.getProfile().name().equalsIgnoreCase(name)) {
                        info = entry;
                        break;
                    }
                }
            }

            if (info != null) return new Skin(info.getSkinTextures(), false);
        }

        UUID fallbackId = id != null ? id : UUID.nameUUIDFromBytes(String.valueOf(name).getBytes(StandardCharsets.UTF_8));
        return new Skin(DefaultSkinHelper.getSkinTextures(fallbackId), true);
    }

    /** Kept for API compatibility with the original module; nothing to preload anymore. */
    public static void preload(String name) {
    }

    public static boolean isReady(String name) {
        return false;
    }
}
