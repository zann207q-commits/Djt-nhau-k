package kren.debug.misc.antivanish;

import net.minecraft.client.gui.DrawContext;

/**
 * Anti-aliased rounded rectangle drawn with plain fill calls (one scanline per corner row,
 * with a partially transparent edge pixel), so no custom textures are needed.
 */
public final class SmoothRoundRect {
    private SmoothRoundRect() {
    }

    public static void draw(DrawContext g, int x, int y, int w, int h, int radius, int argb) {
        if (w <= 0 || h <= 0) return;

        int r = Math.max(2, Math.min(radius, Math.min(w, h) / 2));
        int a = (argb >>> 24) & 0xFF;
        int rgb = argb & 0xFFFFFF;

        // straight middle part
        g.fill(x, y + r, x + w, y + h - r, argb);

        for (int i = 0; i < r; i++) {
            double dy = r - (i + 0.5);
            double inset = r - Math.sqrt(Math.max(0.0, (double) r * r - dy * dy));
            int edge = (int) Math.floor(inset);
            double cover = edge + 1 - inset;

            int fullStart = edge;
            if (cover < 0.995) {
                fullStart = edge + 1;
                int partial = Math.max(0, Math.min(255, (int) Math.round(a * cover)));
                int partialArgb = (partial << 24) | rgb;
                if (partial > 0) {
                    g.fill(x + edge, y + i, x + edge + 1, y + i + 1, partialArgb);
                    g.fill(x + w - edge - 1, y + i, x + w - edge, y + i + 1, partialArgb);
                    g.fill(x + edge, y + h - 1 - i, x + edge + 1, y + h - i, partialArgb);
                    g.fill(x + w - edge - 1, y + h - 1 - i, x + w - edge, y + h - i, partialArgb);
                }
            }

            if (x + w - fullStart > x + fullStart) {
                g.fill(x + fullStart, y + i, x + w - fullStart, y + i + 1, argb);
                g.fill(x + fullStart, y + h - 1 - i, x + w - fullStart, y + h - i, argb);
            }
        }
    }

    public static void clear() {
    }
}
