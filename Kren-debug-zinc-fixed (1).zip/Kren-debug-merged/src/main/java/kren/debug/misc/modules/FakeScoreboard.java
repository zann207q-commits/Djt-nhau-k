package kren.debug.misc.modules;

import kren.debug.KrenDebug;
import kren.debug.misc.utils.MoneyFmt;
import meteordevelopment.meteorclient.events.game.GameJoinedEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.scoreboard.ScoreAccess;
import net.minecraft.scoreboard.ScoreHolder;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardCriterion;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Team;
import net.minecraft.scoreboard.number.BlankNumberFormat;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import java.util.ArrayList;
import java.util.List;

public class FakeScoreboard extends Module {
    private static final String OBJECTIVE = "kren_fakesb";
    private static final String TEAM_PREFIX = "kren_sb_";

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgLines = settings.createGroup("Lines");

    private final Setting<String> title = sgGeneral.add(new StringSetting.Builder()
        .name("title")
        .description("Text at the top of the board.")
        .defaultValue("Glazed")
        .build()
    );

    private final Setting<Boolean> showMoney = sgLines.add(new BoolSetting.Builder()
        .name("money")
        .defaultValue(true)
        .build()
    );

    private final Setting<String> money = sgLines.add(new StringSetting.Builder()
        .name("money-amount")
        .defaultValue("discord.gg")
        .visible(showMoney::get)
        .build()
    );

    private final Setting<Boolean> showShards = sgLines.add(new BoolSetting.Builder()
        .name("shards")
        .defaultValue(true)
        .build()
    );

    private final Setting<String> shards = sgLines.add(new StringSetting.Builder()
        .name("shards-amount")
        .defaultValue("/glazed")
        .visible(showShards::get)
        .build()
    );

    private final Setting<Boolean> showKills = sgLines.add(new BoolSetting.Builder()
        .name("kills")
        .defaultValue(true)
        .build()
    );

    private final Setting<String> kills = sgLines.add(new StringSetting.Builder()
        .name("kills-amount")
        .defaultValue("nnpg")
        .visible(showKills::get)
        .build()
    );

    private final Setting<Boolean> showDeaths = sgLines.add(new BoolSetting.Builder()
        .name("deaths")
        .defaultValue(true)
        .build()
    );

    private final Setting<String> deaths = sgLines.add(new StringSetting.Builder()
        .name("deaths-amount")
        .defaultValue("ar3")
        .visible(showDeaths::get)
        .build()
    );

    private final Setting<Boolean> showPlaytime = sgLines.add(new BoolSetting.Builder()
        .name("playtime")
        .defaultValue(true)
        .build()
    );

    private final Setting<String> playtime = sgLines.add(new StringSetting.Builder()
        .name("playtime-amount")
        .defaultValue("67")
        .visible(showPlaytime::get)
        .build()
    );

    private ScoreboardObjective ours;
    private ScoreboardObjective serverBoard;
    private final List<String> teams = new ArrayList<>();
    private long lastRefresh;

    public FakeScoreboard() {
        super(KrenDebug.MISC, "fake-scoreboard", "Replaces the sidebar with your own numbers.");
    }

    @Override
    public void onActivate() {
        lastRefresh = 0L;
        rebuild();
    }

    @Override
    public void onDeactivate() {
        teardown();
    }

    @EventHandler
    private void onGameJoined(GameJoinedEvent event) {
        ours = null;
        serverBoard = null;
        teams.clear();
        lastRefresh = 0L;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        // nah
        long now = System.currentTimeMillis();
        if (now - lastRefresh < 1000) return;

        lastRefresh = now;
        rebuild();
    }

    public void refresh() {
        lastRefresh = 0L;
    }

    private void rebuild() {
        if (mc.world == null || mc.player == null) return;

        Scoreboard board = mc.world.getScoreboard();

        ScoreboardObjective current = board.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
        if (current != null && !OBJECTIVE.equals(current.getName())) serverBoard = current;

        dropTeams(board);

        ScoreboardObjective old = board.getNullableObjective(OBJECTIVE);
        if (old != null) {
            try {
                board.removeObjective(old);
            } catch (Exception ignored) {
            }
        }

        ours = board.addObjective(OBJECTIVE, ScoreboardCriterion.DUMMY, white(title.get()),
            ScoreboardCriterion.RenderType.INTEGER, false, BlankNumberFormat.INSTANCE);
        board.setObjectiveSlot(ScoreboardDisplaySlot.SIDEBAR, ours);

        List<MutableText> lines = buildLines();
        for (int i = 0; i < lines.size(); i++) {
            String name = TEAM_PREFIX + i;
            teams.add(name);

            Team team = board.getTeam(name);
            if (team != null) board.removeTeam(team);
            team = board.addTeam(name);
            team.setPrefix(lines.get(i));

            // sus
            String holder = "§" + Integer.toHexString(i);
            ScoreHolder scoreHolder = ScoreHolder.fromName(holder);

            board.removeScore(scoreHolder, ours);
            ScoreAccess score = board.getOrCreateScore(scoreHolder, ours);
            score.setScore(lines.size() - i);
            board.addScoreHolderToTeam(holder, team);
        }
    }

    private List<MutableText> buildLines() {
        List<MutableText> lines = new ArrayList<>();

        if (showMoney.get()) lines.add(colored("$ ", 0x00FF00).append(white(displayedMoney())));
        if (showShards.get()) lines.add(colored("★ ", 0xA503FC).append(white(shards.get())));
        if (showKills.get()) lines.add(colored("🗡 ", 0xFF0000).append(white(kills.get())));
        if (showDeaths.get()) lines.add(colored("☠ ", 0xFC7703).append(white(deaths.get())));
        if (showPlaytime.get()) lines.add(colored("⌚ ", 0xFFE600).append(white(playtime.get())));

        if (lines.isEmpty()) lines.add(Text.literal(" "));
        return lines;
    }

    private String displayedMoney() {
        Double base = MoneyFmt.parse(money.get());
        if (base == null) return money.get();

        return MoneyFmt.format(Math.max(0.0, base));
    }

    private void teardown() {
        if (mc.world == null) {
            ours = null;
            teams.clear();
            return;
        }

        Scoreboard board = mc.world.getScoreboard();
        dropTeams(board);

        if (ours != null) {
            try {
                board.removeObjective(ours);
            } catch (Exception ignored) {
            }
            ours = null;
        }

        ScoreboardObjective restore = null;
        if (serverBoard != null) {
            try {
                if (board.getNullableObjective(serverBoard.getName()) != null) restore = serverBoard;
            } catch (Exception ignored) {
            }
        }

        try {
            board.setObjectiveSlot(ScoreboardDisplaySlot.SIDEBAR, restore);
        } catch (Exception ignored) {
        }

        serverBoard = null;
    }

    private void dropTeams(Scoreboard board) {
        for (String name : teams) {
            try {
                Team team = board.getTeam(name);
                if (team != null) board.removeTeam(team);
            } catch (Exception ignored) {
            }
        }
        teams.clear();
    }

    private MutableText colored(String text, int rgb) {
        return Text.literal(text).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(rgb)));
    }

    private MutableText white(String text) {
        return colored(text, 0xFFFFFF);
    }
}
