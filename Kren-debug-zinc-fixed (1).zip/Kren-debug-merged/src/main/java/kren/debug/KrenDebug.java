package kren.debug;

import java.lang.invoke.MethodHandles;
import java.util.List;
import java.util.function.Supplier;
import kren.debug.bridge.KrenSync;
import kren.debug.bridge.KrispyBridgeModule;
import kren.debug.core.Krispy;
import kren.debug.core.feature.*;
import kren.debug.modules.OGChunkFinder;
import kren.debug.modules.SignalDebug;
import kren.debug.modules.SusBypassV2;
import kren.debug.modules.ZenDebug;
import kren.debug.modules.ZenDebugV1;
import kren.debug.misc.antivanish.AntiVanish;
import kren.debug.misc.antivanish.WatchingEffect;
import kren.debug.misc.modules.AdminHud;
import kren.debug.misc.modules.AdminList;
import kren.debug.misc.modules.AutoRelog;
import kren.debug.misc.modules.FakeScoreboard;
import kren.debug.misc.modules.HomeMethod;
import kren.debug.misc.modules.RegionMap;
import kren.debug.misc.modules.SpawnerNotifier;
import kren.debug.misc.modules.SwingSpeed;
import kren.debug.misc.modules.TabDetector;
import kren.debug.misc.modules.UdRelog;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

public class KrenDebug extends MeteorAddon {
   public static final Category CATEGORY = new Category("Kren Debug");
   public static final Category MISC = new Category("Kren Misc", new ItemStack(Items.NETHER_STAR));

   private static final List<Class<? extends kren.debug.core.module.Module>> EXPOSED = List.of(
      ChunkFinderModule.class,
      ChunkFinderBetterModule.class,
      KazeChunkFinderModule.class,
      SusChunkV2Module.class
   );

   @Override
   public void onInitialize() {
      MeteorClient.EVENT_BUS.registerLambdaFactory("kren.debug", (lookupInMethod, klass) -> (MethodHandles.Lookup) lookupInMethod.invoke(null, klass, MethodHandles.lookup()));
      // Z Debug V4 is bundled as bytecode under dev.zv3. Orbit requires a
      // lambda factory for each package containing event-listener classes.
      // Register it before loading Bypass or LightCache, otherwise their
      // @EventHandler subscriptions throw NoLambdaFactoryException.
      MeteorClient.EVENT_BUS.registerLambdaFactory("dev.zv3", (lookupInMethod, klass) -> (MethodHandles.Lookup) lookupInMethod.invoke(null, klass, MethodHandles.lookup()));

      Krispy core = Krispy.boot();
      for (Class<? extends kren.debug.core.module.Module> type : EXPOSED) {
         kren.debug.core.module.Module m = core.getModuleManager().getModuleByClass(type);
         if (m == null) {
            System.err.println("[Kren Debug] module missing: " + type.getSimpleName());
            continue;
         }
         try {
            Modules.get().add(new KrispyBridgeModule(CATEGORY, m));
         } catch (Throwable t) {
            System.err.println("[Kren Debug] failed to register " + type.getSimpleName() + ": " + t);
         }
      }
      // Native Meteor modules merged from the fixed addon source.
      List<Supplier<Module>> nativeModules = List.of(
         OGChunkFinder::new,
         SignalDebug::new,
         com.vrzt.zinc.modules.esp.AdvancedStashFinder::new,
         com.vrzt.zinc.modules.esp.BlockNotifier::new,
         com.vrzt.zinc.modules.esp.ChunkFinderV2::new,
         com.vrzt.zinc.modules.esp.KelpESP::new,
         com.vrzt.zinc.modules.esp.LightESP::new,
         com.vrzt.zinc.modules.main.PlayerDetection::new,
         com.vrzt.zinc.modules.Zinc.BaseDigger::new
      );
      for (Supplier<Module> factory : nativeModules) {
         try {
            Modules.get().add(factory.get());
         } catch (Throwable t) {
            System.err.println("[Kren Debug] failed to register native module: " + t);
         }
      }
      // Imported Z v4 module: register its original bytecode and its light-packet intake.
      try {
         Class<?> z4Class = Class.forName("dev.zv3.modules.Bypass");
         Module z4Module = (Module) z4Class.getDeclaredConstructor().newInstance();
         Modules.get().add(z4Module);
         Class<?> lightCache = Class.forName("dev.zv3.light.LightCache");
         lightCache.getMethod("register").invoke(null);
         System.out.println("[Kren Debug] Registered Z Debug Z4 module.");
      } catch (Throwable t) {
         System.err.println("[Kren Debug] failed to register Z Debug Z4: " + t);
         t.printStackTrace();
      }
      // Modules merged from Glazed (all live in the "Kren Misc" category).
      List<Supplier<Module>> miscModules = List.of(
         SwingSpeed::new,
         AdminHud::new,
         AdminList::new,
         AntiVanish::new,
         AutoRelog::new,
         FakeScoreboard::new,
         HomeMethod::new,
         UdRelog::new,
         TabDetector::new,
         SpawnerNotifier::new,
         RegionMap::new
      );
      for (Supplier<Module> factory : miscModules) {
         try {
            Modules.get().add(factory.get());
         } catch (Throwable t) {
            System.err.println("[Kren Debug] failed to register Kren Misc module: " + t);
         }
      }
      try {
         MeteorClient.EVENT_BUS.subscribe(WatchingEffect.get());
      } catch (Throwable t) {
         System.err.println("[Kren Debug] failed to subscribe WatchingEffect: " + t);
      }
      MeteorClient.EVENT_BUS.subscribe(new KrenSync());
   }

   @Override
   public void onRegisterCategories() {
      Modules.registerCategory(CATEGORY);
      Modules.registerCategory(MISC);
      Modules.registerCategory(com.vrzt.zinc.ZincAddon.esp);
      Modules.registerCategory(com.vrzt.zinc.ZincAddon.Zinc);
   }

   @Override
   public String getPackage() {
      return "kren.debug";
   }
}
