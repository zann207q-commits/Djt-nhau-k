/* Renamed for source analysis. Original archive path: com/example/addon/modules/bl.java
 * Display name: Zen Debug
 * Confidence: High confidence: chunk/base signature detection, marker and RTP.
 * This extracted module may require original addon dependencies to compile.
 */
/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  meteordevelopment.meteorclient.events.packets.PacketEvent$Receive
 *  meteordevelopment.meteorclient.events.render.Render2DEvent
 *  meteordevelopment.meteorclient.events.render.Render3DEvent
 *  meteordevelopment.meteorclient.events.world.TickEvent$Pre
 *  meteordevelopment.meteorclient.renderer.Renderer2D
 *  meteordevelopment.meteorclient.renderer.text.TextRenderer
 *  meteordevelopment.meteorclient.settings.BoolSetting$Builder
 *  meteordevelopment.meteorclient.settings.ColorSetting$Builder
 *  meteordevelopment.meteorclient.settings.DoubleSetting$Builder
 *  meteordevelopment.meteorclient.settings.IntSetting$Builder
 *  meteordevelopment.meteorclient.settings.Setting
 *  meteordevelopment.meteorclient.settings.SettingGroup
 *  meteordevelopment.meteorclient.settings.StringSetting$Builder
 *  meteordevelopment.meteorclient.systems.modules.Module
 *  meteordevelopment.meteorclient.utils.player.ChatUtils
 *  meteordevelopment.meteorclient.utils.render.color.Color
 *  meteordevelopment.meteorclient.utils.render.color.SettingColor
 *  meteordevelopment.orbit.EventHandler
 */
package kren.debug.modules;

import kren.debug.KrenDebug;
import java.util.BitSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.render.Render2DEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.Renderer2D;
import meteordevelopment.meteorclient.renderer.text.TextRenderer;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.network.packet.s2c.play.ChunkDataS2CPacket;
import net.minecraft.network.packet.s2c.play.LightUpdateS2CPacket;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.network.packet.s2c.play.LightData;

public class ZenDebug
extends Module {
    private static final int INTAKE_MAX_PER_TICK = 4096;
    private static final int WORLD_MIN_Y = -64;
    private static final int SECTION_TOP_MAX = 184;
    private static final long NOTIFY_MS = 3000L;
    private final SettingGroup sgGeneral;
    private final SettingGroup sgDetect;
    private final SettingGroup sgRender;
    private final SettingGroup sgRtp;
    private final SettingGroup sgLimits;
    private final Setting<SettingColor> detectedColor;
    private final Setting<Boolean> detectionEnabled;
    private final Setting<Integer> ceilingY;
    private final Setting<Integer> maxDetectCount;
    private final Setting<Double> fadeDuration;
    private final Setting<Integer> renderRadius;
    private final Setting<Double> markerY;
    private final Setting<Double> plateHeight;
    private final Setting<SettingColor> notifyBg;
    private final Setting<Double> notifyY;
    private final Setting<Boolean> rtpEnabled;
    private final Setting<String> rtpCommand;
    private final Setting<Integer> rtpDelaySec;
    private final Setting<Integer> rtpJitterSec;
    private final Setting<Integer> rtpMinIntervalSec;
    private final Setting<Integer> rtpStopRadius;
    private long nextRtpMs;
    private long lastRtpMs;
    private final ConcurrentLinkedQueue<c> intakeQueue = new ConcurrentLinkedQueue();
    private final Map<Long, b> snapshots = new ConcurrentHashMap<Long, b>();
    private final Map<Long, Long> fadeOutStarts = new ConcurrentHashMap<Long, Long>();
    private final Map<Long, Long> detected = new ConcurrentHashMap<Long, Long>();
    private long lastNotifyNanos;
    private ClientWorld lastWorld;

    public ZenDebug() {
        super(KrenDebug.CATEGORY, "zen-debug", "");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.sgDetect = this.settings.createGroup("Detect");
        this.sgRender = this.settings.createGroup("Render");
        this.sgRtp = this.settings.createGroup("RTP");
        this.sgLimits = this.settings.createGroup("Limits");
        this.detectedColor = this.sgGeneral.add(((new ColorSetting.Builder().name("detected-color")).description("Color of the highlight boxes for chunks matching the base signature.")).defaultValue(new SettingColor(255, 30, 50, 220)).build());
        this.maxDetectCount = this.sgLimits.add((((new IntSetting.Builder().name("max-detect-count")).description("Maximum number of detected chunks loaded/rendered at once. When a new chunk is found over the cap, the oldest one is dropped.")).defaultValue(6)).min(1).max(16).build());
        this.ceilingY = this.sgDetect.add((((new IntSetting.Builder().name("ceiling-y")).description("A section only counts as a base signature if it sits entirely below this Y level and has fully zeroed sky light.")).defaultValue(62)).min(-64).max(320).build());
        this.detectionEnabled = this.sgDetect.add((((new BoolSetting.Builder().name("detection-enabled")).description("Master toggle for the whole Zen Debug detection system. Off = no new light packets are processed; previously detected markers still render so you can keep looking at them.")).defaultValue(true)).build());
        this.fadeDuration = this.sgRender.add(((new DoubleSetting.Builder().name("fade-duration")).description("How long detected chunks take to fade in and back out, in seconds.")).defaultValue(3.0).min(0.1).max(10.0).sliderRange(0.1, 10.0).build());
        this.renderRadius = this.sgRender.add((((new IntSetting.Builder().name("render-radius")).description("How many chunks around you to draw detected boxes for.")).defaultValue(16)).min(4).max(48).build());
        this.markerY = this.sgRender.add(((new DoubleSetting.Builder().name("marker-y")).description("Y level of the bottom of the highlight boxes.")).defaultValue(64.0).min(-64.0).max(320.0).build());
        this.plateHeight = this.sgRender.add(((new DoubleSetting.Builder().name("plate-height")).description("Vertical height of the highlight boxes.")).defaultValue(1.0).min(0.05).max(4.0).build());
        this.notifyBg = this.sgRender.add(((new ColorSetting.Builder().name("notify-bg")).description("Background color of the Player Chunk Detected popup.")).defaultValue(new SettingColor(15, 15, 20, 110)).build());
        this.notifyY = this.sgRender.add(((new DoubleSetting.Builder().name("notify-y")).description("Y (vertical) position of the Player Chunk Detected popup on screen.")).defaultValue(12.0).min(0.0).max(500.0).sliderRange(0.0, 300.0).build());
        this.rtpEnabled = this.sgRtp.add((((new BoolSetting.Builder().name("auto-rtp")).description("Automatically runs the RTP command every so often so you keep wandering; stops while a Player Debug chunk is detected near you.")).defaultValue(false)).build());
        this.rtpCommand = this.sgRtp.add((((new StringSetting.Builder().name("rtp-command")).description("Command run by auto-RTP, without the leading slash.")).defaultValue("rtp")).build());
        this.rtpDelaySec = this.sgRtp.add((((new IntSetting.Builder().name("rtp-delay-sec")).description("Base delay between RTPs, in seconds. Keeps you under the server anti-spam threshold.")).defaultValue(8)).min(1).max(600).sliderRange(2, 90).build());
        this.rtpJitterSec = this.sgRtp.add((((new IntSetting.Builder().name("rtp-jitter-sec")).description("Random extra seconds added on top of the delay so the timing looks less robotic.")).defaultValue(4)).min(0).max(120).sliderRange(0, 30).build());
        this.rtpMinIntervalSec = this.sgRtp.add((((new IntSetting.Builder().name("rtp-min-interval-sec")).description("Hard minimum seconds between actual RTP sends. Keeps repeated teleports from making the game laggy.")).defaultValue(60)).min(1).max(600).sliderRange(5, 180).build());
        this.rtpStopRadius = this.sgRtp.add((((new IntSetting.Builder().name("rtp-stop-radius")).description("Auto-RTP stops while a detected player chunk is within this many chunks of you.")).defaultValue(1)).min(0).max(16).build());
    }

    public void onActivate() {
        this.intakeQueue.clear();
        this.snapshots.clear();
        this.fadeOutStarts.clear();
        this.detected.clear();
        this.nextRtpMs = 0L;
        this.lastRtpMs = 0L;
        this.lastNotifyNanos = 0L;
        this.lastWorld = null;
    }

    public void onDeactivate() {
        this.intakeQueue.clear();
        this.snapshots.clear();
        this.fadeOutStarts.clear();
        this.detected.clear();
        this.nextRtpMs = 0L;
        this.lastRtpMs = 0L;
        this.lastNotifyNanos = 0L;
        this.lastWorld = null;
    }

    @EventHandler
    private void onPacketReceive(PacketEvent.Receive receive) {
        if (this.mc.world == null || this.mc.player == null) {
            return;
        }
        if (!((Boolean)this.detectionEnabled.get()).booleanValue()) {
            return;
        }
        if (receive.packet instanceof ChunkDataS2CPacket) {
            ChunkDataS2CPacket chunkDataS2CPacket2 = (ChunkDataS2CPacket)receive.packet;
            this.intakeQueue.offer(new c(chunkDataS2CPacket2.getChunkX(), chunkDataS2CPacket2.getChunkZ(), chunkDataS2CPacket2.getLightData()));
        } else if (receive.packet instanceof LightUpdateS2CPacket) {
            LightUpdateS2CPacket lightUpdateS2CPacket2 = (LightUpdateS2CPacket)receive.packet;
            this.intakeQueue.offer(new c(lightUpdateS2CPacket2.getChunkX(), lightUpdateS2CPacket2.getChunkZ(), lightUpdateS2CPacket2.getData()));
        }
    }

    @EventHandler
    private void onTick(TickEvent.Pre pre) {
        ClientWorld NarrationMessageBuilder = this.mc.world;
        if (NarrationMessageBuilder == null || this.mc.player == null) {
            this.intakeQueue.clear();
            return;
        }
        if (NarrationMessageBuilder != this.lastWorld) {
            this.snapshots.clear();
            this.fadeOutStarts.clear();
            this.detected.clear();
            this.lastNotifyNanos = 0L;
            this.intakeQueue.clear();
            this.lastWorld = NarrationMessageBuilder;
        }
        if (this.mc.player.getY() < 0.0) {
            this.intakeQueue.clear();
            return;
        }
        if (((Boolean)this.detectionEnabled.get()).booleanValue()) {
            c c2;
            for (int i2 = 0; i2 < 4096 && (c2 = this.intakeQueue.poll()) != null; ++i2) {
                try {
                    this.ingest(c2);
                    continue;
                } catch (Throwable throwable) {
                    // skip malformed light packet
                }
            }
        }
        this.sweepUnloaded();
        this.tickRtp();
    }

    private void tickRtp() {
        if (!((Boolean)this.rtpEnabled.get()).booleanValue()) {
            this.nextRtpMs = 0L;
            return;
        }
        if (this.mc.player == null || this.mc.world == null) {
            this.nextRtpMs = 0L;
            return;
        }
        int n2 = this.mc.player.getBlockPos().getX() >> 4;
        int n3 = this.mc.player.getBlockPos().getZ() >> 4;
        int n4 = Math.max(0, (Integer)this.rtpStopRadius.get());
        boolean bl2 = false;
        for (long l2 : this.detected.keySet()) {
            int n5;
            int n6 = (int)l2 - n2;
            if (n6 < 0) {
                n6 = -n6;
            }
            if ((n5 = (int)(l2 >> 32) - n3) < 0) {
                n5 = -n5;
            }
            if (n6 > n4 || n5 > n4) continue;
            bl2 = true;
            break;
        }
        long l3 = System.currentTimeMillis();
        if (bl2) {
            this.nextRtpMs = l3 + 1500L;
            return;
        }
        if (this.nextRtpMs <= 0L) {
            this.nextRtpMs = l3 + 3000L;
            return;
        }
        if (l3 < this.nextRtpMs) {
            return;
        }
        long l4 = (long)((Integer)this.rtpMinIntervalSec.get()).intValue() * 1000L;
        if (this.lastRtpMs > 0L && l3 < this.lastRtpMs + l4) {
            this.nextRtpMs = this.lastRtpMs + l4;
            return;
        }
        String string = (String)this.rtpCommand.get();
        if (string == null || string.trim().isEmpty()) {
            this.nextRtpMs = l3 + 60000L;
            return;
        }
        String string2 = string.trim();
        if (!string2.startsWith("/")) {
            string2 = "/" + string2;
        }
        try {
            ChatUtils.sendPlayerMsg((String)string2);
        } catch (Throwable throwable) {
            // empty catch block
        }
        long l5 = (long)((Integer)this.rtpDelaySec.get()).intValue() * 1000L;
        long l6 = (long)((Integer)this.rtpJitterSec.get()).intValue() * 1000L;
        if (l6 > 0L) {
            l5 += (long)(ZenDebug.hrand(l3 ^ 0x9E3779B97F4A7C15L) * (double)l6);
        }
        if (l5 < l4) {
            l5 = l4;
        }
        if (l5 < 1000L) {
            l5 = 1000L;
        }
        this.lastRtpMs = l3;
        this.nextRtpMs = l3 + l5;
    }

    private void ingest(c c2) {
        if (c2.data == null) {
            return;
        }
        long l2 = ChunkPos.toLong((int)c2.chunkX, (int)c2.chunkZ);
        b b2 = this.snapshots.get(l2);
        if (b2 == null) {
            b2 = new b(c2.chunkX, c2.chunkZ, 0, -4);
            this.snapshots.put(l2, b2);
        }
        a.apply(c2.data, b2, c2.arrivalNanos);
        this.maybeDetect(l2, b2);
    }

    private void maybeDetect(long l2, b b2) {
        if (!((Boolean)this.detectionEnabled.get()).booleanValue()) {
            return;
        }
        if (this.detected.containsKey(l2)) {
            return;
        }
        int n2 = (Integer)this.ceilingY.get();
        for (int i2 = 1; i2 <= b2.sectionCount; ++i2) {
            if (i2 >= b2.sky.length) continue;
            int n3 = b2.bottomSectionY + i2 - 1;
            int n4 = n3 * 16 + 15;
            int n5 = n3 * 16;
            if (n4 < -64 || n5 > 184 || n4 >= n2 || b2.sky[i2] != d.ZEROED_PRESENT) continue;
            this.addDetected(l2);
            return;
        }
    }

    private void addDetected(long l2) {
        long l3 = System.nanoTime();
        int n2 = (Integer)this.maxDetectCount.get();
        if (n2 > 0 && !this.detected.containsKey(l2) && this.detected.size() >= n2) {
            long l4 = -1L;
            long l5 = Long.MAX_VALUE;
            for (Map.Entry<Long, Long> entry : this.detected.entrySet()) {
                if (entry.getValue() >= l5) continue;
                l5 = entry.getValue();
                l4 = entry.getKey();
            }
            this.detected.remove(l4);
            this.fadeOutStarts.remove(l4);
            this.snapshots.remove(l4);
        }
        this.detected.put(l2, l3);
        this.notifyDetect();
    }

    private void sweepUnloaded() {
        int n2 = this.mc.player.getBlockPos().getX() >> 4;
        int n3 = this.mc.player.getBlockPos().getZ() >> 4;
        int n4 = (Integer)this.renderRadius.get();
        for (Map.Entry<Long, b> entry : this.snapshots.entrySet()) {
            int n5;
            boolean bl2;
            long l2 = entry.getKey();
            int n6 = (int)l2;
            boolean bl3 = bl2 = this.mc.world.getChunkManager().getWorldChunk(n6, n5 = (int)(l2 >> 32)) != null || System.nanoTime() - entry.getValue().lastUpdate() < 5000000000L;
            if (bl2) {
                this.fadeOutStarts.remove(l2);
                continue;
            }
            if (this.detected.containsKey(l2)) {
                if (Math.abs(n6 - n2) <= n4 && Math.abs(n5 - n3) <= n4) continue;
                this.snapshots.remove(l2);
                this.fadeOutStarts.remove(l2);
                continue;
            }
            this.snapshots.remove(l2);
        }
    }

    @EventHandler
    private void onRender(Render3DEvent render3DEvent) {
        if (this.mc.world == null || this.mc.player == null) {
            return;
        }
        int n2 = this.mc.player.getBlockPos().getX() >> 4;
        int n3 = this.mc.player.getBlockPos().getZ() >> 4;
        int n4 = (Integer)this.renderRadius.get();
        SettingColor settingColor = (SettingColor)this.detectedColor.get();
        double d2 = (Double)this.fadeDuration.get() * 1000.0;
        long l2 = System.nanoTime();
        double d3 = (Double)this.markerY.get();
        double d4 = d3 + (Double)this.plateHeight.get();
        Iterator<Map.Entry<Long, Long>> iterator = this.detected.entrySet().iterator();
        while (iterator.hasNext()) {
            double d5;
            double d6;
            double d7;
            double d8;
            double d9;
            double d10;
            double d11;
            double d12;
            double d13;
            double d14;
            double d15;
            double d16;
            double d17;
            double d18;
            double d19;
            Color color;
            double d20;
            double d21;
            double d22;
            double d23;
            int n5;
            double d24;
            double d25;
            double d26;
            double d27;
            double d28;
            double d29;
            int n6;
            double d30;
            Map.Entry<Long, Long> entry = iterator.next();
            long l3 = entry.getKey();
            int n7 = (int)l3;
            int n8 = (int)(l3 >> 32);
            if (n7 == n2 && n8 == n3 && this.mc.player.getBlockPos().getY() <= -1) {
                iterator.remove();
                this.snapshots.remove(l3);
                this.fadeOutStarts.remove(l3);
                continue;
            }
            if (Math.abs(n7 - n2) > n4 || Math.abs(n8 - n3) > n4) continue;
            double d31 = (double)(l2 - entry.getValue()) / d2;
            d30 = d31 <= 0.0 ? 0.0 : (d31 >= 1.0 ? 1.0 : d31);
            double d32 = d30;
            if (d30 <= 0.0) continue;
            double d33 = d30 * d30 * (3.0 - 2.0 * d30);
            int n9 = Math.max(15, Math.min(255, (int)((double)settingColor.a * 0.85)));
            int n10 = Math.max(6, Math.min(255, (int)((double)settingColor.a * 0.55)));
            Color color2 = new Color(settingColor.r, settingColor.g, settingColor.b, (int)((double)n9 * d33));
            double d34 = n7 << 4;
            double d35 = n8 << 4;
            double d36 = d34 + 8.0;
            double d37 = d35 + 8.0;
            int n11 = 48;
            int n12 = 5;
            double d38 = 8.0;
            Color color3 = new Color(settingColor.r, settingColor.g, settingColor.b, Math.max(6, Math.min(255, (int)((double)n10 * d33))));
            for (n6 = 0; n6 < n11; ++n6) {
                d29 = Math.PI * 2 * (double)n6 / (double)n11;
                d28 = Math.PI * 2 * (double)(n6 + 1) / (double)n11;
                d27 = d36 + Math.cos(d29) * d38;
                d26 = d37 + Math.sin(d29) * d38;
                d25 = d36 + Math.cos(d28) * d38;
                d24 = d37 + Math.sin(d28) * d38;
                render3DEvent.renderer.quad(d36, d4, d37, d27, d4, d26, d25, d4, d24, d36, d4, d37, color3, color3, color3, color3);
                render3DEvent.renderer.quad(d27, d4, d26, d25, d4, d24, d25, d3, d24, d27, d3, d26, color3, color3, color3, color3);
            }
            for (n6 = 0; n6 < n11 - 1; ++n6) {
                d29 = Math.PI * 2 * (double)n6 / (double)n11;
                d28 = Math.PI * 2 * (double)(n6 + 1) / (double)n11;
                d27 = d36 + Math.cos(d29) * d38;
                d26 = d37 + Math.sin(d29) * d38;
                d25 = d36 + Math.cos(d28) * d38;
                d24 = d37 + Math.sin(d28) * d38;
                render3DEvent.renderer.line(d27, d4, d26, d25, d4, d24, new Color(color2.r, color2.g, color2.b, (int)((double)n9 * d33 * 0.8)));
            }
            double d39 = (double)System.currentTimeMillis() * 0.0015;
            int n13 = 24;
            d28 = 0.3;
            for (n5 = 0; n5 < n13; ++n5) {
                d23 = Math.PI * 2 * (double)n5 / (double)n13 + d39 * 0.4;
                d22 = Math.cos(d23);
                d21 = Math.sin(d23);
                double d40 = d38 - 0.15;
                double d41 = d38 - 1.2;
                double d42 = -d21 * d28 * 0.5;
                d20 = d22 * d28 * 0.5;
                color = new Color(color2.r, color2.g, color2.b, (int)((double)n9 * d33));
                render3DEvent.renderer.quad(d36 + d22 * d40 + d42, d4, d37 + d21 * d40 + d20, d36 + d22 * d40 - d42, d4, d37 + d21 * d40 - d20, d36 + d22 * d41 - d42, d4, d37 + d21 * d41 - d20, d36 + d22 * d41 + d42, d4, d37 + d21 * d41 + d20, color, color, color, color);
            }
            n5 = 100;
            for (int i2 = 0; i2 < n5 - 1; ++i2) {
                d26 = (double)i2 / (double)n5;
                d25 = (double)(i2 + 1) / (double)n5;
                d24 = d39 + d26 * Math.PI * 6.0;
                d19 = d39 + d25 * Math.PI * 6.0;
                d18 = 1.5 + 5.0 * d26;
                d17 = 1.5 + 5.0 * d25;
                d16 = d36 + Math.cos(d24) * d18;
                d15 = d37 + Math.sin(d24) * d18;
                d14 = d36 + Math.cos(d19) * d17;
                d13 = d37 + Math.sin(d19) * d17;
                int n14 = (int)(d33 * 220.0 * (0.5 + 0.5 * (1.0 - d26)));
                render3DEvent.renderer.line(d16, d4, d15, d14, d4, d13, new Color(settingColor.r, settingColor.g, settingColor.b, n14));
            }
            d23 = 1.0;
            d22 = 0.45;
            d21 = d4;
            Color color4 = new Color(settingColor.r, settingColor.g, settingColor.b, Math.max(8, Math.min(255, (int)(d33 * 220.0))));
            for (int i3 = 0; i3 < n12 * 2; ++i3) {
                int n15 = (i3 + 1) % (n12 * 2);
                d18 = -1.5707963267948966 + (double)i3 * Math.PI / (double)n12 + d39 * 0.6;
                d17 = -1.5707963267948966 + (double)n15 * Math.PI / (double)n12 + d39 * 0.6;
                d16 = i3 % 2 == 0 ? d23 : d22;
                d15 = n15 % 2 == 0 ? d23 : d22;
                d14 = d36 + Math.cos(d18) * d16;
                d13 = d37 + Math.sin(d18) * d16;
                double d43 = d36 + Math.cos(d17) * d15;
                double d44 = d37 + Math.sin(d17) * d15;
                render3DEvent.renderer.line(d14, d21, d13, d43, d21, d44, color4);
            }
            d19 = (double)System.currentTimeMillis() * 0.001;
            int n16 = 8;
            long l4 = l3 * 2654435761L + 1013904223L;
            d20 = d33 * 200.0;
            color = new Color(settingColor.r, settingColor.g, settingColor.b, Math.max(10, Math.min(255, (int)d20)));
            for (int i4 = 0; i4 < n16; ++i4) {
                double d45;
                double d46;
                long l5 = l4 + (long)i4 * 7919L;
                double d47 = ZenDebug.hrand(l5 + 3L);
                double d48 = ZenDebug.hrand(l5 + 70001L);
                double d49 = ZenDebug.hrand(l5 + 13L) * Math.PI * 2.0;
                double d50 = ZenDebug.hrand(l5 + 101L) * Math.PI * 2.0;
                d12 = 0.15 + ZenDebug.hrand(l5 + 151L) * 0.15;
                d11 = 0.5 + d47 * 7.5;
                d10 = d48 * Math.PI * 2.0;
                d9 = d36 + Math.cos(d10) * d11;
                double d51 = d37 + Math.sin(d10) * d11;
                double d52 = d3 + 2.0 + d50 / (Math.PI * 2) * 4.0;
                d8 = d9 + Math.sin(d19 * d12 + d49) * 2.4;
                d7 = d51 + Math.sin(d19 * d12 * 0.8 + d49 * 1.7) * 1.8;
                d6 = d52 + Math.sin(d19 * d12 * 1.3 + d49 * 2.3) * 0.8;
                d5 = 0.38;
                double d53 = 0.16;
                double d54 = this.mc.player.getX();
                double d55 = d8 - d54;
                double d56 = Math.sqrt(d55 * d55 + (d46 = d7 - (d45 = this.mc.player.getZ())) * d46);
                if (d56 < 0.001) {
                    d56 = 0.001;
                }
                double d57 = d55 / d56;
                double d58 = d46 / d56;
                double d59 = -d58;
                double d60 = d57;
                for (int i5 = 0; i5 < n12 * 2; ++i5) {
                    double d61 = (double)i5 * Math.PI / (double)n12;
                    double d62 = i5 % 2 == 0 ? d5 : d53;
                    double d63 = i5 % 2 == 0 ? d53 : d5;
                    double d64 = d8 + d59 * Math.sin(d61) * d62;
                    double d65 = d7 + d60 * Math.sin(d61) * d62;
                    double d66 = d6 + Math.cos(d61) * d62;
                    double d67 = d8 + d59 * Math.sin(d61 + Math.PI / (double)n12) * d63;
                    double d68 = d7 + d60 * Math.sin(d61 + Math.PI / (double)n12) * d63;
                    double d69 = d6 + Math.cos(d61 + Math.PI / (double)n12) * d63;
                    render3DEvent.renderer.quad(d64, d66, d65, d8, d6, d7, d8, d6, d7, d67, d69, d68, color);
                }
            }
            d15 = (double)System.currentTimeMillis() * 8.0E-4 + (double)(l3 & 0x1FL);
            d14 = d3 + 1.5;
            d13 = 8.0;
            double d70 = 1.1;
            int n17 = 28;
            int n18 = Math.max(8, Math.min(255, (int)(d33 * 210.0)));
            Color color5 = new Color(settingColor.r, settingColor.g, settingColor.b, n18);
            for (int i6 = 0; i6 < n17; ++i6) {
                double d71 = Math.PI * 2 * (double)i6 / (double)n17;
                double d72 = Math.PI * 2 * (double)(i6 + 1) / (double)n17;
                double d73 = d14 + d70 * Math.cos(d71 - d15);
                double d74 = d14 + d70 * Math.cos(d72 - d15);
                render3DEvent.renderer.line(d36 + Math.cos(d71) * d13, d73, d37 + Math.sin(d71) * d13, d36 + Math.cos(d72) * d13, d74, d37 + Math.sin(d72) * d13, color5);
            }
            d12 = -((double)System.currentTimeMillis() * 8.0E-4) + (double)(l3 >>> 8 & 0x1FL);
            d11 = d3 + 1.5;
            d10 = 8.0;
            d9 = 1.1;
            int n19 = 28;
            int n20 = Math.max(8, Math.min(255, (int)(d33 * 210.0)));
            Color color6 = new Color(settingColor.r, settingColor.g, settingColor.b, n20);
            for (int i7 = 0; i7 < n19; ++i7) {
                d8 = Math.PI * 2 * (double)i7 / (double)n19;
                d7 = Math.PI * 2 * (double)(i7 + 1) / (double)n19;
                d6 = d11 + d9 * Math.cos(d8 - d12);
                d5 = d11 + d9 * Math.cos(d7 - d12);
                render3DEvent.renderer.line(d36 + Math.cos(d8) * d10, d6, d37 + Math.sin(d8) * d10, d36 + Math.cos(d7) * d10, d5, d37 + Math.sin(d7) * d10, color6);
            }
        }
    }

    private void notifyDetect() {
        this.lastNotifyNanos = System.nanoTime();
    }

    private static double hrand(long l2) {
        double d2 = Math.sin((double)l2 * 12.9898) * 43758.5453;
        return d2 - Math.floor(d2);
    }

    @EventHandler
    private void onHud(Render2DEvent render2DEvent) {
        double d2;
        if (this.mc.player == null || this.mc.world == null) {
            return;
        }
        long l2 = System.nanoTime();
        long l3 = (l2 - this.lastNotifyNanos) / 1000000L;
        if (l3 < 0L || l3 >= 3000L) {
            return;
        }
        double d3 = (double)l3 / 3000.0;
        double d4 = d2 = d3 > 0.8 ? 255.0 * (1.0 - (d3 - 0.8) / 0.2) : 255.0;
        if (d2 <= 0.0) {
            return;
        }
        double d5 = (double)this.mc.getWindow().getFramebufferWidth() / 2.0;
        double d6 = 300.0;
        double d7 = 42.0;
        double d8 = d5 - d6 / 2.0;
        double d9 = (Double)this.notifyY.get();
        Color color = (Color)this.notifyBg.get();
        Renderer2D.COLOR.begin();
        Renderer2D.COLOR.quad(d8, d9, d6, d7, new Color(color.r, color.g, color.b, (int)((double)color.a * d2 / 255.0)));
        double d10 = d8 + 26.0;
        double d11 = d9 + d7 / 2.0;
        double d12 = (double)System.currentTimeMillis() * 0.002;
        int n2 = 18;
        for (int i2 = 0; i2 < n2; ++i2) {
            double d13 = (double)i2 / (double)n2;
            double d14 = (double)(i2 + 1) / (double)n2;
            double d15 = d12 + d13 * Math.PI * 6.0;
            double d16 = d12 + d14 * Math.PI * 6.0;
            double d17 = 2.0 + 11.0 * d13;
            double d18 = 2.0 + 11.0 * d14;
            double d19 = d10 + Math.cos(d15) * d17;
            double d20 = d11 + Math.sin(d15) * d17;
            double d21 = d10 + Math.cos(d16) * d18;
            double d22 = d11 + Math.sin(d16) * d18;
            int n3 = (int)(d2 * (0.4 + 0.6 * (1.0 - d13)));
            Renderer2D.COLOR.line(d19, d20, d21, d22, new Color(255, 70, 70, n3));
        }
        Renderer2D.COLOR.render();
        TextRenderer textRenderer = TextRenderer.get();
        String string = "Player Chunk Detected";
        double d23 = 44.0;
        double d24 = 24.0;
        double d25 = d6 - d23 - d24;
        double d26 = 2.0;
        textRenderer.begin(d26);
        double d27 = textRenderer.getWidth(string, string.length(), false);
        if (d27 > d25 && d27 > 0.0) {
            d26 = Math.max(1.0, d26 * d25 / d27);
            textRenderer.end();
            textRenderer.begin(d26);
        }
        double d28 = textRenderer.getHeight(false);
        int n4 = Math.max(20, Math.min(255, (int)d2));
        textRenderer.render(string, d8 + d23, d9 + d7 / 2.0 - d28 / 2.0, new Color(255, 45, 45, n4), true);
        textRenderer.end();
    }

    private static final class c {
        final int chunkX;
        final int chunkZ;
        final LightData data;
        final long arrivalNanos = System.nanoTime();

        c(int n2, int n3, LightData lightData2) {
            this.chunkX = n2;
            this.chunkZ = n3;
            this.data = lightData2;
        }
    }

    private static final class b {
        long lastUpdate() {
            long m = 0L;
            for (long v : this.skyUpdatedNanos) m = Math.max(m, v);
            for (long v : this.blockUpdatedNanos) m = Math.max(m, v);
            return m;
        }

        static final int MAX_SECTIONS = 24;
        final int chunkX;
        final int chunkZ;
        final int bottomSectionY;
        d[] sky;
        d[] block;
        long[] skyUpdatedNanos;
        long[] blockUpdatedNanos;
        int sectionCount;

        b(int n2, int n3, int n4, int n5) {
            this.chunkX = n2;
            this.chunkZ = n3;
            this.bottomSectionY = n5;
            this.grow(n4);
        }

        void grow(int n2) {
            int n3 = Math.max(n2, 1);
            d[] dArray = new d[n3];
            d[] dArray2 = new d[n3];
            long[] lArray = new long[n3];
            long[] lArray2 = new long[n3];
            for (int i2 = 0; i2 < n3; ++i2) {
                dArray[i2] = d.UNKNOWN;
                dArray2[i2] = d.UNKNOWN;
            }
            if (this.sky != null) {
                System.arraycopy(this.sky, 0, dArray, 0, Math.min(this.sectionCount, n3));
                System.arraycopy(this.block, 0, dArray2, 0, Math.min(this.sectionCount, n3));
                System.arraycopy(this.skyUpdatedNanos, 0, lArray, 0, Math.min(this.sectionCount, n3));
                System.arraycopy(this.blockUpdatedNanos, 0, lArray2, 0, Math.min(this.sectionCount, n3));
            }
            this.sky = dArray;
            this.block = dArray2;
            this.skyUpdatedNanos = lArray;
            this.blockUpdatedNanos = lArray2;
            this.sectionCount = n3;
        }
    }

    private static final class a {
        private a() {
        }

        static d classifyPayload(byte[] byArray) {
            if (byArray == null || byArray.length != 2048) {
                return d.UNKNOWN;
            }
            boolean bl2 = false;
            boolean bl3 = false;
            for (byte by : byArray) {
                if (by != 0) {
                    bl2 = true;
                }
                if (by == -1) continue;
                bl3 = true;
            }
            if (!bl2) {
                return d.ZEROED_PRESENT;
            }
            if (!bl3) {
                return d.UNIFORM_MAX;
            }
            return d.NORMAL;
        }

        static void apply(LightData lightData2, b b2, long l2) {
            int n2 = Math.max(Math.max(lightData2.getInitedSky().length(), lightData2.getUninitedSky().length()), Math.max(lightData2.getInitedBlock().length(), lightData2.getUninitedBlock().length()));
            if (n2 > b2.sectionCount) {
                b2.grow(Math.min(n2, 24));
            }
            a.applyTrack(lightData2.getInitedSky(), lightData2.getUninitedSky(), lightData2.getSkyNibbles(), b2.sky, b2.skyUpdatedNanos, l2);
            a.applyTrack(lightData2.getInitedBlock(), lightData2.getUninitedBlock(), lightData2.getBlockNibbles(), b2.block, b2.blockUpdatedNanos, l2);
        }

        private static void applyTrack(BitSet bitSet, BitSet bitSet2, List<byte[]> list, d[] dArray, long[] lArray, long l2) {
            int n2 = 0;
            for (int i2 = 0; i2 < dArray.length; ++i2) {
                if (bitSet.get(i2)) {
                    byte[] byArray = n2 < list.size() ? list.get(n2) : null;
                    ++n2;
                    dArray[i2] = a.classifyPayload(byArray);
                    lArray[i2] = l2;
                    continue;
                }
                if (!bitSet2.get(i2)) continue;
                dArray[i2] = d.EMPTY_MASK;
                lArray[i2] = l2;
            }
        }
    }

    private static enum d {
        NORMAL(0, 220, 0),
        EMPTY_MASK(255, 220, 0),
        ZEROED_PRESENT(255, 40, 40),
        UNIFORM_MAX(0, 220, 255),
        MISSING(140, 140, 140),
        UNKNOWN(80, 80, 80);

        private final int r;
        private final int g;
        private final int b;

        private d(int n3, int n4, int n5) {
            this.r = n3;
            this.g = n4;
            this.b = n5;
        }
    }
}

