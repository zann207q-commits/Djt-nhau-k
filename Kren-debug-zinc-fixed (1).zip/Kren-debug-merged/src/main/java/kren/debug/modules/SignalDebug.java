package kren.debug.modules;

import kren.debug.KrenDebug;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RepeaterBlock;
import net.minecraft.block.entity.BeehiveBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

/**
 * Client-thread-only signal/signature scanner. Results are accumulated per chunk rather than
 * replacing the previous result on every pass, which prevents markers from jumping randomly.
 */
public class SignalDebug extends Module {
    private static final long SCAN_INTERVAL_MS = 2500L;
    private static final int MAX_SCAN_RADIUS = 8;
    private static final int MIN_SCORE = 3;
    private static final int MAX_MARKERS = 64;

    private final Map<Long, Detection> detections = new HashMap<>();
    private long lastScanTime;
    private long lastNotifyTime;

    public SignalDebug() {
        super(KrenDebug.CATEGORY, "signal-debug", "Finds chunks with multiple unusual redstone/build signatures.");
    }

    @Override
    public void onActivate() {
        detections.clear();
        lastScanTime = 0L;
        lastNotifyTime = 0L;
    }

    @Override
    public void onDeactivate() {
        detections.clear();
        lastScanTime = 0L;
        lastNotifyTime = 0L;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.world == null || mc.player == null) {
            detections.clear();
            return;
        }

        long now = System.currentTimeMillis();
        if (now - lastScanTime < SCAN_INTERVAL_MS) return;
        lastScanTime = now;

        int centerX = mc.player.getChunkPos().x;
        int centerZ = mc.player.getChunkPos().z;
        int viewDistance = mc.options.getViewDistance().getValue();
        int radius = Math.min(MAX_SCAN_RADIUS, Math.max(2, viewDistance));

        // World/chunk data is accessed only on the Minecraft client thread.
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(centerX + dx, centerZ + dz);
                if (chunk == null || chunk.isEmpty()) continue;
                long key = ChunkPos.toLong(centerX + dx, centerZ + dz);
                Detection detection = inspectChunk(chunk);
                if (detection.score >= MIN_SCORE) {
                    Detection old = detections.get(key);
                    detections.put(key, detection);
                    if (old == null && now - lastNotifyTime >= 3000L) {
                        lastNotifyTime = now;
                        mc.execute(() -> ChatUtils.info("Signal Debug: unusual chunk detected", new Object[0]));
                    }
                } else {
                    detections.remove(key);
                }
            }
        }

        // Drop unloaded/out-of-range markers, but never clear every marker just because scan order changed.
        Iterator<Map.Entry<Long, Detection>> iterator = detections.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<Long, Detection> entry = iterator.next();
            int x = ChunkPos.getPackedX(entry.getKey());
            int z = ChunkPos.getPackedZ(entry.getKey());
            if (Math.max(Math.abs(x - centerX), Math.abs(z - centerZ)) > radius
                || mc.world.getChunkManager().getWorldChunk(x, z) == null) {
                iterator.remove();
            }
        }

        if (detections.size() > MAX_MARKERS) {
            // Keep the closest detections so the HUD/render work stays bounded.
            List<Map.Entry<Long, Detection>> entries = new ArrayList<>(detections.entrySet());
            entries.sort((a, b) -> Double.compare(distanceSquared(a.getKey(), centerX, centerZ), distanceSquared(b.getKey(), centerX, centerZ)));
            detections.clear();
            for (int i = 0; i < Math.min(MAX_MARKERS, entries.size()); i++) {
                detections.put(entries.get(i).getKey(), entries.get(i).getValue());
            }
        }
    }

    private static double distanceSquared(long key, int centerX, int centerZ) {
        double dx = ChunkPos.getPackedX(key) - centerX;
        double dz = ChunkPos.getPackedZ(key) - centerZ;
        return dx * dx + dz * dz;
    }

    private Detection inspectChunk(WorldChunk chunk) {
        int activeRepeaters = 0;
        int repeaters = 0;
        int cobbled = 0;
        int vines = 0;
        int seagrass = 0;
        boolean occupiedHive = false;

        try {
            for (BlockEntity blockEntity : chunk.getBlockEntities().values()) {
                if (blockEntity instanceof BeehiveBlockEntity hive && hive.getBeeCount() > 0) {
                    occupiedHive = true;
                    break;
                }
            }
        } catch (Throwable ignored) {
            // Incomplete block-entity data is not sufficient evidence by itself.
        }

        int bottomY = chunk.getBottomY();
        ChunkSection[] sections = chunk.getSectionArray();
        for (int sectionIndex = 0; sectionIndex < sections.length; sectionIndex++) {
            ChunkSection section = sections[sectionIndex];
            if (section == null || section.isEmpty()) continue;
            int sectionY = bottomY + (sectionIndex << 4);
            boolean needsScan = section.hasAny(state -> state.isOf(Blocks.REPEATER)
                || state.isOf(Blocks.COBBLED_DEEPSLATE)
                || state.isOf(Blocks.VINE)
                || state.isOf(Blocks.SEAGRASS)
                || state.isOf(Blocks.TALL_SEAGRASS));
            if (!needsScan) continue;

            for (int y = 0; y < 16; y++) {
                int worldY = sectionY + y;
                for (int x = 0; x < 16; x++) {
                    for (int z = 0; z < 16; z++) {
                        BlockState state = section.getBlockState(x, y, z);
                        if (state.isOf(Blocks.REPEATER)) {
                            repeaters++;
                            if (Boolean.TRUE.equals(state.get(RepeaterBlock.POWERED))) activeRepeaters++;
                        } else if (state.isOf(Blocks.COBBLED_DEEPSLATE) && worldY >= -16 && worldY <= 20) {
                            cobbled++;
                        } else if (state.isOf(Blocks.VINE)) {
                            vines++;
                        } else if ((state.isOf(Blocks.SEAGRASS) || state.isOf(Blocks.TALL_SEAGRASS)) && worldY <= 70) {
                            seagrass++;
                        }
                    }
                }
            }
        }
        return buildDetection(activeRepeaters, repeaters, cobbled, vines, seagrass, occupiedHive);
    }

    private Detection buildDetection(int activeRepeaters, int repeaters, int cobbled, int vines, int seagrass, boolean hive) {
        int score = 0;
        String reason = "multiple signatures";
        if (activeRepeaters >= 3) { score += 5; reason = "3+ powered repeaters"; }
        else if (repeaters >= 3) { score += 1; reason = "3+ repeaters"; }
        if (cobbled >= 50) { score += 3; if (score == 3) reason = "large cobbled-deepslate cluster"; }
        if (vines >= 150) { score += 2; if (score == 2) reason = "large vine cluster"; }
        if (seagrass >= 30) { score += 2; if (score == 2) reason = "large seagrass cluster"; }
        if (hive) { score += 2; if (score == 2) reason = "occupied beehive"; }
        return new Detection(score, reason);
    }

    @EventHandler
    private void onRender3D(Render3DEvent event) {
        if (mc.world == null || detections.isEmpty()) return;
        for (Map.Entry<Long, Detection> entry : detections.entrySet()) {
            int chunkX = ChunkPos.getPackedX(entry.getKey());
            int chunkZ = ChunkPos.getPackedZ(entry.getKey());
            if (mc.world.getChunkManager().getWorldChunk(chunkX, chunkZ) == null) continue;
            double x1 = (double) chunkX * 16.0;
            double z1 = (double) chunkZ * 16.0;
            double x2 = x1 + 16.0;
            double z2 = z1 + 16.0;
            double y1 = mc.world.getBottomY();
            double y2 = y1 + mc.world.getHeight();
            int alpha = Math.min(220, 80 + entry.getValue().score * 20);
            meteordevelopment.meteorclient.utils.render.color.Color side = color(alpha / 2);
            meteordevelopment.meteorclient.utils.render.color.Color line = color(alpha);
            event.renderer.box(x1, y1, z1, x2, y2, z2, side, line, ShapeMode.Both, 0);
        }
    }

    private meteordevelopment.meteorclient.utils.render.color.Color color(int alpha) {
        float hue = (float) (System.currentTimeMillis() % 3600L) / 3600.0f;
        int rgb = Color.HSBtoRGB(hue, 1.0f, 1.0f);
        return new meteordevelopment.meteorclient.utils.render.color.Color((rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF, alpha);
    }

    private static final class Detection {
        final int score;
        final String reason;
        Detection(int score, String reason) { this.score = score; this.reason = reason; }
    }
}
