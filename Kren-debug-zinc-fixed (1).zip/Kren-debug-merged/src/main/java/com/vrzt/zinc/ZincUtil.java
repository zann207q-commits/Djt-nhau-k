package com.vrzt.zinc;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;

/** Small helpers that avoid version-specific accessors (ChunkPos fields, Entity#getPos...). */
public final class ZincUtil {
    private ZincUtil() {}

    public static int chunkX(ChunkPos pos) {
        return pos.getStartX() >> 4;
    }

    public static int chunkZ(ChunkPos pos) {
        return pos.getStartZ() >> 4;
    }

    public static Vec3d pos(Entity entity) {
        return new Vec3d(entity.getX(), entity.getY(), entity.getZ());
    }
}
