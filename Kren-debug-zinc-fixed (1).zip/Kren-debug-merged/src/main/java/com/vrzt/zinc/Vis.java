package com.vrzt.zinc;

import meteordevelopment.meteorclient.settings.IVisible;
import meteordevelopment.meteorclient.settings.Setting;

/** Helper so decompiled raw-type code can build IVisible from a Setting<Boolean>. */
public final class Vis {
    private Vis() {}

    public static IVisible of(Setting<?> s) {
        return () -> (Boolean) s.get();
    }
}
