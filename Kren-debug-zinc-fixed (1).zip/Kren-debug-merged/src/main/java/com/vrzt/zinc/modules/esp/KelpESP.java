package com.vrzt.zinc.modules.esp;

import com.vrzt.zinc.ZincToast;
import com.vrzt.zinc.ZincUtil;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.Heightmap;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.world.chunk.WorldChunk;

import com.vrzt.zinc.ZincAddon;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.BlockUpdateEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;

public class KelpESP extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<SettingColor> kelpColor;
   private final Setting<ShapeMode> kelpShapeMode;
   private final Setting<Integer> minKelpColumns;
   private final Setting<Integer> minTopsAt62;
   private final Set<ChunkPos> flaggedKelpChunks;
   private final Set<ChunkPos> notifiedChunks;
   private final Set<ChunkPos> scannedChunks;
   private ExecutorService threadPool;

   public KelpESP() {
      super(ZincAddon.esp, "KelpESP", "Highlights near-perfect kelp farm chunks using threaded scanning.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.kelpColor = this.sgGeneral.add(((ColorSetting.Builder)(new ColorSetting.Builder()).name("esp-color")).defaultValue(new SettingColor(0, 255, 0, 100)).build());
      this.kelpShapeMode = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("shape-mode")).defaultValue(ShapeMode.Both)).build());
      this.minKelpColumns = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("min-kelp-columns")).defaultValue(20)).min(1).build());
      this.minTopsAt62 = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("min-tops-at-y62")).defaultValue(18)).min(1).build());
      this.flaggedKelpChunks = ConcurrentHashMap.newKeySet();
      this.notifiedChunks = ConcurrentHashMap.newKeySet();
      this.scannedChunks = ConcurrentHashMap.newKeySet();
   }

   public void onActivate() {
      this.clearData();
      this.threadPool = Executors.newFixedThreadPool(2);
      if (this.mc.world != null) {
         for(Chunk chunk : Utils.chunks()) {
            if (chunk instanceof WorldChunk) {
               WorldChunk worldChunk = (WorldChunk)chunk;
               this.threadPool.submit(() -> this.scanChunk(worldChunk));
            }
         }
      }

   }

   public void onDeactivate() {
      if (this.threadPool != null) {
         this.threadPool.shutdownNow();
      }

      this.clearData();
   }

   private void clearData() {
      this.flaggedKelpChunks.clear();
      this.notifiedChunks.clear();
      this.scannedChunks.clear();
   }

   @EventHandler
   private void onChunkLoad(ChunkDataEvent event) {
      if (this.threadPool != null && !this.threadPool.isShutdown()) {
         this.threadPool.submit(() -> this.scanChunk(event.chunk()));
      }

   }

   @EventHandler
   private void onBlockUpdate(BlockUpdateEvent event) {
      if (isKelp(event.newState.getBlock()) || isKelp(event.oldState.getBlock())) {
         ChunkPos cp = new ChunkPos(event.pos);
         this.scannedChunks.remove(cp);
         if (this.threadPool != null && !this.threadPool.isShutdown()) {
            Chunk chunk = this.mc.world.getChunk(event.pos);
            if (chunk instanceof WorldChunk) {
               WorldChunk wc = (WorldChunk)chunk;
               this.threadPool.submit(() -> this.scanChunk(wc));
            }
         }
      }

   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      if (this.mc.world != null) {
         Color side = new Color((Color)this.kelpColor.get());
         Color line = (new Color(side)).a(255);

         for(ChunkPos pos : this.flaggedKelpChunks) {
            double x1 = (double)pos.getStartX();
            double z1 = (double)pos.getStartZ();
            event.renderer.box(x1, 62.9, z1, x1 + (double)16.0F, 63.1, z1 + (double)16.0F, side, line, (ShapeMode)this.kelpShapeMode.get(), 0);
         }

      }
   }

   private void scanChunk(Chunk chunk) {
      ChunkPos cpos = chunk.getPos();
      if (this.scannedChunks.add(cpos)) {
         int kelpColumns = 0;
         int kelpTopsAt62 = 0;
         BlockPos.Mutable mutable = new BlockPos.Mutable();

         for(int x = 0; x < 16; ++x) {
            for(int z = 0; z < 16; ++z) {
               int surfaceY = chunk.getHeightmap(Heightmap.Type.WORLD_SURFACE).get(x, z);
               if (surfaceY >= 30 && surfaceY <= 62) {
                  mutable.set(cpos.getStartX() + x, surfaceY, cpos.getStartZ() + z);
                  Block block = chunk.getBlockState(mutable).getBlock();
                  if (isKelp(block)) {
                     ++kelpColumns;
                     if (surfaceY == 62) {
                        ++kelpTopsAt62;
                     }
                  }
               }
            }
         }

         if (kelpColumns >= (Integer)this.minKelpColumns.get() && kelpTopsAt62 >= (Integer)this.minTopsAt62.get()) {
            this.flaggedKelpChunks.add(cpos);
            if (this.notifiedChunks.add(cpos)) {
               this.sendFeedback(cpos, kelpTopsAt62, kelpColumns);
            }
         } else {
            this.flaggedKelpChunks.remove(cpos);
         }

      }
   }

   private void sendFeedback(ChunkPos cpos, int tops, int total) {
      this.mc.execute(() -> {
         if (this.mc.player != null) {
            this.info("Perfect kelp chunk at [%d, %d] (%d/%d tops)", new Object[]{ZincUtil.chunkX(cpos), ZincUtil.chunkZ(cpos), tops, total});
            ZincToast.show(Text.of("KelpESP"), Text.of("X: " + cpos.getCenterX() + " Z: " + cpos.getCenterZ()));
         }

      });
   }



   private static boolean isKelp(Block b) {
      return b == Blocks.KELP || b == Blocks.KELP_PLANT;
   }
}
