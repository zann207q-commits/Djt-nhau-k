package com.vrzt.zinc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.toast.SystemToast;
import net.minecraft.text.Text;

/** Shows a vanilla toast. Replaces the old per-module custom Toast classes. */
public final class ZincToast {
    private ZincToast() {}

    public static void show(Text title, Text description) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null) return;
        mc.execute(() -> SystemToast.add(mc.getToastManager(), SystemToast.Type.PERIODIC_NOTIFICATION, title, description));
    }
}
