package com.vrzt.zinc.modules.esp;

import com.vrzt.zinc.ZincToast;
import com.vrzt.zinc.ZincUtil;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.IllagerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.state.property.Properties;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.entity.passive.TraderLlamaEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.passive.WanderingTraderEntity;
import net.minecraft.world.chunk.WorldChunk;

import com.vrzt.zinc.ZincAddon;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.BlockUpdateEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;

public class ChunkFinderV2 extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Boolean> showCoords;
   private final Setting<Integer> renderDistance;
   private final Setting<HoleMode> holeMode;
   private final Setting<SettingColor> chunkColor;
   private final Setting<Boolean> showTracers;
   private final Setting<Integer> holeCheckRadius;
   private static final int MIN_VINE_LENGTH = 20;
   private static final int MIN_KELP_LENGTH = 20;
   private static final int ROTATED_DEEPSLATE_THRESHOLD = 5;
   private static final int ENTITY_MAX_DISTANCE = 256;
   private static final int MIN_Y_LEVEL = 16;
   private final Map<ChunkPos, DetectionInfo> detectedChunks;
   private final Set<ChunkPos> chunksWithBrokenBlocks;
   private final Set<Integer> detectedEntities;
   private final Set<ChunkPos> scannedChunks;
   private ExecutorService threadPool;

   public ChunkFinderV2() {
      super(ZincAddon.esp, "chunk-finder-v2", "Detects suspicious chunks via unnatural blocks and player-only entities.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.showCoords = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("show-coordinates")).description("Show coordinates in chat and notifications")).defaultValue(true)).build());
      this.renderDistance = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("render-distance")).description("Hide detections further than this distance.")).defaultValue(512)).min(32).sliderMax(2048).build());
      this.holeMode = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("hole-detection")).description("Detect chunks with or without holes")).defaultValue(ChunkFinderV2.HoleMode.Both)).build());
      this.chunkColor = this.sgGeneral.add(((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("chunk-color")).description("Color of detected chunks")).defaultValue(new SettingColor(0, 255, 255, 100)).build());
      this.showTracers = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("show-tracers")).description("Draw tracers to detected chunks")).defaultValue(false)).build());
      this.holeCheckRadius = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("hole-check-radius")).description("Blocks radius to check for holes")).defaultValue(8)).min(0).max(64).visible(() -> this.holeMode.get() == ChunkFinderV2.HoleMode.Without_Holes)).build());
      this.detectedChunks = new ConcurrentHashMap();
      this.chunksWithBrokenBlocks = ConcurrentHashMap.newKeySet();
      this.detectedEntities = ConcurrentHashMap.newKeySet();
      this.scannedChunks = ConcurrentHashMap.newKeySet();
   }

   public void onActivate() {
      this.clearData();
      this.threadPool = Executors.newFixedThreadPool(2);
      if (this.mc.world != null) {
         for(Chunk chunk : Utils.chunks()) {
            if (chunk instanceof WorldChunk) {
               WorldChunk worldChunk = (WorldChunk)chunk;
               this.threadPool.submit(() -> this.scanChunk(worldChunk));
            }
         }
      }

   }

   public void onDeactivate() {
      if (this.threadPool != null) {
         this.threadPool.shutdownNow();
      }

      this.clearData();
   }

   private void clearData() {
      this.detectedChunks.clear();
      this.chunksWithBrokenBlocks.clear();
      this.detectedEntities.clear();
      this.scannedChunks.clear();
   }

   @EventHandler
   private void onChunkLoad(ChunkDataEvent event) {
      if (this.threadPool != null && !this.threadPool.isShutdown()) {
         this.threadPool.submit(() -> this.scanChunk(event.chunk()));
      }

   }

   @EventHandler
   private void onBlockUpdate(BlockUpdateEvent event) {
      if (event.pos.getY() > 16) {
         if (event.newState.isAir()) {
            ChunkPos cp = new ChunkPos(event.pos);
            if (this.detectedChunks.containsKey(cp)) {
               this.chunksWithBrokenBlocks.add(cp);
            }
         }

         if (this.threadPool != null && !this.threadPool.isShutdown()) {
            this.threadPool.submit(() -> {
               BlockState state = event.newState;
               if (state.isOf(Blocks.VINE)) {
                  this.checkVine(event.pos);
               }

               if (state.isOf(Blocks.KELP) || state.isOf(Blocks.KELP_PLANT)) {
                  this.checkKelp(event.pos);
               }

               if (state.isOf(Blocks.DEEPSLATE)) {
                  this.checkRotatedDeepslate(event.pos);
               }

            });
         }

      }
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      if (this.mc.player != null && this.mc.world != null) {
         this.checkEntities();
         Color sideColor = (Color)this.chunkColor.get();
         Color lineColor = (new Color(sideColor)).a(255);

         for(Map.Entry<ChunkPos, DetectionInfo> entry : this.detectedChunks.entrySet()) {
            ChunkPos cp = (ChunkPos)entry.getKey();
            BlockPos pos = ((DetectionInfo)entry.getValue()).position;
            double distSq = PlayerUtils.squaredDistanceTo((double)pos.getX() + (double)0.5F, (double)pos.getY() + (double)0.5F, (double)pos.getZ() + (double)0.5F);
            if (!(distSq > Math.pow((double)(Integer)this.renderDistance.get(), (double)2.0F))) {
               double x1 = (double)cp.getStartX();
               double z1 = (double)cp.getStartZ();
               double y = (double)pos.getY();
               event.renderer.box(x1, y, z1, x1 + (double)16.0F, y + 0.3, z1 + (double)16.0F, sideColor, lineColor, ShapeMode.Both, 0);
               if ((Boolean)this.showTracers.get() && !this.chunksWithBrokenBlocks.contains(cp)) {
                  event.renderer.line(RenderUtils.center.x, RenderUtils.center.y, RenderUtils.center.z, x1 + (double)8.0F, y + 0.15, z1 + (double)8.0F, lineColor);
               }
            }
         }

      }
   }

   private void addDetection(BlockPos pos) {
      if (pos.getY() > 16) {
         ChunkPos chunkPos = new ChunkPos(pos);
         if (this.holeMode.get() != ChunkFinderV2.HoleMode.Without_Holes || !this.chunkHasHoles(chunkPos)) {
            for(ChunkPos existing : this.detectedChunks.keySet()) {
               if (Math.abs(ZincUtil.chunkX(existing) - ZincUtil.chunkX(chunkPos)) <= 2 && Math.abs(ZincUtil.chunkZ(existing) - ZincUtil.chunkZ(chunkPos)) <= 2) {
                  return;
               }
            }

            this.detectedChunks.put(chunkPos, new DetectionInfo(pos, System.currentTimeMillis()));
            this.mc.execute(() -> {
               if (this.mc.world != null && this.mc.player != null) {
                  this.mc.world.playSound(this.mc.player, pos, SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 1.0F, 1.0F);
               }

            });
            if ((Boolean)this.showCoords.get()) {
               this.info("Detected suspicious chunk at X: %d, Z: %d", new Object[]{pos.getX(), pos.getZ()});
               ZincToast.show(Text.of("ChunkFinderV2"), Text.of("X: " + pos.getX() + " Z: " + pos.getZ()));
            }

         }
      }
   }

   private void checkEntities() {
      if (this.mc.world != null && this.mc.player != null) {
         for(Entity entity : this.mc.world.getEntities()) {
            if (entity.getBlockPos().getY() > 16) {
               boolean isSuspicious = entity instanceof VillagerEntity || entity instanceof IllagerEntity || entity instanceof WanderingTraderEntity || entity instanceof TraderLlamaEntity;
               if (isSuspicious && this.mc.player.distanceTo(entity) <= 256.0F && this.detectedEntities.add(entity.getId())) {
                  this.addDetection(entity.getBlockPos());
               }
            }
         }

      }
   }

   private void scanChunk(WorldChunk chunk) {
      ChunkPos cpos = chunk.getPos();
      if (this.scannedChunks.add(cpos)) {
         this.scanChunkForVines(chunk);
         this.scanChunkForKelp(chunk);
         this.scanChunkForRotatedDeepslate(chunk);
      }

   }

   private void scanChunkForRotatedDeepslate(WorldChunk chunk) {
      int rotatedCount = 0;
      BlockPos firstFound = null;
      ChunkPos cPos = chunk.getPos();

      for(int x = cPos.getStartX(); x < cPos.getEndX(); ++x) {
         for(int z = cPos.getStartZ(); z < cPos.getEndZ(); ++z) {
            for(int y = 17; y < 319; ++y) {
               BlockPos pos = new BlockPos(x, y, z);
               BlockState state = chunk.getBlockState(pos);
               if (state.isOf(Blocks.DEEPSLATE) && state.contains(Properties.AXIS)) {
                  Direction.Axis axis = (Direction.Axis)state.get(Properties.AXIS);
                  if (axis == Direction.Axis.X || axis == Direction.Axis.Z) {
                     ++rotatedCount;
                     if (firstFound == null) {
                        firstFound = pos;
                     }

                     if (rotatedCount >= 5) {
                        this.addDetection(firstFound);
                        return;
                     }
                  }
               }
            }
         }
      }

   }

   private void scanChunkForKelp(WorldChunk chunk) {
      ChunkPos cPos = chunk.getPos();

      for(int x = cPos.getStartX(); x < cPos.getEndX(); ++x) {
         for(int z = cPos.getStartZ(); z < cPos.getEndZ(); ++z) {
            for(int y = 17; y < 64; ++y) {
               BlockPos pos = new BlockPos(x, y, z);
               if (chunk.getBlockState(pos).isOf(Blocks.KELP) && this.getKelpLength(pos) >= 20) {
                  this.addDetection(pos);
               }
            }
         }
      }

   }

   private void scanChunkForVines(WorldChunk chunk) {
      ChunkPos cPos = chunk.getPos();

      for(int x = cPos.getStartX(); x < cPos.getEndX(); ++x) {
         for(int z = cPos.getStartZ(); z < cPos.getEndZ(); ++z) {
            for(int y = 318; y > 16; --y) {
               BlockPos pos = new BlockPos(x, y, z);
               if (chunk.getBlockState(pos).isOf(Blocks.VINE) && this.vineExtendsToY16(pos) && this.getVineLength(pos) >= 20) {
                  this.addDetection(pos);
               }
            }
         }
      }

   }

   private void checkRotatedDeepslate(BlockPos pos) {
      if (this.mc.world != null && pos.getY() > 16) {
         WorldChunk chunk = this.mc.world.getWorldChunk(pos);
         if (chunk != null) {
            this.scanChunkForRotatedDeepslate(chunk);
         }
      }

   }

   private void checkVine(BlockPos pos) {
      if (pos.getY() > 16 && this.vineExtendsToY16(pos) && this.getVineLength(pos) >= 20) {
         this.addDetection(pos);
      }

   }

   private void checkKelp(BlockPos pos) {
      if (pos.getY() > 16 && this.getKelpLength(pos) >= 20) {
         this.addDetection(pos);
      }

   }

   private boolean chunkHasHoles(ChunkPos cp) {
      if (this.mc.world == null) {
         return false;
      } else {
         int air = 0;
         int total = 0;
         int radius = (Integer)this.holeCheckRadius.get();
         int cx = cp.getCenterX();
         int cz = cp.getCenterZ();

         for(int x = cx - radius; x <= cx + radius; ++x) {
            for(int z = cz - radius; z <= cz + radius; ++z) {
               for(int y = 60; y <= 70; ++y) {
                  if (this.mc.world.getBlockState(new BlockPos(x, y, z)).isAir()) {
                     ++air;
                  }

                  ++total;
               }
            }
         }

         return total > 0 && (double)air / (double)total > 0.1;
      }
   }

   private boolean vineExtendsToY16(BlockPos start) {
      if (this.mc.world == null) {
         return false;
      } else {
         for(BlockPos p = start; p.getY() >= 16; p = p.down()) {
            if (!this.mc.world.getBlockState(p).isOf(Blocks.VINE)) {
               return false;
            }

            if (p.getY() == 16) {
               return true;
            }
         }

         return false;
      }
   }

   private int getVineLength(BlockPos start) {
      if (this.mc.world == null) {
         return 0;
      } else {
         int l = 0;

         for(BlockPos p = start; this.mc.world.getBlockState(p).isOf(Blocks.VINE); p = p.up()) {
            ++l;
         }

         for(BlockPos p = start.down(); p.getY() >= 16 && this.mc.world.getBlockState(p).isOf(Blocks.VINE); p = p.down()) {
            ++l;
         }

         return l;
      }
   }

   private int getKelpLength(BlockPos start) {
      if (this.mc.world == null) {
         return 0;
      } else {
         int l = 0;

         for(BlockPos p = start; this.mc.world.getBlockState(p).isOf(Blocks.KELP) || this.mc.world.getBlockState(p).isOf(Blocks.KELP_PLANT); p = p.up()) {
            ++l;
         }

         for(BlockPos p = start.down(); p.getY() >= 16 && (this.mc.world.getBlockState(p).isOf(Blocks.KELP) || this.mc.world.getBlockState(p).isOf(Blocks.KELP_PLANT)); p = p.down()) {
            ++l;
         }

         return l;
      }
   }

   public String getInfoString() {
      return this.detectedChunks.isEmpty() ? null : String.valueOf(this.detectedChunks.size());
   }

   public static enum HoleMode {
      Without_Holes,
      Both;

      // $FF: synthetic method
      private static HoleMode[] $values() {
         return new HoleMode[]{Without_Holes, Both};
      }
   }

   private static record DetectionInfo(BlockPos position, long timestamp) {
   }


}
