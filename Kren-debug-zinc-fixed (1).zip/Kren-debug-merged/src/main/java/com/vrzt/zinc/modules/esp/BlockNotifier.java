package com.vrzt.zinc.modules.esp;

import com.vrzt.zinc.ZincToast;
import com.vrzt.zinc.ZincUtil;
import net.minecraft.block.Block;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.text.Text;

import com.vrzt.zinc.ZincAddon;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BlockListSetting;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.network.MeteorExecutor;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;

public class BlockNotifier extends Module {
   private final SettingGroup sg_general;
   private final SettingGroup sg_notifications;
   private final SettingGroup sg_webhook;
   private final SettingGroup sg_render;
   private final Setting<List<Block>> blocks_to_find;
   private final Setting<Boolean> showSpawnerType;
   private final Setting<Integer> min_y;
   private final Setting<Integer> max_y;
   private final Setting<Mode> notification_mode;
   private final Setting<Boolean> disconnect_on_find;
   private final Setting<Boolean> webhook_enabled;
   private final Setting<String> webhook_url;
   private final Setting<Boolean> self_ping;
   private final Setting<String> discord_id;
   private final Setting<Boolean> show_esp;
   private final Setting<SettingColor> esp_color;
   private final Setting<ShapeMode> shape_mode;
   private final Setting<Boolean> tracers;
   private final Setting<SettingColor> tracer_color;
   private final Setting<Boolean> only_render_new;
   private final Setting<Double> render_distance;
   private final Set<ChunkPos> processed_chunks;
   private final Set<BlockPos> found_block_positions;
   private final Set<BlockPos> new_found_blocks;
   private final HttpClient http_client;

   public BlockNotifier() {
      super(ZincAddon.esp, "Block Notifier", "Notifies when specific blocks are detected with visual ESP and Discord logging.");
      this.sg_general = this.settings.getDefaultGroup();
      this.sg_notifications = this.settings.createGroup("Notifications");
      this.sg_webhook = this.settings.createGroup("Webhook");
      this.sg_render = this.settings.createGroup("Render");
      this.blocks_to_find = this.sg_general.add(((BlockListSetting.Builder)((BlockListSetting.Builder)((BlockListSetting.Builder)(new BlockListSetting.Builder()).name("blocks-to-find")).description("Blocks to notify when found.")).defaultValue(Collections.emptyList())).build());
      this.showSpawnerType = this.sg_general.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("show-spawner-type")).description("Shows entity type (e.g. Zombie Spawner).")).defaultValue(true)).build());
      this.min_y = this.sg_general.add(((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("min-y")).defaultValue(-64)).min(-64).max(320).build());
      this.max_y = this.sg_general.add(((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("max-y")).defaultValue(320)).min(-64).max(320).build());
      this.notification_mode = this.sg_notifications.add(((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("notification-mode")).defaultValue(BlockNotifier.Mode.Both)).build());
      this.disconnect_on_find = this.sg_notifications.add(((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("disconnect-on-find")).defaultValue(false)).build());
      this.webhook_enabled = this.sg_webhook.add(((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("webhook-enabled")).defaultValue(false)).build());
      SettingGroup var10001 = this.sg_webhook;
      StringSetting.Builder var10002 = (StringSetting.Builder)((StringSetting.Builder)(new StringSetting.Builder()).name("webhook-url")).defaultValue("");
      Setting var10003 = this.webhook_enabled;
      Objects.requireNonNull(var10003);
      this.webhook_url = var10001.add(((StringSetting.Builder)var10002.visible(com.vrzt.zinc.Vis.of(var10003))).build());
      var10001 = this.sg_webhook;
      BoolSetting.Builder var5 = (BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("self-ping")).defaultValue(false);
      var10003 = this.webhook_enabled;
      Objects.requireNonNull(var10003);
      this.self_ping = var10001.add(((BoolSetting.Builder)var5.visible(com.vrzt.zinc.Vis.of(var10003))).build());
      this.discord_id = this.sg_webhook.add(((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)(new StringSetting.Builder()).name("discord-id")).defaultValue("")).visible(() -> (Boolean)this.webhook_enabled.get() && (Boolean)this.self_ping.get())).build());
      this.show_esp = this.sg_render.add(((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("show-esp")).defaultValue(true)).build());
      var10001 = this.sg_render;
      ColorSetting.Builder var6 = ((ColorSetting.Builder)(new ColorSetting.Builder()).name("esp-color")).defaultValue(new SettingColor(255, 165, 0, 100));
      var10003 = this.show_esp;
      Objects.requireNonNull(var10003);
      this.esp_color = var10001.add(((ColorSetting.Builder)var6.visible(com.vrzt.zinc.Vis.of(var10003))).build());
      var10001 = this.sg_render;
      EnumSetting.Builder var7 = (EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("shape-mode")).defaultValue(ShapeMode.Both);
      var10003 = this.show_esp;
      Objects.requireNonNull(var10003);
      this.shape_mode = var10001.add(((EnumSetting.Builder)var7.visible(com.vrzt.zinc.Vis.of(var10003))).build());
      this.tracers = this.sg_render.add(((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("tracers")).defaultValue(true)).build());
      var10001 = this.sg_render;
      ColorSetting.Builder var8 = ((ColorSetting.Builder)(new ColorSetting.Builder()).name("tracer-color")).defaultValue(new SettingColor(255, 165, 0, 200));
      var10003 = this.tracers;
      Objects.requireNonNull(var10003);
      this.tracer_color = var10001.add(((ColorSetting.Builder)var8.visible(com.vrzt.zinc.Vis.of(var10003))).build());
      this.only_render_new = this.sg_render.add(((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("only-render-new")).defaultValue(false)).build());
      this.render_distance = this.sg_render.add(((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("render-distance")).defaultValue((double)0.0F).min((double)0.0F).max((double)500.0F).build());
      this.processed_chunks = Collections.synchronizedSet(new HashSet());
      this.found_block_positions = Collections.synchronizedSet(new HashSet());
      this.new_found_blocks = Collections.synchronizedSet(new HashSet());
      this.http_client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10L)).build();
   }

   public void onActivate() {
      this.processed_chunks.clear();
      this.found_block_positions.clear();
      this.new_found_blocks.clear();
   }

   @EventHandler
   private void on_chunk_data(ChunkDataEvent event) {
      if (this.mc.player != null && this.mc.world != null) {
         ChunkPos chunk_pos = event.chunk().getPos();
         if (!this.processed_chunks.contains(chunk_pos)) {
            MeteorExecutor.execute(() -> {
               Map<Block, String> found_blocks_map = new HashMap();
               boolean has_target_blocks = false;
               int startY = Math.max((Integer)this.min_y.get(), this.mc.world.getBottomY());
               int endY = Math.min((Integer)this.max_y.get(), (this.mc.world.getBottomY() + this.mc.world.getHeight() - 1));

               for(int x = 0; x < 16; ++x) {
                  for(int z = 0; z < 16; ++z) {
                     for(int y = startY; y <= endY; ++y) {
                        BlockPos pos = new BlockPos(chunk_pos.getStartX() + x, y, chunk_pos.getStartZ() + z);
                        if (this.mc.world == null) {
                           return;
                        }

                        Block block = this.mc.world.getBlockState(pos).getBlock();
                        if (((List)this.blocks_to_find.get()).contains(block)) {
                           String blockName = block.getName().getString();
                           if ((Boolean)this.showSpawnerType.get() && block == Blocks.SPAWNER) {
                              BlockEntity be = this.mc.world.getBlockEntity(pos);
                              if (be instanceof MobSpawnerBlockEntity) {
                                 MobSpawnerBlockEntity spawner = (MobSpawnerBlockEntity)be;
                                 Entity spawnerEntity = spawner.getLogic().getRenderedEntity(this.mc.world, pos);
                                 if (spawnerEntity != null) {
                                    blockName = spawnerEntity.getType().getName().getString() + " Spawner";
                                 }
                              }
                           }

                           found_blocks_map.put(block, blockName);
                           this.found_block_positions.add(pos);
                           this.new_found_blocks.add(pos);
                           has_target_blocks = true;
                        }
                     }
                  }
               }

               if (has_target_blocks) {
                  this.processed_chunks.add(chunk_pos);
                  this.mc.execute(() -> this.handle_blocks_found(chunk_pos, found_blocks_map));
               }

            });
         }
      }
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      if (this.mc.player != null && ((Boolean)this.show_esp.get() || (Boolean)this.tracers.get())) {
         Color color = new Color((Color)this.esp_color.get());
         Color tracerColorValue = new Color((Color)this.tracer_color.get());
         double maxDistance = (Double)this.render_distance.get();
         double s = 0.15;
         synchronized(this.found_block_positions) {
            for(BlockPos pos : this.found_block_positions) {
               if (!(Boolean)this.only_render_new.get() || this.new_found_blocks.contains(pos)) {
                  if (maxDistance > (double)0.0F) {
                     double distance = Math.sqrt(this.mc.player.getBlockPos().getSquaredDistance(pos));
                     if (distance > maxDistance) {
                        continue;
                     }
                  }

                  if ((Boolean)this.show_esp.get()) {
                     event.renderer.box((double)pos.getX() + s, (double)pos.getY() + s, (double)pos.getZ() + s, (double)(pos.getX() + 1) - s, (double)(pos.getY() + 1) - s, (double)(pos.getZ() + 1) - s, color, color, (ShapeMode)this.shape_mode.get(), 0);
                  }

                  if ((Boolean)this.tracers.get()) {
                     event.renderer.line(RenderUtils.center.x, RenderUtils.center.y, RenderUtils.center.z, (double)pos.getX() + (double)0.5F, (double)pos.getY() + (double)0.5F, (double)pos.getZ() + (double)0.5F, tracerColorValue);
                  }
               }
            }
         }

         this.new_found_blocks.clear();
      }
   }

   private void handle_blocks_found(ChunkPos chunk_pos, Map<Block, String> found_blocks) {
      String message = this.build_notification_message(chunk_pos, found_blocks);
      switch (((Mode)this.notification_mode.get()).ordinal()) {
         case 0:
            this.info(message, new Object[0]);
            break;
         case 1:
            this.show_toast_notification(chunk_pos, found_blocks);
            break;
         case 2:
            this.info(message, new Object[0]);
            this.show_toast_notification(chunk_pos, found_blocks);
      }

      this.send_webhook_notification(chunk_pos, found_blocks);
      if ((Boolean)this.disconnect_on_find.get()) {
         this.handle_disconnection(found_blocks);
      }

   }

   private String build_notification_message(ChunkPos chunk_pos, Map<Block, String> found_blocks) {
      String var10000 = String.join(", ", found_blocks.values());
      return "Target blocks found: " + var10000 + " at " + (ZincUtil.chunkX(chunk_pos) * 16 + 8) + ", " + (ZincUtil.chunkZ(chunk_pos) * 16 + 8);
   }

   private void show_toast_notification(ChunkPos chunk_pos, Map<Block, String> found_blocks) {
      Map.Entry<Block, String> firstEntry = (Map.Entry)found_blocks.entrySet().iterator().next();
      ZincToast.show(Text.literal("Block Found"), Text.literal((String)firstEntry.getValue()));
   }

   private void send_webhook_notification(ChunkPos chunk_pos, Map<Block, String> found_blocks) {
      if ((Boolean)this.webhook_enabled.get() && !((String)this.webhook_url.get()).trim().isEmpty()) {
         CompletableFuture.runAsync(() -> {
            try {
               String server_info = this.mc.getCurrentServerEntry() != null ? this.mc.getCurrentServerEntry().address : "Singleplayer";
               String ping_content = (Boolean)this.self_ping.get() && !((String)this.discord_id.get()).trim().isEmpty() ? String.format("<@%s>", ((String)this.discord_id.get()).trim()) : "";
               StringBuilder items_breakdown = new StringBuilder();

               for(String name : found_blocks.values()) {
                  items_breakdown.append(String.format("• %s\\n", name));
               }

               String json_payload = String.format("{\"content\":\"%s\",\"username\":\"Block Notifier\",\"embeds\":[{\"title\":\"Block Notifier Alert\",\"description\":\"Detected at **%d, %d**\",\"color\":3447003,\"fields\":[{\"name\":\"Total Types\",\"value\":\"%d\",\"inline\":false},{\"name\":\"Breakdown\",\"value\":\"%s\",\"inline\":false},{\"name\":\"Server\",\"value\":\"%s\",\"inline\":true},{\"name\":\"Time\",\"value\":\"<t:%d:R>\",\"inline\":true}],\"footer\":{\"text\":\"Zinc Addon\"}}]}", ping_content, ZincUtil.chunkX(chunk_pos) * 16 + 8, ZincUtil.chunkZ(chunk_pos) * 16 + 8, found_blocks.size(), items_breakdown, server_info, System.currentTimeMillis() / 1000L);
               HttpRequest request = HttpRequest.newBuilder().uri(URI.create(((String)this.webhook_url.get()).trim())).header("Content-Type", "application/json").POST(BodyPublishers.ofString(json_payload)).build();
               this.http_client.send(request, BodyHandlers.discarding());
            } catch (Exception var8) {
            }

         });
      }
   }

   private void handle_disconnection(Map<Block, String> found_blocks) {
      if (this.mc.getNetworkHandler() != null && this.mc.getNetworkHandler().getConnection() != null) {
         this.mc.getNetworkHandler().getConnection().disconnect(Text.literal("Target found " + (String)found_blocks.values().iterator().next()));
         this.toggle();
      }

   }

   public static enum Mode {
      Chat,
      Toast,
      Both;

      // $FF: synthetic method
      private static Mode[] $values() {
         return new Mode[]{Chat, Toast, Both};
      }
   }


}
