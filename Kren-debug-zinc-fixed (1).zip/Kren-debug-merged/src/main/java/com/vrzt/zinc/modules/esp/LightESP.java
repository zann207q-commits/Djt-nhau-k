package com.vrzt.zinc.modules.esp;

import com.vrzt.zinc.ZincUtil;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.LightType;
import net.minecraft.world.chunk.WorldChunk;

import com.vrzt.zinc.ZincAddon;
import java.util.Collections;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;

public class LightESP extends Module {
   private final SettingGroup sgGeneral;
   private final SettingGroup sgRender;
   private final SettingGroup sgThreading;
   private final Setting<Integer> chunkRadius;
   private final Setting<Integer> minY;
   private final Setting<Integer> maxY;
   private final Setting<Integer> minLightLevel;
   private final Setting<Boolean> autoToggleY;
   private final Setting<Integer> toggleYLevel;
   private final Setting<Integer> fadeDistance;
   private final Setting<ShapeMode> shapeMode;
   private final Setting<Boolean> useThreading;
   private final Setting<Integer> threadPoolSize;
   private final Setting<Integer> scanDelay;
   private final Setting<Boolean> incrementalScan;
   private final Set<BlockPos> lightPositions;
   private final Set<BlockPos> lightPositionsToRender;
   private ExecutorService threadPool;
   private ScheduledExecutorService scheduler;
   private final AtomicBoolean isScanning;
   private final ReentrantLock renderLock;
   private boolean shouldRender;
   private int scanTickCounter;
   private int currentScanChunkX;
   private int currentScanChunkZ;
   private boolean firstScanComplete;
   private ChunkPos lastPlayerChunk;
   private long lastRenderTime;

   public LightESP() {
      super(ZincAddon.esp, "LightESP", "Highlights blocks with light levels above a threshold.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgRender = this.settings.createGroup("Render");
      this.sgThreading = this.settings.createGroup("Threading");
      this.chunkRadius = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("chunk-radius")).description("Radius in chunks around player to scan.")).defaultValue(2)).min(1).max(8).sliderMax(8).build());
      this.minY = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("min-y")).description("Minimum Y level to scan.")).defaultValue(-63)).min(-64).max(319).build());
      this.maxY = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("max-y")).description("Maximum Y level to scan.")).defaultValue(0)).min(-64).max(319).build());
      this.minLightLevel = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("min-light-level")).description("Minimum block light level to highlight.")).defaultValue(5)).min(0).max(15).sliderMax(15).build());
      this.autoToggleY = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("auto-toggle-y")).description("Auto disable when below Y level, render when above.")).defaultValue(false)).build());
      SettingGroup var10001 = this.sgGeneral;
      IntSetting.Builder var10002 = ((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("toggle-y-level")).description("Y level for auto toggle.")).defaultValue(0)).min(-64).max(319).sliderRange(-64, 319);
      Setting var10003 = this.autoToggleY;
      Objects.requireNonNull(var10003);
      this.toggleYLevel = var10001.add(((IntSetting.Builder)var10002.visible(com.vrzt.zinc.Vis.of(var10003))).build());
      this.fadeDistance = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("fade-distance")).description("Chunks away from player where lights start fading (0 = instant remove).")).defaultValue(3)).min(0).max(8).sliderRange(0, 8).build());
      this.shapeMode = this.sgRender.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("shape-mode")).description("How the shapes should be rendered.")).defaultValue(ShapeMode.Both)).build());
      this.useThreading = this.sgThreading.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("enable-threading")).description("Use multi-threading for chunk scanning (better performance)")).defaultValue(true)).build());
      var10001 = this.sgThreading;
      var10002 = ((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("thread-pool-size")).description("Number of threads to use for scanning")).defaultValue(2)).min(1).max(4).sliderRange(1, 4);
      var10003 = this.useThreading;
      Objects.requireNonNull(var10003);
      this.threadPoolSize = var10001.add(((IntSetting.Builder)var10002.visible(com.vrzt.zinc.Vis.of(var10003))).build());
      this.scanDelay = this.sgThreading.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("scan-delay")).description("Delay between full scans in ticks (20 ticks = 1 second).")).defaultValue(20)).min(5).max(100).sliderRange(5, 60).build());
      this.incrementalScan = this.sgThreading.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("incremental-scan")).description("Scan chunks incrementally to reduce lag.")).defaultValue(true)).build());
      this.lightPositions = ConcurrentHashMap.newKeySet();
      this.lightPositionsToRender = ConcurrentHashMap.newKeySet();
      this.isScanning = new AtomicBoolean(false);
      this.renderLock = new ReentrantLock();
      this.shouldRender = true;
      this.scanTickCounter = 0;
      this.currentScanChunkX = 0;
      this.currentScanChunkZ = 0;
      this.firstScanComplete = false;
      this.lastPlayerChunk = null;
      this.lastRenderTime = 0L;
   }

   public void onActivate() {
      if ((Boolean)this.useThreading.get()) {
         this.threadPool = Executors.newFixedThreadPool(Math.min((Integer)this.threadPoolSize.get(), 4));
         this.scheduler = Executors.newSingleThreadScheduledExecutor();
      }

      this.lightPositions.clear();
      this.lightPositionsToRender.clear();
      this.shouldRender = true;
      this.lastPlayerChunk = null;
      this.scanTickCounter = 0;
      this.firstScanComplete = false;
      this.isScanning.set(false);
      if (this.mc.world != null && this.mc.player != null) {
         this.scheduleFullScan();
      }

   }

   public void onDeactivate() {
      this.stopAllThreads();
      this.lightPositions.clear();
      this.lightPositionsToRender.clear();
      this.lastPlayerChunk = null;
   }

   private void stopAllThreads() {
      if (this.threadPool != null && !this.threadPool.isShutdown()) {
         this.threadPool.shutdownNow();

         try {
            if (!this.threadPool.awaitTermination(2L, TimeUnit.SECONDS)) {
               this.threadPool.shutdownNow();
            }
         } catch (InterruptedException var3) {
            this.threadPool.shutdownNow();
            Thread.currentThread().interrupt();
         }

         this.threadPool = null;
      }

      if (this.scheduler != null && !this.scheduler.isShutdown()) {
         this.scheduler.shutdownNow();

         try {
            if (!this.scheduler.awaitTermination(1L, TimeUnit.SECONDS)) {
               this.scheduler.shutdownNow();
            }
         } catch (InterruptedException var2) {
            this.scheduler.shutdownNow();
            Thread.currentThread().interrupt();
         }

         this.scheduler = null;
      }

   }

   @EventHandler
   private void onRender3D(Render3DEvent event) {
      if (this.mc.world != null && this.mc.player != null) {
         if ((Boolean)this.autoToggleY.get()) {
            int playerY = this.mc.player.getBlockY();
            int threshold = (Integer)this.toggleYLevel.get();
            this.shouldRender = playerY >= threshold;
            if (!this.shouldRender) {
               return;
            }
         }

         this.updateRenderPositions();
         ChunkPos playerChunkPos = this.mc.player.getChunkPos();
         this.scheduleScansBasedOnMovement(playerChunkPos);
         this.renderLights(event, playerChunkPos);
         this.lastRenderTime = System.currentTimeMillis();
      }

   }

   private void scheduleScansBasedOnMovement(ChunkPos currentChunkPos) {
      ++this.scanTickCounter;
      boolean shouldScan = false;
      if (this.lastPlayerChunk == null) {
         shouldScan = true;
      } else if (ZincUtil.chunkX(currentChunkPos) == ZincUtil.chunkX(this.lastPlayerChunk) && ZincUtil.chunkZ(currentChunkPos) == ZincUtil.chunkZ(this.lastPlayerChunk)) {
         if (this.scanTickCounter >= (Integer)this.scanDelay.get()) {
            shouldScan = true;
            this.scanTickCounter = 0;
         }
      } else {
         shouldScan = true;
      }

      if (shouldScan && !this.isScanning.get()) {
         this.lastPlayerChunk = currentChunkPos;
         if ((Boolean)this.incrementalScan.get() && this.firstScanComplete) {
            this.scheduleIncrementalScan(currentChunkPos);
         } else {
            this.scheduleFullScan();
         }
      }

   }

   private void scheduleFullScan() {
      if (this.mc.world != null && this.mc.player != null && !this.isScanning.get()) {
         this.isScanning.set(true);
         if ((Boolean)this.useThreading.get() && this.threadPool != null && !this.threadPool.isShutdown()) {
            this.threadPool.submit(() -> {
               try {
                  this.performFullScan();
               } catch (Exception var5) {
               } finally {
                  this.isScanning.set(false);
                  this.firstScanComplete = true;
               }

            });
         } else {
            this.performFullScan();
            this.isScanning.set(false);
            this.firstScanComplete = true;
         }
      }

   }

   private void scheduleIncrementalScan(ChunkPos centerChunk) {
      if (this.mc.world != null && this.mc.player != null && !this.isScanning.get()) {
         this.isScanning.set(true);
         if ((Boolean)this.useThreading.get() && this.threadPool != null && !this.threadPool.isShutdown()) {
            this.threadPool.submit(() -> {
               try {
                  this.performIncrementalScan(centerChunk);
               } catch (Exception var6) {
               } finally {
                  this.isScanning.set(false);
               }

            });
         } else {
            this.performIncrementalScan(centerChunk);
            this.isScanning.set(false);
         }
      }

   }

   private void performFullScan() {
      if (this.mc.world != null && this.mc.player != null) {
         ChunkPos playerChunkPos = this.mc.player.getChunkPos();
         int radius = (Integer)this.chunkRadius.get();
         Set<BlockPos> newLightPositions = new HashSet();

         for(int chunkX = ZincUtil.chunkX(playerChunkPos) - radius; chunkX <= ZincUtil.chunkX(playerChunkPos) + radius; ++chunkX) {
            for(int chunkZ = ZincUtil.chunkZ(playerChunkPos) - radius; chunkZ <= ZincUtil.chunkZ(playerChunkPos) + radius; ++chunkZ) {
               if (Thread.currentThread().isInterrupted()) {
                  return;
               }

               Set<BlockPos> chunkLights = this.scanSingleChunk(chunkX, chunkZ);
               if (chunkLights != null) {
                  newLightPositions.addAll(chunkLights);
               }

               try {
                  Thread.sleep(1L);
               } catch (InterruptedException var12) {
                  Thread.currentThread().interrupt();
                  return;
               }
            }
         }

         this.renderLock.lock();

         try {
            this.lightPositions.clear();
            this.lightPositions.addAll(newLightPositions);
            this.cleanDistantLights(playerChunkPos);
         } finally {
            this.renderLock.unlock();
         }
      }

   }

   private void performIncrementalScan(ChunkPos centerChunk) {
      if (this.mc.world != null && this.mc.player != null) {
         int radius = (Integer)this.chunkRadius.get();
         int chunkX = ZincUtil.chunkX(centerChunk) + this.currentScanChunkX;
         int chunkZ = ZincUtil.chunkZ(centerChunk) + this.currentScanChunkZ;
         Set<BlockPos> chunkLights = this.scanSingleChunk(chunkX, chunkZ);
         if (chunkLights != null) {
            this.renderLock.lock();

            try {
               this.lightPositions.removeIf((pos) -> {
                  ChunkPos lightChunk = new ChunkPos(pos);
                  return ZincUtil.chunkX(lightChunk) == chunkX && ZincUtil.chunkZ(lightChunk) == chunkZ;
               });
               this.lightPositions.addAll(chunkLights);
               this.cleanDistantLights(centerChunk);
            } finally {
               this.renderLock.unlock();
            }
         }

         ++this.currentScanChunkX;
         if (this.currentScanChunkX > radius) {
            this.currentScanChunkX = -radius;
            ++this.currentScanChunkZ;
            if (this.currentScanChunkZ > radius) {
               this.currentScanChunkZ = -radius;
            }
         }
      }

   }

   private Set<BlockPos> scanSingleChunk(int chunkX, int chunkZ) {
      if (this.mc.world == null) {
         return null;
      } else {
         WorldChunk chunk = this.mc.world.getChunk(chunkX, chunkZ);
         if (chunk != null && !chunk.isEmpty()) {
            Set<BlockPos> chunkLights = new HashSet();

            for(int x = 0; x < 16; ++x) {
               for(int z = 0; z < 16; ++z) {
                  for(int y = (Integer)this.minY.get(); y <= (Integer)this.maxY.get(); ++y) {
                     BlockPos pos = new BlockPos(chunkX * 16 + x, y, chunkZ * 16 + z);
                     int blockLight = this.mc.world.getLightLevel(LightType.BLOCK, pos);
                     int skyLight = this.mc.world.getLightLevel(LightType.SKY, pos);
                     if (blockLight >= (Integer)this.minLightLevel.get() && blockLight > skyLight) {
                        chunkLights.add(pos);
                     }
                  }
               }
            }

            return chunkLights;
         } else {
            return Collections.emptySet();
         }
      }
   }

   private void cleanDistantLights(ChunkPos playerChunkPos) {
      if ((Integer)this.fadeDistance.get() == 0) {
         this.lightPositions.removeIf((pos) -> {
            ChunkPos lightChunk = new ChunkPos(pos);
            int chunkDistance = Math.max(Math.abs(ZincUtil.chunkX(lightChunk) - ZincUtil.chunkX(playerChunkPos)), Math.abs(ZincUtil.chunkZ(lightChunk) - ZincUtil.chunkZ(playerChunkPos)));
            return chunkDistance > (Integer)this.chunkRadius.get();
         });
      } else {
         this.lightPositions.removeIf((pos) -> {
            ChunkPos lightChunk = new ChunkPos(pos);
            int chunkDistance = Math.max(Math.abs(ZincUtil.chunkX(lightChunk) - ZincUtil.chunkX(playerChunkPos)), Math.abs(ZincUtil.chunkZ(lightChunk) - ZincUtil.chunkZ(playerChunkPos)));
            return chunkDistance > (Integer)this.fadeDistance.get();
         });
      }

   }

   private void updateRenderPositions() {
      this.renderLock.lock();

      try {
         this.lightPositionsToRender.clear();
         this.lightPositionsToRender.addAll(this.lightPositions);
      } finally {
         this.renderLock.unlock();
      }

   }

   private void renderLights(Render3DEvent event, ChunkPos playerChunkPos) {
      if (!this.lightPositionsToRender.isEmpty()) {
         Set<BlockPos> positionsToRender = new HashSet(this.lightPositionsToRender);

         for(BlockPos pos : positionsToRender) {
            if (this.mc.world == null) {
               return;
            }

            ChunkPos lightChunk = new ChunkPos(pos);
            int chunkDistance = Math.max(Math.abs(ZincUtil.chunkX(lightChunk) - ZincUtil.chunkX(playerChunkPos)), Math.abs(ZincUtil.chunkZ(lightChunk) - ZincUtil.chunkZ(playerChunkPos)));
            if (chunkDistance <= (Integer)this.fadeDistance.get()) {
               int lightLevel = this.mc.world.getLightLevel(LightType.BLOCK, pos);
               if (lightLevel >= 15 || this.shouldRenderBlock(pos, positionsToRender)) {
                  float[] thermal = this.getThermalColor(lightLevel);
                  float alphaMultiplier = 1.0F;
                  if ((Integer)this.fadeDistance.get() > 0 && chunkDistance > (Integer)this.chunkRadius.get()) {
                     float fadeStart = (float)(Integer)this.chunkRadius.get();
                     float fadeEnd = (float)(Integer)this.fadeDistance.get();
                     float progress = ((float)chunkDistance - fadeStart) / (fadeEnd - fadeStart);
                     alphaMultiplier = 1.0F - Math.max(0.0F, Math.min(1.0F, progress));
                  }

                  alphaMultiplier = Math.max(0.3F, alphaMultiplier);
                  SettingColor sColor = new SettingColor((int)(thermal[0] * 255.0F), (int)(thermal[1] * 255.0F), (int)(thermal[2] * 255.0F), (int)(thermal[3] * 255.0F * alphaMultiplier));
                  SettingColor lColor = new SettingColor((int)(thermal[0] * 255.0F), (int)(thermal[1] * 255.0F), (int)(thermal[2] * 255.0F), (int)(255.0F * alphaMultiplier));
                  event.renderer.box(pos, sColor, lColor, (ShapeMode)this.shapeMode.get(), 0);
               }
            }
         }
      }

   }

   private boolean shouldRenderBlock(BlockPos pos, Set<BlockPos> allLights) {
      for(int dx = -1; dx <= 1; ++dx) {
         for(int dy = -1; dy <= 1; ++dy) {
            for(int dz = -1; dz <= 1; ++dz) {
               if (dx != 0 || dy != 0 || dz != 0) {
                  BlockPos neighbor = pos.add(dx, dy, dz);
                  if (!allLights.contains(neighbor)) {
                     return true;
                  }
               }
            }
         }
      }

      return false;
   }

   private float[] getThermalColor(int lightLevel) {
      float[] color = new float[4];
      if (lightLevel <= 5) {
         color[3] = 0.25F + (float)lightLevel / 5.0F * 0.25F;
      } else if (lightLevel <= 10) {
         color[3] = 0.5F + (float)(lightLevel - 5) / 5.0F * 0.35F;
      } else {
         color[3] = 0.85F + (float)(lightLevel - 10) / 5.0F * 0.15F;
      }

      color[3] = Math.max(0.3F, color[3]);
      if (lightLevel <= 5) {
         float intensity = (float)lightLevel / 5.0F;
         color[0] = intensity * 0.4F;
         color[1] = intensity * 0.2F;
         color[2] = 0.0F;
      } else if (lightLevel <= 10) {
         float intensity = (float)(lightLevel - 5) / 5.0F;
         color[0] = 0.4F + intensity * 0.6F;
         color[1] = 0.2F + intensity * 0.4F;
         color[2] = intensity * 0.2F;
      } else {
         float intensity = (float)(lightLevel - 10) / 5.0F;
         color[0] = 1.0F;
         color[1] = 0.6F + intensity * 0.4F;
         color[2] = 0.2F + intensity * 0.3F;
      }

      return color;
   }
}
